#!/bin/bash
set -e

# Sentinel CNAPP — Production Start Script
# Detects environment and starts the right services.

# ── Configuration ──
SCAN_MODE="${SCAN_MODE:-auto}"  # auto | real | mock
PORT="${PORT:-3000}"
SCANNER_PORT="${SCANNER_PORT:-3030}"
MOTO_PORT="${MOTO_PORT:-5000}"

PROJECT_DIR="${PROJECT_DIR:-$(cd "$(dirname "$0")" && pwd)}"
SCANNER_DIR="$PROJECT_DIR/mini-services/scanner"
DB_DIR="$PROJECT_DIR/db"
mkdir -p "$DB_DIR"

echo "============================================"
echo "  Sentinel CNAPP — Starting"
echo "  Mode: $SCAN_MODE"
echo "  Port: $PORT"
echo "============================================"

# ── Determine scan mode ──
if [ "$SCAN_MODE" = "auto" ]; then
  if [ -n "$AWS_ACCESS_KEY_ID" ] && [ "$AWS_ACCESS_KEY_ID" != "test" ]; then
    SCAN_MODE="real"
    echo "[start] Real AWS credentials detected → PRODUCTION MODE"
  elif [ -n "$AWS_ROLE_ARN" ]; then
    SCAN_MODE="real"
    echo "[start] AWS_ROLE_ARN detected → PRODUCTION MODE (cross-account)"
  else
    SCAN_MODE="mock"
    echo "[start] No AWS credentials → MOCK MODE (moto emulator)"
  fi
fi

# ── Start moto (only in mock mode) ──
if [ "$SCAN_MODE" = "mock" ]; then
  echo "[start] Starting moto (AWS emulator) on port $MOTO_PORT..."
  cd "$SCANNER_DIR"
  python3 -m moto.server -p $MOTO_PORT -H 127.0.0.1 &
  MOTO_PID=$!
  sleep 5

  echo "[start] Provisioning mock AWS resources..."
  AWS_ENDPOINT_URL=http://127.0.0.1:$MOTO_PORT python3 provision.py || true
  AWS_ENDPOINT_URL=http://127.0.0.1:$MOTO_PORT python3 provision_v2.py || true

  export AWS_ENDPOINT_URL=http://127.0.0.1:$MOTO_PORT
  export AWS_ACCESS_KEY_ID=test
  export AWS_SECRET_ACCESS_KEY=test
else
  echo "[start] PRODUCTION MODE — connecting to real AWS"
  # In production mode, do NOT set AWS_ENDPOINT_URL
  # boto3 will connect to real AWS endpoints
  unset AWS_ENDPOINT_URL 2>/dev/null || true
fi

# ── Start scanner service ──
echo "[start] Starting FastAPI scanner on port $SCANNER_PORT..."
cd "$SCANNER_DIR"
python3 -m uvicorn main:app --host 127.0.0.1 --port $SCANNER_PORT --workers 1 &
SCANNER_PID=$!
sleep 3

# ── Seed database ──
echo "[start] Seeding database..."
cd "$PROJECT_DIR"
python3 scripts/seed_db.py 2>/dev/null || true

# ── Start Next.js ──
echo "[start] Starting Next.js on port $PORT..."
if [ "$NODE_ENV" = "production" ]; then
  exec npx next start -p $PORT -H 0.0.0.0
else
  exec npx next dev -p $PORT
fi
