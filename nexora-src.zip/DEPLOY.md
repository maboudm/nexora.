# Nexora — Deploy Guide (Fly.io رایگان)

## پیش‌نیازها

1. **GitHub حساب** (رایگان در github.com)
2. **ترمینال** (Linux, Mac, یا Windows PowerShell)
3. **۵ دقیقه زمان**

---

## مراحل Deploy

### مرحله ۱: نصب Fly CLI

```bash
# Linux / Mac / WSL:
curl -L https://fly.io/install.sh | sh

# اگه مسیر پیدا نشد:
export PATH="$HOME/.fly/bin:$PATH"
```

### مرحله ۲: ثبت‌نام در Fly.io

```bash
# ثبت‌نام با GitHub:
flyctl auth signup

# یا اگه حساب داری:
flyctl auth login
```

> به صفحه GitHub می‌ره، Authorize رو بزن، تموم.
> **هیچ کارت بانکی لازم نیست.**

### مرحله ۳: دانلود پروژه

```bash
# پروژه رو دانلود کن (از ZIP که دریافت کردی)
unzip nexora-complete.zip -d nexora
cd nexora
```

> اگه ZIP نداری، فایل‌ها رو از پوشه دانلود کپی کن.

### مرحله ۴: ساخت اپ در Fly.io

```bash
flyctl launch --no-deploy
```

> این دستور می‌پرسه:
> - App name? → `nexora` (یا هر چی دوست داری)
> - Region? → `fra` (Frankfurt) یا `ams` (Amsterdam)
> - Would you like to set up a database? → `N`
> - Deploy now? → `N`

### مرحله ۵: ساخت Volume (برای دیتابیس)

```bash
flyctl volumes create sentinel_data --region fra --size 1
```

### مرحله ۶: Deploy!

```bash
flyctl deploy
```

> اولین deploy ممکنه ۳-۵ دقیقه طول بکشه.
> وقتی تموم شد، آدرس می‌ده:
> ```
> Deployment completed successfully
> https://nexora.fly.dev
> ```

### مرحله ۷: ورود به پلتفرم

مرورگر رو باز کن:
```
https://nexora.fly.dev
```

ورود:
- Email: `admin@sentinel.local`
- Password: `admin123`

---

## دستورات مفید

```bash
# مشاهده لاگ‌ها
flyctl logs

# وضعیت اپ
flyctl status

# ری‌استارت
flyctl apps restart nexora

# توقف
flyctl scale count 0

# روشن کردن دوباره
flyctl scale count 1

# حذف کامل
flyctl apps destroy nexora
```

---

## اگه ارور داد

### ارور: "Could not find Dockerfile"
```bash
# مطمئن شو Dockerfile تو پوشه اصلیه
ls Dockerfile fly.toml
```

### ارور: "volume not found"
```bash
flyctl volumes create sentinel_data --region fra --size 1
flyctl deploy
```

### ارور: "out of memory"
```bash
# در fly.toml، memory_mb رو به 512 تغییر بده
# یا پلن پولی بگیر (۳۴۴MB رایگان کافیه)
```

### ارور: "build failed"
```bash
# کش رو پاک کن
flyctl deploy --no-cache
```

---

## پس از Deploy موفق

1. به `https://YOUR-APP.fly.dev` برو
2. با `admin@sentinel.local` / `admin123` وارد شو
3. دکمه **Run Scan** رو بزن
4. ۲۸ یافته باید لود بشن
5. بین تب‌ها بگرد: Findings, Attack Graph, Compliance, Posture Score

---

## نکات مهم

- **رایگان دائمی**: Fly.io ۳ ماشین ۲۵۶MB رایگان می‌ده
- **HTTPS خودکار**: نیازی به تنظیم SSL نیست
- **دامنه رایگان**: `xxx.fly.dev` خودکار می‌سه
- **دیتابیس**: SQLite روی volume دائمی ذخیره می‌شه
- **اگه خوابید**: `auto_stop_machines = false` در fly.toml تنظیم شده

---

## مشکل؟

اگه به مشکل خوردی، این دستور رو بزن و خروجی رو بفرست:
```bash
flyctl logs --no-tail | tail -50
```
