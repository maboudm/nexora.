# Contributing to Nexora

Contributions welcome! This project aims to be the best open-source CNAPP platform.

## 🚀 Quick Start for Contributors

```bash
# Fork & clone
git clone https://github.com/YOUR_USERNAME/nexora.git
cd nexora

# Backend setup
cd backend
python3.12 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install prowler checkov
cd ..

# Frontend setup
npm install

# Run both (in separate terminals)
cd backend && python -m uvicorn gateway.app:app --reload --port 8000
npm run dev  # in another terminal

# Open http://localhost:3000
# Login: admin@nexora.io / admin123
```

## 📋 Development Workflow

1. **Fork** the repo
2. **Create a branch**: `git checkout -b feature/amazing-feature`
3. **Make changes** (follow code style below)
4. **Test**: `python scripts/validate_all.sh`
5. **Commit**: `git commit -m 'feat: add amazing feature'`
6. **Push**: `git push origin feature/amazing-feature`
7. **Open Pull Request**

## 🎨 Code Style

### Python
- **Formatter**: Black (line length 100)
- **Imports**: isort
- **Linter**: flake8
- **Type hints**: Required on all public functions

```bash
# Auto-format
black backend/
isort backend/
flake8 backend/
```

### TypeScript
- **Formatter**: Prettier
- **Linter**: ESLint
- **Types**: Strict mode (no `any`)

```bash
npx prettier --write src/
npx eslint src/ --fix
```

### Commit Messages

Follow [Conventional Commits](https://conventionalcommits.org/):

```
feat: add new security check for AWS Lambda
fix: resolve drift detection false positive
docs: update deployment guide
refactor: simplify billing tier logic
test: add load test for 50 concurrent users
chore: upgrade dependencies
```

## 🧪 Testing

```bash
# Run all tests
python scripts/validate_all.sh

# Run specific engine test
python scripts/validate_phase7.py
python scripts/validate_phase8_prowler.py
python scripts/proof_scan_triggers_all_features.py

# Load test
python scripts/load_test.py

# Type check
npx tsc --noEmit
```

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────┐
│              Next.js Frontend (port 3000)            │
│  20 tabs: Dashboard, Findings, Attack Graph,         │
│  Premium Features, Billing, Schedules, etc.          │
└──────────────────────┬──────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────┐
│           FastAPI Gateway (port 8000)                │
│  188 routes: Auth, Scans, Billing, SSO, Prowler,     │
│  Checkov, 6 premium features, Scheduler              │
└──────────────────────┬──────────────────────────────┘
                       │
       ┌───────────────┼───────────────┐
       │               │               │
┌──────▼──────┐ ┌──────▼──────┐ ┌──────▼──────┐
│  Scanners   │ │   Rules     │ │  Premium    │
│             │ │             │ │  Engines    │
│ • Prowler   │ │ • 58 CIS    │ │ • Drift     │
│ • Checkov   │ │ • Bayesian  │ │ • Evidence  │
│ • boto3     │ │ • Economics │ │ • Workflow  │
└─────────────┘ └─────────────┘ └─────────────┘
```

## ➕ Adding a New Security Check

1. **Native rule** (for CIS-style checks):
   - Add to `backend/rule_engine/cis_rules.py` or `extended_rules.py`
   - Follow the DSL format

2. **Prowler-based** (preferred — 915 checks available):
   - Already integrated, just call `/v1/prowler/scan`

3. **Checkov-based** (for IaC):
   - Already integrated, just call `/v1/checkov/scan-code`

## ➕ Adding a New Compliance Framework

1. Add framework definition to `backend/compliance_engine/engine.py`
2. Map controls to rule_ids
3. Add tests in `scripts/validate_all.sh`

## ➕ Adding a New Cloud Provider

1. Create `backend/scanner_engine/<provider>_scanner.py`
2. Implement scan function returning assets + findings
3. Add route in `backend/gateway/app.py`
4. Add tests

## 🐛 Reporting Bugs

Open a [GitHub Issue](https://github.com/yourusername/nexora/issues) with:

- **Description**: What happened?
- **Steps to reproduce**: Detailed steps
- **Expected behavior**: What should have happened?
- **Actual behavior**: What actually happened
- **Screenshots**: If applicable
- **Environment**: OS, Python version, Node version, browser

## 💡 Requesting Features

Open a [GitHub Issue](https://github.com/yourusername/nexora/issues) with:

- **Use case**: What problem does this solve?
- **Proposed solution**: How would you like it to work?
- **Alternatives considered**: What else did you think about?

## 📜 License

By contributing, you agree that your contributions will be licensed under the Apache License 2.0.

## 🙏 Recognition

Contributors will be added to:
- `CONTRIBUTORS.md` file
- Release notes
- README acknowledgment section

Thank you for helping make cloud security accessible to everyone! 🛡️
