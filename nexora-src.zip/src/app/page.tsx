"use client";

import { useEffect, useState, useCallback } from "react";
import { LoginScreen } from "@/components/dashboard/login-screen";
import { Dashboard } from "@/components/dashboard/dashboard";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Topbar } from "@/components/dashboard/topbar";
import { FindingsTable } from "@/components/dashboard/findings-table";
import { AttackGraph } from "@/components/dashboard/attack-graph";
import { RulesPanel } from "@/components/dashboard/rules-panel";
import { SettingsPanel } from "@/components/dashboard/settings-panel";
import { ResourcesPanel } from "@/components/dashboard/resources-panel";
import { ScanHistoryPanel } from "@/components/dashboard/scan-history-panel";
import { PosturePanel } from "@/components/dashboard/posture-panel";
import { CompliancePanel } from "@/components/dashboard/compliance-panel";
import { RemediationsPanel } from "@/components/dashboard/remediations-panel";
import { AuditPanel } from "@/components/dashboard/audit-panel";
import { UsersPanel } from "@/components/dashboard/users-panel";
import { AdminPanel } from "@/components/dashboard/admin-panel";
import { PostureDashboard } from "@/components/dashboard/posture-dashboard";
import { DetectionDashboard } from "@/components/dashboard/detection-dashboard";
import { ThreatIntelDashboard } from "@/components/dashboard/threat-intel-dashboard";
import { SecurityEnginesDashboard } from "@/components/dashboard/security-engines-dashboard";
import { ReportingDashboard } from "@/components/dashboard/reporting-dashboard";
import { LiveAlertsBanner } from "@/components/dashboard/live-alerts-banner";
import { gateway, scanDetailToScanResult, type User, type ScanDetail } from "@/lib/gateway";
import type { ScanResult } from "@/lib/scanner";

type Tab = "dashboard" | "posture" | "findings" | "graph" | "resources" |
           "remediations" | "compliance" | "history" | "audit" | "users" |
           "admin" | "rules" | "settings" |
           "detection" | "threat-intel" | "security-engines" | "reports";

interface UserInfo {
  id: string;
  email: string;
  name: string;
  role: string;
}

export default function Home() {
  const [authed, setAuthed] = useState(false);
  const [user, setUser] = useState<UserInfo | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [scanning, setScanning] = useState(false);
  const [currentScanId, setCurrentScanId] = useState<string | null>(null);
  const [gatewayStatus, setGatewayStatus] = useState<"up" | "down" | "checking">("checking");
  const [error, setError] = useState<string | null>(null);

  // Auth check on mount
  useEffect(() => {
    if (gateway.isAuthenticated()) {
      const u = gateway.getUser();
      if (u) {
        setUser({
          id: u.user_id,
          email: u.email,
          name: u.name,
          role: u.role,
        });
        setAuthed(true);
        // Load latest scan
        loadLatestScan();
      }
    }
    setAuthChecked(true);
  }, []);

  const loadLatestScan = async () => {
    try {
      const scans = await gateway.listScans(1);
      if (scans.length > 0 && scans[0].status === "completed") {
        const detail = await gateway.getScan(scans[0].scan_id);
        setScanResult(scanDetailToScanResult(detail));
      }
    } catch (e) {
      console.warn("Failed to load latest scan:", e);
    }
  };

  // Gateway health — uses proxy which auto-starts gateway
  const checkHealth = useCallback(async () => {
    try {
      const res = await fetch("/api/gateway-health", { cache: "no-store" });
      if (res.ok) {
        const data = await res.json();
        setGatewayStatus(data.status === "healthy" || data.gateway_up ? "up" : "down");
      } else {
        setGatewayStatus("down");
      }
    } catch {
      setGatewayStatus("down");
    }
  }, []);

  useEffect(() => {
    checkHealth();
    const id = setInterval(checkHealth, 30000);
    return () => clearInterval(id);
  }, [checkHealth]);

  // Run scan via gateway
  const runScan = useCallback(async () => {
    if (!gateway.isAuthenticated()) return;
    setScanning(true);
    setError(null);
    setScanResult(null);
    try {
      // Get first cloud account
      const accounts = await gateway.listCloudAccounts();
      if (accounts.length === 0) {
        throw new Error("No cloud accounts configured. Add one in Settings.");
      }
      const account = accounts[0];
      // Trigger scan
      const { scan_id } = await gateway.triggerScan(account.account_id, ["iam", "s3", "sg", "eks"]);
      setCurrentScanId(scan_id);

      // Poll until done (max 30s)
      const detail: ScanDetail = await gateway.pollScanUntilDone(scan_id, 30000, 1000);
      if (detail.status === "failed") {
        throw new Error(detail.error || "Scan failed");
      }
      setScanResult(scanDetailToScanResult(detail));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Scan failed");
    } finally {
      setScanning(false);
    }
  }, []);

  // Login handler — calls gateway via LoginScreen which passes token
  const handleLogin = async (token: string, userInfo: UserInfo) => {
    // LoginScreen has already authenticated with the gateway and received a token.
    // We need to manually set it on the gateway client.
    // The gateway.login() was called inside LoginScreen via direct fetch.
    // Store the token in the gateway client's localStorage.
    if (typeof window !== "undefined") {
      localStorage.setItem("gateway_token", token);
      // Re-fetch user from gateway to populate the client
      try {
        const gatewayUrl = process.env.NEXT_PUBLIC_GATEWAY_URL ||
          window.location.origin.replace(/:\d+$/, ":8000");
        const resp = await fetch(`${gatewayUrl}/v1/auth/me`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (resp.ok) {
          const data = await resp.json();
          localStorage.setItem("gateway_user", JSON.stringify(data));
          gateway.token = token;
          gateway.user = data;
          setUser({
            id: data.user_id,
            email: data.email,
            name: data.name,
            role: data.role,
          });
          setAuthed(true);
          loadLatestScan();
          return;
        }
      } catch (e) {
        console.error("Failed to fetch user after login:", e);
      }
    }
    // Fallback
    setUser(userInfo);
    setAuthed(true);
  };

  const handleLogout = () => {
    gateway.logout();
    setAuthed(false);
    setUser(null);
    setScanResult(null);
  };

  if (!authChecked) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-primary/30 border-t-primary" />
      </div>
    );
  }

  if (!authed || !user) {
    return <LoginScreen onLogin={handleLogin} scannerStatus={gatewayStatus} />;
  }

  const tabs: { id: Tab; label: string; icon: string; adminOnly?: boolean }[] = [
    { id: "dashboard", label: "Overview", icon: "LayoutDashboard" },
    { id: "posture", label: "Posture Score", icon: "TrendingUp" },
    { id: "findings", label: "Findings", icon: "ShieldAlert" },
    { id: "graph", label: "Attack Graph", icon: "Network" },
    { id: "resources", label: "Resources", icon: "Boxes" },
    { id: "remediations", label: "Remediations", icon: "Wrench" },
    { id: "compliance", label: "Compliance", icon: "ShieldCheck" },
    { id: "detection", label: "Real-time Alerts", icon: "Activity" },
    { id: "threat-intel", label: "Threat Intel", icon: "Globe" },
    { id: "security-engines", label: "Security Engines", icon: "Zap" },
    { id: "reports", label: "Reports", icon: "FileText" },
    { id: "history", label: "Scan History", icon: "History" },
    { id: "audit", label: "Audit Log", icon: "ScrollText" },
    { id: "users", label: "Users", icon: "Users" },
    { id: "admin", label: "Admin", icon: "Settings", adminOnly: true },
    { id: "rules", label: "Rules", icon: "BookOpen" },
    { id: "settings", label: "Settings", icon: "Settings" },
  ].filter((t) => !t.adminOnly || user.role === "admin" || user.role === "owner") as { id: Tab; label: string; icon: string }[];

  return (
    <div className="min-h-screen flex bg-background text-foreground">
      <LiveAlertsBanner token={gateway.getToken()} />
      <Sidebar
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={(t) => setActiveTab(t as Tab)}
        scannerStatus={gatewayStatus}
        user={user}
        onLogout={handleLogout}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <Topbar
          scanResult={scanResult}
          scanning={scanning}
          onRunScan={runScan}
          scannerStatus={gatewayStatus}
          user={user}
        />

        <main className="flex-1 overflow-auto p-6">
          {error && (
            <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-700 dark:text-red-300">
              <strong className="font-semibold">Error:</strong> {error}
              <button onClick={runScan} className="ml-3 underline hover:no-underline">Retry</button>
            </div>
          )}

          {!scanResult && !scanning && !error && activeTab === "dashboard" && (
            <div className="flex flex-col items-center justify-center py-20 text-center max-w-md mx-auto">
              <h2 className="text-lg font-semibold">No scan yet</h2>
              <p className="text-sm text-muted-foreground mt-2">
                Click <span className="font-medium text-foreground">Run Scan</span> to scan your cloud account
                through the gateway. The scanner will discover resources, evaluate CIS rules,
                build the attack graph, and assess compliance.
              </p>
              <button onClick={runScan} disabled={gatewayStatus === "down"}
                className="mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
                Run First Scan
              </button>
            </div>
          )}

          {scanning && (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="h-10 w-10 animate-spin rounded-full border-2 border-primary/30 border-t-primary" />
              <p className="mt-3 text-sm text-muted-foreground">
                Scanning through gateway… {currentScanId && (
                  <span className="font-mono text-xs">(scan: {currentScanId.slice(0, 8)}…)</span>
                )}
              </p>
            </div>
          )}

          {scanResult && (
            <>
              {activeTab === "dashboard" && <Dashboard scanResult={scanResult} onNavigate={(t) => setActiveTab(t as Tab)} />}
              {activeTab === "findings" && <FindingsTable scanResult={scanResult} />}
              {activeTab === "graph" && <AttackGraph scanResult={scanResult} />}
              {activeTab === "resources" && <ResourcesPanel scanResult={scanResult} />}
              {activeTab === "history" && <ScanHistoryPanel token={gateway.getToken() || ""} onRescanComplete={setScanResult} />}
              {activeTab === "rules" && <RulesPanel token={gateway.getToken() || ""} />}
              {activeTab === "settings" && <SettingsPanel scannerStatus={gatewayStatus} onRunScan={runScan} user={user} />}
            </>
          )}

          {/* Tabs that don't require a scan result */}
          {activeTab === "posture" && <PostureDashboard token={gateway.getToken() || ""} />}
          {activeTab === "detection" && <DetectionDashboard token={gateway.getToken() || ""} />}
          {activeTab === "threat-intel" && <ThreatIntelDashboard token={gateway.getToken() || ""} />}
          {activeTab === "security-engines" && <SecurityEnginesDashboard token={gateway.getToken() || ""} />}
          {activeTab === "reports" && <ReportingDashboard token={gateway.getToken() || ""} />}
          {activeTab === "remediations" && <RemediationsPanel token={gateway.getToken() || ""} />}
          {activeTab === "compliance" && <CompliancePanel token={gateway.getToken() || ""} />}
          {activeTab === "audit" && <AuditPanel token={gateway.getToken() || ""} />}
          {activeTab === "users" && <UsersPanel token={gateway.getToken() || ""} user={user} />}
          {activeTab === "admin" && (user.role === "admin" || user.role === "owner") && <AdminPanel token={gateway.getToken() || ""} user={user} />}
        </main>

        <footer className="border-t border-border/60 px-6 py-3 text-xs text-muted-foreground">
          Nexora · FastAPI Gateway · Multi-tenant · Hash-chained Audit ·{" "}
          <span className="font-mono">{scanResult ? `${scanResult.summary.total_findings} findings` : "no scan yet"}</span>
        </footer>
      </div>
    </div>
  );
}
