"use client";

import { useState, useEffect } from "react";
import {
  ShieldCheck, Zap, TrendingUp, GitBranch, FileLock, Workflow,
  Building2, Check, ArrowRight, Star, BarChart3, Cloud, Lock,
  Github, Twitter, AlertCircle, Sparkles,
} from "lucide-react";
import Link from "next/link";

interface Tier {
  tier_id: string;
  name: string;
  price_monthly: number;
  price_yearly: number;
  features: string[];
  description: string;
  limits: Record<string, any>;
}

export default function LandingPage() {
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  useEffect(() => {
    fetch("/api/gateway-proxy/v1/billing/tiers")
      .then(r => r.json())
      .then(data => setTiers(data))
      .catch(() => {});
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center">
              <ShieldCheck className="h-5 w-5 text-primary" />
            </div>
            <span className="font-bold text-lg">Sentinel</span>
            <span className="text-xs px-1.5 py-0.5 rounded bg-primary/10 text-primary font-mono">CNAPP</span>
          </div>
          <nav className="flex items-center gap-6 text-sm">
            <a href="#features" className="text-muted-foreground hover:text-foreground">Features</a>
            <a href="#pricing" className="text-muted-foreground hover:text-foreground">Pricing</a>
            <a href="#comparison" className="text-muted-foreground hover:text-foreground">vs Wiz</a>
            <a href="#faq" className="text-muted-foreground hover:text-foreground">FAQ</a>
            <Link href="/" className="px-4 py-1.5 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90">
              Sign in
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-xs font-medium text-primary mb-6">
            <Sparkles className="h-3 w-3" />
            2,064 security checks • AWS + Azure + GCP • Open-source
          </div>
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
            Cloud security that
            <span className="block bg-gradient-to-r from-primary to-purple-500 bg-clip-text text-transparent">
              doesn't cost $30K/year
            </span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Sentinel scans your AWS, Azure, and GCP accounts for 2,064 security misconfigurations —
            then tells you which finding to fix first using attack path analysis and economic ROI.
          </p>
          <div className="flex items-center justify-center gap-4">
            <Link href="/" className="px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 flex items-center gap-2">
              Start free <ArrowRight className="h-4 w-4" />
            </Link>
            <a href="#pricing" className="px-6 py-3 border border-border rounded-lg font-medium hover:bg-accent">
              See pricing
            </a>
          </div>
          <p className="text-xs text-muted-foreground mt-4">
            No credit card required • 1 cloud account free forever • Cancel anytime
          </p>
        </div>
      </section>

      {/* Stats bar */}
      <section className="border-y border-border bg-muted/30 py-12">
        <div className="max-w-6xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <div className="text-4xl font-bold text-primary">2,064</div>
            <div className="text-sm text-muted-foreground mt-1">Security checks</div>
          </div>
          <div>
            <div className="text-4xl font-bold text-primary">3</div>
            <div className="text-sm text-muted-foreground mt-1">Cloud providers</div>
          </div>
          <div>
            <div className="text-4xl font-bold text-primary">48</div>
            <div className="text-sm text-muted-foreground mt-1">Compliance frameworks</div>
          </div>
          <div>
            <div className="text-4xl font-bold text-primary">$0</div>
            <div className="text-sm text-muted-foreground mt-1">to start</div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Everything Wiz does, at 1% of the price</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We absorbed Prowler (915 checks) and Checkov (1,149 policies) as our scanning backbone,
              then built the platform layer on top — drift detection, attack paths, evidence vault,
              workflow integration, and more.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Feature
              icon={Zap}
              title="2,064 security checks"
              desc="Prowler's 915 cloud checks + Checkov's 1,149 IaC policies. Covers CIS, PCI-DSS, HIPAA, ISO 27001, SOC2, NIST, GDPR, and more."
            />
            <Feature
              icon={GitBranch}
              title="Attack path visualization"
              desc="See how attackers chain risks to reach your crown jewels. Mapped to MITRE ATT&CK Enterprise Matrix with probability scoring."
            />
            <Feature
              icon={TrendingUp}
              title="Risk-based prioritization"
              desc="Not all findings matter equally. We combine CVSS + EPSS + asset criticality + threat intel to tell you which to fix first."
            />
            <Feature
              icon={FileLock}
              title="Evidence vault"
              desc="Hash-chained, tamper-evident evidence for SOC2/ISO auditors. Prove control X was enforced at time Y."
            />
            <Feature
              icon={Workflow}
              title="Workflow integration"
              desc="Auto-create Jira/Slack/ServiceNow tickets for critical findings. Bidirectional sync — close ticket, resolve finding."
            />
            <Feature
              icon={Building2}
              title="Multi-account discovery"
              desc="Connect your AWS Organizations management account. We auto-discover all member accounts and rollup posture across the org."
            />
            <Feature
              icon={Cloud}
              title="Continuous monitoring"
              desc="Scheduled scans (daily/weekly/monthly) with email alerts. Get notified when critical findings appear."
            />
            <Feature
              icon={Lock}
              title="SSO & SAML"
              desc="Google OAuth + SAML for Okta/Azure AD. IT teams approve in 1 day, not 2 weeks."
            />
            <Feature
              icon={BarChart3}
              title="Posture scoring"
              desc="Multi-factor KPI: compliance (25%) + vulnerability (20%) + exposure (20%) + identity (15%) + data (10%) + detection (10%)."
            />
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Simple, transparent pricing</h2>
            <p className="text-muted-foreground">Start free, upgrade when you need more.</p>
            <div className="flex items-center justify-center gap-3 mt-6">
              <button
                onClick={() => setBillingCycle("monthly")}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium ${billingCycle === "monthly" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingCycle("yearly")}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium flex items-center gap-2 ${billingCycle === "yearly" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
              >
                Yearly <span className="text-xs px-1.5 py-0.5 rounded bg-green-500/20 text-green-400">2 months free</span>
              </button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {tiers.filter(t => t.tier_id !== "enterprise").map(tier => {
              const price = billingCycle === "monthly" ? tier.price_monthly : tier.price_yearly;
              const monthlyEq = billingCycle === "yearly" && price > 0 ? Math.round(price / 12 / 100) : price / 100;
              const isPopular = tier.tier_id === "team";
              return (
                <div
                  key={tier.tier_id}
                  className={`relative bg-background border rounded-xl p-5 flex flex-col ${isPopular ? "border-primary shadow-lg shadow-primary/10" : "border-border"}`}
                >
                  {isPopular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-primary text-primary-foreground text-xs font-bold rounded-full flex items-center gap-1">
                      <Star className="h-3 w-3" /> Most Popular
                    </div>
                  )}
                  <h3 className="text-lg font-bold">{tier.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1 mb-4">{tier.description}</p>
                  <div className="mb-4">
                    {price === 0 ? (
                      <div className="text-3xl font-bold">Free</div>
                    ) : (
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-bold">${monthlyEq}</span>
                        <span className="text-sm text-muted-foreground">/mo</span>
                      </div>
                    )}
                  </div>
                  <ul className="space-y-2 mb-5 flex-1">
                    {tier.features.slice(0, 5).map((f, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs">
                        <Check className="h-3.5 w-3.5 text-green-400 mt-0.5 shrink-0" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                  <Link
                    href="/"
                    className={`w-full py-2 rounded-lg text-sm font-medium text-center block ${isPopular ? "bg-primary text-primary-foreground hover:bg-primary/90" : "bg-background border border-border hover:bg-accent"}`}
                  >
                    {tier.tier_id === "free" ? "Start free" : "Choose " + tier.name}
                  </Link>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Comparison */}
      <section id="comparison" className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Sentinel vs the competition</h2>
            <p className="text-muted-foreground">Honest comparison — we're not for everyone.</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm border border-border rounded-lg overflow-hidden">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left p-3 font-medium">Feature</th>
                  <th className="text-center p-3 font-medium">Prowler OSS</th>
                  <th className="text-center p-3 font-medium text-primary">Sentinel</th>
                  <th className="text-center p-3 font-medium">Wiz</th>
                </tr>
              </thead>
              <tbody>
                <ComparisonRow label="Security checks" prowler="915" sentinel="2,064" wiz="300+" />
                <ComparisonRow label="IaC scanning" prowler="❌" sentinel="✅ 1,149" wiz="✅" />
                <ComparisonRow label="Web UI" prowler="❌ CLI only" sentinel="✅" wiz="✅" />
                <ComparisonRow label="Scheduled scans" prowler="❌ Manual" sentinel="✅" wiz="✅" />
                <ComparisonRow label="Email/Slack alerts" prowler="❌" sentinel="✅" wiz="✅" />
                <ComparisonRow label="Attack path analysis" prowler="❌" sentinel="✅" wiz="✅" />
                <ComparisonRow label="Risk prioritization" prowler="❌" sentinel="✅" wiz="✅" />
                <ComparisonRow label="Evidence vault" prowler="❌" sentinel="✅" wiz="✅" />
                <ComparisonRow label="Multi-tenant SaaS" prowler="❌" sentinel="✅" wiz="✅" />
                <ComparisonRow label="SSO/SAML" prowler="❌" sentinel="✅" wiz="✅" />
                <ComparisonRow label="Agentless scanning" prowler="❌" sentinel="❌" wiz="✅" highlight />
                <ComparisonRow label="Real-time monitoring" prowler="❌" sentinel="❌" wiz="✅" highlight />
                <ComparisonRow label="SOC2/ISO certified" prowler="❌" sentinel="❌" wiz="✅" highlight />
                <ComparisonRow label="24/7 support" prowler="Community" sentinel="Community" wiz="✅" highlight />
                <ComparisonRow label="Price/mo" prowler="Free" sentinel="$0-299" wiz="$3,000-8,000" />
              </tbody>
            </table>
          </div>
          <div className="mt-6 p-4 bg-muted/30 border border-border rounded-lg text-sm text-muted-foreground">
            <AlertCircle className="h-4 w-4 inline mr-2" />
            <strong>Honest take:</strong> Use Wiz if you're an enterprise with compliance requirements and $30K+ budget.
            Use Sentinel if you want 90% of the value at 1% of the price. Use Prowler OSS if you're a CLI wizard who doesn't need a UI.
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-20 px-6 bg-muted/30">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center">Frequently asked questions</h2>
          <div className="space-y-4">
            <FAQItem q="Is the Free tier really free forever?" a="Yes. 1 cloud account, 5 scans per month, all 2,064 security checks. Not a trial — permanent free tier." />
            <FAQItem q="Do I need a credit card to start?" a="No. The Free tier requires no payment. You only need a credit card when upgrading to Pro or higher." />
            <FAQItem q="How is this different from Prowler?" a="Prowler is a CLI tool — Sentinel is a full SaaS platform with UI, scheduled scans, attack paths, evidence vault, and multi-tenant support. We use Prowler's 915 checks as our scanning backbone." />
            <FAQItem q="How is this different from Wiz?" a="Wiz is $30K-100K/year with agentless scanning, real-time monitoring, and SOC2. Sentinel is $29-299/month and covers the same 2,064+ checks but without those enterprise features." />
            <FAQItem q="Can I cancel anytime?" a="Yes. One-click cancel. You keep access until end of billing period, then downgrade to Free automatically." />
            <FAQItem q="Is my data secure?" a="Yes. JWT auth, multi-tenant isolation, hash-chained audit logs, SQLite WAL mode. All credentials encrypted at rest. No card data touches our servers (Stripe handles payments)." />
            <FAQItem q="Do you support Azure and GCP?" a="Yes. Prowler has 190 Azure checks + 109 GCP checks. We support all three clouds from one platform." />
            <FAQItem q="Can I self-host?" a="Yes. Sentinel is Apache 2.0 licensed. The Enterprise tier includes on-prem deployment with dedicated support." />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Start securing your cloud in 3 minutes</h2>
          <p className="text-muted-foreground mb-8">
            Connect your AWS account, run your first scan, see 2,064 security findings — all in 3 minutes.
          </p>
          <Link href="/" className="inline-flex items-center gap-2 px-8 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90">
            Start free <ArrowRight className="h-4 w-4" />
          </Link>
          <p className="text-xs text-muted-foreground mt-4">No credit card • Cancel anytime</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded bg-primary/15 flex items-center justify-center">
              <ShieldCheck className="h-4 w-4 text-primary" />
            </div>
            <span className="font-medium">Nexora</span>
            <span className="text-xs text-muted-foreground ml-2">Apache 2.0 Licensed</span>
          </div>
          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground flex items-center gap-1"><Github className="h-4 w-4" /> GitHub</a>
            <a href="#" className="hover:text-foreground flex items-center gap-1"><Twitter className="h-4 w-4" /> Twitter</a>
            <a href="#faq" className="hover:text-foreground">FAQ</a>
            <a href="#pricing" className="hover:text-foreground">Pricing</a>
          </div>
        </div>
        <div className="max-w-6xl mx-auto text-center mt-8 text-xs text-muted-foreground">
          © 2025 Nexora — Created by Maboud Bakhshi Nezhad. Built on Prowler + Checkov. Not affiliated with Wiz, Prisma Cloud, or Orca Security.
        </div>
      </footer>
    </div>
  );
}

function Feature({ icon: Icon, title, desc }: { icon: any; title: string; desc: string }) {
  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <div className="p-2 bg-primary/10 rounded-lg w-fit mb-3">
        <Icon className="h-5 w-5 text-primary" />
      </div>
      <h3 className="font-semibold mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground">{desc}</p>
    </div>
  );
}

function ComparisonRow({ label, prowler, sentinel, wiz, highlight }: {
  label: string;
  prowler: string;
  sentinel: string;
  wiz: string;
  highlight?: boolean;
}) {
  return (
    <tr className={`border-t border-border ${highlight ? "bg-muted/20" : ""}`}>
      <td className="p-3">{label}</td>
      <td className="p-3 text-center text-muted-foreground">{prowler}</td>
      <td className="p-3 text-center font-medium text-primary">{sentinel}</td>
      <td className="p-3 text-center">{wiz}</td>
    </tr>
  );
}

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="bg-background border border-border rounded-lg overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center justify-between w-full p-4 text-left font-medium hover:bg-accent/30"
      >
        {q}
        <span className="text-muted-foreground">{open ? "−" : "+"}</span>
      </button>
      {open && <p className="p-4 pt-0 text-sm text-muted-foreground">{a}</p>}
    </div>
  );
}
