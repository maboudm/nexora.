import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";

/**
 * GET /api/schedules — list scheduled scans
 * POST /api/schedules — create a scheduled scan
 */
export async function GET(req: NextRequest) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const schedules = await db.scheduledScan.findMany({
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ schedules });
}

export async function POST(req: NextRequest) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const { name, cron, scanners, enabled } = body;
  if (!name || !cron) {
    return NextResponse.json({ error: "name and cron required" }, { status: 400 });
  }
  // Compute next run based on cron (simplified: just store, real cron eval in worker)
  const schedule = await db.scheduledScan.create({
    data: {
      name,
      cron,
      scanners: Array.isArray(scanners) ? scanners.join(",") : "iam,s3,sg,k8s",
      enabled: enabled !== false,
    },
  });
  return NextResponse.json({ schedule }, { status: 201 });
}
