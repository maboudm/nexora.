import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";

const RULES = [
  { rule_id: "IAM-001", title: "Overly permissive assume role policy (Principal: *)", description: "The role trust policy allows any AWS principal to assume it.", severity: "critical", category: "iam", compliance: "CIS-AWS-1.3", cvss_score: 9.8, remediation: "Restrict the Principal to specific AWS accounts, services, or roles." },
  { rule_id: "IAM-002", title: "AdministratorAccess policy attached", description: "The role has the AWS-managed AdministratorAccess policy attached.", severity: "high", category: "iam", compliance: "CIS-AWS-1.4", cvss_score: 8.5, remediation: "Replace AdministratorAccess with a least-privilege custom policy." },
  { rule_id: "IAM-003", title: "Unused IAM role (90+ days)", description: "The role has not been used in over 90 days.", severity: "low", category: "iam", compliance: "CIS-AWS-1.21", cvss_score: 3.5, remediation: "Remove the role if no longer needed." },
  { rule_id: "IAM-004", title: "Role grants S3 FullAccess to compute service", description: "Compute service role has AmazonS3FullAccess attached.", severity: "high", category: "iam", compliance: "CIS-AWS-1.16", cvss_score: 7.7, remediation: "Scope S3 permissions to specific bucket ARNs." },
  { rule_id: "S3-001", title: "S3 bucket is publicly readable", description: "Bucket ACL or policy grants READ permission to AllUsers.", severity: "critical", category: "s3", compliance: "CIS-AWS-2.1", cvss_score: 9.1, remediation: "Remove public ACL grants. Enable Block Public Access." },
  { rule_id: "S3-002", title: "S3 bucket has no server-side encryption", description: "Bucket does not have default server-side encryption configured.", severity: "medium", category: "encryption", compliance: "CIS-AWS-2.2", cvss_score: 5.3, remediation: "Enable SSE-S3 (AES256) or SSE-KMS on the bucket." },
  { rule_id: "S3-003", title: "S3 bucket versioning is not enabled", description: "Without versioning, deleted or overwritten objects cannot be recovered.", severity: "low", category: "s3", compliance: "CIS-AWS-2.3", cvss_score: 3.7, remediation: "Enable versioning and MFA delete on critical buckets." },
  { rule_id: "S3-004", title: "S3 bucket public access block is disabled", description: "Block Public Access is not enabled.", severity: "high", category: "s3", compliance: "CIS-AWS-2.4", cvss_score: 7.5, remediation: "Enable all four Block Public Access settings." },
  { rule_id: "S3-005", title: "S3 bucket access logging is not enabled", description: "Without access logging, you cannot audit who accessed objects.", severity: "medium", category: "logging", compliance: "CIS-AWS-2.6", cvss_score: 4.3, remediation: "Enable server access logging to a dedicated logging bucket." },
  { rule_id: "NET-001", title: "Security group allows SSH (port 22) from 0.0.0.0/0", description: "SSH is open to the entire internet.", severity: "critical", category: "network", compliance: "CIS-AWS-5.2", cvss_score: 9.0, remediation: "Restrict SSH to known corporate CIDR ranges or use SSM Session Manager." },
  { rule_id: "NET-002", title: "Security group allows RDP (port 3389) from 0.0.0.0/0", description: "RDP is open to the entire internet.", severity: "critical", category: "network", compliance: "CIS-AWS-5.3", cvss_score: 9.5, remediation: "Restrict RDP to specific corporate CIDR ranges." },
  { rule_id: "NET-003", title: "Security group allows database port from 0.0.0.0/0", description: "Database ports are publicly accessible.", severity: "critical", category: "network", compliance: "CIS-AWS-5.4", cvss_score: 9.4, remediation: "Database security groups should only allow ingress from application tier." },
  { rule_id: "NET-004", title: "Security group allows all egress traffic to 0.0.0.0/0", description: "Outbound traffic is unrestricted.", severity: "medium", category: "network", compliance: "CIS-AWS-5.6", cvss_score: 5.4, remediation: "Restrict egress to required destinations only." },
  { rule_id: "K8S-001", title: "EKS cluster has public API server endpoint with 0.0.0.0/0", description: "The Kubernetes API server is reachable from the internet with no IP restriction.", severity: "critical", category: "k8s", compliance: "CIS-EKS-1.1", cvss_score: 8.6, remediation: "Either set the API endpoint to private, or restrict publicAccessCidrs." },
  { rule_id: "K8S-002", title: "EKS cluster control plane logging is disabled", description: "API, audit, and authenticator logs are not being shipped to CloudWatch.", severity: "high", category: "logging", compliance: "CIS-EKS-1.2", cvss_score: 7.1, remediation: "Enable all cluster control plane log types." },
  { rule_id: "K8S-003", title: "EKS cluster secrets encryption (KMS) is not configured", description: "Kubernetes secrets stored in etcd are not encrypted.", severity: "high", category: "encryption", compliance: "CIS-EKS-1.3", cvss_score: 7.4, remediation: "Configure EncryptionConfig with a customer-managed KMS key." },
];

export async function GET(req: NextRequest) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  return NextResponse.json(RULES);
}
