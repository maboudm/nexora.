import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";

/**
 * GET /api/audit
 *   Returns the audit log (most recent 200 entries).
 */
export async function GET(req: NextRequest) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }

  const logs = await db.auditLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
    include: {
      user: { select: { id: true, name: true, email: true } },
    },
  });
  return NextResponse.json({ logs });
}

/**
 * Helper: record an audit log entry. Called by other API routes.
 */
export async function recordAudit(
  userId: string | null,
  action: string,
  resource: string | null,
  details: Record<string, unknown>,
  ipAddress?: string,
) {
  await db.auditLog.create({
    data: {
      userId,
      action,
      resource,
      details: JSON.stringify(details),
      ipAddress,
    },
  });
}
