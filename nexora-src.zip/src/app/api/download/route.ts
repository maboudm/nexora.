import { NextRequest, NextResponse } from "next/server";
import { readFile } from "fs/promises";
import path from "path";

export async function GET(req: NextRequest) {
  const file = req.nextUrl.searchParams.get("file") || "nexora-all.zip";
  const filePath = path.join("/home/z/my-project/download", file);
  
  try {
    const data = await readFile(filePath);
    const response = new NextResponse(data);
    response.headers.set("Content-Type", "application/zip");
    response.headers.set("Content-Disposition", `attachment; filename="${file}"`);
    response.headers.set("Content-Length", data.length.toString());
    return response;
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 404 });
  }
}
