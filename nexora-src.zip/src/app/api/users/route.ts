import { NextRequest, NextResponse } from "next/server";
import { requireAuth, hashPassword } from "@/lib/auth";
import { db } from "@/lib/db";

/**
 * GET /api/users
 *   List all users (admin only).
 *
 * POST /api/users
 *   Create a new user (admin only).
 */
export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req.headers.get("authorization"));
    if (payload.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const users = await db.user.findMany({
    select: { id: true, email: true, name: true, role: true, createdAt: true },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ users });
}

export async function POST(req: NextRequest) {
  try {
    const payload = requireAuth(req.headers.get("authorization"));
    if (payload.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const { email, name, password, role } = body;
  if (!email || !name || !password) {
    return NextResponse.json({ error: "email, name, password required" }, { status: 400 });
  }
  if (role && !["admin", "analyst", "viewer"].includes(role)) {
    return NextResponse.json({ error: "Invalid role" }, { status: 400 });
  }
  // Check email uniqueness
  const existing = await db.user.findUnique({ where: { email } });
  if (existing) {
    return NextResponse.json({ error: "Email already registered" }, { status: 409 });
  }
  const passwordHash = await hashPassword(password);
  const user = await db.user.create({
    data: { email, name, passwordHash, role: role || "analyst" },
    select: { id: true, email: true, name: true, role: true, createdAt: true },
  });
  return NextResponse.json({ user }, { status: 201 });
}
