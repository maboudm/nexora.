import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";
import bcrypt from "bcryptjs";
import crypto from "crypto";

/**
 * GET /api/api-keys — list API keys (without revealing the actual key)
 * POST /api/api-keys — create a new API key (returns the full key ONCE)
 */
export async function GET(req: NextRequest) {
  try {
    const payload = requireAuth(req.headers.get("authorization"));
    if (payload.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const keys = await db.apiKey.findMany({
    select: {
      id: true, name: true, keyPrefix: true, permissions: true,
      lastUsedAt: true, expiresAt: true, createdAt: true,
      user: { select: { id: true, name: true, email: true } },
    },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ apiKeys: keys });
}

export async function POST(req: NextRequest) {
  let payload;
  try {
    payload = requireAuth(req.headers.get("authorization"));
    if (payload.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const { name, permissions, expiresAt } = body;
  if (!name) {
    return NextResponse.json({ error: "name required" }, { status: 400 });
  }
  // Generate a random API key
  const rawKey = `sk-${crypto.randomBytes(24).toString("hex")}`;
  const keyHash = bcrypt.hashSync(rawKey, 10);
  const keyPrefix = rawKey.slice(0, 11); // "sk-" + 8 chars

  const apiKey = await db.apiKey.create({
    data: {
      name,
      keyHash,
      keyPrefix,
      userId: payload.sub,
      permissions: permissions || "read",
      expiresAt: expiresAt ? new Date(expiresAt) : null,
    },
    select: {
      id: true, name: true, keyPrefix: true, permissions: true, createdAt: true,
    },
  });
  // Return the full key ONCE
  return NextResponse.json({ apiKey, key: rawKey }, { status: 201 });
}
