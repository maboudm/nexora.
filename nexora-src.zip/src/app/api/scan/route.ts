import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";

/**
 * POST /api/scan
 *   Triggers a "scan" — in this self-contained mode, it creates a new Scan
 *   record that references the latest finding data from the DB.
 *   When deployed with real AWS, this would call the FastAPI scanner service.
 */
export async function POST(req: NextRequest) {
  let userId: string;
  try {
    const payload = requireAuth(req.headers.get("authorization"));
    userId = payload.sub;
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const scanners = Array.isArray(body.scanners) && body.scanners.length > 0
      ? body.scanners : ["iam", "s3", "sg", "k8s"];

    // Get or create cloud account
    let account = await db.cloudAccount.findFirst();
    if (!account) {
      account = await db.cloudAccount.create({
        data: { provider: "aws", accountId: "123456789012", alias: "default", region: "us-east-1", scanMode: "real" },
      });
    }

    // Get the latest completed scan to copy its findings
    const latestScan = await db.scan.findFirst({
      where: { status: "completed" },
      orderBy: { createdAt: "desc" },
      include: { findings: true, resources: true },
    });

    if (!latestScan) {
      return NextResponse.json({ error: "No baseline scan data available" }, { status: 404 });
    }

    // Create a new scan record
    const newScan = await db.scan.create({
      data: {
        taskId: `local-${Date.now()}`,
        status: "completed",
        triggeredById: userId,
        accountId: account.id,
        scannerTypes: scanners.join(","),
        startedAt: new Date(),
        completedAt: new Date(),
        durationMs: 500 + Math.floor(Math.random() * 500),
        findingsCount: latestScan.findingsCount,
        criticalCount: latestScan.criticalCount,
        highCount: latestScan.highCount,
        mediumCount: latestScan.mediumCount,
        lowCount: latestScan.lowCount,
        postureScore: latestScan.postureScore,
      },
    });

    // Copy findings and resources from the latest scan
    for (const resource of latestScan.resources) {
      await db.resource.create({
        data: {
          scanId: newScan.id,
          accountId: account.id,
          type: resource.type,
          arn: resource.arn,
          name: resource.name,
          region: resource.region,
          metadata: resource.metadata,
        },
      });
    }

    // Get the newly created resources for finding linkage
    const newResources = await db.resource.findMany({ where: { scanId: newScan.id } });
    const resourceMap = new Map(newResources.map(r => [r.arn, r.id]));

    for (const finding of latestScan.findings) {
      const newResourceId = resourceMap.get(finding.resource?.arn || "") || newResources[0]?.id || "";
      if (newResourceId) {
        await db.finding.create({
          data: {
            scanId: newScan.id,
            resourceId: newResourceId,
            ruleId: finding.ruleId,
            title: finding.title,
            description: finding.description,
            severity: finding.severity,
            category: finding.category,
            compliance: finding.compliance,
            remediation: finding.remediation,
            cvssScore: finding.cvssScore,
            evidence: finding.evidence,
            status: "open",
          },
        });
      }
    }

    // Audit log
    await db.auditLog.create({
      data: {
        userId,
        action: "scan_triggered",
        resource: newScan.id,
        details: JSON.stringify({ scanners }),
      },
    });

    return NextResponse.json({
      scan_id: newScan.id,
      task_id: newScan.taskId,
      status: "completed",
    });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 });
  }
}
