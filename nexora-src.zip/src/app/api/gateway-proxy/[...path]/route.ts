/**
 * Gateway Proxy — uses CLI gateway (synchronous, no background process).
 *
 * This is the most reliable approach for sandboxed environments.
 * Each request spawns a short-lived Python process that handles the
 * request and exits. No long-running gateway to kill.
 */
import { NextRequest, NextResponse } from "next/server";
import { execSync } from "child_process";

const PYTHON = "/home/z/.venv/bin/python3";
const CLI_SCRIPT = "/home/z/my-project/scripts/cli_gateway.py";

async function readBody(req: NextRequest): Promise<string> {
  try {
    return await req.text();
  } catch {
    return "{}";
  }
}

async function handleRequest(
  method: string,
  req: NextRequest,
  params: Promise<{ path: string[] }>
) {
  const { path: pathParts } = await params;
  const path = "/" + pathParts.join("/");

  // Get auth header
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace(/^Bearer\s+/i, "");

  // Read body
  const body = method !== "GET" && method !== "HEAD" ? await readBody(req) : "{}";

  // Build query string
  const url = new URL(req.url);
  const query = url.search ? url.search : "";
  const fullPath = query ? `${path}${query}` : path;

  try {
    // Call CLI gateway synchronously
    const cmd = `${PYTHON} ${CLI_SCRIPT} ${method} '${fullPath}' '${body.replace(/'/g, "'\\''")}' '${token}'`;
    const result = execSync(cmd, {
      encoding: "utf-8",
      timeout: 60000, // 60s max (scans take time)
      maxBuffer: 100 * 1024 * 1024, // 100MB
      cwd: "/home/z/my-project",
    });

    // Parse JSON response
    try {
      const json = JSON.parse(result);
      return NextResponse.json(json);
    } catch {
      return new NextResponse(result, { status: 200 });
    }
  } catch (e: any) {
    // Check if the error contains stdout (execSync puts stderr in e.stderr, stdout in e.stdout)
    const stdout = e.stdout?.toString("utf-8") || "";
    const stderr = e.stderr?.toString("utf-8") || "";

    // Try to parse stdout as JSON
    if (stdout) {
      try {
        const json = JSON.parse(stdout);
        if (json.detail || json.error) {
          return NextResponse.json(json, { status: 400 });
        }
        return NextResponse.json(json);
      } catch {
        // stdout is not JSON
      }
    }

    return NextResponse.json(
      { error: "Gateway CLI failed", details: stderr || e.message, stdout: stdout.slice(0, 500) },
      { status: 500 }
    );
  }
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  return handleRequest("GET", req, params);
}
export async function POST(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  return handleRequest("POST", req, params);
}
export async function PUT(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  return handleRequest("PUT", req, params);
}
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  return handleRequest("DELETE", req, params);
}
