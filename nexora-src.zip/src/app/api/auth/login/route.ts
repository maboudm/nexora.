import { NextRequest, NextResponse } from "next/server";
import { authenticate, seedDefaultUser } from "@/lib/auth";

// Ensure the default user exists on first request
let seeded = false;
async function ensureSeeded() {
  if (!seeded) {
    await seedDefaultUser();
    seeded = true;
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    const body = await req.json().catch(() => ({}));
    const email = body.email;
    const password = body.password;
    if (!email || !password) {
      return NextResponse.json(
        { error: "Email and password are required" },
        { status: 400 },
      );
    }
    const result = await authenticate(email, password);
    if (!result) {
      return NextResponse.json(
        { error: "Invalid email or password" },
        { status: 401 },
      );
    }
    return NextResponse.json(result);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
