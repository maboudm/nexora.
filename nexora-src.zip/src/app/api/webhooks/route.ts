import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";

/**
 * GET /api/webhooks — list alert webhooks
 * POST /api/webhooks — create an alert webhook
 */
export async function GET(req: NextRequest) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const webhooks = await db.alertWebhook.findMany({
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ webhooks });
}

export async function POST(req: NextRequest) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const { name, url, eventType, severityFilter, enabled, secret } = body;
  if (!name || !url || !eventType) {
    return NextResponse.json({ error: "name, url, eventType required" }, { status: 400 });
  }
  const webhook = await db.alertWebhook.create({
    data: {
      name,
      url,
      eventType,
      severityFilter: severityFilter || "critical",
      enabled: enabled !== false,
      secret: secret || null,
    },
  });
  return NextResponse.json({ webhook }, { status: 201 });
}
