import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";

/**
 * PATCH /api/remediations/:id
 *   Update remediation status, priority, assignee, or comment.
 */
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const { status, priority, comment, assignedToId, dueDate } = body;

  const update: Record<string, unknown> = {};
  if (status) update.status = status;
  if (priority) update.priority = priority;
  if (comment !== undefined) update.comment = comment;
  if (assignedToId !== undefined) update.assignedToId = assignedToId;
  if (dueDate !== undefined) update.dueDate = dueDate ? new Date(dueDate) : null;
  if (status === "resolved") update.resolvedAt = new Date();

  const remediation = await db.remediation.update({
    where: { id },
    data: update,
  });

  // Sync finding status with remediation status
  if (status) {
    const findingStatus =
      status === "resolved" ? "resolved" :
      status === "in_progress" ? "in_progress" :
      status === "wont_fix" ? "suppressed" : "open";
    await db.finding.update({
      where: { id: remediation.findingId },
      data: { status: findingStatus, resolvedAt: status === "resolved" ? new Date() : null },
    });
  }

  return NextResponse.json({ remediation });
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const { id } = await params;
  await db.remediation.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
