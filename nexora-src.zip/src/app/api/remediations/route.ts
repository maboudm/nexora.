import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";

/**
 * GET /api/remediations
 *   List all remediations with their findings.
 *
 * POST /api/remediations
 *   Create a remediation for a finding (assign, set priority, due date).
 */
export async function GET(req: NextRequest) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const url = new URL(req.url);
  const status = url.searchParams.get("status");
  const priority = url.searchParams.get("priority");

  const where: Record<string, unknown> = {};
  if (status) where.status = status;
  if (priority) where.priority = priority;

  const remediations = await db.remediation.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: {
      finding: {
        select: {
          id: true, ruleId: true, title: true, severity: true,
          compliance: true, resource: { select: { arn: true, name: true, type: true } },
        },
      },
      assignedTo: { select: { id: true, name: true, email: true } },
    },
  });
  return NextResponse.json({ remediations });
}

export async function POST(req: NextRequest) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const { findingId, priority, dueDate, comment, assignedToId } = body;
  if (!findingId) {
    return NextResponse.json({ error: "findingId is required" }, { status: 400 });
  }
  const remediation = await db.remediation.create({
    data: {
      findingId,
      priority: priority || "medium",
      dueDate: dueDate ? new Date(dueDate) : null,
      comment: comment || null,
      assignedToId: assignedToId || null,
      status: "open",
    },
  });
  // Update finding status to in_progress
  await db.finding.update({
    where: { id: findingId },
    data: { status: "in_progress" },
  });
  return NextResponse.json({ remediation });
}
