import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";
import { execSync } from "child_process";
import fs from "fs";
import os from "os";
import path from "path";

const FRAMEWORK_CONTROLS: Record<string, { id: string; title: string; ruleIds: string[] }[]> = {
  "CIS-AWS": [
    { id: "1.3", title: "IAM roles should not have wildcard trust policies", ruleIds: ["IAM-001"] },
    { id: "1.4", title: "Ensure IAM policies are attached only to groups or roles", ruleIds: ["IAM-002"] },
    { id: "1.16", title: "Ensure IAM policies that grant full access are not attached", ruleIds: ["IAM-002", "IAM-004"] },
    { id: "1.21", title: "IAM roles should not be unused for 90 days", ruleIds: ["IAM-003"] },
    { id: "2.1", title: "S3 buckets should not allow public read access", ruleIds: ["S3-001"] },
    { id: "2.2", title: "S3 buckets should have default encryption enabled", ruleIds: ["S3-002"] },
    { id: "2.3", title: "S3 buckets should have versioning enabled", ruleIds: ["S3-003"] },
    { id: "2.4", title: "S3 buckets should have block public access enabled", ruleIds: ["S3-004"] },
    { id: "2.6", title: "S3 buckets should have server access logging enabled", ruleIds: ["S3-005"] },
    { id: "5.2", title: "Security groups should not allow SSH from 0.0.0.0/0", ruleIds: ["NET-001"] },
    { id: "5.3", title: "Security groups should not allow RDP from 0.0.0.0/0", ruleIds: ["NET-002"] },
    { id: "5.4", title: "Security groups should not allow DB ports from 0.0.0.0/0", ruleIds: ["NET-003"] },
    { id: "5.6", title: "Security groups should restrict egress traffic", ruleIds: ["NET-004"] },
  ],
  "PCI-DSS": [
    { id: "1.2.1", title: "Restrict inbound/outbound traffic to necessary ports", ruleIds: ["NET-001", "NET-002", "NET-003"] },
    { id: "2.1", title: "Always change vendor-supplied defaults (no public S3)", ruleIds: ["S3-001"] },
    { id: "3.4", title: "Render PAN unreadable anywhere it is stored (encryption)", ruleIds: ["S3-002"] },
    { id: "7.1", title: "Limit access to system components to authorized users (IAM)", ruleIds: ["IAM-001", "IAM-002"] },
    { id: "10.1", title: "Implement audit trails (S3 logging, EKS logging)", ruleIds: ["S3-005", "K8S-002"] },
  ],
  "SOC2": [
    { id: "CC6.1", title: "Logical and physical access controls (IAM, network)", ruleIds: ["IAM-001", "IAM-002", "NET-001", "NET-003"] },
    { id: "CC6.6", title: "Restrict access to authorized users (IAM)", ruleIds: ["IAM-002", "IAM-004"] },
    { id: "CC7.1", title: "Detection and monitoring (logging)", ruleIds: ["S3-005", "K8S-002"] },
    { id: "CC7.2", title: "Vulnerability detection (encryption, public access)", ruleIds: ["S3-001", "S3-002", "K8S-003"] },
  ],
  "ISO27001": [
    { id: "A.9.2.3", title: "Management of privileged access rights (IAM)", ruleIds: ["IAM-001", "IAM-002", "IAM-004"] },
    { id: "A.9.4.1", title: "Information access restriction (network)", ruleIds: ["NET-001", "NET-003"] },
    { id: "A.10.1.1", title: "Policy on the use of cryptographic controls (encryption)", ruleIds: ["S3-002", "K8S-003"] },
    { id: "A.12.4.1", title: "Event logging (S3 logging, EKS logging)", ruleIds: ["S3-005", "K8S-002"] },
    { id: "A.13.1.1", title: "Network controls (security groups)", ruleIds: ["NET-001", "NET-002", "NET-003", "NET-004"] },
  ],
};

/**
 * GET /api/compliance/[framework]/pdf
 *   Generates a downloadable PDF compliance report for the given framework.
 */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ framework: string }> },
) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }

  const { framework } = await params;
  const controls = FRAMEWORK_CONTROLS[framework];
  if (!controls) {
    return NextResponse.json({ error: `Unknown framework: ${framework}` }, { status: 400 });
  }

  // Get latest scan
  const latestScan = await db.scan.findFirst({
    where: { status: "completed" },
    orderBy: { createdAt: "desc" },
    include: { findings: { include: { resource: true } }, triggeredBy: true, account: true },
  });

  if (!latestScan) {
    return NextResponse.json({ error: "No completed scan found" }, { status: 404 });
  }

  // Map findings by ruleId
  const findingsByRule: Record<string, typeof latestScan.findings> = {};
  for (const f of latestScan.findings) {
    if (!findingsByRule[f.ruleId]) findingsByRule[f.ruleId] = [];
    findingsByRule[f.ruleId].push(f);
  }

  // Build controls with status
  const controlsWithStatus = controls.map((control) => {
    const controlFindings = control.ruleIds.flatMap((rid) => findingsByRule[rid] || []);
    const openFindings = controlFindings.filter((f) => f.status === "open" || f.status === "in_progress");
    return {
      ...control,
      status: openFindings.length === 0 ? "passed" : "failed",
      findings: openFindings.map((f) => ({
        ruleId: f.ruleId,
        title: f.title,
        severity: f.severity,
        resource: f.resource?.name || f.resourceId,
        arn: f.resource?.arn || "",
      })),
    };
  });

  const passed = controlsWithStatus.filter((c) => c.status === "passed").length;
  const failed = controlsWithStatus.filter((c) => c.status === "failed").length;
  const compliancePercentage = Math.round((passed / controls.length) * 100);

  // Generate PDF
  const pdfBuffer = await generateCompliancePDF({
    framework,
    scan: latestScan,
    controls: controlsWithStatus,
    summary: { total: controls.length, passed, failed, compliancePercentage },
  });

  const filename = `compliance-${framework}-${new Date().toISOString().slice(0, 10)}.pdf`;
  return new NextResponse(new Uint8Array(pdfBuffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${filename}"`,
    },
  });
}

async function generateCompliancePDF(data: {
  framework: string;
  scan: any;
  controls: any[];
  summary: { total: number; passed: number; failed: number; compliancePercentage: number };
}): Promise<Buffer> {
  const tmpDir = os.tmpdir();
  const dataFile = path.join(tmpDir, `compliance-data-${Date.now()}.json`);
  const pdfFile = path.join(tmpDir, `compliance-report-${Date.now()}.pdf`);
  const scriptFile = path.join(tmpDir, `gen-compliance-${Date.now()}.py`);

  fs.writeFileSync(dataFile, JSON.stringify(data));

  const script = `
import json, sys
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, HRFlowable

# Fonts
FONT_DIR = '/usr/share/fonts'
pdfmetrics.registerFont(TTFont('FreeSerif', f'{FONT_DIR}/truetype/freefont/FreeSerif.ttf'))
pdfmetrics.registerFont(TTFont('FreeSerif-Bold', f'{FONT_DIR}/truetype/freefont/FreeSerifBold.ttf'))
pdfmetrics.registerFont(TTFont('FreeSerif-Italic', f'{FONT_DIR}/truetype/freefont/FreeSerifItalic.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuSans', f'{FONT_DIR}/truetype/dejavu/DejaVuSansMono.ttf'))
registerFontFamily('FreeSerif', normal='FreeSerif', bold='FreeSerif-Bold', italic='FreeSerif-Italic')

# Colors
HEADER_FILL = colors.HexColor('#534b34')
ACCENT = colors.HexColor('#a3862f')
SEM_SUCCESS = colors.HexColor('#46865b')
SEM_ERROR = colors.HexColor('#a34e46')
TEXT_PRIMARY = colors.HexColor('#262522')
TEXT_MUTED = colors.HexColor('#8e8c85')
TABLE_STRIPE = colors.HexColor('#f0efee')
BORDER = colors.HexColor('#c6bda4')

data = json.load(open('${dataFile}'))
output = '${pdfFile}'

doc = SimpleDocTemplate(output, pagesize=A4,
    leftMargin=18*mm, rightMargin=18*mm, topMargin=22*mm, bottomMargin=18*mm,
    title=f"Compliance Report - {data['framework']}", author="Nexora")

styles = {
    'h1': ParagraphStyle('h1', fontName='FreeSerif-Bold', fontSize=22, leading=28,
                         textColor=TEXT_PRIMARY, spaceAfter=10),
    'h2': ParagraphStyle('h2', fontName='FreeSerif-Bold', fontSize=14, leading=20,
                         textColor=HEADER_FILL, spaceBefore=14, spaceAfter=8),
    'body': ParagraphStyle('body', fontName='FreeSerif', fontSize=10, leading=15,
                           textColor=TEXT_PRIMARY, alignment=TA_JUSTIFY, spaceAfter=6),
    'meta': ParagraphStyle('meta', fontName='FreeSerif-Italic', fontSize=9, leading=12,
                           textColor=TEXT_MUTED, spaceAfter=4),
    'mono': ParagraphStyle('mono', fontName='DejaVuSans', fontSize=8, leading=11,
                           textColor=TEXT_PRIMARY),
}

story = []
story.append(Paragraph(f"Compliance Report", styles['h1']))
story.append(Paragraph(f"Framework: <b>{data['framework']}</b>", styles['h2']))
story.append(HRFlowable(width='100%', thickness=0.6, color=ACCENT, spaceAfter=10))

# Summary
story.append(Paragraph("Executive Summary", styles['h2']))
s = data['summary']
status = "COMPLIANT" if s['failed'] == 0 else "NON-COMPLIANT"
status_color = SEM_SUCCESS if s['failed'] == 0 else SEM_ERROR
story.append(Paragraph(
    f"This report presents the compliance status of AWS account "
    f"<b>{data['scan']['account']['accountId']}</b> against the <b>{data['framework']}</b> framework. "
    f"The assessment is based on the most recent security scan completed on "
    f"<b>{data['scan']['createdAt']}</b>.",
    styles['body']))
story.append(Paragraph(
    f"Overall Status: <font color='{status_color.hexval()}'><b>{status}</b></font> "
    f"({s['compliancePercentage']}% compliant)", styles['body']))
story.append(Spacer(1, 6))

# Summary table
summary_data = [
    ['Metric', 'Value'],
    ['Total Controls', str(s['total'])],
    ['Passed', str(s['passed'])],
    ['Failed', str(s['failed'])],
    ['Compliance %', f"{s['compliancePercentage']}%"],
    ['Scan Date', data['scan']['createdAt']],
    ['Scan ID', data['scan']['id']],
]
t = Table(summary_data, colWidths=[50*mm, 130*mm])
t.setStyle(TableStyle([
    ('BACKGROUND', (0,0), (-1,0), HEADER_FILL),
    ('TEXTCOLOR', (0,0), (-1,0), colors.white),
    ('FONT', (0,0), (-1,0), 'FreeSerif-Bold', 9),
    ('FONT', (0,1), (-1,-1), 'FreeSerif', 9),
    ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ('LEFTPADDING', (0,0), (-1,-1), 6),
    ('TOPPADDING', (0,0), (-1,-1), 5),
    ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ('LINEBELOW', (0,0), (-1,0), 1, HEADER_FILL),
]))
story.append(t)
story.append(PageBreak())

# Control details
story.append(Paragraph("Control Details", styles['h2']))
story.append(Paragraph(
    f"The following table lists each control in the {data['framework']} framework, "
    f"its current status, and any findings that caused it to fail.", styles['body']))
story.append(Spacer(1, 8))

for ctrl in data['controls']:
    status_color = SEM_SUCCESS if ctrl['status'] == 'passed' else SEM_ERROR
    status_label = "PASS" if ctrl['status'] == 'passed' else "FAIL"
    story.append(Paragraph(
        f"<b>{ctrl['id']}</b> — {ctrl['title']} "
        f"<font color='{status_color.hexval()}'><b>[{status_label}]</b></font>", styles['body']))
    if ctrl['findings']:
        for f in ctrl['findings']:
            story.append(Paragraph(
                f"&nbsp;&nbsp;• <font color='{SEM_ERROR.hexval()}'>[{f['severity'].upper()}]</font> "
                f"<b>{f['ruleId']}</b>: {f['title']} — <i>{f['resource']}</i>", styles['meta']))
    else:
        story.append(Paragraph("&nbsp;&nbsp;<i>No findings — control satisfied.</i>", styles['meta']))
    story.append(Spacer(1, 4))

story.append(Spacer(1, 20))
story.append(HRFlowable(width='100%', thickness=0.4, color=BORDER))
story.append(Paragraph(
    f"Generated by Nexora on {data.get('generated_at', '')}. "
    f"This report is based on automated security scans and should be reviewed by a qualified security engineer.",
    styles['meta']))

doc.build(story)
print(f"PDF written: {output}")
`;

  fs.writeFileSync(scriptFile, script);

  try {
    execSync(`python3 ${scriptFile}`, { stdio: 'pipe', timeout: 30000 });
    const pdfBuffer = fs.readFileSync(pdfFile);
    // Cleanup
    fs.unlinkSync(dataFile);
    fs.unlinkSync(scriptFile);
    fs.unlinkSync(pdfFile);
    return Buffer.from(pdfBuffer);
  } catch (err) {
    // Cleanup on error
    try { fs.unlinkSync(dataFile); } catch {}
    try { fs.unlinkSync(scriptFile); } catch {}
    try { fs.unlinkSync(pdfFile); } catch {}
    throw err;
  }
}