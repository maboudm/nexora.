import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";

/**
 * GET /api/compliance?framework=SOC2
 *   Returns compliance status for a given framework.
 *   Supported frameworks: CIS-AWS, PCI-DSS, SOC2, ISO27001
 *
 * Maps findings to compliance control families and computes pass/fail per control.
 */
const FRAMEWORK_CONTROLS: Record<string, { id: string; title: string; ruleIds: string[] }[]> = {
  "CIS-AWS": [
    { id: "1.3", title: "IAM roles should not have wildcard trust policies", ruleIds: ["IAM-001"] },
    { id: "1.4", title: "Ensure IAM policies are attached only to groups or roles", ruleIds: ["IAM-002"] },
    { id: "1.16", title: "Ensure IAM policies that grant full access are not attached", ruleIds: ["IAM-002", "IAM-004"] },
    { id: "1.21", title: "IAM roles should not be unused for 90 days", ruleIds: ["IAM-003"] },
    { id: "2.1", title: "S3 buckets should not allow public read access", ruleIds: ["S3-001"] },
    { id: "2.2", title: "S3 buckets should have default encryption enabled", ruleIds: ["S3-002"] },
    { id: "2.3", title: "S3 buckets should have versioning enabled", ruleIds: ["S3-003"] },
    { id: "2.4", title: "S3 buckets should have block public access enabled", ruleIds: ["S3-004"] },
    { id: "2.6", title: "S3 buckets should have server access logging enabled", ruleIds: ["S3-005"] },
    { id: "5.2", title: "Security groups should not allow SSH from 0.0.0.0/0", ruleIds: ["NET-001"] },
    { id: "5.3", title: "Security groups should not allow RDP from 0.0.0.0/0", ruleIds: ["NET-002"] },
    { id: "5.4", title: "Security groups should not allow DB ports from 0.0.0.0/0", ruleIds: ["NET-003"] },
    { id: "5.6", title: "Security groups should restrict egress traffic", ruleIds: ["NET-004"] },
  ],
  "PCI-DSS": [
    { id: "1.2.1", title: "Restrict inbound/outbound traffic to necessary ports", ruleIds: ["NET-001", "NET-002", "NET-003"] },
    { id: "2.1", title: "Always change vendor-supplied defaults (no public S3)", ruleIds: ["S3-001"] },
    { id: "3.4", title: "Render PAN unreadable anywhere it is stored (encryption)", ruleIds: ["S3-002"] },
    { id: "7.1", title: "Limit access to system components to authorized users (IAM)", ruleIds: ["IAM-001", "IAM-002"] },
    { id: "10.1", title: "Implement audit trails (S3 logging, EKS logging)", ruleIds: ["S3-005", "K8S-002"] },
  ],
  "SOC2": [
    { id: "CC6.1", title: "Logical and physical access controls (IAM, network)", ruleIds: ["IAM-001", "IAM-002", "NET-001", "NET-003"] },
    { id: "CC6.6", title: "Restrict access to authorized users (IAM)", ruleIds: ["IAM-002", "IAM-004"] },
    { id: "CC7.1", title: "Detection and monitoring (logging)", ruleIds: ["S3-005", "K8S-002"] },
    { id: "CC7.2", title: "Vulnerability detection (encryption, public access)", ruleIds: ["S3-001", "S3-002", "K8S-003"] },
  ],
  "ISO27001": [
    { id: "A.9.2.3", title: "Management of privileged access rights (IAM)", ruleIds: ["IAM-001", "IAM-002", "IAM-004"] },
    { id: "A.9.4.1", title: "Information access restriction (network)", ruleIds: ["NET-001", "NET-003"] },
    { id: "A.10.1.1", title: "Policy on the use of cryptographic controls (encryption)", ruleIds: ["S3-002", "K8S-003"] },
    { id: "A.12.4.1", title: "Event logging (S3 logging, EKS logging)", ruleIds: ["S3-005", "K8S-002"] },
    { id: "A.13.1.1", title: "Network controls (security groups)", ruleIds: ["NET-001", "NET-002", "NET-003", "NET-004"] },
  ],
};

export async function GET(req: NextRequest) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }
  const url = new URL(req.url);
  const framework = url.searchParams.get("framework") || "CIS-AWS";
  const controls = FRAMEWORK_CONTROLS[framework];
  if (!controls) {
    return NextResponse.json({ error: `Unknown framework: ${framework}` }, { status: 400 });
  }

  // Get latest scan findings
  const latestScan = await db.scan.findFirst({
    where: { status: "completed" },
    orderBy: { createdAt: "desc" },
    include: { findings: { include: { resource: true } } },
  });

  if (!latestScan) {
    return NextResponse.json({
      framework,
      generated_at: new Date().toISOString(),
      overall_status: "no_data",
      controls: controls.map((c) => ({ ...c, status: "no_data", findings: [] })),
      summary: { total: controls.length, passed: 0, failed: 0, no_data: controls.length },
    });
  }

  // Map findings by ruleId
  const findingsByRule: Record<string, typeof latestScan.findings> = {};
  for (const f of latestScan.findings) {
    if (!findingsByRule[f.ruleId]) findingsByRule[f.ruleId] = [];
    findingsByRule[f.ruleId].push(f);
  }

  // Compute status per control
  const controlsWithStatus = controls.map((control) => {
    const controlFindings = control.ruleIds.flatMap((rid) => findingsByRule[rid] || []);
    const openFindings = controlFindings.filter((f) => f.status === "open" || f.status === "in_progress");
    return {
      ...control,
      status: openFindings.length === 0 ? "passed" : "failed",
      findings: openFindings.map((f) => ({
        id: f.id,
        ruleId: f.ruleId,
        title: f.title,
        severity: f.severity,
        resource: f.resource?.name || f.resourceId,
      })),
    };
  });

  const passed = controlsWithStatus.filter((c) => c.status === "passed").length;
  const failed = controlsWithStatus.filter((c) => c.status === "failed").length;

  return NextResponse.json({
    framework,
    scan_id: latestScan.id,
    scan_date: latestScan.createdAt.toISOString(),
    generated_at: new Date().toISOString(),
    overall_status: failed === 0 ? "compliant" : "non_compliant",
    controls: controlsWithStatus,
    summary: {
      total: controls.length,
      passed,
      failed,
      compliance_percentage: Math.round((passed / controls.length) * 100),
    },
  });
}
