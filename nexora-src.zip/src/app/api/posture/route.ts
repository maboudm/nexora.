import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";

/**
 * GET /api/posture
 *   Returns posture score history + current score + trend.
 *   Posture score = 100 - (critical*10 + high*5 + medium*2 + low*0.5)
 *   Clamped to [0, 100].
 */
export async function GET(req: NextRequest) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }

  // Get last 30 completed scans for trend
  const scans = await db.scan.findMany({
    where: { status: "completed" },
    orderBy: { createdAt: "desc" },
    take: 30,
    select: {
      id: true,
      createdAt: true,
      postureScore: true,
      findingsCount: true,
      criticalCount: true,
      highCount: true,
      mediumCount: true,
      lowCount: true,
    },
  });

  // Reverse so oldest is first (for chart)
  const trend = scans.reverse().map((s) => ({
    date: s.createdAt.toISOString(),
    score: s.postureScore,
    findings: s.findingsCount,
    critical: s.criticalCount,
    high: s.highCount,
    medium: s.mediumCount,
    low: s.lowCount,
  }));

  const current = trend.length > 0 ? trend[trend.length - 1] : null;
  const previous = trend.length > 1 ? trend[trend.length - 2] : null;
  const delta = current && previous ? current.score - previous.score : 0;

  // Compute trend classification
  let trendClass = "stable";
  if (delta > 1) trendClass = "improving";
  else if (delta < -1) trendClass = "declining";

  // 7-day and 30-day stats
  const now = new Date();
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  const last7 = trend.filter((t) => new Date(t.date) >= sevenDaysAgo);
  const last30 = trend.filter((t) => new Date(t.date) >= thirtyDaysAgo);

  return NextResponse.json({
    current: current?.score ?? 100,
    delta,
    trend: trendClass,
    history: trend,
    stats: {
      scans_last_7_days: last7.length,
      scans_last_30_days: last30.length,
      avg_score_7_day: last7.length > 0 ? last7.reduce((s, t) => s + t.score, 0) / last7.length : null,
      avg_score_30_day: last30.length > 0 ? last30.reduce((s, t) => s + t.score, 0) / last30.length : null,
      best_score: trend.length > 0 ? Math.max(...trend.map((t) => t.score)) : null,
      worst_score: trend.length > 0 ? Math.min(...trend.map((t) => t.score)) : null,
    },
  });
}
