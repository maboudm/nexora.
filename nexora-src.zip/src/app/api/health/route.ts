import { NextResponse } from "next/server";

/**
 * GET /api/health - Public health check.
 * Returns platform status. Does NOT depend on external scanner service.
 */
export async function GET() {
  return NextResponse.json({
    status: "healthy",
    version: "2.0.0",
    database: "connected",
    scanner: "standby",
  });
}
