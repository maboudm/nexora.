import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";

/**
 * GET /api/scans
 *   - Requires Authorization: Bearer <jwt>
 *   - Returns the 20 most recent scans with summary stats.
 */
export async function GET(req: NextRequest) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 401 });
  }
  const scans = await db.scan.findMany({
    orderBy: { createdAt: "desc" },
    take: 20,
    include: {
      triggeredBy: {
        select: { id: true, name: true, email: true },
      },
      account: {
        select: { id: true, provider: true, accountId: true, alias: true },
      },
    },
  });
  return NextResponse.json({ scans });
}
