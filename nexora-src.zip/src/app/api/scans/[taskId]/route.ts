import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { db } from "@/lib/db";

/**
 * GET /api/scans/:taskId
 *   Returns scan result from database. No external service needed.
 */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ taskId: string }> },
) {
  try {
    requireAuth(req.headers.get("authorization"));
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 401 });
  }

  const { taskId } = await params;

  const scan = await db.scan.findUnique({
    where: { taskId },
    include: {
      findings: { include: { resource: true }, orderBy: { severity: "asc" } },
      resources: true,
    },
  });

  if (!scan) {
    return NextResponse.json({ error: "Scan not found" }, { status: 404 });
  }

  if (scan.status !== "completed") {
    return NextResponse.json({ status: scan.status, taskId });
  }

  // Build result in the format the frontend expects
  const severityCounts: Record<string, number> = { critical: 0, high: 0, medium: 0, low: 0 };
  const categoryCounts: Record<string, number> = {};
  const complianceCounts: Record<string, number> = {};

  const findings = scan.findings.map((f) => {
    severityCounts[f.severity] = (severityCounts[f.severity] || 0) + 1;
    categoryCounts[f.category] = (categoryCounts[f.category] || 0) + 1;
    complianceCounts[f.compliance] = (complianceCounts[f.compliance] || 0) + 1;
    return {
      id: f.id, rule_id: f.ruleId, title: f.title, description: f.description,
      severity: f.severity, category: f.category, compliance: f.compliance,
      cvss_score: f.cvssScore, remediation: f.remediation,
      resource_type: f.resource?.type || "unknown", resource_arn: f.resource?.arn || "",
      resource_name: f.resource?.name || "", region: f.resource?.region || "us-east-1",
      evidence: (() => { try { return JSON.parse(f.evidence); } catch { return {}; } })(),
      status: f.status, detected_at: Math.floor(f.detectedAt.getTime() / 1000),
    };
  });

  const resources = scan.resources.map((r) => ({
    type: r.type, arn: r.arn, name: r.name, region: r.region,
    metadata: (() => { try { return JSON.parse(r.metadata); } catch { return {}; } })(),
  }));

  // Build a simple graph
  const graphNodes: any[] = [{ id: "aws::internet", label: "Internet (Attacker)", type: "external", region: "global", findings_count: 0, severity: "external", severity_counts: { critical: 0, high: 0, medium: 0, low: 0 }, position: { x: 100, y: 80 } }];
  const graphEdges: any[] = [];
  const tiers: Record<string, number> = { aws_security_group: 1, aws_ec2_instance: 2, aws_eks_cluster: 2, aws_iam_role: 3, aws_s3_bucket: 4 };
  const tierIdx: Record<number, number> = {};
  for (const r of resources) {
    const t = tiers[r.type] || 3; const i = tierIdx[t] || 0; tierIdx[t] = i + 1;
    const rf = findings.filter((f: any) => f.resource_arn === r.arn);
    const sc: Record<string, number> = { critical: 0, high: 0, medium: 0, low: 0 };
    let ms = "low";
    for (const f of rf) { sc[f.severity] = (sc[f.severity] || 0) + 1; if (f.severity === "critical") ms = "critical"; else if (f.severity === "high" && ms !== "critical") ms = "high"; else if (f.severity === "medium" && ms === "low") ms = "medium"; }
    graphNodes.push({ id: r.arn, label: r.name.length > 24 ? r.name.slice(0, 22) + "…" : r.name, type: r.type, region: r.region, findings_count: rf.length, severity: ms, severity_counts: sc, position: { x: i * 220 + 100, y: t * 160 + 80 } });
  }
  const sgs = resources.filter((r: any) => r.type === "aws_security_group");
  const ec2s = resources.filter((r: any) => r.type === "aws_ec2_instance");
  const roles = resources.filter((r: any) => r.type === "aws_iam_role");
  const buckets = resources.filter((r: any) => r.type === "aws_s3_bucket");
  for (const sg of sgs) { if (findings.some((f: any) => f.resource_arn === sg.arn && f.rule_id.startsWith("NET-00"))) graphEdges.push({ id: `aws::internet->${sg.arn}`, source: "aws::internet", target: sg.arn, label: "public_ingress" }); }
  for (const ec2 of ec2s) { const m = ec2.metadata || {}; for (const sg of m.SecurityGroups || []) { const sgr = sgs.find((s: any) => s.name.includes(sg.GroupName)); if (sgr) graphEdges.push({ id: `${sgr.arn}->${ec2.arn}`, source: sgr.arn, target: ec2.arn, label: "attached_sg" }); } }
  for (const ec2 of ec2s) { const m = ec2.metadata || {}; const p = m.IamInstanceProfile; if (p && p.Arn) { const rn = p.Arn.split("/").pop(); const role = roles.find((r: any) => r.name === rn); if (role) graphEdges.push({ id: `${ec2.arn}->${role.arn}`, source: ec2.arn, target: role.arn, label: "assumes_role" }); } }
  for (const role of roles) { if (findings.some((f: any) => f.resource_arn === role.arn && (f.rule_id === "IAM-002" || f.rule_id === "IAM-004"))) for (const b of buckets) graphEdges.push({ id: `${role.arn}->${b.arn}`, source: role.arn, target: b.arn, label: "can_access_s3" }); }

  const graph = {
    nodes: graphNodes,
    edges: graphEdges,
    attack_paths: [],
    summary: { total_nodes: graphNodes.length, total_edges: graphEdges.length, critical_paths: 0, internet_reachable_resources: graphEdges.filter((e: any) => e.source === "aws::internet").length },
  };

  return NextResponse.json({
    status: "completed",
    result: {
      scan_id: scan.id,
      status: "completed",
      scan_mode: "real",
      scanners_run: scan.scannerTypes.split(","),
      duration_ms: scan.durationMs,
      findings,
      resources,
      graph,
      summary: {
        total_findings: findings.length,
        total_resources: resources.length,
        severity_counts: severityCounts,
        category_counts: categoryCounts,
        compliance_counts: complianceCounts,
        critical_attack_paths: 0,
      },
    },
  });
}
