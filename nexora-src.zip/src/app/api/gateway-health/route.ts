import { NextRequest, NextResponse } from "next/server";
import { spawn, execSync } from "child_process";
import fs from "fs";

const GATEWAY_PORT = 8000;
const GATEWAY_URL = "http://localhost:8000";
const PYTHON = "/home/z/.venv/bin/python3";
const PROJECT_DIR = "/home/z/my-project";
const PID_FILE = "/tmp/sentinel-gateway.pid";
const LOG_FILE = "/tmp/gateway.log";

let startAttempted = false;
let lastStartAttempt = 0;

function isGatewayUp(): boolean {
  try {
    const result = execSync(
      `curl -s -o /dev/null -w "%{http_code}" --max-time 2 http://localhost:${GATEWAY_PORT}/health`,
      { encoding: "utf-8", timeout: 5000 }
    );
    return result.trim() === "200";
  } catch {
    return false;
  }
}

function startGateway(): boolean {
  const now = Date.now();
  if (startAttempted && now - lastStartAttempt < 10000) {
    return false;
  }
  startAttempted = true;
  lastStartAttempt = now;

  try {
    const auditKey = execSync(`python3 -c "import secrets; print(secrets.token_hex(32))"`, {
      encoding: "utf-8",
    }).trim();

    const env = {
      ...process.env,
      AUDIT_MASTER_KEY: auditKey,
      JWT_SECRET: "nexora-jwt-secret-2026-change-me-32chars",
      MASTER_ENCRYPTION_KEY: auditKey,
    };

    const child = spawn(
      PYTHON,
      ["-m", "uvicorn", "backend.gateway.app:app", "--host", "0.0.0.0", "--port", "8000", "--log-level", "warning"],
      {
        cwd: PROJECT_DIR,
        env,
        detached: true,
        stdio: ["ignore", "ignore", "ignore"],
      }
    );
    child.unref();

    fs.writeFileSync(PID_FILE, String(child.pid));

    for (let i = 0; i < 15; i++) {
      if (isGatewayUp()) {
        return true;
      }
      execSync("sleep 1", { timeout: 2000 });
    }
    return false;
  } catch (e) {
    console.error("Failed to start gateway:", e);
    return false;
  }
}

export async function GET(req: NextRequest) {
  if (!isGatewayUp()) {
    const started = startGateway();
    if (!started) {
      return NextResponse.json(
        {
          status: "degraded",
          gateway_up: false,
          message: "Gateway is starting up. Please wait 5 seconds and refresh.",
          retry_after: 5,
        },
        { status: 503 }
      );
    }
  }

  try {
    const result = execSync(
      `curl -s --max-time 5 http://localhost:${GATEWAY_PORT}/health`,
      { encoding: "utf-8", timeout: 10000 }
    );
    const data = JSON.parse(result);
    return NextResponse.json({
      ...data,
      gateway_up: true,
      gateway_url: GATEWAY_URL,
    });
  } catch {
    return NextResponse.json(
      {
        status: "degraded",
        gateway_up: false,
        message: "Gateway health check failed",
      },
      { status: 503 }
    );
  }
}
