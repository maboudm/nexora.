/**
 * Gateway Login — uses CLI gateway (synchronous, no background process).
 */
import { NextRequest, NextResponse } from "next/server";
import { execSync } from "child_process";

const PYTHON = "/home/z/.venv/bin/python3";
const CLI_SCRIPT = "/home/z/my-project/scripts/cli_gateway.py";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const { email, password } = body;

  if (!email || !password) {
    return NextResponse.json(
      { error: "Email and password are required" },
      { status: 400 }
    );
  }

  try {
    const bodyStr = JSON.stringify({ email, password }).replace(/'/g, "'\\''");
    const cmd = `${PYTHON} ${CLI_SCRIPT} POST /v1/auth/login '${bodyStr}'`;
    const result = execSync(cmd, {
      encoding: "utf-8",
      timeout: 30000,
      maxBuffer: 10 * 1024 * 1024,
      cwd: "/home/z/my-project",
    });

    const data = JSON.parse(result);
    if (data.token) {
      return NextResponse.json({
        token: data.token,
        user: {
          id: data.user.user_id,
          email: data.user.email,
          name: data.user.name,
          role: data.user.role,
        },
        gateway_mode: true,
      });
    } else {
      return NextResponse.json(
        { error: data.detail || "Invalid credentials" },
        { status: 401 }
      );
    }
  } catch (e: any) {
    const stdout = e.stdout?.toString("utf-8") || "";
    if (stdout) {
      try {
        const data = JSON.parse(stdout);
        return NextResponse.json(
          { error: data.detail || "Login failed" },
          { status: 401 }
        );
      } catch {}
    }
    return NextResponse.json(
      { error: "Login failed. Please try again.", details: e.message },
      { status: 500 }
    );
  }
}
