/**
 * CNAPP Scanner Service client.
 * All requests to the FastAPI scanner mini-service go through the Caddy gateway
 * using the XTransformPort query param. NEVER use direct localhost URLs.
 */

const SCANNER_PORT = 3030;

export type Severity = "critical" | "high" | "medium" | "low";
export type ScanMode = "mock" | "real";
export type FindingStatus = "open" | "suppressed" | "resolved";

export interface Finding {
  id: string;
  rule_id: string;
  title: string;
  description: string;
  severity: Severity;
  category: string;
  compliance: string;
  cvss_score: number;
  remediation: string;
  resource_type: string;
  resource_arn: string;
  resource_name: string;
  region: string;
  evidence: Record<string, unknown>;
  status: FindingStatus;
  detected_at: number;
}

export interface CloudResource {
  type: string;
  arn: string;
  name: string;
  region: string;
  metadata: Record<string, unknown>;
}

export interface GraphNode {
  id: string;
  label: string;
  type: string;
  region: string;
  findings_count: number;
  severity: string;
  severity_counts: Record<string, number>;
  position: { x: number; y: number };
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  label: string;
}

export interface AttackPath {
  path: string[];
  findings: string[];
  length: number;
}

export interface ScanSummary {
  total_findings: number;
  total_resources: number;
  severity_counts: Record<Severity, number>;
  category_counts: Record<string, number>;
  compliance_counts: Record<string, number>;
  critical_attack_paths: number;
}

export interface ScanResult {
  scan_id: string;
  status: string;
  scan_mode: ScanMode;
  scanners_run: string[];
  duration_ms: number;
  findings: Finding[];
  resources: CloudResource[];
  graph: {
    nodes: GraphNode[];
    edges: GraphEdge[];
    attack_paths: AttackPath[];
    summary: {
      total_nodes: number;
      total_edges: number;
      critical_paths: number;
      internet_reachable_resources: number;
    };
  };
  summary: ScanSummary;
}

export interface ScanRule {
  rule_id: string;
  title: string;
  description: string;
  severity: Severity;
  category: string;
  compliance: string;
  cvss_score: number;
  remediation: string;
}

/**
 * Internal helper that calls the scanner service via the gateway.
 * The gateway routes ?XTransformPort=3030 to localhost:3030.
 */
async function scannerFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const url = path.includes("?")
    ? `${path}&XTransformPort=${SCANNER_PORT}`
    : `${path}?XTransformPort=${SCANNER_PORT}`;
  const res = await fetch(url, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Scanner ${res.status}: ${text}`);
  }
  return res.json() as Promise<T>;
}

/**
 * Trigger a new scan.
 */
export async function triggerScan(opts: {
  scanMode: ScanMode;
  scanners?: string[];
}): Promise<ScanResult> {
  return scannerFetch<ScanResult>("/scan", {
    method: "POST",
    body: JSON.stringify({
      scan_mode: opts.scanMode,
      scanners: opts.scanners ?? ["iam", "s3", "sg", "k8s"],
      account_id: "123456789012",
      region: "us-east-1",
    }),
  });
}

/**
 * List all scanner rules.
 */
export async function listRules(): Promise<ScanRule[]> {
  return scannerFetch<ScanRule[]>("/rules");
}

/**
 * Severity colors for the UI.
 */
export const SEVERITY_COLORS: Record<Severity, { bg: string; text: string; dot: string; border: string }> = {
  critical: {
    bg: "bg-red-500/10",
    text: "text-red-700 dark:text-red-400",
    dot: "bg-red-500",
    border: "border-red-500/30",
  },
  high: {
    bg: "bg-orange-500/10",
    text: "text-orange-700 dark:text-orange-400",
    dot: "bg-orange-500",
    border: "border-orange-500/30",
  },
  medium: {
    bg: "bg-amber-500/10",
    text: "text-amber-700 dark:text-amber-400",
    dot: "bg-amber-500",
    border: "border-amber-500/30",
  },
  low: {
    bg: "bg-blue-500/10",
    text: "text-blue-700 dark:text-blue-400",
    dot: "bg-blue-500",
    border: "border-blue-500/30",
  },
};

export const RESOURCE_TYPE_LABELS: Record<string, string> = {
  aws_iam_role: "IAM Role",
  aws_s3_bucket: "S3 Bucket",
  aws_security_group: "Security Group",
  aws_eks_cluster: "EKS Cluster",
  aws_ec2_instance: "EC2 Instance",
  external: "External",
};

export const RESOURCE_TYPE_ICONS: Record<string, string> = {
  aws_iam_role: "User",
  aws_s3_bucket: "Database",
  aws_security_group: "Shield",
  aws_eks_cluster: "Box",
  aws_ec2_instance: "Server",
  external: "Globe",
};
