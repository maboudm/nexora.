/**
 * Authentication module - real JWT-based auth with bcrypt password hashing.
 *
 * - Passwords are hashed with bcrypt (10 rounds).
 * - JWTs are signed with JWT_SECRET from env (NOT hardcoded).
 * - Tokens expire in 8 hours.
 * - User records are persisted in Prisma (User model).
 *
 * On first run, a default admin user is seeded if none exists:
 *   email: admin@sentinel.local
 *   password: admin123 (CHANGE THIS IMMEDIATELY in production via the UI)
 */
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { db } from "@/lib/db";

const JWT_SECRET: string = process.env.JWT_SECRET || "nexora-fallback-secret-2026-do-not-use-in-production-x9k2m7p4";
if (!process.env.JWT_SECRET) {
  console.warn("[auth] WARNING: JWT_SECRET not set in environment. Using fallback. Set JWT_SECRET in .env for production.");
}

const TOKEN_EXPIRY = "8h";

export interface JwtPayload {
  sub: string; // user id
  email: string;
  role: string;
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 10);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

export function signToken(payload: JwtPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
}

export function verifyToken(token: string): JwtPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JwtPayload;
  } catch {
    return null;
  }
}

/**
 * Seed a default admin user if the User table is empty.
 * Called once on app startup.
 */
export async function seedDefaultUser(): Promise<void> {
  const count = await db.user.count();
  if (count > 0) return;
  const passwordHash = await hashPassword("admin123");
  await db.user.create({
    data: {
      email: "admin@sentinel.local",
      name: "Default Admin",
      passwordHash,
      role: "admin",
    },
  });
  console.log("[auth] Seeded default user: admin@sentinel.local / admin123");
}

/**
 * Authenticate a user by email + password. Returns a JWT or null.
 */
export async function authenticate(
  email: string,
  password: string,
): Promise<{ token: string; user: { id: string; email: string; name: string; role: string } } | null> {
  const user = await db.user.findUnique({ where: { email } });
  if (!user) return null;
  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) return null;
  const token = signToken({
    sub: user.id,
    email: user.email,
    role: user.role,
  });
  return {
    token,
    user: { id: user.id, email: user.email, name: user.name, role: user.role },
  };
}

/**
 * Verify a request's Authorization header. Throws if invalid.
 * Returns the user payload.
 */
export function requireAuth(authHeader: string | null): JwtPayload {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    throw new Error("Missing or malformed Authorization header");
  }
  const token = authHeader.slice(7);
  const payload = verifyToken(token);
  if (!payload) {
    throw new Error("Invalid or expired token");
  }
  return payload;
}
