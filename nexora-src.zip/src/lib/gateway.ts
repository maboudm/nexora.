/**
 * Enterprise Gateway Client — TypeScript client for the FastAPI gateway.
 *
 * This module is the single point of contact between the Next.js frontend
 * and the FastAPI backend (which hosts all CNAPP engines: scanner, rules,
 * risk, attack graph, compliance, audit, notification, AI).
 *
 * Authentication flow:
 *   1. User submits login form → client.login(email, password)
 *   2. Gateway returns JWT token + user object
 *   3. Token stored in localStorage and sent as Bearer on every request
 *   4. Token expiry handled — auto-logout on 401
 *
 * Multi-tenant isolation:
 *   The JWT contains tenant_id. The gateway NEVER accepts tenant_id from
 *   the client — it always extracts from the JWT. This makes cross-tenant
 *   access impossible even if the client is compromised.
 */

const GATEWAY_URL =
  process.env.NEXT_PUBLIC_GATEWAY_URL ||
  (typeof window !== "undefined"
    ? window.location.origin.replace(/:\d+$/, ":8000")
    : "http://localhost:8000");

export interface User {
  user_id: string;
  tenant_id: string;
  email: string;
  name: string;
  role: string;
  status: string;
  created_at: number;
  last_login: number;
}

export interface LoginResponse {
  token: string;
  user: User;
  expires_in: number;
}

export interface CloudAccount {
  account_id: string;
  name: string;
  provider: string;
  external_id: string;
  credential_type: string;
  role_arn?: string;
  regions: string[];
  status: string;
  last_scan_at?: number;
  created_at: number;
}

export interface ScanRecord {
  scan_id: string;
  cloud_account_id: string;
  status: string;
  started_at?: number;
  completed_at?: number;
  total_assets: number;
  total_findings: number;
  findings_by_severity: Record<string, number>;
  error?: string;
}

export interface ScanDetail extends ScanRecord {
  workspace_id: string;
  tenant_id: string;
  assets: CloudResource[];
  findings: Finding[];
  attack_graph: AttackGraph;
  risk_scores: Record<string, number>;
}

export interface CloudResource {
  id: string;
  type: string;
  arn: string;
  name: string;
  region: string;
  metadata: Record<string, unknown>;
}

export type Severity = "critical" | "high" | "medium" | "low" | "info";
export type FindingStatus = "open" | "suppressed" | "resolved";

export interface Finding {
  id: string;
  rule_id: string;
  title: string;
  description: string;
  severity: Severity;
  category: string;
  compliance: string;
  cvss_score: number;
  remediation: string;
  resource_type: string;
  resource_arn: string;
  resource_name: string;
  region: string;
  evidence: Record<string, unknown>;
  status: FindingStatus;
  detected_at: number;
}

export interface AttackGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  attack_paths: AttackPath[];
  blast_radius: {
    affected_assets: number;
    total_assets: number;
    percentage: number;
  };
}

export interface GraphNode {
  id: string;
  label: string;
  type: string;
  region: string;
  findings_count: number;
  severity: string;
  severity_counts: Record<string, number>;
}

export interface GraphEdge {
  source: string;
  target: string;
  type: string;
}

export interface AttackPath {
  id: string;
  path: string[];
  risk_score: number;
  description: string;
  length: number;
}

export interface ComplianceFramework {
  framework_id: string;
  name: string;
  version: string;
  description: string;
  industry: string;
  mandatory: boolean;
  certification: boolean;
  categories: string[];
  total_controls: number;
  automated_controls: number;
  manual_controls: number;
}

export interface ComplianceAssessment {
  assessment_id: string;
  framework_id: string;
  framework_name: string;
  framework_version: string;
  assessed_at: number;
  total_controls: number;
  passed: number;
  failed: number;
  manual: number;
  not_applicable: number;
  not_assessed: number;
  score: number;
  category_scores: Record<string, Record<string, number>>;
  failed_controls: FailedControl[];
}

export interface FailedControl {
  control_id: string;
  title: string;
  description: string;
  category: string;
  priority: string;
  failing_finding_count: number;
  highest_severity: string;
  guidance: string;
  references: string[];
}

export interface AuditEntry {
  entry_id: string;
  tenant_id: string;
  timestamp: number;
  actor_type: string;
  actor_id: string;
  actor_ip?: string;
  category: string;
  action: string;
  outcome: string;
  severity: string;
  target_type: string;
  target_id?: string;
  target_name?: string;
  description: string;
  details: Record<string, unknown>;
  sequence: number;
  prev_hash: string;
  entry_hash: string;
  signature: string;
}

export interface AIResponse {
  conversation_id: string;
  message_id: string;
  response: string;
  citations: AICitation[];
  suggested_actions: AIAction[];
  intent: string;
  model: string;
}

export interface AICitation {
  citation_id: string;
  source_type: string;
  source_id: string;
  title: string;
  snippet: string;
  relevance_score: number;
}

export interface AIAction {
  type: string;
  label: string;
  [key: string]: unknown;
}

export interface NotificationChannel {
  channel_type: string;
  display_name: string;
}

export interface NotificationResult {
  notification_id: string;
  status: string;
  delivery_results: Array<{
    channel: string;
    success: boolean;
    error?: string;
    message_id?: string;
    attempted_at: number;
  }>;
}

export interface ConversationSummary {
  conversation_id: string;
  title: string;
  created_at: number;
  updated_at: number;
  message_count: number;
}

export interface GatewayStats {
  event_bus: {
    events_published: number;
    events_delivered: number;
    events_failed: number;
    events_dlq: number;
    outbox_size: number;
    dlq_size: number;
    subscriber_count: number;
  };
  notification: {
    total_sent: number;
    total_failed: number;
    total_suppressed: number;
    by_channel: Record<string, number>;
  };
  ai: {
    queries_total: number;
    avg_response_ms: number;
    queries_by_intent: Record<string, number>;
    active_conversations: number;
    vector_store: Record<string, unknown>;
  };
}

// ═══════════════════════════════════════════════════════════════
// Gateway Client
// ═══════════════════════════════════════════════════════════════

class GatewayClient {
  public token: string | null = null;
  public user: User | null = null;

  constructor() {
    if (typeof window !== "undefined") {
      this.token = localStorage.getItem("gateway_token");
      const userStr = localStorage.getItem("gateway_user");
      if (userStr) {
        try { this.user = JSON.parse(userStr); } catch { /* ignore */ }
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // Authentication
  // ═══════════════════════════════════════════════════════════════

  async login(email: string, password: string): Promise<LoginResponse> {
    // Use Next.js proxy that auto-starts gateway if needed
    const resp = await fetch("/api/gateway-login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
      cache: "no-store",
    });
    const data = await resp.json();
    if (!resp.ok) {
      throw new Error(data.error || data.detail || "Login failed");
    }
    this.token = data.token;
    this.user = {
      user_id: data.user.id,
      tenant_id: "org-default",
      email: data.user.email,
      name: data.user.name,
      role: data.user.role,
      status: "active",
      created_at: 0,
      last_login: 0,
    };
    if (typeof window !== "undefined") {
      localStorage.setItem("gateway_token", this.token!);
      localStorage.setItem("gateway_user", JSON.stringify(this.user));
    }
    return {
      token: data.token,
      user: this.user,
      expires_in: 86400,
    };
  }

  logout(): void {
    this.token = null;
    this.user = null;
    if (typeof window !== "undefined") {
      localStorage.removeItem("gateway_token");
      localStorage.removeItem("gateway_user");
    }
  }

  getToken(): string | null { return this.token; }
  getUser(): User | null { return this.user; }
  isAuthenticated(): boolean { return !!this.token; }

  // ═══════════════════════════════════════════════════════════════
  // Cloud Accounts
  // ═══════════════════════════════════════════════════════════════

  async listCloudAccounts(): Promise<CloudAccount[]> {
    const resp = await this.request("/v1/cloud-accounts");
    return resp.json();
  }

  async addCloudAccount(data: {
    name: string;
    provider: string;
    external_id: string;
    credential_type: string;
    role_arn?: string;
    regions?: string[];
  }): Promise<CloudAccount> {
    const resp = await this.request("/v1/cloud-accounts", {
      method: "POST",
      body: JSON.stringify(data),
    });
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // Scans
  // ═══════════════════════════════════════════════════════════════

  async triggerScan(cloudAccountId: string, scanners: string[] = ["iam", "s3", "sg", "ec2", "eks"]): Promise<{ scan_id: string; status: string }> {
    const resp = await this.request("/v1/scans", {
      method: "POST",
      body: JSON.stringify({ cloud_account_id: cloudAccountId, scanners }),
    });
    return resp.json();
  }

  async listScans(limit = 50): Promise<ScanRecord[]> {
    const resp = await this.request(`/v1/scans?limit=${limit}`);
    return resp.json();
  }

  async getScan(scanId: string): Promise<ScanDetail> {
    const resp = await this.request(`/v1/scans/${scanId}`);
    return resp.json();
  }

  async pollScanUntilDone(scanId: string, timeoutMs = 30000, intervalMs = 1000): Promise<ScanDetail> {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const scan = await this.getScan(scanId);
      if (scan.status === "completed" || scan.status === "failed") {
        return scan;
      }
      await new Promise(r => setTimeout(r, intervalMs));
    }
    throw new Error("Scan polling timed out");
  }

  // ═══════════════════════════════════════════════════════════════
  // Compliance
  // ═══════════════════════════════════════════════════════════════

  async listFrameworks(): Promise<ComplianceFramework[]> {
    const resp = await this.request("/v1/compliance/frameworks");
    return resp.json();
  }

  async assessCompliance(frameworkId: string, scanId?: string): Promise<ComplianceAssessment> {
    const resp = await this.request("/v1/compliance/assess", {
      method: "POST",
      body: JSON.stringify({ framework_id: frameworkId, scan_id: scanId }),
    });
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // Audit
  // ═══════════════════════════════════════════════════════════════

  async queryAudit(params: {
    category?: string;
    action?: string;
    actor_id?: string;
    start_time?: number;
    end_time?: number;
    severity?: string;
    limit?: number;
    offset?: number;
  } = {}): Promise<AuditEntry[]> {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null) qs.append(k, String(v));
    }
    const resp = await this.request(`/v1/audit?${qs}`);
    return resp.json();
  }

  async verifyAuditChain(): Promise<{ valid: boolean; verified_count: number; first_break_sequence?: number; reason?: string }> {
    const resp = await this.request("/v1/audit/verify");
    return resp.json();
  }

  async exportAuditChain(): Promise<Record<string, unknown>> {
    const resp = await this.request("/v1/audit/export");
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // AI Copilot
  // ═══════════════════════════════════════════════════════════════

  async askAI(message: string, conversationId?: string): Promise<AIResponse> {
    const resp = await this.request("/v1/ai/ask", {
      method: "POST",
      body: JSON.stringify({ message, conversation_id: conversationId }),
    });
    return resp.json();
  }

  async listConversations(limit = 50): Promise<ConversationSummary[]> {
    const resp = await this.request(`/v1/ai/conversations?limit=${limit}`);
    return resp.json();
  }

  async getConversation(conversationId: string): Promise<{
    conversation_id: string;
    title: string;
    messages: Array<{
      role: string;
      content: string;
      timestamp: number;
      citations: AICitation[];
      suggested_actions: AIAction[];
    }>;
  }> {
    const resp = await this.request(`/v1/ai/conversations/${conversationId}`);
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // Notifications
  // ═══════════════════════════════════════════════════════════════

  async listNotificationChannels(): Promise<NotificationChannel[]> {
    const resp = await this.request("/v1/notifications/channels");
    return resp.json();
  }

  async configureNotificationChannel(channelType: string, config: Record<string, unknown>): Promise<{ status: string; channel: string }> {
    const resp = await this.request("/v1/notifications/channels/configure", {
      method: "POST",
      body: JSON.stringify({ channel_type: channelType, config }),
    });
    return resp.json();
  }

  async sendNotification(data: {
    title: string;
    message: string;
    priority?: string;
    severity?: string;
    category?: string;
    resource_type?: string;
    resource_id?: string;
    resource_name?: string;
    target_channels?: string[];
  }): Promise<NotificationResult> {
    const resp = await this.request("/v1/notifications/send", {
      method: "POST",
      body: JSON.stringify(data),
    });
    return resp.json();
  }

  async notificationStats(): Promise<{ total_sent: number; total_failed: number; total_suppressed: number; by_channel: Record<string, number> }> {
    const resp = await this.request("/v1/notifications/stats");
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // Users
  // ═══════════════════════════════════════════════════════════════

  async listUsers(): Promise<User[]> {
    const resp = await this.request("/v1/users");
    return resp.json();
  }

  async createUser(data: { email: string; name: string; password: string; role?: string }): Promise<User> {
    const resp = await this.request("/v1/users", {
      method: "POST",
      body: JSON.stringify(data),
    });
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // System
  // ═══════════════════════════════════════════════════════════════

  async health(): Promise<{ status: string; version: string; engines: Record<string, string>; stats: GatewayStats }> {
    const resp = await this.request("/health", { auth: false });
    return resp.json();
  }

  async eventStats(): Promise<GatewayStats["event_bus"] & { by_channel?: Record<string, number> }> {
    const resp = await this.request("/v1/events/stats");
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // Posture Score
  // ═══════════════════════════════════════════════════════════════

  async calculatePosture(data: {
    compliance_data?: Record<string, unknown>;
    vulnerability_data?: Record<string, unknown>;
    exposure_data?: Record<string, unknown>;
    identity_data?: Record<string, unknown>;
    data_protection_data?: Record<string, unknown>;
    detection_data?: Record<string, unknown>;
    industry?: string;
  }): Promise<any> {
    const resp = await this.request("/v1/posture/calculate", {
      method: "POST",
      body: JSON.stringify(data),
    });
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // Real-time Detection
  // ═══════════════════════════════════════════════════════════════

  async listDetections(limit = 100): Promise<any[]> {
    const resp = await this.request(`/v1/detection/detections?limit=${limit}`);
    return resp.json();
  }

  async getDetectionStats(): Promise<any> {
    const resp = await this.request("/v1/detection/stats");
    return resp.json();
  }

  async listDetectionRules(): Promise<any[]> {
    const resp = await this.request("/v1/detection/rules");
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // Threat Intelligence
  // ═══════════════════════════════════════════════════════════════

  async getThreatIntelStats(): Promise<any> {
    const resp = await this.request("/v1/threat-intel/stats");
    return resp.json();
  }

  async listThreatActors(): Promise<any[]> {
    const resp = await this.request("/v1/threat-intel/threat-actors");
    return resp.json();
  }

  async queryThreatIntel(value: string): Promise<any> {
    const resp = await this.request("/v1/threat-intel/query", {
      method: "POST",
      body: JSON.stringify({ value }),
    });
    return resp.json();
  }

  async listThreatIntelAlerts(limit = 50): Promise<any[]> {
    const resp = await this.request(`/v1/threat-intel/alerts?limit=${limit}`);
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // Vulnerability Management
  // ═══════════════════════════════════════════════════════════════

  async getCVEStats(): Promise<any> {
    const resp = await this.request("/v1/vulnerability/cve-db-stats");
    return resp.json();
  }

  async scanVulnerabilities(data: {
    manifest_files: Array<{ path: string; content: string }>;
    artifact_name?: string;
    artifact_version?: string;
    artifact_type?: string;
    business_context?: Record<string, unknown>;
  }): Promise<any> {
    const resp = await this.request("/v1/vulnerability/scan", {
      method: "POST",
      body: JSON.stringify(data),
    });
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // CIEM
  // ═══════════════════════════════════════════════════════════════

  async listPrivescMethods(): Promise<any[]> {
    const resp = await this.request("/v1/ciem/escalation-methods");
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // Blast Radius
  // ═══════════════════════════════════════════════════════════════

  async getBlastRadiusGraphStats(): Promise<any> {
    const resp = await this.request("/v1/blast-radius/graph-stats");
    return resp.json();
  }

  async getCriticalPaths(maxPaths = 10): Promise<any[]> {
    const resp = await this.request(`/v1/blast-radius/critical-paths?max_paths=${maxPaths}`);
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // Reporting
  // ═══════════════════════════════════════════════════════════════

  async listReportTypes(): Promise<any[]> {
    const resp = await this.request("/v1/reports/types");
    return resp.json();
  }

  async generateReport(data: {
    report_type: string;
    format: string;
    title?: string;
    data?: Record<string, unknown>;
  }): Promise<any> {
    const resp = await this.request("/v1/reports/generate", {
      method: "POST",
      body: JSON.stringify(data),
    });
    return resp.json();
  }

  async listReports(limit = 50): Promise<any[]> {
    const resp = await this.request(`/v1/reports?limit=${limit}`);
    return resp.json();
  }

  // ═══════════════════════════════════════════════════════════════
  // Internal request helper
  // ═══════════════════════════════════════════════════════════════

  private async request(
    path: string,
    options: {
      method?: string;
      body?: string;
      auth?: boolean;
      headers?: Record<string, string>;
    } = {},
  ): Promise<Response> {
    const { method = "GET", body, auth = true, headers = {} } = options;

    // Route through Next.js proxy which auto-starts gateway if needed
    // and avoids CORS issues
    const proxyPath = path.startsWith("/") ? path.slice(1) : path;
    const proxyUrl = `/api/gateway-proxy/${proxyPath}`;

    const finalHeaders: Record<string, string> = {
      "Content-Type": "application/json",
      ...headers,
    };
    if (auth && this.token) {
      finalHeaders["Authorization"] = `Bearer ${this.token}`;
    }

    const resp = await fetch(proxyUrl, {
      method,
      headers: finalHeaders,
      body,
      cache: "no-store",
    });

    if (resp.status === 401 && auth) {
      // Token expired or invalid
      this.logout();
      if (typeof window !== "undefined") {
        window.location.reload();
      }
      throw new Error("Session expired");
    }

    if (!resp.ok) {
      let errorMsg = `Gateway error ${resp.status}`;
      try {
        const errBody = await resp.json();
        errorMsg = errBody.detail || errBody.error || errorMsg;
      } catch { /* ignore */ }
      throw new Error(errorMsg);
    }

    return resp;
  }
}

// Singleton instance
export const gateway = new GatewayClient();

// Helper to convert gateway scan detail to the ScanResult shape expected by existing components
export function scanDetailToScanResult(scan: ScanDetail): import("./scanner").ScanResult {
  const severityCounts: Record<string, number> = { critical: 0, high: 0, medium: 0, low: 0 };
  const categoryCounts: Record<string, number> = {};
  const complianceCounts: Record<string, number> = {};

  for (const f of scan.findings) {
    severityCounts[f.severity] = (severityCounts[f.severity] || 0) + 1;
    categoryCounts[f.category] = (categoryCounts[f.category] || 0) + 1;
    if (f.compliance) {
      // Split compliance string and count each
      for (const c of f.compliance.split(",").map(s => s.trim())) {
        if (c) complianceCounts[c] = (complianceCounts[c] || 0) + 1;
      }
    }
  }

  // Build positions for graph nodes (circular layout fallback)
  const nodes = (scan.attack_graph?.nodes || []).map((n, i) => ({
    id: n.id,
    label: n.label,
    type: n.type,
    region: n.region,
    findings_count: n.findings_count,
    severity: n.severity,
    severity_counts: n.severity_counts,
    position: {
      x: 100 + (i % 6) * 200,
      y: 80 + Math.floor(i / 6) * 160,
    },
  }));

  const edges = (scan.attack_graph?.edges || []).map((e, i) => ({
    id: `e-${i}`,
    source: e.source,
    target: e.target,
    label: e.type,
  }));

  const attackPaths = (scan.attack_graph?.attack_paths || []).map(p => ({
    path: p.path,
    findings: [],
    length: p.length,
  }));

  return {
    scan_id: scan.scan_id,
    status: scan.status,
    scan_mode: "real" as const,
    scanners_run: [],
    duration_ms: scan.completed_at && scan.started_at ? scan.completed_at - scan.started_at : 0,
    findings: scan.findings,
    resources: scan.assets.map(a => ({
      type: a.type,
      arn: a.arn,
      name: a.name,
      region: a.region,
      metadata: a.metadata,
    })),
    graph: {
      nodes,
      edges,
      attack_paths: attackPaths,
      summary: {
        total_nodes: nodes.length,
        total_edges: edges.length,
        critical_paths: attackPaths.length,
        internet_reachable_resources: 0,
      },
    },
    summary: {
      total_findings: scan.total_findings,
      total_resources: scan.total_assets,
      severity_counts: severityCounts as Record<Severity, number>,
      category_counts: categoryCounts,
      compliance_counts: complianceCounts,
      critical_attack_paths: attackPaths.length,
    },
  };
}
