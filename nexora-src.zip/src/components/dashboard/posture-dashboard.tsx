"use client";

import { useEffect, useState } from "react";
import { TrendingUp, TrendingDown, Minus, AlertTriangle, Zap, Target, Shield, Activity } from "lucide-react";
import { ResponsiveContainer, RadialBarChart, RadialBar, PolarAngleAxis, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from "recharts";
import { gateway } from "@/lib/gateway";

interface PostureData {
  overall_score: number;
  grade: string;
  trend: string;
  previous_score: number | null;
  score_change: number | null;
  industry_benchmark: number | null;
  percentile: number | null;
  potential_score_if_fixed: number;
  factors: Array<{
    factor_name: string;
    score: number;
    weight: number;
    weighted_score: number;
    findings_count: number;
    critical_findings: number;
    high_findings: number;
    details: Record<string, unknown>;
  }>;
  top_recommendations: Array<{ action: string; priority: string; impact: number; factor: string }>;
  quick_wins: Array<{ action: string; effort: string; impact: number; factor: string }>;
}

const GRADE_COLORS: Record<string, string> = {
  A: "#10b981", B: "#84cc16", C: "#f59e0b", D: "#f97316", F: "#ef4444",
};

export function PostureDashboard({ token }: { token: string }) {
  const [posture, setPosture] = useState<PostureData | null>(null);
  const [loading, setLoading] = useState(true);
  const [calculating, setCalculating] = useState(false);

  useEffect(() => {
    loadPosture();
  }, []);

  async function loadPosture() {
    setLoading(true);
    try {
      // Calculate posture with sample data (in production, gather from all engines)
      const result = await gateway.calculatePosture({
        compliance_data: { assessments: [{ score: 78, failed: 8, failed_controls: [{ highest_severity: "critical" }] }] },
        vulnerability_data: { total_vulnerabilities: 12, by_severity: { critical: 2, high: 4, medium: 4, low: 2 }, exploitable_count: 5, total_packages: 50 },
        exposure_data: { total_assets: 30, internet_exposed_count: 5, public_critical_count: 1, open_security_groups: 3 },
        identity_data: { total_principals: 25, admin_principals: 2, privilege_escalation_paths: 5, unused_permissions: 50, mfa_disabled_users: 3 },
        data_protection_data: { unencrypted_sensitive_assets: 2, public_sensitive_assets: 1, pii_exposed_count: 1, secrets_in_code: 3 },
        detection_data: { cloudtrail_enabled: true, config_enabled: true, guardduty_enabled: false, securityhub_enabled: false, cloudwatch_alarms: 5, detection_rules: 17 },
        industry: "technology",
      });
      setPosture(result);
    } catch (e) {
      console.error("Failed to load posture:", e);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-primary/30 border-t-primary" />
      </div>
    );
  }

  if (!posture) {
    return <div className="text-center py-20 text-muted-foreground">No posture data available</div>;
  }

  const trendIcon = posture.trend === "improving" ? <TrendingUp className="h-4 w-4 text-emerald-500" /> :
                    posture.trend === "degrading" ? <TrendingDown className="h-4 w-4 text-red-500" /> :
                    <Minus className="h-4 w-4 text-muted-foreground" />;

  const gradeColor = GRADE_COLORS[posture.grade] || "#6b7280";

  const radialData = [{ name: "Score", value: posture.overall_score, fill: gradeColor }];

  const factorData = posture.factors.map(f => ({
    name: f.factor_name,
    score: f.score,
    weight: f.weight * 100,
    findings: f.findings_count,
  }));

  return (
    <div className="space-y-6">
      {/* Hero score */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Overall Score Gauge */}
        <div className="rounded-lg border border-border/60 bg-card p-6">
          <h3 className="text-sm font-medium text-muted-foreground mb-2">Overall Posture Score</h3>
          <div className="relative h-48">
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart innerRadius="70%" outerRadius="100%" data={radialData} startAngle={90} endAngle={-270}>
                <PolarAngleAxis type="number" domain={[0, 100]} angleAxisId={0} tick={false} />
                <RadialBar background dataKey="value" cornerRadius={10} />
              </RadialBarChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl font-bold" style={{ color: gradeColor }}>{posture.overall_score}</span>
              <span className="text-sm text-muted-foreground">out of 100</span>
              <span className="mt-2 text-2xl font-bold" style={{ color: gradeColor }}>Grade {posture.grade}</span>
            </div>
          </div>
          <div className="flex items-center justify-center gap-2 mt-2 text-sm">
            {trendIcon}
            <span className="capitalize">{posture.trend}</span>
            {posture.score_change !== null && (
              <span className={posture.score_change > 0 ? "text-emerald-500" : "text-red-500"}>
                ({posture.score_change > 0 ? "+" : ""}{posture.score_change})
              </span>
            )}
          </div>
        </div>

        {/* Industry Benchmark */}
        <div className="rounded-lg border border-border/60 bg-card p-6">
          <h3 className="text-sm font-medium text-muted-foreground mb-2">Industry Benchmark</h3>
          <div className="space-y-4 mt-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Your Score</span>
                <span className="font-semibold" style={{ color: gradeColor }}>{posture.overall_score}</span>
              </div>
              <div className="h-3 rounded-full bg-muted overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${posture.overall_score}%`, backgroundColor: gradeColor }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Industry Average</span>
                <span className="font-semibold text-blue-500">{posture.industry_benchmark}</span>
              </div>
              <div className="h-3 rounded-full bg-muted overflow-hidden">
                <div className="h-full rounded-full bg-blue-500" style={{ width: `${posture.industry_benchmark}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Potential (if fixed)</span>
                <span className="font-semibold text-emerald-500">{posture.potential_score_if_fixed}</span>
              </div>
              <div className="h-3 rounded-full bg-muted overflow-hidden">
                <div className="h-full rounded-full bg-emerald-500" style={{ width: `${posture.potential_score_if_fixed}%` }} />
              </div>
            </div>
          </div>
          <div className="mt-4 p-3 rounded-md bg-muted/30">
            <p className="text-xs text-muted-foreground">You are in the</p>
            <p className="text-2xl font-bold">{posture.percentile}th percentile</p>
            <p className="text-xs text-muted-foreground">of technology companies</p>
          </div>
        </div>

        {/* Quick Wins */}
        <div className="rounded-lg border border-border/60 bg-card p-6">
          <h3 className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-2">
            <Zap className="h-4 w-4 text-amber-500" />
            Quick Wins
          </h3>
          <div className="space-y-3 mt-4">
            {posture.quick_wins.length === 0 && (
              <p className="text-sm text-muted-foreground">No quick wins available</p>
            )}
            {posture.quick_wins.map((qw, i) => (
              <div key={i} className="flex items-start gap-2">
                <div className="rounded bg-amber-500/10 px-2 py-1 text-xs text-amber-600 font-medium">
                  +{qw.impact}
                </div>
                <div className="flex-1">
                  <p className="text-sm">{qw.action}</p>
                  <p className="text-xs text-muted-foreground capitalize">{qw.effort} effort · {qw.factor}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Factor breakdown */}
      <div className="rounded-lg border border-border/60 bg-card p-6">
        <h3 className="text-sm font-medium text-muted-foreground mb-4">Factor Breakdown</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={factorData}>
              <XAxis dataKey="name" stroke="#888888" fontSize={11} angle={-15} textAnchor="end" height={60} />
              <YAxis domain={[0, 100]} stroke="#888888" fontSize={12} />
              <Tooltip
                contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}
                formatter={(value: number, name: string) => {
                  if (name === "score") return [value, "Score"];
                  return [value, name];
                }}
              />
              <Bar dataKey="score" radius={[4, 4, 0, 0]}>
                {factorData.map((entry, index) => {
                  const color = entry.score >= 80 ? "#10b981" : entry.score >= 60 ? "#f59e0b" : entry.score >= 40 ? "#f97316" : "#ef4444";
                  return <Cell key={index} fill={color} />;
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-3">
          {posture.factors.map((f, i) => (
            <div key={i} className="rounded-md border border-border/40 p-3">
              <div className="flex justify-between items-start">
                <span className="text-xs text-muted-foreground">{f.factor_name}</span>
                <span className="text-xs font-medium">{(f.weight * 100).toFixed(0)}% weight</span>
              </div>
              <div className="text-lg font-semibold mt-1">{f.score.toFixed(1)}/100</div>
              <div className="text-xs text-muted-foreground">
                {f.findings_count} findings ({f.critical_findings} critical)
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top recommendations */}
      <div className="rounded-lg border border-border/60 bg-card p-6">
        <h3 className="text-sm font-medium text-muted-foreground mb-4 flex items-center gap-2">
          <Target className="h-4 w-4 text-primary" />
          Top Recommendations
        </h3>
        <div className="space-y-2">
          {posture.top_recommendations.map((rec, i) => (
            <div key={i} className="flex items-center gap-3 rounded-md border border-border/40 p-3">
              <div className="rounded-full bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
                {rec.priority}
              </div>
              <div className="flex-1">
                <p className="text-sm">{rec.action}</p>
                <p className="text-xs text-muted-foreground">{rec.factor}</p>
              </div>
              <div className="text-sm font-medium text-emerald-500">+{rec.impact}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
