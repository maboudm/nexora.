"use client";

interface ScanPanelProps {
  title: string;
  description: string;
  onAction: () => void;
  actionLabel: string;
}

export function ScanPanel({ title, description, onAction, actionLabel }: ScanPanelProps) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center max-w-md mx-auto">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="text-sm text-muted-foreground mt-2">{description}</p>
      <button
        onClick={onAction}
        className="mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90"
      >
        {actionLabel}
      </button>
    </div>
  );
}
