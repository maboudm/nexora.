"use client";

import { useEffect, useState } from "react";
import { Activity, AlertTriangle, Shield, Zap, Clock, TrendingUp } from "lucide-react";
import { gateway } from "@/lib/gateway";

interface Detection {
  detection_id: string;
  rule_id: string;
  rule_name: string;
  severity: string;
  category: string;
  description: string;
  tactics: string[];
  techniques: string[];
  source_ip: string;
  aws_region: string;
  user_identity: Record<string, unknown>;
  recommended_actions: string[];
  detected_at: number;
}

interface DetectionStats {
  events_processed: number;
  events_matched: number;
  detections_triggered: number;
  by_severity: Record<string, number>;
  by_category: Record<string, number>;
  top_rules: Array<[string, number]>;
  processing_latency_ms_avg: number;
  active_rules: number;
}

const SEVERITY_COLORS: Record<string, string> = {
  critical: "#ef4444",
  high: "#f97316",
  medium: "#f59e0b",
  low: "#3b82f6",
  info: "#6b7280",
};

export function DetectionDashboard({ token }: { token: string }) {
  const [detections, setDetections] = useState<Detection[]>([]);
  const [stats, setStats] = useState<DetectionStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>("all");

  useEffect(() => {
    load();
    const id = setInterval(load, 5000); // refresh every 5s for real-time feel
    return () => clearInterval(id);
  }, []);

  async function load() {
    try {
      const [d, s] = await Promise.all([
        gateway.listDetections(50),
        gateway.getDetectionStats(),
      ]);
      setDetections(d);
      setStats(s);
    } catch (e) {
      console.error("Failed to load detections:", e);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-primary/30 border-t-primary" />
      </div>
    );
  }

  const filtered = filter === "all" ? detections : detections.filter(d => d.severity === filter);

  return (
    <div className="space-y-6">
      {/* Stats cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Events Processed</span>
            <Activity className="h-4 w-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{stats?.events_processed || 0}</div>
        </div>
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Detections</span>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{stats?.detections_triggered || 0}</div>
        </div>
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Active Rules</span>
            <Shield className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{stats?.active_rules || 0}</div>
        </div>
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Avg Latency</span>
            <Zap className="h-4 w-4 text-purple-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{stats?.processing_latency_ms_avg?.toFixed(2) || 0}ms</div>
        </div>
      </div>

      {/* Severity breakdown */}
      {stats && (
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <h3 className="text-sm font-medium text-muted-foreground mb-3">Detections by Severity</h3>
          <div className="flex gap-2">
            {["critical", "high", "medium", "low", "info"].map(sev => {
              const count = stats.by_severity[sev] || 0;
              const color = SEVERITY_COLORS[sev];
              return (
                <button
                  key={sev}
                  onClick={() => setFilter(filter === sev ? "all" : sev)}
                  className={`flex-1 rounded-md border p-3 text-left transition-colors ${filter === sev ? "border-primary" : "border-border/40 hover:border-border"}`}
                  style={filter === sev ? { borderColor: color } : {}}
                >
                  <div className="text-xs uppercase text-muted-foreground">{sev}</div>
                  <div className="text-2xl font-bold" style={{ color }}>{count}</div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Detections list */}
      <div className="rounded-lg border border-border/60 bg-card">
        <div className="flex items-center justify-between p-4 border-b border-border/40">
          <h3 className="text-sm font-medium">Real-time Detections {filter !== "all" && `(${filter})`}</h3>
          {filter !== "all" && (
            <button onClick={() => setFilter("all")} className="text-xs text-primary hover:underline">
              Clear filter
            </button>
          )}
        </div>
        {filtered.length === 0 ? (
          <div className="p-12 text-center text-muted-foreground text-sm">
            <Shield className="h-10 w-10 mx-auto mb-3 text-muted-foreground/40" />
            No detections {filter !== "all" && `of severity "${filter}"`}. The platform is secure.
          </div>
        ) : (
          <div className="divide-y divide-border/40">
            {filtered.slice(0, 20).map(d => {
              const color = SEVERITY_COLORS[d.severity] || "#6b7280";
              return (
                <div key={d.detection_id} className="p-4 hover:bg-muted/30 transition-colors">
                  <div className="flex items-start gap-3">
                    <div className="rounded-full px-2 py-1 text-xs font-medium uppercase" style={{ backgroundColor: `${color}20`, color }}>
                      {d.severity}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-medium truncate">{d.rule_name}</h4>
                        <span className="text-xs text-muted-foreground">·</span>
                        <span className="text-xs text-muted-foreground capitalize">{d.category}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{d.description}</p>
                      <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-muted-foreground">
                        {d.source_ip && (
                          <span>Source: <span className="font-mono">{d.source_ip}</span></span>
                        )}
                        {d.aws_region && (
                          <span>Region: {d.aws_region}</span>
                        )}
                        {d.techniques.length > 0 && (
                          <span>MITRE: {d.techniques.join(", ")}</span>
                        )}
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {new Date(d.detected_at).toLocaleTimeString()}
                        </span>
                      </div>
                      {d.recommended_actions.length > 0 && (
                        <div className="mt-2 rounded bg-amber-500/5 border border-amber-500/20 p-2 text-xs">
                          <span className="font-medium text-amber-700 dark:text-amber-400">Action: </span>
                          <span className="text-muted-foreground">{d.recommended_actions[0]}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Top triggered rules */}
      {stats && stats.top_rules && stats.top_rules.length > 0 && (
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <h3 className="text-sm font-medium text-muted-foreground mb-3 flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Most Triggered Rules
          </h3>
          <div className="space-y-2">
            {stats.top_rules.slice(0, 5).map(([ruleId, count]) => (
              <div key={ruleId} className="flex items-center gap-3">
                <span className="text-xs font-mono text-muted-foreground w-32 truncate">{ruleId}</span>
                <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full bg-primary"
                    style={{ width: `${(count / stats.top_rules[0][1]) * 100}%` }}
                  />
                </div>
                <span className="text-xs font-medium w-8 text-right">{count}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
