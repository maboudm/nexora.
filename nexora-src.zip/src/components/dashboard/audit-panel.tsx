"use client";

import { useEffect, useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import { Loader2, AlertCircle, ScrollText } from "lucide-react";

interface AuditProps {
  token: string;
}

interface AuditLog {
  id: string;
  action: string;
  resource: string | null;
  details: string;
  ipAddress: string | null;
  createdAt: string;
  user: { id: string; name: string; email: string } | null;
}

const ACTION_COLORS: Record<string, string> = {
  login: "text-blue-400",
  scan_triggered: "text-amber-400",
  scan_completed: "text-emerald-400",
  finding_updated: "text-purple-400",
  user_created: "text-cyan-400",
  remediation_updated: "text-orange-400",
};

export function AuditPanel({ token }: AuditProps) {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/audit", { headers: { Authorization: `Bearer ${token}` }, cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const d = await res.json();
      setLogs(d.logs || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load audit log");
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-md bg-primary/15 border border-primary/30 flex items-center justify-center text-primary">
            <ScrollText className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-sm font-semibold">Audit Log</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Immutable record of all user actions. Required for SOC2, ISO 27001, and PCI-DSS compliance.
            </p>
          </div>
        </div>
      </div>

      {loading && (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      {error && (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-700 dark:text-red-300 flex items-center gap-2">
          <AlertCircle className="h-4 w-4" /> {error}
        </div>
      )}

      {!loading && logs.length > 0 && (
        <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
          <div className="divide-y divide-border/40 max-h-[600px] overflow-y-auto">
            {logs.map((log) => {
              let details: Record<string, unknown> = {};
              try { details = JSON.parse(log.details); } catch {}
              return (
                <div key={log.id} className="p-3 hover:bg-accent/30 transition-colors">
                  <div className="flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={cn("text-xs font-mono font-semibold", ACTION_COLORS[log.action] || "text-muted-foreground")}>
                          {log.action}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          by {log.user?.name || "system"} ({log.user?.email || "—"})
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground font-mono mt-1">
                        {new Date(log.createdAt).toLocaleString()}
                        {log.resource && <span> · resource: {log.resource.slice(0, 50)}</span>}
                        {log.ipAddress && <span> · IP: {log.ipAddress}</span>}
                      </p>
                      {Object.keys(details).length > 0 && (
                        <pre className="text-[10px] font-mono text-muted-foreground mt-1 bg-muted/30 p-1.5 rounded">
                          {JSON.stringify(details, null, 2).slice(0, 300)}
                        </pre>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
