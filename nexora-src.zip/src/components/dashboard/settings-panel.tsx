"use client";

import { Play, Settings as SettingsIcon, ShieldCheck, Database, User } from "lucide-react";
import { cn } from "@/lib/utils";

interface SettingsPanelProps {
  scannerStatus: "up" | "down" | "checking";
  onRunScan: () => void;
  user: { id: string; email: string; name: string; role: string };
}

export function SettingsPanel({ scannerStatus, onRunScan, user }: SettingsPanelProps) {
  return (
    <div className="space-y-4 max-w-4xl">
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <div className="flex items-start gap-3 mb-4">
          <div className="h-9 w-9 rounded-md bg-primary/15 border border-primary/30 flex items-center justify-center text-primary">
            <SettingsIcon className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-sm font-semibold">Settings</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Configure the cloud scanning engine and view account information.
            </p>
          </div>
        </div>
      </div>

      {/* User account */}
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <h3 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-3 flex items-center gap-2">
          <User className="h-3.5 w-3.5" />
          Account
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <Detail label="Name" value={user.name} />
          <Detail label="Email" value={user.email} mono />
          <Detail label="Role" value={user.role} />
          <Detail label="User ID" value={user.id} mono />
        </div>
      </div>

      {/* AWS connection */}
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <h3 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-3 flex items-center gap-2">
          <Database className="h-3.5 w-3.5" />
          AWS Connection
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <Detail label="Account ID" value="123456789012" mono />
          <Detail label="Region" value="us-east-1" mono />
          <Detail label="Mode" value="boto3 → moto" mono />
          <Detail label="Endpoint" value="http://127.0.0.1:5000" mono />
        </div>
        <div className="mt-4 rounded-md border border-blue-500/30 bg-blue-500/5 p-3 text-xs text-blue-700 dark:text-blue-400">
          <p className="font-semibold mb-1">How scanning works</p>
          <p>
            The scanner uses real AWS SDK (<code className="font-mono">boto3</code>) calls to fetch IAM roles,
            S3 buckets, Security Groups, EC2 instances, and EKS clusters. In this development environment,
            these calls are routed to a local <code className="font-mono">moto</code> server (an AWS API emulator)
            running on port 5000. The same scanner code works against real AWS - only the{" "}
            <code className="font-mono">AWS_ENDPOINT_URL</code> environment variable differs.
          </p>
        </div>
      </div>

      {/* Scanner engine info */}
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <h3 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-3 flex items-center gap-2">
          <ShieldCheck className="h-3.5 w-3.5" />
          Scanner Engine
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <Detail label="Service" value="FastAPI :3030" mono />
          <Detail label="Status" value={scannerStatus} />
          <Detail label="Workers" value="1" mono />
          <Detail label="Python" value="3.12" mono />
          <Detail label="AWS SDK" value="boto3 1.35" mono />
          <Detail label="AWS Emulator" value="moto 5.2" mono />
          <Detail label="Graph Engine" value="networkx 3.3" mono />
          <Detail label="Rules" value="14 active" mono />
        </div>
      </div>

      {/* Auth info */}
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <h3 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-3">
          Authentication
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <Detail label="Method" value="JWT (HS256)" mono />
          <Detail label="Password Hash" value="bcrypt (10 rounds)" mono />
          <Detail label="Token Expiry" value="8 hours" mono />
          <Detail label="Secret" value="env: JWT_SECRET" mono />
        </div>
        <div className="mt-4 rounded-md border border-amber-500/30 bg-amber-500/5 p-3 text-xs text-amber-700 dark:text-amber-400">
          <p className="font-semibold mb-1">Default credentials</p>
          <p>
            Seeded on first run: <code className="font-mono">admin@sentinel.local</code> /{" "}
            <code className="font-mono">admin123</code>. Change the JWT_SECRET in{" "}
            <code className="font-mono">.env</code> before production deployment.
          </p>
        </div>
      </div>

      {/* Run scan */}
      <div className="rounded-lg border border-border/60 bg-card p-4 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium">Ready to scan?</p>
          <p className="text-xs text-muted-foreground mt-0.5">
            Triggers an async scan that fetches real AWS resources via boto3 and runs the CIS rule engine.
          </p>
        </div>
        <button
          onClick={onRunScan}
          disabled={scannerStatus === "down"}
          className={cn(
            "inline-flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors",
            "bg-primary text-primary-foreground hover:bg-primary/90",
            "disabled:opacity-50 disabled:cursor-not-allowed",
          )}
        >
          <Play className="h-4 w-4" />
          Run Scan Now
        </button>
      </div>
    </div>
  );
}

function Detail({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className={cn("text-sm mt-0.5", mono && "font-mono text-xs")}>{value}</p>
    </div>
  );
}
