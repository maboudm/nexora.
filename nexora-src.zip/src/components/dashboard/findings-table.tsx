"use client";

import { useMemo, useState } from "react";
import { ChevronDown, ChevronUp, Search, Filter, X } from "lucide-react";
import type { ScanResult, Finding, Severity } from "@/lib/scanner";
import { SEVERITY_COLORS, RESOURCE_TYPE_LABELS } from "@/lib/scanner";
import { cn } from "@/lib/utils";

interface FindingsTableProps {
  scanResult: ScanResult;
}

type SortKey = "severity" | "cvss_score" | "rule_id" | "category" | "resource_name";
type SortDir = "asc" | "desc";

const SEVERITY_RANK: Record<Severity, number> = { critical: 4, high: 3, medium: 2, low: 1 };

export function FindingsTable({ scanResult }: FindingsTableProps) {
  const { findings } = scanResult;
  const [search, setSearch] = useState("");
  const [sevFilter, setSevFilter] = useState<Severity | "all">("all");
  const [catFilter, setCatFilter] = useState<string>("all");
  const [sortKey, setSortKey] = useState<SortKey>("severity");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [selected, setSelected] = useState<Finding | null>(null);

  const categories = useMemo(() => {
    const set = new Set(findings.map((f) => f.category));
    return ["all", ...Array.from(set).sort()];
  }, [findings]);

  const filtered = useMemo(() => {
    let result = findings;
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (f) =>
          f.title.toLowerCase().includes(q) ||
          f.rule_id.toLowerCase().includes(q) ||
          f.resource_arn.toLowerCase().includes(q) ||
          f.resource_name.toLowerCase().includes(q) ||
          f.description.toLowerCase().includes(q),
      );
    }
    if (sevFilter !== "all") {
      result = result.filter((f) => f.severity === sevFilter);
    }
    if (catFilter !== "all") {
      result = result.filter((f) => f.category === catFilter);
    }
    // sort
    result = [...result].sort((a, b) => {
      let cmp = 0;
      switch (sortKey) {
        case "severity":
          cmp = SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity];
          break;
        case "cvss_score":
          cmp = a.cvss_score - b.cvss_score;
          break;
        case "rule_id":
          cmp = a.rule_id.localeCompare(b.rule_id);
          break;
        case "category":
          cmp = a.category.localeCompare(b.category);
          break;
        case "resource_name":
          cmp = a.resource_name.localeCompare(b.resource_name);
          break;
      }
      return sortDir === "asc" ? cmp : -cmp;
    });
    return result;
  }, [findings, search, sevFilter, catFilter, sortKey, sortDir]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortDir("desc");
    }
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="rounded-lg border border-border/60 bg-card p-4 space-y-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search rule id, resource, title, description…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-md border border-border/60 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>

          <div className="flex items-center gap-2 text-xs">
            <Filter className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="text-muted-foreground">Severity:</span>
            <div className="flex rounded-md border border-border/60 overflow-hidden">
              {(["all", "critical", "high", "medium", "low"] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setSevFilter(s)}
                  className={cn(
                    "px-2.5 py-1.5 font-medium transition-colors capitalize",
                    sevFilter === s
                      ? "bg-primary text-primary-foreground"
                      : "bg-card text-muted-foreground hover:bg-accent",
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-muted-foreground">Category:</span>
            <select
              value={catFilter}
              onChange={(e) => setCatFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-md border border-border/60 bg-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c === "all" ? "All" : c}
                </option>
              ))}
            </select>
          </div>

          <div className="text-xs text-muted-foreground ml-auto">
            {filtered.length} of {findings.length} findings
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 border-b border-border/60">
              <tr>
                <Th label="Rule" sortKey="rule_id" current={sortKey} dir={sortDir} onSort={toggleSort} />
                <Th label="Finding" />
                <Th label="Severity" sortKey="severity" current={sortKey} dir={sortDir} onSort={toggleSort} />
                <Th label="CVSS" sortKey="cvss_score" current={sortKey} dir={sortDir} onSort={toggleSort} />
                <Th label="Category" sortKey="category" current={sortKey} dir={sortDir} onSort={toggleSort} />
                <Th label="Resource" sortKey="resource_name" current={sortKey} dir={sortDir} onSort={toggleSort} />
                <Th label="Compliance" />
                <Th label="" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border/40">
              {filtered.map((f) => (
                <tr
                  key={f.id}
                  className="hover:bg-accent/30 transition-colors cursor-pointer"
                  onClick={() => setSelected(f)}
                >
                  <td className="px-3 py-2.5">
                    <span className="font-mono text-xs text-muted-foreground">{f.rule_id}</span>
                  </td>
                  <td className="px-3 py-2.5 max-w-md">
                    <p className="font-medium truncate">{f.title}</p>
                    <p className="text-xs text-muted-foreground truncate font-mono">{f.resource_arn}</p>
                  </td>
                  <td className="px-3 py-2.5">
                    <SeverityBadge severity={f.severity} />
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="font-mono text-xs tabular-nums">{f.cvss_score.toFixed(1)}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs capitalize">{f.category}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs">
                      <span className="text-muted-foreground">{RESOURCE_TYPE_LABELS[f.resource_type] || f.resource_type}</span>
                      <span className="block font-mono text-[11px] truncate max-w-[200px]">{f.resource_name}</span>
                    </span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                      {f.compliance}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelected(f);
                      }}
                      className="text-xs text-primary hover:underline"
                    >
                      Details
                    </button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-3 py-12 text-center text-muted-foreground text-sm">
                    No findings match the current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail drawer */}
      {selected && (
        <FindingDetailDrawer finding={selected} onClose={() => setSelected(null)} />
      )}
    </div>
  );
}

function Th({
  label,
  sortKey,
  current,
  dir,
  onSort,
}: {
  label: string;
  sortKey?: SortKey;
  current?: SortKey;
  dir?: SortDir;
  onSort?: (k: SortKey) => void;
}) {
  const sortable = !!sortKey && !!onSort;
  const active = sortable && current === sortKey;
  return (
    <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">
      {sortable ? (
        <button
          onClick={() => onSort!(sortKey!)}
          className="inline-flex items-center gap-1 hover:text-foreground transition-colors"
        >
          {label}
          {active && (dir === "asc" ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />)}
        </button>
      ) : (
        label
      )}
    </th>
  );
}

function SeverityBadge({ severity }: { severity: Severity }) {
  const colors = SEVERITY_COLORS[severity];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-medium uppercase tracking-wider",
        colors.bg,
        colors.text,
        "border",
        colors.border,
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", colors.dot)} />
      {severity}
    </span>
  );
}

function FindingDetailDrawer({ finding, onClose }: { finding: Finding; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative ml-auto w-full max-w-2xl bg-card border-l border-border/60 overflow-y-auto shadow-xl">
        <div className="sticky top-0 bg-card/95 backdrop-blur border-b border-border/60 px-6 py-4 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <SeverityBadge severity={finding.severity} />
              <span className="font-mono text-xs text-muted-foreground">{finding.rule_id}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                {finding.compliance}
              </span>
            </div>
            <h2 className="text-base font-semibold">{finding.title}</h2>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          <Section title="Description">
            <p className="text-sm text-muted-foreground leading-relaxed">{finding.description}</p>
          </Section>

          <Section title="Affected Resource">
            <div className="rounded-md border border-border/60 bg-muted/30 p-3 space-y-1 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground text-xs">Type</span>
                <span className="font-medium">{RESOURCE_TYPE_LABELS[finding.resource_type] || finding.resource_type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground text-xs">Name</span>
                <span className="font-mono text-xs">{finding.resource_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground text-xs">Region</span>
                <span className="font-mono text-xs">{finding.region}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground text-xs">ARN</span>
                <span className="font-mono text-[10px] break-all text-right max-w-[300px]">{finding.resource_arn}</span>
              </div>
            </div>
          </Section>

          <Section title="CVSS Score">
            <div className="flex items-center gap-3">
              <span className="text-3xl font-semibold tabular-nums">{finding.cvss_score.toFixed(1)}</span>
              <span className="text-sm text-muted-foreground">
                {finding.cvss_score >= 9 ? "Critical" : finding.cvss_score >= 7 ? "High" : finding.cvss_score >= 4 ? "Medium" : "Low"} severity
              </span>
            </div>
          </Section>

          <Section title="Remediation">
            <div className="rounded-md border border-primary/30 bg-primary/5 p-3 text-sm leading-relaxed">
              {finding.remediation}
            </div>
          </Section>

          <Section title="Evidence">
            <pre className="rounded-md border border-border/60 bg-background p-3 text-xs font-mono overflow-x-auto max-h-64">
              {JSON.stringify(finding.evidence, null, 2)}
            </pre>
          </Section>

          <Section title="Metadata">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Rule ID</p>
                <p className="font-mono text-xs mt-0.5">{finding.rule_id}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Compliance</p>
                <p className="font-mono text-xs mt-0.5">{finding.compliance}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Category</p>
                <p className="text-xs mt-0.5 capitalize">{finding.category}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Detected</p>
                <p className="text-xs mt-0.5 font-mono">
                  {new Date(finding.detected_at * 1000).toLocaleString()}
                </p>
              </div>
            </div>
          </Section>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-2">{title}</h3>
      {children}
    </div>
  );
}
