"use client";

import {
  AlertOctagon,
  ShieldAlert,
  Network,
  Boxes,
  TrendingUp,
  ArrowRight,
  Zap,
  Globe,
  Clock,
} from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell, PieChart, Pie } from "recharts";
import type { ScanResult, Severity } from "@/lib/scanner";
import { SEVERITY_COLORS } from "@/lib/scanner";
import { cn } from "@/lib/utils";

interface DashboardProps {
  scanResult: ScanResult;
  onNavigate: (tab: string) => void;
}

const SEVERITY_ORDER: Severity[] = ["critical", "high", "medium", "low"];

export function Dashboard({ scanResult, onNavigate }: DashboardProps) {
  const { summary } = scanResult;
  const sev = summary.severity_counts;
  const graph = scanResult.graph || { nodes: [], edges: [], attack_paths: [], summary: { total_nodes: 0, total_edges: 0, critical_paths: 0, internet_reachable_resources: 0 } };

  const sevData = SEVERITY_ORDER.map((s) => ({
    name: s.charAt(0).toUpperCase() + s.slice(1),
    key: s,
    value: sev[s] || 0,
    color: s === "critical" ? "#ef4444" : s === "high" ? "#f97316" : s === "medium" ? "#f59e0b" : "#3b82f6",
  }));

  const catData = Object.entries(summary.category_counts)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  const complianceData = Object.entries(summary.compliance_counts)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  return (
    <div className="space-y-6">
      {/* Hero stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Findings"
          value={summary.total_findings}
          icon={<ShieldAlert className="h-5 w-5" />}
          accent="primary"
          subtitle={`${sev.critical + sev.high} need attention`}
        />
        <StatCard
          title="Critical"
          value={sev.critical}
          icon={<AlertOctagon className="h-5 w-5" />}
          accent="critical"
          subtitle="Immediate remediation"
        />
        <StatCard
          title="Cloud Resources"
          value={summary.total_resources}
          icon={<Boxes className="h-5 w-5" />}
          accent="info"
          subtitle="Scanned"
        />
        <StatCard
          title="Attack Paths"
          value={summary.critical_attack_paths}
          icon={<Network className="h-5 w-5" />}
          accent="warning"
          subtitle="Internet → data"
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Severity breakdown */}
        <ChartCard
          title="Severity Breakdown"
          subtitle="Findings by CVSS-equivalent severity"
          action={
            <button
              onClick={() => onNavigate("findings")}
              className="text-xs text-primary hover:underline inline-flex items-center gap-1"
            >
              View all <ArrowRight className="h-3 w-3" />
            </button>
          }
        >
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sevData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" stroke="currentColor" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="currentColor" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {sevData.map((entry, idx) => (
                    <Cell key={idx} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* Category breakdown */}
        <ChartCard
          title="Findings by Category"
          subtitle="Distribution across security domains"
        >
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={catData} layout="vertical" margin={{ top: 5, right: 20, left: 30, bottom: 5 }}>
                <XAxis type="number" stroke="currentColor" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                <YAxis type="category" dataKey="name" stroke="currentColor" fontSize={11} tickLine={false} axisLine={false} width={70} />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]} fill="var(--primary)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* Compliance mapping */}
        <ChartCard
          title="Compliance Coverage"
          subtitle="Frameworks these findings map to"
        >
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={complianceData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={70}
                  innerRadius={40}
                  paddingAngle={2}
                >
                  {complianceData.map((_, idx) => (
                    <Cell
                      key={idx}
                      fill={["#10b981", "#3b82f6", "#f59e0b", "#a855f7", "#ec4899"][idx % 5]}
                    />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 flex flex-wrap gap-2 justify-center">
            {complianceData.map((c, i) => (
              <span key={c.name} className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
                <span
                  className="h-2 w-2 rounded-full"
                  style={{ background: ["#10b981", "#3b82f6", "#f59e0b", "#a855f7", "#ec4899"][i % 5] }}
                />
                {c.name} ({c.value})
              </span>
            ))}
          </div>
        </ChartCard>
      </div>

      {/* Top critical findings + attack paths */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Top critical findings */}
        <Card>
          <CardHeader
            title="Top Critical Findings"
            subtitle="Highest-risk items requiring immediate attention"
            icon={<Zap className="h-4 w-4 text-red-500" />}
          />
          <div className="divide-y divide-border/40">
            {scanResult.findings
              .filter((f) => f.severity === "critical")
              .slice(0, 5)
              .map((f) => (
                <div key={f.id} className="p-3 hover:bg-accent/30 transition-colors">
                  <div className="flex items-start gap-3">
                    <span className={cn("mt-1 h-2 w-2 rounded-full shrink-0", SEVERITY_COLORS[f.severity].dot)} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] text-muted-foreground">{f.rule_id}</span>
                        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{f.compliance}</span>
                      </div>
                      <p className="text-sm font-medium truncate">{f.title}</p>
                      <p className="text-xs text-muted-foreground font-mono mt-0.5 truncate">{f.resource_arn}</p>
                    </div>
                  </div>
                </div>
              ))}
            {scanResult.findings.filter((f) => f.severity === "critical").length === 0 && (
              <div className="p-6 text-center text-sm text-muted-foreground">
                No critical findings in this scan.
              </div>
            )}
          </div>
        </Card>

        {/* Attack paths */}
        <Card>
          <CardHeader
            title="Critical Attack Paths"
            subtitle="Lateral movement paths from internet to data"
            icon={<Network className="h-4 w-4 text-amber-500" />}
            action={
              <button
                onClick={() => onNavigate("graph")}
                className="text-xs text-primary hover:underline inline-flex items-center gap-1"
              >
                View graph <ArrowRight className="h-3 w-3" />
              </button>
            }
          />
          <div className="divide-y divide-border/40 max-h-80 overflow-y-auto">
            {graph.attack_paths.length === 0 && (
              <div className="p-6 text-center text-sm text-muted-foreground">
                No internet-reachable attack paths detected.
              </div>
            )}
            {graph.attack_paths.slice(0, 6).map((path, i) => (
              <div key={i} className="p-3">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
                    Path {i + 1} · {path.length} hops
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/15 text-red-400 font-mono">
                    {path.findings.length} findings
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-1 text-xs">
                  {path.path.map((node, idx) => {
                    const isLast = idx === path.path.length - 1;
                    const isInternet = node.includes("internet");
                    return (
                      <span key={idx} className="inline-flex items-center gap-1">
                        <span
                          className={cn(
                            "px-1.5 py-0.5 rounded font-mono text-[10px]",
                            isInternet
                              ? "bg-red-500/15 text-red-400"
                              : isLast
                                ? "bg-amber-500/15 text-amber-400"
                                : "bg-muted text-muted-foreground",
                          )}
                        >
                          {node.split("/").pop()?.split(":").pop() || node}
                        </span>
                        {!isLast && <ArrowRight className="h-3 w-3 text-muted-foreground/50" />}
                      </span>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Scan metadata */}
      <Card>
        <CardHeader
          title="Scan Metadata"
          subtitle="Technical details about this scan run"
          icon={<Clock className="h-4 w-4 text-muted-foreground" />}
        />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 text-sm">
          <Meta label="Scan ID" value={scanResult.scan_id} mono />
          <Meta label="Duration" value={`${scanResult.duration_ms} ms`} />
          <Meta label="Mode" value={scanResult.scan_mode} />
          <Meta label="Scanners" value={scanResult.scanners_run.join(", ")} />
          <Meta label="Resources" value={String(summary.total_resources)} />
          <Meta label="Findings" value={String(summary.total_findings)} />
          <Meta label="Graph Nodes" value={String(graph.summary.total_nodes)} />
          <Meta label="Graph Edges" value={String(graph.summary.total_edges)} />
        </div>
      </Card>
    </div>
  );
}

// ---------- helpers ----------

function StatCard({
  title,
  value,
  icon,
  subtitle,
  accent,
}: {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  subtitle?: string;
  accent: "primary" | "critical" | "warning" | "info";
}) {
  const accentMap = {
    primary: "text-primary bg-primary/10 border-primary/20",
    critical: "text-red-500 bg-red-500/10 border-red-500/20",
    warning: "text-amber-500 bg-amber-500/10 border-amber-500/20",
    info: "text-blue-500 bg-blue-500/10 border-blue-500/20",
  };
  return (
    <div className="rounded-lg border border-border/60 bg-card p-4 hover:border-border transition-colors">
      <div className="flex items-start justify-between">
        <div className="min-w-0">
          <p className="text-xs uppercase tracking-widest text-muted-foreground">{title}</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums">{value}</p>
          {subtitle && <p className="mt-1 text-xs text-muted-foreground">{subtitle}</p>}
        </div>
        <div className={cn("h-9 w-9 rounded-md border flex items-center justify-center", accentMap[accent])}>
          {icon}
        </div>
      </div>
    </div>
  );
}

function ChartCard({
  title,
  subtitle,
  action,
  children,
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-lg border border-border/60 bg-card p-4">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="text-sm font-semibold">{title}</h3>
          {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
        </div>
        {action}
      </div>
      {children}
    </div>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return <div className="rounded-lg border border-border/60 bg-card overflow-hidden">{children}</div>;
}

function CardHeader({
  title,
  subtitle,
  icon,
  action,
}: {
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex items-start justify-between p-4 pb-2 border-b border-border/40">
      <div className="flex items-start gap-3">
        {icon && <div className="mt-0.5">{icon}</div>}
        <div>
          <h3 className="text-sm font-semibold">{title}</h3>
          {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
        </div>
      </div>
      {action}
    </div>
  );
}

function Meta({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className={cn("text-sm mt-0.5", mono && "font-mono text-xs break-all")}>{value}</p>
    </div>
  );
}
