"use client";

import { useState, useEffect } from "react";
import { Bell, X, AlertTriangle, Activity } from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";

interface LiveAlertsBannerProps {
  token: string | null;
}

export function LiveAlertsBanner({ token }: LiveAlertsBannerProps) {
  const [showBanner, setShowBanner] = useState(false);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());

  const { connected, alerts } = useWebSocket({
    token,
    channels: ["detections", "threat_intel", "cwpp", "findings"],
  });

  // Show banner when there are new alerts
  const visibleAlerts = alerts.filter(a => !dismissed.has(a.timestamp + "_" + a.channel));
  const criticalAlerts = visibleAlerts.filter(a => a.data?.severity === "critical");
  const shouldShow = visibleAlerts.length > 0 && (criticalAlerts.length > 0 || showBanner);

  useEffect(() => {
    if (criticalAlerts.length > 0) {
      setShowBanner(true);
    }
  }, [criticalAlerts.length]);

  if (!token || !shouldShow) {
    return null;
  }

  const dismiss = (timestamp?: number, channel?: string) => {
    if (timestamp && channel) {
      setDismissed(prev => new Set(prev).add(timestamp + "_" + channel));
    } else {
      setShowBanner(false);
    }
  };

  const topAlert = visibleAlerts[0];

  return (
    <div className="fixed top-16 right-4 z-50 max-w-md">
      {connected && topAlert && (
        <div
          className="rounded-lg border shadow-lg p-4 animate-in slide-in-from-top"
          style={{
            borderColor: topAlert.data?.severity === "critical" ? "#ef4444" : "#f97316",
            backgroundColor: "hsl(var(--card))",
          }}
        >
          <div className="flex items-start gap-3">
            <div className="rounded-full p-2" style={{
              backgroundColor: topAlert.data?.severity === "critical" ? "#ef444420" : "#f9731620",
            }}>
              <AlertTriangle
                className="h-5 w-5"
                style={{ color: topAlert.data?.severity === "critical" ? "#ef4444" : "#f97316" }}
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-medium uppercase" style={{
                  color: topAlert.data?.severity === "critical" ? "#ef4444" : "#f97316",
                }}>
                  {topAlert.data?.severity || "alert"}
                </span>
                <span className="text-xs text-muted-foreground">·</span>
                <span className="text-xs text-muted-foreground">{topAlert.channel}</span>
              </div>
              <p className="text-sm font-medium">{topAlert.data?.title || topAlert.data?.rule_name || "Security Alert"}</p>
              {topAlert.data?.description && (
                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{topAlert.data.description}</p>
              )}
              <div className="flex items-center gap-2 mt-2">
                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Activity className="h-3 w-3" />
                  {visibleAlerts.length} alert{visibleAlerts.length > 1 ? "s" : ""}
                </span>
                <button
                  onClick={() => dismiss(topAlert.timestamp, topAlert.channel)}
                  className="text-xs text-primary hover:underline ml-auto"
                >
                  Dismiss
                </button>
              </div>
            </div>
            <button onClick={() => dismiss()} className="text-muted-foreground hover:text-foreground">
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
