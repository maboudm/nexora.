"use client";

import { useEffect, useState, useMemo } from "react";
import type { ScanRule, Severity } from "@/lib/scanner";
import { SEVERITY_COLORS } from "@/lib/scanner";
import { cn } from "@/lib/utils";
import { BookOpen, Search } from "lucide-react";

interface RulesPanelProps {
  token: string;
}

export function RulesPanel({ token }: RulesPanelProps) {
  const [rules, setRules] = useState<ScanRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [sevFilter, setSevFilter] = useState<Severity | "all">("all");
  const [catFilter, setCatFilter] = useState<string>("all");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/rules", {
          cache: "no-store",
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (!cancelled) {
          setRules(Array.isArray(data) ? data : []);
          setLoading(false);
        }
      } catch (e) {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : "Failed to load rules");
          setLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [token]);

  const categories = useMemo(() => {
    const set = new Set(rules.map((r) => r.category));
    return ["all", ...Array.from(set).sort()];
  }, [rules]);

  const filtered = useMemo(() => {
    let r = rules;
    if (search.trim()) {
      const q = search.toLowerCase();
      r = r.filter(
        (rule) =>
          rule.rule_id.toLowerCase().includes(q) ||
          rule.title.toLowerCase().includes(q) ||
          rule.description.toLowerCase().includes(q) ||
          rule.compliance.toLowerCase().includes(q),
      );
    }
    if (sevFilter !== "all") r = r.filter((rule) => rule.severity === sevFilter);
    if (catFilter !== "all") r = r.filter((rule) => rule.category === catFilter);
    return [...r].sort((a, b) => {
      const order = { critical: 4, high: 3, medium: 2, low: 1 } as const;
      return order[b.severity] - order[a.severity];
    });
  }, [rules, search, sevFilter, catFilter]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-muted-foreground">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary/30 border-t-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-700 dark:text-red-300">
        Failed to load rules: {error}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <div className="flex items-start gap-3 mb-4">
          <div className="h-9 w-9 rounded-md bg-primary/15 border border-primary/30 flex items-center justify-center text-primary">
            <BookOpen className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-sm font-semibold">Scanner Rules Library</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {rules.length} rules mapped to CIS AWS Benchmark, PCI-DSS, SOC 2, and ISO 27001. Each rule defines
              a specific misconfiguration pattern, its severity, CVSS-equivalent score, and remediation guidance.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search rules…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-md border border-border/60 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-muted-foreground">Severity:</span>
            <div className="flex rounded-md border border-border/60 overflow-hidden">
              {(["all", "critical", "high", "medium", "low"] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setSevFilter(s)}
                  className={cn(
                    "px-2.5 py-1.5 font-medium transition-colors capitalize",
                    sevFilter === s
                      ? "bg-primary text-primary-foreground"
                      : "bg-card text-muted-foreground hover:bg-accent",
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-muted-foreground">Category:</span>
            <select
              value={catFilter}
              onChange={(e) => setCatFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-md border border-border/60 bg-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c === "all" ? "All" : c}
                </option>
              ))}
            </select>
          </div>
          <div className="text-xs text-muted-foreground ml-auto">{filtered.length} rules</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filtered.map((rule) => {
          const colors = SEVERITY_COLORS[rule.severity];
          return (
            <div
              key={rule.rule_id}
              className={cn(
                "rounded-lg border bg-card p-4 hover:border-border transition-colors",
                colors.border,
              )}
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span className={cn("h-2 w-2 rounded-full shrink-0", colors.dot)} />
                  <span className="font-mono text-xs text-muted-foreground">{rule.rule_id}</span>
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    {rule.compliance}
                  </span>
                </div>
                <span
                  className={cn(
                    "inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium uppercase tracking-wider",
                    colors.bg,
                    colors.text,
                  )}
                >
                  {rule.severity}
                </span>
              </div>
              <h3 className="text-sm font-semibold mb-1">{rule.title}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed mb-3">{rule.description}</p>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">
                  Category: <span className="capitalize text-foreground">{rule.category}</span>
                </span>
                <span className="font-mono tabular-nums">CVSS {rule.cvss_score.toFixed(1)}</span>
              </div>
              <div className="mt-3 pt-3 border-t border-border/40">
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Remediation</p>
                <p className="text-xs leading-relaxed">{rule.remediation}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
