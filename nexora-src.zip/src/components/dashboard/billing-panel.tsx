"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Check, X, Sparkles, Crown, Building2, Rocket, Zap, Loader2,
  TrendingUp, ArrowRight, Star,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface BillingPanelProps {
  token: string;
}

interface Tier {
  tier_id: string;
  name: string;
  price_monthly: number;
  price_yearly: number;
  limits: Record<string, any>;
  features: string[];
  description: string;
}

interface Subscription {
  subscription: {
    tier_id: string;
    tier_name: string;
    status: string;
    started_at: number;
    renewal_at: number;
  };
  tier: Tier;
  usage: {
    tier: string;
    tier_name: string;
    scan_count_this_month: number;
    scan_limit: number;
    days_until_renewal: number;
  };
}

export function BillingPanel({ token }: BillingPanelProps) {
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [upgrading, setUpgrading] = useState<string | null>(null);
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const tiersRes = await fetch("/api/gateway-proxy/v1/billing/tiers");
      const tiersData = await tiersRes.json();
      setTiers(tiersData);

      const subRes = await fetch("/api/gateway-proxy/v1/billing/subscription", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (subRes.ok) {
        setSubscription(await subRes.json());
      }
    } catch (err) {
      console.error("Failed to load billing:", err);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const upgrade = async (tierId: string) => {
    if (!confirm(`Upgrade to ${tierId}? In production, this redirects to Stripe checkout.`)) return;
    setUpgrading(tierId);
    try {
      const res = await fetch(`/api/gateway-proxy/v1/billing/upgrade?tier_id=${tierId}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        await load();
      }
    } catch (err) {
      console.error("Upgrade failed:", err);
    } finally {
      setUpgrading(null);
    }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin" /></div>;

  const currentTier = subscription?.subscription.tier_id || "free";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold tracking-tight">Simple, transparent pricing</h2>
        <p className="text-sm text-muted-foreground mt-2 max-w-2xl mx-auto">
          Start free, upgrade when you need more. No credit card required for Free tier.
          Cancel anytime. Prices in USD.
        </p>
      </div>

      {/* Billing cycle toggle */}
      <div className="flex items-center justify-center gap-3">
        <button
          onClick={() => setBillingCycle("monthly")}
          className={cn(
            "px-4 py-1.5 rounded-lg text-sm font-medium transition-colors",
            billingCycle === "monthly" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent"
          )}
        >
          Monthly
        </button>
        <button
          onClick={() => setBillingCycle("yearly")}
          className={cn(
            "px-4 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-2",
            billingCycle === "yearly" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent"
          )}
        >
          Yearly
          <span className="text-xs px-1.5 py-0.5 rounded bg-green-500/20 text-green-400">2 months free</span>
        </button>
      </div>

      {/* Current plan banner */}
      {subscription && (
        <div className="bg-card border border-border rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-sm text-muted-foreground">Current plan</div>
            <div className="text-xl font-bold">
              {subscription.subscription.tier_name}
              <span className="text-sm text-muted-foreground ml-2 capitalize">({subscription.subscription.status})</span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Renews in {subscription.usage.days_until_renewal} days</div>
            <div className="text-sm">
              Scans this month: <span className="font-bold">{subscription.usage.scan_count_this_month}</span>
              {subscription.usage.scan_limit > 0 && ` / ${subscription.usage.scan_limit}`}
              {subscription.usage.scan_limit === -1 && " / unlimited"}
            </div>
          </div>
        </div>
      )}

      {/* Tier cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {tiers.filter(t => t.tier_id !== "enterprise").map(tier => {
          const isCurrent = currentTier === tier.tier_id;
          const isPopular = tier.tier_id === "team"; // mid-market sweet spot
          const price = billingCycle === "monthly" ? tier.price_monthly : tier.price_yearly;
          const monthlyEquivalent = billingCycle === "yearly" && price > 0 ? Math.round(price / 12 / 100) : price / 100;

          return (
            <div
              key={tier.tier_id}
              className={cn(
                "relative bg-card border rounded-xl p-5 flex flex-col",
                isPopular ? "border-primary shadow-lg shadow-primary/10" : "border-border",
                isCurrent && "ring-2 ring-primary"
              )}
            >
              {isPopular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-primary text-primary-foreground text-xs font-bold rounded-full flex items-center gap-1">
                  <Star className="h-3 w-3" /> Most Popular
                </div>
              )}
              {isCurrent && (
                <div className="absolute -top-3 right-3 px-2 py-0.5 bg-green-500 text-white text-xs font-bold rounded-full">
                  Current
                </div>
              )}

              <div className="mb-3">
                <div className="flex items-center gap-2">
                  {tier.tier_id === "free" && <Rocket className="h-4 w-4 text-blue-400" />}
                  {tier.tier_id === "pro" && <Zap className="h-4 w-4 text-purple-400" />}
                  {tier.tier_id === "team" && <Sparkles className="h-4 w-4 text-orange-400" />}
                  {tier.tier_id === "business" && <Building2 className="h-4 w-4 text-green-400" />}
                  <h3 className="text-lg font-bold">{tier.name}</h3>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{tier.description}</p>
              </div>

              <div className="mb-4">
                {price === 0 ? (
                  <div className="text-3xl font-bold">Free</div>
                ) : price === -1 ? (
                  <div className="text-3xl font-bold">Custom</div>
                ) : (
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-bold">${monthlyEquivalent}</span>
                    <span className="text-sm text-muted-foreground">/mo</span>
                    {billingCycle === "yearly" && (
                      <span className="text-xs text-green-400 ml-1">billed yearly</span>
                    )}
                  </div>
                )}
              </div>

              <ul className="space-y-2 mb-5 flex-1">
                {tier.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs">
                    <Check className="h-3.5 w-3.5 text-green-400 mt-0.5 shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => upgrade(tier.tier_id)}
                disabled={isCurrent || upgrading === tier.tier_id}
                className={cn(
                  "w-full py-2 rounded-lg text-sm font-medium transition-colors",
                  isCurrent
                    ? "bg-muted text-muted-foreground cursor-default"
                    : isPopular
                    ? "bg-primary text-primary-foreground hover:bg-primary/90"
                    : "bg-background border border-border hover:bg-accent",
                  upgrading === tier.tier_id && "opacity-50"
                )}
              >
                {upgrading === tier.tier_id ? (
                  <Loader2 className="h-4 w-4 animate-spin mx-auto" />
                ) : isCurrent ? (
                  "Current Plan"
                ) : (
                  <span className="flex items-center justify-center gap-1">
                    Upgrade <ArrowRight className="h-3.5 w-3.5" />
                  </span>
                )}
              </button>
            </div>
          );
        })}
      </div>

      {/* Enterprise CTA */}
      <div className="bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/30 rounded-xl p-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-primary/10 rounded-xl">
            <Crown className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-bold">Enterprise</h3>
            <p className="text-sm text-muted-foreground">
              On-premise deployment, custom rules, 24/7 support, SOC2 audit assistance.
            </p>
          </div>
        </div>
        <a
          href="mailto:sales@sentinel.example?subject=Enterprise inquiry"
          className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 flex items-center gap-2"
        >
          Contact Sales <ArrowRight className="h-4 w-4" />
        </a>
      </div>

      {/* Feature comparison table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="p-4 border-b border-border">
          <h3 className="text-sm font-semibold">Feature comparison</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left p-3 font-medium">Feature</th>
                {tiers.filter(t => t.tier_id !== "enterprise").map(t => (
                  <th key={t.tier_id} className="text-center p-3 font-medium">{t.name}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              <FeatureRow label="Cloud accounts" tiers={tiers} getLimit={(t) => t.limits.max_cloud_accounts === -1 ? "Unlimited" : t.limits.max_cloud_accounts} />
              <FeatureRow label="Scans per month" tiers={tiers} getLimit={(t) => t.limits.max_scans_per_month === -1 ? "Unlimited" : t.limits.max_scans_per_month} />
              <FeatureRow label="Team members" tiers={tiers} getLimit={(t) => t.limits.max_users === -1 ? "Unlimited" : t.limits.max_users} />
              <FeatureRow label="Scheduled scans" tiers={tiers} getLimit={(t) => t.limits.scheduled_scans ? "✓" : "—"} />
              <FeatureRow label="Email alerts" tiers={tiers} getLimit={(t) => t.limits.scheduled_scans ? "✓" : "—"} />
              <FeatureRow label="Slack/Teams alerts" tiers={tiers} getLimit={(t) => t.limits.slack_alerts ? "✓" : "—"} />
              <FeatureRow label="Google OAuth SSO" tiers={tiers} getLimit={(t) => t.limits.sso ? "✓" : "—"} />
              <FeatureRow label="SAML SSO (Okta/AD)" tiers={tiers} getLimit={(t) => t.limits.sso ? "✓" : "—"} />
              <FeatureRow label="Audit log export" tiers={tiers} getLimit={(t) => t.limits.audit_export ? "✓" : "—"} />
              <FeatureRow label="Drift history" tiers={tiers} getLimit={(t) => t.limits.max_drift_history_days === -1 ? "Unlimited" : `${t.limits.max_drift_history_days} days`} />
              <FeatureRow label="Evidence retention" tiers={tiers} getLimit={(t) => t.limits.max_evidence_records === -1 ? "Unlimited" : t.limits.max_evidence_records.toLocaleString()} />
            </tbody>
          </table>
        </div>
      </div>

      {/* FAQ */}
      <div className="bg-card border border-border rounded-xl p-6">
        <h3 className="text-sm font-semibold mb-3">Frequently asked questions</h3>
        <div className="space-y-3 text-sm">
          <FAQItem
            q="Can I really use it for free forever?"
            a="Yes. The Free tier includes 1 cloud account, 5 scans per month, and all 2,064 security checks. It's not a trial — it's a permanent free tier."
          />
          <FAQItem
            q="What happens when I hit my scan limit?"
            a="You'll see an upgrade prompt. Your existing data is preserved. You can upgrade immediately or wait until next month when the counter resets."
          />
          <FAQItem
            q="Do I need a credit card for the Free tier?"
            a="No. The Free tier requires no payment information. You only need a credit card when upgrading to Pro or higher."
          />
          <FAQItem
            q="Can I cancel anytime?"
            a="Yes. Cancel with one click. You keep access until the end of your billing period, then automatically downgrade to Free."
          />
          <FAQItem
            q="Is my data secure?"
            a="Yes. We use JWT auth, multi-tenant isolation (your data is never mixed with other tenants), hash-chained audit logs, and SQLite with WAL mode. All credentials are encrypted at rest."
          />
          <FAQItem
            q="How is this different from Prowler?"
            a="Prowler is a CLI tool — Sentinel is a full SaaS platform with UI, scheduled scans, attack path analysis, evidence vault, workflow integration, and multi-tenant support. We use Prowler's 915 checks as our scanning backbone, then add the platform layer on top."
          />
          <FAQItem
            q="How is this different from Wiz?"
            a="Wiz is $30K-100K/year and includes agentless snapshot scanning, real-time monitoring, and SOC2 certification. Sentinel is $29-299/month and covers the same 2,064+ checks but without those enterprise features. Use Wiz if you're an enterprise with compliance requirements — use Sentinel if you want 90% of the value at 1% of the price."
          />
        </div>
      </div>
    </div>
  );
}

function FeatureRow({ label, tiers, getLimit }: {
  label: string;
  tiers: Tier[];
  getLimit: (t: Tier) => string | number;
}) {
  return (
    <tr className="border-b border-border/50 hover:bg-muted/20">
      <td className="p-3 text-muted-foreground">{label}</td>
      {tiers.filter(t => t.tier_id !== "enterprise").map(t => (
        <td key={t.tier_id} className="text-center p-3 font-medium">
          {getLimit(t)}
        </td>
      ))}
    </tr>
  );
}

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-border/50 pb-2">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center justify-between w-full text-left font-medium hover:text-primary"
      >
        {q}
        <span className="text-xs">{open ? "−" : "+"}</span>
      </button>
      {open && <p className="text-muted-foreground mt-2 text-xs">{a}</p>}
    </div>
  );
}
