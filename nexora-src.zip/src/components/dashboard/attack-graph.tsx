"use client";

import { useMemo, useState, useRef } from "react";
import type { ScanResult, GraphNode, GraphEdge } from "@/lib/scanner";
import { cn } from "@/lib/utils";
import { Maximize2, ZoomIn, ZoomOut, RotateCcw, Network as NetworkIcon } from "lucide-react";

interface AttackGraphProps {
  scanResult: ScanResult;
}

const NODE_COLORS: Record<string, { fill: string; stroke: string; text: string }> = {
  external: { fill: "#1f1518", stroke: "#ef4444", text: "#fca5a5" },
  aws_security_group: { fill: "#1a1f2e", stroke: "#3b82f6", text: "#93c5fd" },
  aws_iam_role: { fill: "#2a2014", stroke: "#f59e0b", text: "#fcd34d" },
  aws_s3_bucket: { fill: "#1a2a1f", stroke: "#10b981", text: "#86efac" },
  aws_eks_cluster: { fill: "#2a1a2a", stroke: "#a855f7", text: "#d8b4fe" },
  aws_ec2_instance: { fill: "#1f2a2a", stroke: "#06b6d4", text: "#67e8f9" },
};

const SEVERITY_NODE_SIZE: Record<string, number> = {
  external: 38,
  critical: 32,
  high: 28,
  medium: 24,
  low: 20,
};

export function AttackGraph({ scanResult }: AttackGraphProps) {
  const graph = scanResult.graph || { nodes: [], edges: [], attack_paths: [], summary: { total_nodes: 0, total_edges: 0, critical_paths: 0, internet_reachable_resources: 0 } };
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [highlightPath, setHighlightPath] = useState<number | null>(null);
  const dragRef = useRef<{ x: number; y: number; px: number; py: number } | null>(null);

  const bounds = useMemo(() => {
    if (graph.nodes.length === 0) return { minX: 0, minY: 0, maxX: 800, maxY: 600 };
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const n of graph.nodes) {
      const s = SEVERITY_NODE_SIZE[n.severity] ?? 24;
      minX = Math.min(minX, n.position.x - s);
      minY = Math.min(minY, n.position.y - s);
      maxX = Math.max(maxX, n.position.x + s);
      maxY = Math.max(maxY, n.position.y + s);
    }
    return { minX, minY, maxX: maxX + 40, maxY: maxY + 40 };
  }, [graph.nodes]);

  const width = Math.max(800, bounds.maxX - bounds.minX);
  const height = Math.max(500, bounds.maxY - bounds.minY);

  const highlightNodes = useMemo(() => {
    if (highlightPath === null) return null;
    const path = graph.attack_paths[highlightPath];
    return path ? new Set(path.path) : null;
  }, [highlightPath, graph.attack_paths]);

  const handleMouseDown = (e: React.MouseEvent) => {
    dragRef.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y };
    setIsDragging(true);
  };
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!dragRef.current) return;
    const dx = e.clientX - dragRef.current.x;
    const dy = e.clientY - dragRef.current.y;
    setPan({ x: dragRef.current.px + dx, y: dragRef.current.py + dy });
  };
  const handleMouseUp = () => {
    dragRef.current = null;
    setIsDragging(false);
  };

  return (
    <div className="space-y-4">
      {/* Header / controls */}
      <div className="rounded-lg border border-border/60 bg-card p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <NetworkIcon className="h-4 w-4" />
            Attack Path Graph
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            {graph.summary.total_nodes} resources · {graph.summary.total_edges} relationships ·{" "}
            <span className="text-red-400">{graph.summary.internet_reachable_resources}</span> internet-reachable ·{" "}
            <span className="text-amber-400">{graph.summary.critical_paths}</span> critical paths
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setZoom((z) => Math.max(0.4, z - 0.15))}
            className="p-1.5 rounded-md border border-border/60 hover:bg-accent"
            title="Zoom out"
          >
            <ZoomOut className="h-4 w-4" />
          </button>
          <span className="text-xs font-mono w-12 text-center">{Math.round(zoom * 100)}%</span>
          <button
            onClick={() => setZoom((z) => Math.min(3, z + 0.15))}
            className="p-1.5 rounded-md border border-border/60 hover:bg-accent"
            title="Zoom in"
          >
            <ZoomIn className="h-4 w-4" />
          </button>
          <button
            onClick={() => {
              setZoom(1);
              setPan({ x: 0, y: 0 });
            }}
            className="p-1.5 rounded-md border border-border/60 hover:bg-accent"
            title="Reset view"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Graph canvas */}
        <div className="lg:col-span-3 rounded-lg border border-border/60 bg-card overflow-hidden">
          <div
            className="relative overflow-auto"
            style={{ height: 600 }}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          >
            <svg
              width={width * zoom}
              height={height * zoom}
              viewBox={`${bounds.minX - 20} ${bounds.minY - 20} ${width + 40} ${height + 40}`}
              style={{ transform: `translate(${pan.x}px, ${pan.y}px)`, cursor: isDragging ? "grabbing" : "grab" }}
            >
              <defs>
                <marker
                  id="arrow"
                  viewBox="0 0 10 10"
                  refX="8"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto"
                >
                  <path d="M 0 0 L 10 5 L 0 10 z" fill="currentColor" className="text-muted-foreground/50" />
                </marker>
                <marker
                  id="arrow-active"
                  viewBox="0 0 10 10"
                  refX="8"
                  refY="5"
                  markerWidth="8"
                  markerHeight="8"
                  orient="auto"
                >
                  <path d="M 0 0 L 10 5 L 0 10 z" fill="#ef4444" />
                </marker>
              </defs>

              {/* Edges */}
              {graph.edges.map((edge: GraphEdge) => {
                const source = graph.nodes.find((n) => n.id === edge.source);
                const target = graph.nodes.find((n) => n.id === edge.target);
                if (!source || !target) return null;
                const isHighlighted =
                  highlightNodes && highlightNodes.has(edge.source) && highlightNodes.has(edge.target);
                return (
                  <g key={edge.id}>
                    <line
                      x1={source.position.x}
                      y1={source.position.y}
                      x2={target.position.x}
                      y2={target.position.y}
                      stroke={isHighlighted ? "#ef4444" : "currentColor"}
                      strokeOpacity={isHighlighted ? 0.8 : 0.2}
                      strokeWidth={isHighlighted ? 2 : 1}
                      strokeDasharray={isHighlighted ? "0" : "4 4"}
                      markerEnd={`url(#${isHighlighted ? "arrow-active" : "arrow"})`}
                    />
                    {isHighlighted && (
                      <text
                        x={(source.position.x + target.position.x) / 2}
                        y={(source.position.y + target.position.y) / 2 - 5}
                        fill="#fca5a5"
                        fontSize="9"
                        textAnchor="middle"
                        className="font-mono"
                      >
                        {edge.label}
                      </text>
                    )}
                  </g>
                );
              })}

              {/* Nodes */}
              {graph.nodes.map((node: GraphNode) => {
                const colors = NODE_COLORS[node.type] ?? NODE_COLORS.aws_security_group;
                const size = SEVERITY_NODE_SIZE[node.severity] ?? 24;
                const isSelected = selectedNode?.id === node.id;
                const isHighlighted = highlightNodes?.has(node.id);
                const isDimmed = highlightNodes !== null && !isHighlighted;
                return (
                  <g
                    key={node.id}
                    transform={`translate(${node.position.x}, ${node.position.y})`}
                    onClick={() => setSelectedNode(node)}
                    className="cursor-pointer"
                    opacity={isDimmed ? 0.25 : 1}
                  >
                    {/* Halo for critical nodes */}
                    {node.severity === "critical" && (
                      <circle r={size + 6} fill="none" stroke={colors.stroke} strokeOpacity="0.25" strokeWidth="2">
                        <animate attributeName="r" values={`${size + 4};${size + 8};${size + 4}`} dur="2s" repeatCount="indefinite" />
                      </circle>
                    )}
                    <circle
                      r={size}
                      fill={colors.fill}
                      stroke={isSelected ? "#fff" : isHighlighted ? "#ef4444" : colors.stroke}
                      strokeWidth={isSelected ? 2.5 : isHighlighted ? 2 : 1.5}
                    />
                    {/* Severity dot */}
                    {node.findings_count > 0 && (
                      <>
                        <circle cx={size * 0.6} cy={-size * 0.6} r={6} fill={node.severity === "critical" ? "#ef4444" : node.severity === "high" ? "#f97316" : "#f59e0b"} />
                        <text x={size * 0.6} y={-size * 0.6 + 3} textAnchor="middle" fill="#fff" fontSize="8" className="font-mono font-bold pointer-events-none">
                          {node.findings_count}
                        </text>
                      </>
                    )}
                    <text
                      y={size + 12}
                      fill={colors.text}
                      fontSize="10"
                      textAnchor="middle"
                      className="font-mono pointer-events-none select-none"
                    >
                      {node.label.length > 24 ? node.label.slice(0, 22) + "…" : node.label}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Side panel: attack paths */}
        <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
          <div className="p-3 border-b border-border/40">
            <h3 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold">
              Critical Attack Paths
            </h3>
            <p className="text-[10px] text-muted-foreground mt-0.5">Click to highlight in graph</p>
          </div>
          <div className="divide-y divide-border/40 max-h-[550px] overflow-y-auto">
            {graph.attack_paths.length === 0 && (
              <div className="p-4 text-center text-xs text-muted-foreground">
                No internet-reachable paths found.
              </div>
            )}
            {graph.attack_paths.map((path, i) => (
              <button
                key={i}
                onClick={() => setHighlightPath(highlightPath === i ? null : i)}
                className={cn(
                  "w-full text-left p-3 hover:bg-accent/40 transition-colors",
                  highlightPath === i && "bg-red-500/10 border-l-2 border-red-500",
                )}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
                    Path {i + 1}
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-red-500/15 text-red-400">
                    {path.length} hops · {path.findings.length} findings
                  </span>
                </div>
                <div className="space-y-1">
                  {path.path.map((nodeId, idx) => {
                    const node = graph.nodes.find((n) => n.id === nodeId);
                    const label = node?.label || nodeId.split("/").pop() || nodeId;
                    return (
                      <div key={idx} className="flex items-center gap-2 text-[11px]">
                        <span
                          className={cn(
                            "h-1.5 w-1.5 rounded-full",
                            idx === 0 ? "bg-red-500" : idx === path.path.length - 1 ? "bg-amber-500" : "bg-muted-foreground",
                          )}
                        />
                        <span className="font-mono truncate">{label}</span>
                      </div>
                    );
                  })}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Selected node detail */}
      {selectedNode && (
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold">Selected Node</h3>
            <button onClick={() => setSelectedNode(null)} className="text-xs text-muted-foreground hover:text-foreground">
              Clear
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <Detail label="Name" value={selectedNode.label} mono />
            <Detail label="Type" value={selectedNode.type} />
            <Detail label="Region" value={selectedNode.region} mono />
            <Detail label="Findings" value={String(selectedNode.findings_count)} />
          </div>
          <div className="mt-3">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">Severity Breakdown</p>
            <div className="flex gap-2">
              {(["critical", "high", "medium", "low"] as const).map((s) => (
                <span
                  key={s}
                  className={cn(
                    "inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs border",
                    s === "critical" && "bg-red-500/10 text-red-400 border-red-500/30",
                    s === "high" && "bg-orange-500/10 text-orange-400 border-orange-500/30",
                    s === "medium" && "bg-amber-500/10 text-amber-400 border-amber-500/30",
                    s === "low" && "bg-blue-500/10 text-blue-400 border-blue-500/30",
                  )}
                >
                  <span className="capitalize">{s}</span>
                  <span className="font-mono">{selectedNode.severity_counts[s] || 0}</span>
                </span>
              ))}
            </div>
          </div>
          <div className="mt-3">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">ARN</p>
            <p className="font-mono text-xs break-all text-muted-foreground">{selectedNode.id}</p>
          </div>
        </div>
      )}
    </div>
  );
}

function Detail({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className={cn("text-sm mt-0.5", mono && "font-mono text-xs")}>{value}</p>
    </div>
  );
}
