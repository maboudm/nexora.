"use client";

import { useEffect, useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import { FileText, Download, CheckCircle2, XCircle, Loader2, ShieldCheck } from "lucide-react";

interface ComplianceProps {
  token: string;
}

const FRAMEWORKS = ["CIS-AWS", "PCI-DSS", "SOC2", "ISO27001"] as const;
type Framework = typeof FRAMEWORKS[number];

interface ComplianceData {
  framework: string;
  scan_id: string;
  scan_date: string;
  generated_at: string;
  overall_status: string;
  controls: Array<{
    id: string;
    title: string;
    status: "passed" | "failed" | "no_data";
    findings: Array<{ id: string; ruleId: string; title: string; severity: string; resource: string }>;
  }>;
  summary: { total: number; passed: number; failed: number; compliance_percentage: number };
}

export function CompliancePanel({ token }: ComplianceProps) {
  const [selected, setSelected] = useState<Framework>("CIS-AWS");
  const [data, setData] = useState<ComplianceData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [downloading, setDownloading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/compliance?framework=${selected}`, {
        headers: { Authorization: `Bearer ${token}` },
        cache: "no-store",
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const d = await res.json();
      setData(d);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load compliance data");
    } finally {
      setLoading(false);
    }
  }, [token, selected]);

  useEffect(() => {
    load();
  }, [load]);

  const downloadPDF = async () => {
    setDownloading(true);
    try {
      const res = await fetch(`/api/compliance/${selected}/pdf`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `compliance-${selected}-${new Date().toISOString().slice(0, 10)}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to download PDF");
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <div className="flex items-start gap-3 mb-4">
          <div className="h-9 w-9 rounded-md bg-primary/15 border border-primary/30 flex items-center justify-center text-primary">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <h2 className="text-sm font-semibold">Compliance Reports</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Map security findings to compliance frameworks. Download audit-ready PDF reports for SOC2, PCI-DSS, ISO 27001, and CIS-AWS.
            </p>
          </div>
        </div>

        {/* Framework selector */}
        <div className="flex flex-wrap items-center gap-2">
          {FRAMEWORKS.map((fw) => (
            <button
              key={fw}
              onClick={() => setSelected(fw)}
              className={cn(
                "px-3 py-1.5 rounded-md text-xs font-medium transition-colors border",
                selected === fw
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card text-muted-foreground hover:bg-accent border-border/60",
              )}
            >
              {fw}
            </button>
          ))}
          <div className="ml-auto">
            <button
              onClick={downloadPDF}
              disabled={loading || downloading || !data}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium bg-primary/15 text-primary border border-primary/30 hover:bg-primary/25 disabled:opacity-50"
            >
              {downloading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
              Download PDF
            </button>
          </div>
        </div>
      </div>

      {loading && (
        <div className="flex items-center justify-center py-20">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary/30 border-t-primary" />
        </div>
      )}

      {error && (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {!loading && data && (
        <>
          {/* Overall status */}
          <div className="rounded-lg border border-border/60 bg-card p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-xs uppercase tracking-widest text-muted-foreground">{data.framework}</p>
                <p className="text-3xl font-bold tabular-nums mt-1">
                  {data.summary.compliance_percentage}%
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {data.summary.passed} of {data.summary.total} controls passing
                </p>
              </div>
              <div className={cn(
                "text-right",
                data.overall_status === "compliant" ? "text-emerald-500" : "text-red-500",
              )}>
                {data.overall_status === "compliant" ? (
                  <CheckCircle2 className="h-12 w-12" />
                ) : (
                  <XCircle className="h-12 w-12" />
                )}
                <p className="text-xs uppercase tracking-widest mt-1">
                  {data.overall_status === "compliant" ? "Compliant" : "Non-Compliant"}
                </p>
              </div>
            </div>
            {/* Progress bar */}
            <div className="h-3 rounded-full bg-muted overflow-hidden">
              <div
                className={cn(
                  "h-full transition-all",
                  data.summary.compliance_percentage >= 80 ? "bg-emerald-500" :
                  data.summary.compliance_percentage >= 60 ? "bg-amber-500" : "bg-red-500",
                )}
                style={{ width: `${data.summary.compliance_percentage}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Last assessed: {new Date(data.scan_date).toLocaleString()}
            </p>
          </div>

          {/* Controls list */}
          <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
            <div className="p-4 border-b border-border/40">
              <h3 className="text-sm font-semibold">Control Details</h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                Each control maps to one or more scanner rules. Failed controls list the findings that caused them to fail.
              </p>
            </div>
            <div className="divide-y divide-border/40">
              {data.controls.map((ctrl) => (
                <div key={ctrl.id} className="p-4">
                  <div className="flex items-start gap-3">
                    {ctrl.status === "passed" ? (
                      <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                          {ctrl.id}
                        </span>
                        <span className="text-sm font-medium">{ctrl.title}</span>
                      </div>
                      {ctrl.findings.length > 0 ? (
                        <div className="mt-2 space-y-1">
                          {ctrl.findings.map((f) => (
                            <div key={f.id} className="flex items-start gap-2 text-xs">
                              <span className={cn(
                                "px-1.5 py-0.5 rounded font-mono uppercase tracking-wider shrink-0",
                                f.severity === "critical" && "bg-red-500/15 text-red-400",
                                f.severity === "high" && "bg-orange-500/15 text-orange-400",
                                f.severity === "medium" && "bg-amber-500/15 text-amber-400",
                                f.severity === "low" && "bg-blue-500/15 text-blue-400",
                              )}>
                                {f.severity}
                              </span>
                              <span className="font-mono text-muted-foreground">{f.ruleId}</span>
                              <span className="flex-1">{f.title}</span>
                              <span className="font-mono text-muted-foreground truncate max-w-[200px]">{f.resource}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-emerald-500">No findings — control satisfied.</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
