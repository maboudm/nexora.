"use client";

import { useState, useEffect } from "react";
import { ShieldCheck, AlertCircle, Loader2, Server, Zap } from "lucide-react";

interface LoginScreenProps {
  onLogin: (token: string, user: { id: string; email: string; name: string; role: string }) => void;
  scannerStatus: "up" | "down" | "checking";
  useGateway?: boolean;
}

export function LoginScreen({ onLogin, scannerStatus, useGateway = false }: LoginScreenProps) {
  const [email, setEmail] = useState("admin@nexora.io");
  const [password, setPassword] = useState("admin123");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [gatewayUrl, setGatewayUrl] = useState("http://localhost:8000");
  const [backendMode, setBackendMode] = useState<"gateway" | "local" | "checking">("checking");

  // Detect which backend is available on mount
  useEffect(() => {
    const detect = async () => {
      // Try gateway first
      try {
        const gwUrl = process.env.NEXT_PUBLIC_GATEWAY_URL ||
          (typeof window !== "undefined" ? window.location.origin.replace(/:\d+$/, ":8000") : "http://localhost:8000");
        setGatewayUrl(gwUrl);
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 2000);
        const res = await fetch(`${gwUrl}/health`, { signal: controller.signal });
        clearTimeout(timeout);
        if (res.ok) {
          setBackendMode("gateway");
          return;
        }
      } catch {
        // Gateway unavailable
      }
      // Fall back to local Next.js API
      try {
        const res = await fetch("/api/health", { cache: "no-store" });
        if (res.ok) {
          setBackendMode("local");
          return;
        }
      } catch {
        // Local also unavailable
      }
      setBackendMode("gateway"); // default to gateway mode so user sees the helpful error
    };
    detect();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Always try the gateway-login proxy first — it auto-starts the gateway if needed
      const res = await fetch("/api/gateway-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const contentType = res.headers.get("content-type") || "";
      if (!contentType.includes("application/json")) {
        throw new Error("LOCAL_UNREACHABLE");
      }
      const data = await res.json();
      if (!res.ok) {
        if (data.gateway_starting) {
          throw new Error("GATEWAY_STARTING");
        }
        throw new Error(data.error || `Login failed (${res.status})`);
      }
      onLogin(data.token, data.user);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Login failed";
      if (msg === "GATEWAY_STARTING") {
        setError("Gateway is starting up. Please wait 5 seconds and click Sign in again.");
      } else if (msg === "LOCAL_UNREACHABLE" || msg.includes("Failed to fetch") || msg.includes("NetworkError")) {
        setError("Cannot connect to the server. Please wait 5 seconds and try again.");
      } else {
        setError(msg);
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background text-foreground p-4">
      <div className="w-full max-w-sm space-y-6">
        {/* Logo */}
        <div className="flex flex-col items-center gap-3">
          <div className="h-12 w-12 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center text-primary">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <div className="text-center">
            <h1 className="text-xl font-semibold">Nexora</h1>
            <p className="text-xs text-muted-foreground mt-1">
              Cloud-Native Application Protection Platform
            </p>
          </div>
        </div>

        {/* Backend status indicator */}
        <div className="flex items-center justify-center gap-2 text-xs">
          {backendMode === "checking" && (
            <span className="flex items-center gap-1.5 text-muted-foreground">
              <Loader2 className="h-3 w-3 animate-spin" />
              Detecting backend...
            </span>
          )}
          {backendMode === "gateway" && (
            <span className="flex items-center gap-1.5 text-emerald-500">
              <Server className="h-3 w-3" />
              Gateway mode (port 8000)
            </span>
          )}
          {backendMode === "local" && (
            <span className="flex items-center gap-1.5 text-blue-500">
              <Zap className="h-3 w-3" />
              Local mode (Next.js API)
            </span>
          )}
        </div>

        {/* Login form */}
        <form onSubmit={handleSubmit} className="space-y-3 rounded-lg border border-border/60 bg-card p-6">
          <div>
            <label className="text-xs uppercase tracking-widest text-muted-foreground block mb-1">
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-md border border-border/60 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>
          <div>
            <label className="text-xs uppercase tracking-widest text-muted-foreground block mb-1">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-md border border-border/60 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>

          {error && (
            <div className="rounded-md border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-700 dark:text-red-300 whitespace-pre-wrap font-mono">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || backendMode === "checking"}
            className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 rounded-md text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          >
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            {loading ? "Signing in…" : "Sign in"}
          </button>
        </form>

        {/* Default credentials hint */}
        <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-3 text-xs text-amber-700 dark:text-amber-400">
          <p className="font-semibold mb-1">Default credentials:</p>
          <p className="font-mono">
            {backendMode === "local" ? "admin@sentinel.local" : "admin@nexora.io"} / admin123
          </p>
        </div>

        {/* Quick start command */}
        <div className="rounded-md border border-border/60 bg-muted/30 p-3 text-xs">
          <p className="text-muted-foreground mb-1">Quick start (run in terminal):</p>
          <p className="font-mono text-foreground break-all">cd /home/z/my-project &amp;&amp; ./start-sentinel.sh</p>
        </div>
      </div>
    </div>
  );
}
