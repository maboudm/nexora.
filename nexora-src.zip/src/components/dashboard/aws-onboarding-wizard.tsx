"use client";

import { useState } from "react";
import {
  Cloud, ArrowRight, ArrowLeft, CheckCircle2, Loader2, Copy,
  ShieldCheck, AlertCircle, ExternalLink,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface AWSOnboardingWizardProps {
  token: string;
  onComplete?: () => void;
}

type Step = "intro" | "iam-role" | "connect" | "scan" | "done";

const STEPS: { id: Step; label: string }[] = [
  { id: "intro", label: "Introduction" },
  { id: "iam-role", label: "Create IAM Role" },
  { id: "connect", label: "Connect Account" },
  { id: "scan", label: "Run First Scan" },
  { id: "done", label: "Complete" },
];

export function AWSOnboardingWizard({ token, onComplete }: AWSOnboardingWizardProps) {
  const [step, setStep] = useState<Step>("intro");
  const [accountId, setAccountId] = useState("");
  const [roleName, setRoleName] = useState("NexoraScanner");
  const [regions, setRegions] = useState<string[]>(["us-east-1", "us-west-2"]);
  const [scanId, setScanId] = useState<string | null>(null);
  const [scanStatus, setScanStatus] = useState<"idle" | "running" | "done" | "error">("idle");
  const [scanResults, setScanResults] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const stepIndex = STEPS.findIndex(s => s.id === step);

  const goTo = (s: Step) => {
    setStep(s);
    setError(null);
  };

  // ─── IAM Role template ───
  const cfTemplate = `AWSTemplateFormatVersion: '2010-09-09'
Description: IAM role for Nexora scanner (read-only)

Resources:
  NexoraScannerRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: ${roleName}
      AssumeRolePolicyDocument:
        Version: '2012-10-17'
        Statement:
          - Effect: Allow
            Principal:
              AWS: arn:aws:iam::${accountId || "YOUR_ACCOUNT_ID"}:root
            Action: sts:AssumeRole
      ManagedPolicyArns:
        - arn:aws:iam::aws:policy/SecurityAudit
        - arn:aws:iam::aws:policy/ReadOnlyAccess

Outputs:
  RoleArn:
    Value: !GetAtt NexoraScannerRole.Arn
    Description: ARN of the Sentinel scanner role`;

  const cliCommand = `aws cloudformation deploy \\
  --template-file sentinel-scanner.yaml \\
  --stack-name sentinel-scanner-role \\
  --capabilities CAPABILITY_NAMED_IAM`;

  // ─── Connect account ───
  const connectAccount = async () => {
    setError(null);
    try {
      const res = await fetch("/api/gateway-proxy/v1/cloud-accounts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          provider: "aws",
          name: `AWS ${accountId}`,
          external_id: accountId,
          credential_type: "assume_role",
          role_arn: `arn:aws:iam::${accountId}:role/${roleName}`,
          regions,
        }),
      });
      if (!res.ok) throw new Error(await res.text());
      goTo("scan");
    } catch (err: any) {
      setError(err.message);
    }
  };

  // ─── Run scan ───
  const runScan = async () => {
    setScanStatus("running");
    setError(null);
    try {
      // Get cloud account
      const acctsRes = await fetch("/api/gateway-proxy/v1/cloud-accounts", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const accts = await acctsRes.json();
      if (!accts.length) throw new Error("No cloud accounts");
      const acctId = accts[0].account_id;

      // Trigger scan
      const scanRes = await fetch("/api/gateway-proxy/v1/scans", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          cloud_account_id: acctId,
          scanners: ["iam", "s3", "ec2", "rds", "eks", "lambda", "cloudtrail"],
        }),
      });
      const scanData = await scanRes.json();
      setScanId(scanData.scan_id);

      // Poll
      const poll = async () => {
        for (let i = 0; i < 60; i++) {
          await new Promise(r => setTimeout(r, 1500));
          const r = await fetch(`/api/gateway-proxy/v1/scans/${scanData.scan_id}`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          const d = await r.json();
          if (d.status === "completed") {
            setScanResults(d);
            setScanStatus("done");
            return;
          }
          if (d.status === "failed") {
            setError(d.error || "Scan failed");
            setScanStatus("error");
            return;
          }
        }
        setError("Scan timed out");
        setScanStatus("error");
      };
      poll();
    } catch (err: any) {
      setError(err.message);
      setScanStatus("error");
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Stepper */}
      <div className="flex items-center justify-between bg-card border border-border rounded-xl p-4">
        {STEPS.map((s, i) => (
          <div key={s.id} className="flex items-center flex-1">
            <div className={cn(
              "flex items-center justify-center w-8 h-8 rounded-full border-2 text-xs font-bold transition-colors",
              i < stepIndex ? "bg-green-500/20 border-green-500 text-green-400" :
              i === stepIndex ? "bg-primary border-primary text-primary-foreground" :
              "bg-background border-border text-muted-foreground"
            )}>
              {i < stepIndex ? <CheckCircle2 className="h-4 w-4" /> : i + 1}
            </div>
            <span className={cn(
              "ml-2 text-xs hidden sm:inline",
              i === stepIndex ? "text-foreground font-medium" : "text-muted-foreground"
            )}>
              {s.label}
            </span>
            {i < STEPS.length - 1 && (
              <div className={cn(
                "flex-1 h-0.5 mx-2 transition-colors",
                i < stepIndex ? "bg-green-500/50" : "bg-border"
              )} />
            )}
          </div>
        ))}
      </div>

      {/* Content */}
      <div className="bg-card border border-border rounded-xl p-6">
        {step === "intro" && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-orange-500/10 rounded-xl">
                <Cloud className="h-6 w-6 text-orange-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold">Connect your AWS account</h2>
                <p className="text-sm text-muted-foreground">3 minutes to your first scan</p>
              </div>
            </div>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-400 mt-0.5 shrink-0" />
                Sentinel uses an IAM role with <strong className="text-foreground">SecurityAudit</strong> + <strong className="text-foreground">ReadOnlyAccess</strong> policies — read-only, no changes to your AWS.
              </p>
              <p className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-400 mt-0.5 shrink-0" />
                You'll need your AWS Account ID (12 digits) and permission to create an IAM role.
              </p>
              <p className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-400 mt-0.5 shrink-0" />
                We'll scan IAM, S3, EC2, RDS, EKS, Lambda, CloudTrail — 915+ security checks via Prowler.
              </p>
            </div>
            <button
              onClick={() => goTo("iam-role")}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 flex items-center gap-2"
            >
              Get Started <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        )}

        {step === "iam-role" && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold">Step 1: Create IAM Role</h2>
            <p className="text-sm text-muted-foreground">
              Enter your AWS Account ID and pick a role name. We'll generate a CloudFormation template you can deploy.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted-foreground">AWS Account ID (12 digits)</label>
                <input
                  type="text"
                  value={accountId}
                  onChange={(e) => setAccountId(e.target.value.replace(/\D/g, "").slice(0, 12))}
                  placeholder="123456789012"
                  className="w-full px-3 py-2 text-sm bg-background border border-border rounded-md mt-1 font-mono"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">IAM Role Name</label>
                <input
                  type="text"
                  value={roleName}
                  onChange={(e) => setRoleName(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-background border border-border rounded-md mt-1 font-mono"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs text-muted-foreground">CloudFormation Template</label>
                <button
                  onClick={() => navigator.clipboard.writeText(cfTemplate)}
                  className="text-xs text-blue-400 hover:underline flex items-center gap-1"
                >
                  <Copy className="h-3 w-3" /> Copy
                </button>
              </div>
              <pre className="text-xs bg-background border border-border rounded-md p-3 overflow-x-auto max-h-[300px] font-mono">
                {cfTemplate}
              </pre>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
              <div className="text-sm font-medium text-blue-400 mb-1">Deploy via AWS CLI:</div>
              <pre className="text-xs font-mono whitespace-pre-wrap">{cliCommand}</pre>
              <p className="text-xs text-muted-foreground mt-2">
                Or deploy via AWS Console → CloudFormation → Create stack → upload this template.
              </p>
            </div>

            <div className="flex items-center justify-between">
              <button onClick={() => goTo("intro")} className="px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground flex items-center gap-1">
                <ArrowLeft className="h-4 w-4" /> Back
              </button>
              <button
                onClick={() => goTo("connect")}
                disabled={accountId.length !== 12}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                Continue <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {step === "connect" && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold">Step 2: Connect Your Account</h2>
            <p className="text-sm text-muted-foreground">
              Confirm these details and we'll register your AWS account with Sentinel.
            </p>
            <div className="space-y-2">
              <Row label="Provider" value="AWS" />
              <Row label="Account ID" value={accountId} mono />
              <Row label="Role ARN" value={`arn:aws:iam::${accountId}:role/${roleName}`} mono />
              <div>
                <div className="text-xs text-muted-foreground">Regions to scan:</div>
                <div className="flex flex-wrap gap-2 mt-1">
                  {["us-east-1", "us-east-2", "us-west-1", "us-west-2", "eu-west-1", "eu-central-1"].map(r => (
                    <label key={r} className="flex items-center gap-1 text-xs">
                      <input
                        type="checkbox"
                        checked={regions.includes(r)}
                        onChange={(e) => {
                          if (e.target.checked) setRegions([...regions, r]);
                          else setRegions(regions.filter(x => x !== r));
                        }}
                      />
                      <span className="font-mono">{r}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-sm text-red-400">
                <AlertCircle className="h-4 w-4 inline mr-2" />{error}
              </div>
            )}

            <div className="flex items-center justify-between">
              <button onClick={() => goTo("iam-role")} className="px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground flex items-center gap-1">
                <ArrowLeft className="h-4 w-4" /> Back
              </button>
              <button
                onClick={connectAccount}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 flex items-center gap-2"
              >
                Connect Account <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {step === "scan" && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold">Step 3: Run Your First Scan</h2>
            <p className="text-sm text-muted-foreground">
              Click below to trigger a scan. This will scan IAM, S3, EC2, RDS, EKS, Lambda, and CloudTrail using 915+ Prowler checks.
            </p>

            {scanStatus === "idle" && (
              <button
                onClick={runScan}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90"
              >
                Start Scan Now
              </button>
            )}

            {scanStatus === "running" && (
              <div className="flex items-center gap-3 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                <Loader2 className="h-5 w-5 text-blue-400 animate-spin" />
                <div>
                  <div className="text-sm font-medium text-blue-400">Scanning in progress...</div>
                  <div className="text-xs text-muted-foreground">This takes 1-2 minutes</div>
                </div>
              </div>
            )}

            {scanStatus === "error" && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-sm text-red-400">
                <AlertCircle className="h-4 w-4 inline mr-2" />{error}
                <button onClick={runScan} className="ml-3 px-2 py-0.5 bg-red-600 text-white rounded text-xs">Retry</button>
              </div>
            )}

            {scanStatus === "done" && scanResults && (
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                  <CheckCircle2 className="h-5 w-5 text-green-400" />
                  <div>
                    <div className="text-sm font-medium text-green-400">Scan complete!</div>
                    <div className="text-xs text-muted-foreground">
                      {scanResults.total_assets} assets scanned · {scanResults.total_findings} findings
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-3">
                  {(scanResults.findings_by_severity || {}).critical > 0 && (
                    <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-center">
                      <div className="text-2xl font-bold text-red-400">{scanResults.findings_by_severity.critical}</div>
                      <div className="text-xs text-muted-foreground">Critical</div>
                    </div>
                  )}
                  {(scanResults.findings_by_severity || {}).high > 0 && (
                    <div className="p-3 bg-orange-500/10 border border-orange-500/30 rounded-lg text-center">
                      <div className="text-2xl font-bold text-orange-400">{scanResults.findings_by_severity.high}</div>
                      <div className="text-xs text-muted-foreground">High</div>
                    </div>
                  )}
                  {(scanResults.findings_by_severity || {}).medium > 0 && (
                    <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg text-center">
                      <div className="text-2xl font-bold text-amber-400">{scanResults.findings_by_severity.medium}</div>
                      <div className="text-xs text-muted-foreground">Medium</div>
                    </div>
                  )}
                  {(scanResults.findings_by_severity || {}).low > 0 && (
                    <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg text-center">
                      <div className="text-2xl font-bold text-blue-400">{scanResults.findings_by_severity.low}</div>
                      <div className="text-xs text-muted-foreground">Low</div>
                    </div>
                  )}
                </div>

                <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg text-xs text-blue-400">
                  <ShieldCheck className="h-4 w-4 inline mr-2" />
                  All 6 premium features auto-triggered: drift detection, finding prioritization, attack paths, evidence vault, workflow tickets (if configured), multi-account rollup.
                </div>

                <button
                  onClick={() => { setStep("done"); onComplete?.(); }}
                  className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 flex items-center gap-2"
                >
                  Finish <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {step === "done" && (
          <div className="text-center space-y-4">
            <div className="inline-flex p-4 bg-green-500/10 rounded-full">
              <CheckCircle2 className="h-12 w-12 text-green-400" />
            </div>
            <h2 className="text-2xl font-bold">You're all set!</h2>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Your AWS account is now continuously monitored. Visit the dashboard to see findings, attack paths, and compliance status.
            </p>
            <div className="grid grid-cols-2 gap-3 max-w-md mx-auto text-left">
              <a href="#" onClick={(e) => { e.preventDefault(); window.location.hash = "findings"; }} className="p-3 bg-background/50 border border-border rounded-lg hover:bg-accent">
                <div className="text-sm font-medium">View Findings</div>
                <div className="text-xs text-muted-foreground">Browse {scanResults?.total_findings || 0} findings</div>
              </a>
              <a href="#" onClick={(e) => { e.preventDefault(); window.location.hash = "premium-features"; }} className="p-3 bg-background/50 border border-border rounded-lg hover:bg-accent">
                <div className="text-sm font-medium">Premium Features</div>
                <div className="text-xs text-muted-foreground">Drift, attack paths, evidence</div>
              </a>
            </div>
            <a
              href="#"
              onClick={(e) => { e.preventDefault(); window.location.hash = "schedules"; }}
              className="inline-block text-sm text-blue-400 hover:underline"
            >
              Set up daily scheduled scans + email alerts →
            </a>
          </div>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-border/50">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={cn("text-sm", mono && "font-mono")}>{value}</span>
    </div>
  );
}
