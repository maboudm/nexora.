"use client";

import { useMemo, useState } from "react";
import type { ScanResult } from "@/lib/scanner";
import { RESOURCE_TYPE_LABELS } from "@/lib/scanner";
import { cn } from "@/lib/utils";
import { Search, Boxes } from "lucide-react";

interface ResourcesPanelProps {
  scanResult: ScanResult;
}

export function ResourcesPanel({ scanResult }: ResourcesPanelProps) {
  const { resources, findings } = scanResult;
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [selectedArn, setSelectedArn] = useState<string | null>(null);

  const types = useMemo(() => {
    const set = new Set(resources.map((r) => r.type));
    return ["all", ...Array.from(set).sort()];
  }, [resources]);

  const findingsByArn = useMemo(() => {
    const map: Record<string, typeof findings> = {};
    for (const f of findings) {
      (map[f.resource_arn] ??= []).push(f);
    }
    return map;
  }, [findings]);

  const filtered = useMemo(() => {
    let r = resources;
    if (search.trim()) {
      const q = search.toLowerCase();
      r = r.filter((res) => res.arn.toLowerCase().includes(q) || res.name.toLowerCase().includes(q));
    }
    if (typeFilter !== "all") r = r.filter((res) => res.type === typeFilter);
    return r;
  }, [resources, search, typeFilter]);

  const selected = selectedArn ? resources.find((r) => r.arn === selectedArn) : null;
  const selectedFindings = selectedArn ? findingsByArn[selectedArn] || [] : [];

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <div className="flex items-start gap-3 mb-4">
          <div className="h-9 w-9 rounded-md bg-primary/15 border border-primary/30 flex items-center justify-center text-primary">
            <Boxes className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-sm font-semibold">Cloud Resources Inventory</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {resources.length} resources discovered in the last scan. Click any resource to see its findings and raw metadata.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search by name or ARN…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-md border border-border/60 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-muted-foreground">Type:</span>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-md border border-border/60 bg-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            >
              {types.map((t) => (
                <option key={t} value={t}>
                  {t === "all" ? "All" : RESOURCE_TYPE_LABELS[t] || t}
                </option>
              ))}
            </select>
          </div>
          <div className="text-xs text-muted-foreground ml-auto">{filtered.length} resources</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Resource list */}
        <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
          <div className="divide-y divide-border/40 max-h-[600px] overflow-y-auto">
            {filtered.map((res) => {
              const f = findingsByArn[res.arn] || [];
              const criticalCount = f.filter((x) => x.severity === "critical").length;
              const isSelected = selectedArn === res.arn;
              return (
                <button
                  key={res.arn}
                  onClick={() => setSelectedArn(res.arn)}
                  className={cn(
                    "w-full text-left p-3 hover:bg-accent/30 transition-colors flex items-start gap-3",
                    isSelected && "bg-primary/10 border-l-2 border-primary",
                  )}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium">{RESOURCE_TYPE_LABELS[res.type] || res.type}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                        {res.region}
                      </span>
                    </div>
                    <p className="text-sm font-medium truncate">{res.name}</p>
                    <p className="text-[10px] font-mono text-muted-foreground truncate mt-0.5">{res.arn}</p>
                  </div>
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    {f.length > 0 ? (
                      <>
                        <span className="text-xs font-semibold">{f.length}</span>
                        <span className="text-[10px] text-muted-foreground">findings</span>
                        {criticalCount > 0 && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/15 text-red-400 font-mono">
                            {criticalCount} critical
                          </span>
                        )}
                      </>
                    ) : (
                      <span className="text-[10px] text-emerald-500">clean</span>
                    )}
                  </div>
                </button>
              );
            })}
            {filtered.length === 0 && (
              <div className="p-12 text-center text-sm text-muted-foreground">No resources match the filter.</div>
            )}
          </div>
        </div>

        {/* Resource detail */}
        <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
          {selected ? (
            <div className="p-4 space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs uppercase tracking-widest text-muted-foreground">
                    {RESOURCE_TYPE_LABELS[selected.type] || selected.type}
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                    {selected.region}
                  </span>
                </div>
                <h3 className="text-base font-semibold font-mono">{selected.name}</h3>
                <p className="text-[10px] font-mono text-muted-foreground mt-1 break-all">{selected.arn}</p>
              </div>

              <div>
                <h4 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-2">
                  Findings ({selectedFindings.length})
                </h4>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {selectedFindings.length === 0 ? (
                    <p className="text-sm text-emerald-500">No security findings on this resource.</p>
                  ) : (
                    selectedFindings.map((f) => (
                      <div key={f.id} className="rounded-md border border-border/40 bg-muted/30 p-2">
                        <div className="flex items-center gap-2 mb-1">
                          <span
                            className={cn(
                              "h-1.5 w-1.5 rounded-full",
                              f.severity === "critical" && "bg-red-500",
                              f.severity === "high" && "bg-orange-500",
                              f.severity === "medium" && "bg-amber-500",
                              f.severity === "low" && "bg-blue-500",
                            )}
                          />
                          <span className="font-mono text-[10px] text-muted-foreground">{f.rule_id}</span>
                          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                            {f.severity}
                          </span>
                        </div>
                        <p className="text-xs font-medium">{f.title}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div>
                <h4 className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-2">
                  Raw Metadata
                </h4>
                <pre className="rounded-md border border-border/60 bg-background p-3 text-[10px] font-mono overflow-x-auto max-h-64">
                  {JSON.stringify(selected.metadata, null, 2)}
                </pre>
              </div>
            </div>
          ) : (
            <div className="p-12 text-center text-sm text-muted-foreground">
              Select a resource to view its findings and metadata.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
