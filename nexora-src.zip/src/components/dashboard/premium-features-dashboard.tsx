"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Activity, AlertTriangle, GitBranch, FileLock, Workflow as WorkflowIcon,
  Building2, Search, Filter, RefreshCw, ExternalLink, CheckCircle2,
  XCircle, Clock, TrendingUp, ArrowRight, ChevronRight, Loader2,
  ShieldAlert, ShieldCheck, KeyRound, Network, Hash, Boxes,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface PremiumFeaturesDashboardProps {
  token: string;
}

const SEVERITY_COLORS: Record<string, string> = {
  critical: "#ef4444",
  high: "#f97316",
  medium: "#f59e0b",
  low: "#3b82f6",
  info: "#6b7280",
};

const SEVERITY_BG: Record<string, string> = {
  critical: "bg-red-500/10 border-red-500/30 text-red-400",
  high: "bg-orange-500/10 border-orange-500/30 text-orange-400",
  medium: "bg-amber-500/10 border-amber-500/30 text-amber-400",
  low: "bg-blue-500/10 border-blue-500/30 text-blue-400",
  info: "bg-gray-500/10 border-gray-500/30 text-gray-400",
};

type SubTab = "drift" | "prioritization" | "kill-chain" | "evidence" | "workflow" | "multi-account" | "prowler" | "checkov";

const SUB_TABS: { id: SubTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: "drift", label: "Drift Detection", icon: Activity },
  { id: "prioritization", label: "Fix Prioritization", icon: TrendingUp },
  { id: "kill-chain", label: "Attack Paths", icon: GitBranch },
  { id: "evidence", label: "Evidence Vault", icon: FileLock },
  { id: "workflow", label: "Workflow Tickets", icon: WorkflowIcon },
  { id: "multi-account", label: "Multi-Account", icon: Building2 },
  { id: "prowler", label: "Prowler Rules", icon: ShieldAlert },
  { id: "checkov", label: "IaC Policies", icon: ShieldCheck },
];

export function PremiumFeaturesDashboard({ token }: PremiumFeaturesDashboardProps) {
  const [subTab, setSubTab] = useState<SubTab>("drift");

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Premium Security Features</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Continuous monitoring, risk-based prioritization, attack path analysis, compliance evidence, workflow orchestration, and multi-cloud rule catalogs.
        </p>
      </div>

      {/* Sub-tab navigation */}
      <div className="flex flex-wrap gap-2 border-b border-border pb-3">
        {SUB_TABS.map((t) => {
          const Icon = t.icon;
          const isActive = subTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setSubTab(t.id)}
              className={cn(
                "flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )}
            >
              <Icon className="h-4 w-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      {subTab === "drift" && <DriftDetectionPanel token={token} />}
      {subTab === "prioritization" && <PrioritizationPanel token={token} />}
      {subTab === "kill-chain" && <KillChainPanel token={token} />}
      {subTab === "evidence" && <EvidenceVaultPanel token={token} />}
      {subTab === "workflow" && <WorkflowPanel token={token} />}
      {subTab === "multi-account" && <MultiAccountPanel token={token} />}
      {subTab === "prowler" && <ProwlerPanel token={token} />}
      {subTab === "checkov" && <CheckovPanel token={token} />}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Shared API helper
// ─────────────────────────────────────────────────────────────────────────
async function apiCall<T>(
  token: string,
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const res = await fetch(`/api/gateway-proxy/${path.replace(/^\//, "")}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...options.headers,
    },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "Request failed");
    throw new Error(`${res.status}: ${text}`);
  }
  return res.json();
}

// ─────────────────────────────────────────────────────────────────────────
// 1. Drift Detection Panel
// ─────────────────────────────────────────────────────────────────────────
function DriftDetectionPanel({ token }: { token: string }) {
  const [stats, setStats] = useState<any>(null);
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>("");

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [s, e] = await Promise.all([
        apiCall<any>(token, "/v1/drift/stats?window_hours=24"),
        apiCall<any[]>(token, "/v1/drift/events?limit=100"),
      ]);
      setStats(s);
      setEvents(e);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const filtered = filter
    ? events.filter(e =>
        e.asset_name?.toLowerCase().includes(filter.toLowerCase()) ||
        e.drift_type?.toLowerCase().includes(filter.toLowerCase()) ||
        e.field_path?.toLowerCase().includes(filter.toLowerCase())
      )
    : events;

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorBox message={error} onRetry={load} />;

  return (
    <div className="space-y-4">
      {/* Stats cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Drifts (24h)" value={stats?.total_drifts ?? 0} icon={Activity} color="text-blue-400" />
        <StatCard label="High-Risk Drifts" value={stats?.high_risk_drift_count ?? 0} icon={AlertTriangle} color="text-red-400" />
        <StatCard label="Velocity (per hour)" value={stats?.drift_velocity_per_hour ?? 0} icon={TrendingUp} color="text-amber-400" />
        <StatCard label="By Severity" value={
          <div className="text-xs space-y-0.5 mt-1">
            {Object.entries(stats?.by_severity || {}).map(([k, v]: any) => (
              <div key={k} className="flex justify-between">
                <span className="capitalize">{k}:</span>
                <span className="font-mono">{v}</span>
              </div>
            ))}
          </div>
        } icon={Filter} color="text-purple-400" />
      </div>

      {/* Filter + events */}
      <Card>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">Recent Drift Events</h3>
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Filter by asset, type, field..."
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-3 py-1 text-sm bg-background border border-border rounded-md w-64"
            />
            <button onClick={load} className="p-1.5 hover:bg-accent rounded-md">
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>
        </div>
        {filtered.length === 0 ? (
          <EmptyState message="No drift events. Run a scan to establish baseline." />
        ) : (
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {filtered.map((e, i) => (
              <div key={i} className="flex items-start gap-3 p-3 bg-background/50 rounded-lg border border-border">
                <div className={cn("mt-0.5 p-1 rounded border", SEVERITY_BG[e.severity] || SEVERITY_BG.info)}>
                  {e.drift_type === "created" && <CheckCircle2 className="h-3.5 w-3.5" />}
                  {e.drift_type === "deleted" && <XCircle className="h-3.5 w-3.5" />}
                  {(e.drift_type === "updated" || e.drift_type === "high_risk") && <AlertTriangle className="h-3.5 w-3.5" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-medium">{e.asset_name || e.asset_id}</span>
                    <span className="text-xs text-muted-foreground">({e.asset_type})</span>
                    <span className={cn("text-xs px-1.5 py-0.5 rounded border", SEVERITY_BG[e.severity] || SEVERITY_BG.info)}>
                      {e.drift_type} · {e.severity}
                    </span>
                    {e.risk_weight >= 80 && (
                      <span className="text-xs px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/30">
                        Risk: {e.risk_weight}
                      </span>
                    )}
                  </div>
                  {e.field_path && (
                    <div className="text-xs text-muted-foreground mt-1 font-mono">
                      {e.field_path}:{" "}
                      <span className="text-red-400">{JSON.stringify(e.old_value).slice(0, 50)}</span>
                      {" → "}
                      <span className="text-green-400">{JSON.stringify(e.new_value).slice(0, 50)}</span>
                    </div>
                  )}
                  <div className="text-xs text-muted-foreground mt-1">
                    {new Date(e.timestamp * 1000).toLocaleString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// 2. Prioritization Panel
// ─────────────────────────────────────────────────────────────────────────
function PrioritizationPanel({ token }: { token: string }) {
  const [findings, setFindings] = useState<any[]>([]);
  const [assets, setAssets] = useState<any[]>([]);
  const [prioritized, setPrioritized] = useState<any[]>([]);
  const [budget, setBudget] = useState(20);
  const [plan, setPlan] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // Get latest scan to extract findings
      const scans = await apiCall<any[]>(token, "/v1/scans?limit=1");
      if (scans.length === 0) {
        setLoading(false);
        return;
      }
      const scanDetail = await apiCall<any>(token, `/v1/scans/${scans[0].scan_id}`);
      const fs = scanDetail.findings || [];
      const as = scanDetail.assets || [];
      setFindings(fs);
      setAssets(as);
      if (fs.length > 0) {
        const result = await apiCall<any>(token, "/v1/prioritization/prioritize", {
          method: "POST",
          body: JSON.stringify({ findings: fs, assets: as }),
        });
        setPrioritized(result.prioritized || []);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const buildPlan = async () => {
    try {
      const result = await apiCall<any>(token, "/v1/prioritization/fix-plan", {
        method: "POST",
        body: JSON.stringify({ findings, assets, budget_hours: budget }),
      });
      setPlan(result);
    } catch (err: any) {
      setError(err.message);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorBox message={error} onRetry={load} />;

  return (
    <div className="space-y-4">
      {prioritized.length === 0 ? (
        <EmptyState message="No findings to prioritize. Run a scan first." />
      ) : (
        <>
          {/* Top stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard label="Total Findings" value={prioritized.length} icon={ShieldAlert} color="text-blue-400" />
            <StatCard label="Critical Risk" value={prioritized.filter(p => p.risk_band === "CRITICAL").length} icon={AlertTriangle} color="text-red-400" />
            <StatCard label="Top Risk Score" value={prioritized[0]?.risk_score.toFixed(1) || "—"} icon={TrendingUp} color="text-orange-400" />
            <StatCard label="Total Effort" value={`${prioritized.reduce((s, p) => s + p.fix_effort_hours, 0).toFixed(1)}h`} icon={Clock} color="text-purple-400" />
          </div>

          {/* Fix plan builder */}
          <Card>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold">Fix-Plan Optimizer (Greedy Knapsack)</h3>
              <div className="flex items-center gap-3">
                <label className="text-sm text-muted-foreground">Budget:</label>
                <input
                  type="number"
                  value={budget}
                  onChange={(e) => setBudget(Number(e.target.value))}
                  className="w-20 px-2 py-1 text-sm bg-background border border-border rounded-md"
                  min={1}
                  max={500}
                />
                <span className="text-sm text-muted-foreground">hours</span>
                <button
                  onClick={buildPlan}
                  className="px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90"
                >
                  Build Plan
                </button>
              </div>
            </div>
            {plan && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
                <div className="p-3 bg-background/50 rounded-lg border border-border">
                  <div className="text-xs text-muted-foreground">Selected</div>
                  <div className="text-lg font-bold">{plan.selected_findings?.length || 0}</div>
                </div>
                <div className="p-3 bg-background/50 rounded-lg border border-border">
                  <div className="text-xs text-muted-foreground">Hours Used</div>
                  <div className="text-lg font-bold">{plan.used_hours}h / {plan.budget_hours}h</div>
                </div>
                <div className="p-3 bg-green-500/10 rounded-lg border border-green-500/30">
                  <div className="text-xs text-green-400">Risk Reduced</div>
                  <div className="text-lg font-bold text-green-400">{plan.total_risk_reduction}</div>
                </div>
                <div className="p-3 bg-background/50 rounded-lg border border-border">
                  <div className="text-xs text-muted-foreground">Quick Wins</div>
                  <div className="text-lg font-bold">{plan.quick_wins?.length || 0}</div>
                </div>
              </div>
            )}
          </Card>

          {/* Ranked findings list */}
          <Card>
            <h3 className="text-sm font-semibold mb-3">Risk-Ranked Findings</h3>
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {prioritized.map((p, i) => (
                <div key={i} className="p-3 bg-background/50 rounded-lg border border-border">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs text-muted-foreground font-mono">#{i + 1}</span>
                        <span className={cn("text-xs px-1.5 py-0.5 rounded border font-bold",
                          p.risk_band === "CRITICAL" ? "bg-red-500/10 border-red-500/30 text-red-400" :
                          p.risk_band === "HIGH" ? "bg-orange-500/10 border-orange-500/30 text-orange-400" :
                          p.risk_band === "MEDIUM" ? "bg-amber-500/10 border-amber-500/30 text-amber-400" :
                          "bg-blue-500/10 border-blue-500/30 text-blue-400"
                        )}>
                          {p.risk_band}
                        </span>
                        <span className="text-sm font-medium truncate">{p.title}</span>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {p.asset_name} · {p.category} · {p.exposure} exposure · tier {p.asset_tier.replace("tier_", "")}
                      </div>
                      <div className="text-xs text-muted-foreground mt-1 font-mono">
                        {p.reason}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-lg font-bold">{p.risk_score.toFixed(1)}</div>
                      <div className="text-xs text-muted-foreground">risk score</div>
                      <div className="text-xs text-green-400 mt-1">{p.risk_reduction_per_hour.toFixed(0)}/hr</div>
                      <div className="text-xs text-muted-foreground">{p.fix_effort_hours}h fix</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// 3. Kill Chain / Attack Path Panel
// ─────────────────────────────────────────────────────────────────────────
function KillChainPanel({ token }: { token: string }) {
  const [summary, setSummary] = useState<any>(null);
  const [paths, setPaths] = useState<any[]>([]);
  const [viz, setViz] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [s, p, v] = await Promise.all([
        apiCall<any>(token, "/v1/kill-chain/summary"),
        apiCall<any[]>(token, "/v1/kill-chain/paths?limit=20"),
        apiCall<any>(token, "/v1/kill-chain/visualization?max_paths=15"),
      ]);
      setSummary(s);
      setPaths(p);
      setViz(v);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorBox message={error} onRetry={load} />;

  return (
    <div className="space-y-4">
      {/* Summary stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <StatCard label="Attack Paths" value={summary?.total_paths ?? 0} icon={GitBranch} color="text-red-400" />
        <StatCard label="Graph Assets" value={summary?.total_assets ?? 0} icon={Network} color="text-blue-400" />
        <StatCard label="Graph Edges" value={summary?.total_edges ?? 0} icon={ArrowRight} color="text-purple-400" />
        <StatCard label="Entry Points" value={summary?.sources_count ?? 0} icon={ShieldAlert} color="text-orange-400" />
        <StatCard label="Crown Jewels" value={summary?.targets_count ?? 0} icon={KeyRound} color="text-yellow-400" />
      </div>

      {/* MITRE ATT&CK phase coverage */}
      {summary?.by_phase && Object.keys(summary.by_phase).length > 0 && (
        <Card>
          <h3 className="text-sm font-semibold mb-3">MITRE ATT&CK Phase Coverage</h3>
          <div className="flex flex-wrap gap-2">
            {Object.entries(summary.by_phase).map(([phase, count]: any) => {
              const phaseNames: Record<string, string> = {
                "TA0001": "Initial Access",
                "TA0002": "Execution",
                "TA0003": "Persistence",
                "TA0004": "Privilege Escalation",
                "TA0005": "Defense Evasion",
                "TA0006": "Credential Access",
                "TA0007": "Discovery",
                "TA0008": "Lateral Movement",
                "TA0009": "Collection",
                "TA0010": "Exfiltration",
                "TA0011": "Command & Control",
                "TA0040": "Impact",
                "TA0042": "Resource Development",
                "TA0043": "Reconnaissance",
              };
              return (
                <div key={phase} className="px-3 py-1.5 bg-background/50 border border-border rounded-lg text-xs">
                  <span className="font-mono text-muted-foreground">{phase}</span>
                  {" "}
                  <span className="font-medium">{phaseNames[phase] || phase}</span>
                  {" "}
                  <span className="px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 font-bold ml-1">{count}</span>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Choke points */}
      {summary?.choke_points && summary.choke_points.length > 0 && (
        <Card>
          <h3 className="text-sm font-semibold mb-3">Choke Points (assets in multiple paths)</h3>
          <div className="space-y-2">
            {summary.choke_points.map((cp: any, i: number) => (
              <div key={i} className="flex items-center justify-between p-2 bg-background/50 rounded border border-border">
                <span className="text-sm font-medium">{cp.asset_name || cp.asset_id}</span>
                <span className="text-xs px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 border border-orange-500/30">
                  Appears in {cp.appearances} paths
                </span>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Attack paths list */}
      <Card>
        <h3 className="text-sm font-semibold mb-3">Top Attack Paths (by risk score)</h3>
        {paths.length === 0 ? (
          <EmptyState message="No attack paths found. Need internet-facing assets + crown jewels in scan results." />
        ) : (
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {paths.map((p, i) => (
              <div key={i} className="p-3 bg-background/50 rounded-lg border border-border">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground font-mono">#{i + 1}</span>
                    <span className="text-sm font-medium">{p.summary}</span>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-red-400">{p.risk_score}</div>
                    <div className="text-xs text-muted-foreground">P={p.path_probability}</div>
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-wrap text-xs">
                  <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400">
                    {p.path_length} hops
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-yellow-500/20 text-yellow-400">
                    target: {p.target_tier}
                  </span>
                  {p.kill_chain_phases?.map((phase: string) => (
                    <span key={phase} className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-400 font-mono">
                      {phase}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// 4. Evidence Vault Panel
// ─────────────────────────────────────────────────────────────────────────
function EvidenceVaultPanel({ token }: { token: string }) {
  const [stats, setStats] = useState<any>(null);
  const [verify, setVerify] = useState<any>(null);
  const [records, setRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [frameworkFilter, setFrameworkFilter] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [s, v, r] = await Promise.all([
        apiCall<any>(token, "/v1/evidence/stats"),
        apiCall<any>(token, "/v1/evidence/verify"),
        apiCall<any[]>(token, "/v1/evidence/records?limit=100"),
      ]);
      setStats(s);
      setVerify(v);
      setRecords(r);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const filtered = frameworkFilter
    ? records.filter(r => r.framework === frameworkFilter)
    : records;

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorBox message={error} onRetry={load} />;

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Records" value={stats?.total_records ?? 0} icon={FileLock} color="text-blue-400" />
        <StatCard label="Chain Verified" value={stats?.chain_verified ? "✓ Valid" : "✗ Broken"} icon={verify?.verified ? CheckCircle2 : XCircle} color={stats?.chain_verified ? "text-green-400" : "text-red-400"} />
        <StatCard label="Chain Length" value={stats?.chain_length ?? 0} icon={Hash} color="text-purple-400" />
        <StatCard label="Frameworks" value={Object.keys(stats?.by_framework || {}).length} icon={ShieldCheck} color="text-orange-400" />
      </div>

      {/* Verification banner */}
      <Card>
        <div className={cn("flex items-center gap-3 p-3 rounded-lg border",
          verify?.verified ? "bg-green-500/10 border-green-500/30" : "bg-red-500/10 border-red-500/30"
        )}>
          {verify?.verified ? (
            <CheckCircle2 className="h-5 w-5 text-green-400" />
          ) : (
            <XCircle className="h-5 w-5 text-red-400" />
          )}
          <div>
            <div className="text-sm font-semibold">
              Hash Chain {verify?.verified ? "Verified" : "TAMPERED"}
            </div>
            <div className="text-xs text-muted-foreground">
              {verify?.reason || "All records cryptographically verified"}
              {verify?.break_at_record_id && ` (break at ${verify.break_at_record_id.slice(0, 8)})`}
            </div>
          </div>
        </div>
      </Card>

      {/* Compliance breakdown */}
      {stats?.by_framework && (
        <Card>
          <h3 className="text-sm font-semibold mb-3">Evidence by Compliance Framework</h3>
          <div className="flex flex-wrap gap-2">
            {Object.entries(stats.by_framework).map(([fw, count]: any) => (
              <button
                key={fw}
                onClick={() => setFrameworkFilter(frameworkFilter === fw ? "" : fw)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors",
                  frameworkFilter === fw
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-background/50 border-border hover:bg-accent"
                )}
              >
                {fw}: {count}
              </button>
            ))}
          </div>
        </Card>
      )}

      {/* Records */}
      <Card>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">
            Evidence Records {frameworkFilter && `(${frameworkFilter})`}
          </h3>
          <button onClick={load} className="p-1.5 hover:bg-accent rounded-md">
            <RefreshCw className="h-4 w-4" />
          </button>
        </div>
        {filtered.length === 0 ? (
          <EmptyState message="No evidence records yet. They auto-ingest on each scan." />
        ) : (
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {filtered.map((r, i) => (
              <div key={i} className="p-3 bg-background/50 rounded-lg border border-border">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={cn("text-xs px-1.5 py-0.5 rounded border font-bold",
                        r.status === "pass" ? "bg-green-500/10 border-green-500/30 text-green-400" :
                        r.status === "fail" ? "bg-red-500/10 border-red-500/30 text-red-400" :
                        "bg-gray-500/10 border-gray-500/30 text-gray-400"
                      )}>
                        {r.status.toUpperCase()}
                      </span>
                      <span className="text-sm font-medium font-mono">{r.control_id}</span>
                      <span className="text-xs text-muted-foreground">{r.framework}</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      Resource: <span className="font-mono">{r.resource_name}</span> ({r.resource_type})
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {new Date(r.collected_at * 1000).toLocaleString()}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground font-mono shrink-0 text-right">
                    <div>hash: {r.record_hash?.slice(0, 12)}...</div>
                    <div>prev: {r.prev_hash?.slice(0, 12)}...</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// 5. Workflow Integration Panel
// ─────────────────────────────────────────────────────────────────────────
function WorkflowPanel({ token }: { token: string }) {
  const [stats, setStats] = useState<any>(null);
  const [integrations, setIntegrations] = useState<any[]>([]);
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [newType, setNewType] = useState("slack");
  const [newName, setNewName] = useState("");
  const [newConfig, setNewConfig] = useState("{}");

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [s, i, t] = await Promise.all([
        apiCall<any>(token, "/v1/workflow/stats"),
        apiCall<any[]>(token, "/v1/workflow/integrations"),
        apiCall<any[]>(token, "/v1/workflow/tickets?limit=50"),
      ]);
      setStats(s);
      setIntegrations(i);
      setTickets(t);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const addIntegration = async () => {
    try {
      const config = JSON.parse(newConfig);
      await apiCall(token, "/v1/workflow/integrations", {
        method: "POST",
        body: JSON.stringify({ type: newType, name: newName || `${newType} integration`, config }),
      });
      setShowAdd(false);
      setNewName("");
      setNewConfig("{}");
      load();
    } catch (err: any) {
      setError(err.message);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorBox message={error} onRetry={load} />;

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Integrations" value={stats?.total_integrations ?? 0} icon={WorkflowIcon} color="text-blue-400" />
        <StatCard label="Total Tickets" value={stats?.total_tickets ?? 0} icon={FileLock} color="text-purple-400" />
        <StatCard label="Open Tickets" value={stats?.open_tickets ?? 0} icon={AlertTriangle} color="text-orange-400" />
        <StatCard label="Resolved" value={stats?.resolved_tickets ?? 0} icon={CheckCircle2} color="text-green-400" />
      </div>

      {/* Integrations */}
      <Card>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">Configured Integrations</h3>
          <button
            onClick={() => setShowAdd(!showAdd)}
            className="px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90"
          >
            {showAdd ? "Cancel" : "+ Add Integration"}
          </button>
        </div>

        {showAdd && (
          <div className="mb-4 p-4 bg-background/50 rounded-lg border border-border space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted-foreground">Type</label>
                <select
                  value={newType}
                  onChange={(e) => setNewType(e.target.value)}
                  className="w-full px-2 py-1 text-sm bg-background border border-border rounded-md mt-1"
                >
                  <option value="slack">Slack</option>
                  <option value="jira">Jira</option>
                  <option value="servicenow">ServiceNow</option>
                  <option value="github">GitHub Issues</option>
                  <option value="pagerduty">PagerDuty</option>
                  <option value="teams">Microsoft Teams</option>
                  <option value="webhook">Generic Webhook</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g., Security Alerts"
                  className="w-full px-2 py-1 text-sm bg-background border border-border rounded-md mt-1"
                />
              </div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Config (JSON)</label>
              <textarea
                value={newConfig}
                onChange={(e) => setNewConfig(e.target.value)}
                rows={4}
                className="w-full px-2 py-1 text-sm bg-background border border-border rounded-md mt-1 font-mono"
                placeholder='{"webhook_url": "https://hooks.slack.com/...", "channel": "#security"}'
              />
            </div>
            <button
              onClick={addIntegration}
              className="px-3 py-1.5 bg-green-600 text-white rounded-md text-sm font-medium hover:bg-green-700"
            >
              Save Integration
            </button>
          </div>
        )}

        {integrations.length === 0 ? (
          <EmptyState message="No integrations configured. Add one to enable auto-ticket creation for critical findings." />
        ) : (
          <div className="space-y-2">
            {integrations.map((integ, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-background/50 rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <WorkflowIcon className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm font-medium">{integ.name}</div>
                    <div className="text-xs text-muted-foreground">{integ.type} · {integ.integration_id.slice(0, 8)}...</div>
                  </div>
                </div>
                <span className={cn("text-xs px-2 py-0.5 rounded border",
                  integ.enabled ? "bg-green-500/10 border-green-500/30 text-green-400" : "bg-gray-500/10 border-gray-500/30 text-gray-400"
                )}>
                  {integ.enabled ? "Active" : "Disabled"}
                </span>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Tickets */}
      <Card>
        <h3 className="text-sm font-semibold mb-3">Auto-Created Tickets</h3>
        {tickets.length === 0 ? (
          <EmptyState message="No tickets yet. Critical findings auto-create tickets when an integration is configured." />
        ) : (
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {tickets.map((t, i) => (
              <div key={i} className="p-3 bg-background/50 rounded-lg border border-border">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={cn("text-xs px-1.5 py-0.5 rounded border font-bold",
                        t.state === "open" ? "bg-orange-500/10 border-orange-500/30 text-orange-400" :
                        t.state === "resolved" || t.state === "closed" ? "bg-green-500/10 border-green-500/30 text-green-400" :
                        "bg-gray-500/10 border-gray-500/30 text-gray-400"
                      )}>
                        {t.state.toUpperCase()}
                      </span>
                      <span className="text-xs px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/30">
                        {t.integration_type}
                      </span>
                      {t.finding_severity && (
                        <span className={cn("text-xs px-1.5 py-0.5 rounded border",
                          SEVERITY_BG[t.finding_severity.toLowerCase()] || SEVERITY_BG.info
                        )}>
                          {t.finding_severity}
                        </span>
                      )}
                    </div>
                    <div className="text-sm font-medium mt-1">{t.finding_title}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      Asset: {t.asset_name} · Created: {new Date(t.created_at * 1000).toLocaleString()}
                    </div>
                  </div>
                  {t.external_url && (
                    <a href={t.external_url} target="_blank" rel="noopener noreferrer"
                       className="text-xs text-blue-400 hover:underline flex items-center gap-1">
                      View <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// 6. Multi-Account Panel
// ─────────────────────────────────────────────────────────────────────────
function MultiAccountPanel({ token }: { token: string }) {
  const [stats, setStats] = useState<any>(null);
  const [orgs, setOrgs] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [rollup, setRollup] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [s, o] = await Promise.all([
        apiCall<any>(token, "/v1/multi-account/stats"),
        apiCall<any[]>(token, "/v1/multi-account/organizations"),
      ]);
      setStats(s);
      setOrgs(o);
      if (o.length > 0) {
        const [accts, roll] = await Promise.all([
          apiCall<any[]>(token, "/v1/multi-account/accounts"),
          apiCall<any>(token, `/v1/multi-account/organizations/${o[0].org_id}/rollup`),
        ]);
        setAccounts(accts);
        setRollup(roll);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorBox message={error} onRetry={load} />;

  return (
    <div className="space-y-4">
      {orgs.length === 0 ? (
        <Card>
          <EmptyState
            icon={Building2}
            message="No AWS Organizations discovered yet."
            action={
              <div className="text-xs text-muted-foreground mt-2">
                Call POST /v1/multi-account/discover with your management account ID to auto-discover all member accounts.
              </div>
            }
          />
        </Card>
      ) : (
        <>
          {/* Rollup stats */}
          {rollup && (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <StatCard label="Total Accounts" value={rollup.total_accounts} icon={Building2} color="text-blue-400" />
              <StatCard label="Active" value={rollup.active_accounts} icon={CheckCircle2} color="text-green-400" />
              <StatCard label="Total Resources" value={rollup.total_resources} icon={Boxes} color="text-purple-400" />
              <StatCard label="Weighted Posture" value={`${rollup.weighted_posture_score}/100`} icon={TrendingUp} color={rollup.weighted_posture_score >= 70 ? "text-green-400" : "text-orange-400"} />
              <StatCard label="Total Findings" value={rollup.total_findings} icon={AlertTriangle} color="text-red-400" />
            </div>
          )}

          {/* By criticality */}
          {rollup?.by_criticality && (
            <Card>
              <h3 className="text-sm font-semibold mb-3">Posture by Account Criticality</h3>
              <div className="space-y-2">
                {Object.entries(rollup.by_criticality).map(([crit, data]: any) => (
                  <div key={crit} className="flex items-center justify-between p-3 bg-background/50 rounded-lg border border-border">
                    <div>
                      <div className="text-sm font-medium capitalize">{crit}</div>
                      <div className="text-xs text-muted-foreground">{data.accounts} accounts · {data.findings} findings</div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold">{data.score}/100</div>
                      <div className="text-xs text-muted-foreground">compliance: {data.compliance}/100</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Weakest accounts */}
          {rollup?.weakest_accounts && rollup.weakest_accounts.length > 0 && (
            <Card>
              <h3 className="text-sm font-semibold mb-3">Weakest Accounts (need attention)</h3>
              <div className="space-y-2">
                {rollup.weakest_accounts.map((a: any, i: number) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-background/50 rounded-lg border border-border">
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground font-mono">#{i + 1}</span>
                      <div>
                        <div className="text-sm font-medium">{a.account_name}</div>
                        <div className="text-xs text-muted-foreground">{a.account_id} · {a.criticality}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs px-2 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/30">
                        {a.critical_findings} critical
                      </span>
                      <span className="text-xs text-muted-foreground">{a.findings} total</span>
                      <span className={cn("text-lg font-bold",
                        a.posture_score >= 70 ? "text-green-400" :
                        a.posture_score >= 50 ? "text-orange-400" : "text-red-400"
                      )}>
                        {a.posture_score}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* All accounts table */}
          <Card>
            <h3 className="text-sm font-semibold mb-3">All Discovered Accounts ({accounts.length})</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left border-b border-border">
                    <th className="pb-2 pr-3">Name</th>
                    <th className="pb-2 pr-3">ID</th>
                    <th className="pb-2 pr-3">Criticality</th>
                    <th className="pb-2 pr-3">Status</th>
                    <th className="pb-2 pr-3 text-right">Resources</th>
                    <th className="pb-2 pr-3 text-right">Findings</th>
                    <th className="pb-2 text-right">Posture</th>
                  </tr>
                </thead>
                <tbody>
                  {accounts.map((a, i) => (
                    <tr key={i} className="border-b border-border/50 hover:bg-accent/30">
                      <td className="py-2 pr-3 font-medium">{a.account_name}</td>
                      <td className="py-2 pr-3 font-mono text-xs text-muted-foreground">{a.account_id}</td>
                      <td className="py-2 pr-3 capitalize">{a.criticality}</td>
                      <td className="py-2 pr-3">
                        <span className={cn("text-xs px-1.5 py-0.5 rounded",
                          a.status === "ACTIVE" ? "bg-green-500/10 text-green-400" : "bg-gray-500/10 text-gray-400"
                        )}>
                          {a.status}
                        </span>
                      </td>
                      <td className="py-2 pr-3 text-right font-mono">{a.resource_count}</td>
                      <td className="py-2 pr-3 text-right font-mono">{a.findings_count}</td>
                      <td className={cn("py-2 text-right font-bold",
                        a.posture_score >= 70 ? "text-green-400" :
                        a.posture_score >= 50 ? "text-orange-400" : "text-red-400"
                      )}>
                        {a.posture_score}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// 7. Prowler Rules Panel
// ─────────────────────────────────────────────────────────────────────────
function ProwlerPanel({ token }: { token: string }) {
  const [stats, setStats] = useState<any>(null);
  const [checks, setChecks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [providerFilter, setProviderFilter] = useState("");
  const [severityFilter, setSeverityFilter] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const s = await apiCall<any>(token, "/v1/prowler/stats");
      setStats(s);
      const params = new URLSearchParams({ limit: "100" });
      if (providerFilter) params.set("provider", providerFilter);
      if (severityFilter) params.set("severity", severityFilter);
      const c = await apiCall<any[]>(token, `/v1/prowler/checks?${params}`);
      setChecks(c);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token, providerFilter, severityFilter]);

  useEffect(() => { load(); }, [load]);

  const doSearch = async () => {
    if (!search) { load(); return; }
    setLoading(true);
    try {
      const r = await apiCall<any[]>(token, `/v1/prowler/search?q=${encodeURIComponent(search)}&limit=50`);
      setChecks(r);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorBox message={error} onRetry={load} />;

  const filtered = checks.filter(c =>
    !search || c.title?.toLowerCase().includes(search.toLowerCase()) ||
    c.check_id?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Checks" value={stats?.total_checks ?? 0} icon={ShieldAlert} color="text-blue-400" />
        <StatCard label="AWS" value={stats?.by_provider?.aws ?? 0} icon={ShieldCheck} color="text-orange-400" />
        <StatCard label="Azure" value={stats?.by_provider?.azure ?? 0} icon={ShieldCheck} color="text-blue-500" />
        <StatCard label="GCP" value={stats?.by_provider?.gcp ?? 0} icon={ShieldCheck} color="text-green-400" />
      </div>

      {/* Compliance frameworks */}
      {stats?.by_category && (
        <Card>
          <h3 className="text-sm font-semibold mb-3">Compliance Frameworks (auto-detected)</h3>
          <div className="flex flex-wrap gap-2">
            {Object.entries(stats.by_category).sort((a: any, b: any) => b[1] - a[1]).map(([cat, count]: any) => (
              <span key={cat} className="px-3 py-1.5 bg-background/50 border border-border rounded-lg text-xs">
                <span className="font-medium">{cat}</span>
                <span className="ml-2 px-1.5 py-0.5 rounded bg-primary/20 text-primary font-bold">{count}</span>
              </span>
            ))}
          </div>
        </Card>
      )}

      {/* Search + filters */}
      <Card>
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <div className="flex-1 min-w-[200px] relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search 915 Prowler checks..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && doSearch()}
              className="w-full pl-9 pr-3 py-2 text-sm bg-background border border-border rounded-md"
            />
          </div>
          <select
            value={providerFilter}
            onChange={(e) => setProviderFilter(e.target.value)}
            className="px-3 py-2 text-sm bg-background border border-border rounded-md"
          >
            <option value="">All Providers</option>
            <option value="aws">AWS</option>
            <option value="azure">Azure</option>
            <option value="gcp">GCP</option>
          </select>
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="px-3 py-2 text-sm bg-background border border-border rounded-md"
          >
            <option value="">All Severities</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          <button onClick={load} className="p-2 hover:bg-accent rounded-md">
            <RefreshCw className="h-4 w-4" />
          </button>
        </div>

        {/* Checks list */}
        <div className="space-y-1 max-h-[500px] overflow-y-auto">
          {filtered.length === 0 ? (
            <EmptyState message="No checks match your filters." />
          ) : (
            filtered.map((c, i) => (
              <div key={i} className="p-2 bg-background/50 rounded border border-border hover:bg-accent/30">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={cn("text-xs px-1.5 py-0.5 rounded border font-bold",
                        SEVERITY_BG[c.severity] || SEVERITY_BG.info
                      )}>
                        {c.severity}
                      </span>
                      <span className="text-xs font-mono text-muted-foreground">{c.check_id}</span>
                      <span className="text-xs px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400">
                        {c.provider}/{c.service}
                      </span>
                    </div>
                    <div className="text-sm font-medium mt-1">{c.title}</div>
                    {c.categories && c.categories.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1">
                        {c.categories.map((cat: string) => (
                          <span key={cat} className="text-xs px-1 py-0.5 rounded bg-purple-500/10 text-purple-400">
                            {cat}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// 8. Checkov IaC Policies Panel
// ─────────────────────────────────────────────────────────────────────────
function CheckovPanel({ token }: { token: string }) {
  const [stats, setStats] = useState<any>(null);
  const [policies, setPolicies] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [providerFilter, setProviderFilter] = useState("");
  const [scanCode, setScanCode] = useState("");
  const [scanResult, setScanResult] = useState<any>(null);
  const [scanning, setScanning] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const s = await apiCall<any>(token, "/v1/checkov/stats");
      setStats(s);
      const params = new URLSearchParams({ limit: "100" });
      if (providerFilter) params.set("provider", providerFilter);
      const p = await apiCall<any[]>(token, `/v1/checkov/policies?${params}`);
      setPolicies(p);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token, providerFilter]);

  useEffect(() => { load(); }, [load]);

  const runScan = async () => {
    if (!scanCode.trim()) return;
    setScanning(true);
    setError(null);
    try {
      const result = await apiCall<any>(token, "/v1/checkov/scan-code", {
        method: "POST",
        body: JSON.stringify({ code: scanCode, filename: "test.tf", framework: "terraform" }),
      });
      setScanResult(result);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setScanning(false);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorBox message={error} onRetry={load} />;

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <StatCard label="Total Policies" value={stats?.total_policies ?? 0} icon={ShieldCheck} color="text-blue-400" />
        <StatCard label="AWS" value={stats?.by_provider?.aws ?? 0} icon={ShieldAlert} color="text-orange-400" />
        <StatCard label="Azure" value={stats?.by_provider?.azure ?? 0} icon={ShieldAlert} color="text-blue-500" />
        <StatCard label="GCP" value={stats?.by_provider?.gcp ?? 0} icon={ShieldAlert} color="text-green-400" />
        <StatCard label="K8s" value={stats?.by_provider?.kubernetes ?? 0} icon={ShieldAlert} color="text-purple-400" />
      </div>

      {/* IaC scanner */}
      <Card>
        <h3 className="text-sm font-semibold mb-3">Live IaC Scanner (Checkov)</h3>
        <p className="text-xs text-muted-foreground mb-3">
          Paste Terraform/CloudFormation/K8s/Dockerfile code to scan for security issues. Findings auto-trigger all 6 premium features.
        </p>
        <textarea
          value={scanCode}
          onChange={(e) => setScanCode(e.target.value)}
          rows={6}
          placeholder={`resource "aws_s3_bucket" "public" {\n  bucket = "my-bucket"\n  acl    = "public-read"\n}`}
          className="w-full px-3 py-2 text-sm bg-background border border-border rounded-md font-mono"
        />
        <div className="flex items-center justify-between mt-2">
          <span className="text-xs text-muted-foreground">{scanCode.length} chars</span>
          <button
            onClick={runScan}
            disabled={scanning || !scanCode.trim()}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {scanning ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldAlert className="h-4 w-4" />}
            {scanning ? "Scanning..." : "Scan Code"}
          </button>
        </div>

        {scanResult && (
          <div className="mt-4 space-y-3">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-2 bg-background/50 rounded-lg border border-border">
                <div className="text-xs text-muted-foreground">Total Findings</div>
                <div className="text-lg font-bold">{scanResult.total_findings}</div>
              </div>
              <div className="p-2 bg-red-500/10 rounded-lg border border-red-500/30">
                <div className="text-xs text-red-400">Critical</div>
                <div className="text-lg font-bold text-red-400">{scanResult.by_severity?.critical || 0}</div>
              </div>
              <div className="p-2 bg-orange-500/10 rounded-lg border border-orange-500/30">
                <div className="text-xs text-orange-400">High</div>
                <div className="text-lg font-bold text-orange-400">{scanResult.by_severity?.high || 0}</div>
              </div>
              <div className="p-2 bg-amber-500/10 rounded-lg border border-amber-500/30">
                <div className="text-xs text-amber-400">Medium</div>
                <div className="text-lg font-bold text-amber-400">{scanResult.by_severity?.medium || 0}</div>
              </div>
            </div>

            {scanResult.premium_features_triggered && (
              <div className="p-2 bg-green-500/10 rounded-lg border border-green-500/30 text-xs">
                <span className="text-green-400 font-medium">Premium features auto-triggered:</span>{" "}
                {scanResult.premium_features_triggered.drift_events} drift events ·{" "}
                {scanResult.premium_features_triggered.findings_prioritized} prioritized ·{" "}
                {scanResult.premium_features_triggered.evidence_records} evidence records
              </div>
            )}

            {scanResult.findings && scanResult.findings.length > 0 && (
              <div className="space-y-1 max-h-[300px] overflow-y-auto">
                {scanResult.findings.map((f: any, i: number) => (
                  <div key={i} className="p-2 bg-background/50 rounded border border-border">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={cn("text-xs px-1.5 py-0.5 rounded border font-bold",
                        SEVERITY_BG[f.severity] || SEVERITY_BG.info
                      )}>
                        {f.severity}
                      </span>
                      <span className="text-xs font-mono text-muted-foreground">{f.check_id}</span>
                      <span className="text-sm font-medium">{f.check_name}</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1 font-mono">
                      {f.resource} · {f.file_path}:{f.file_line_range?.join("-")}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </Card>

      {/* Policy browser */}
      <Card>
        <div className="flex items-center gap-2 mb-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search 1,149 Checkov policies..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-sm bg-background border border-border rounded-md"
            />
          </div>
          <select
            value={providerFilter}
            onChange={(e) => setProviderFilter(e.target.value)}
            className="px-3 py-2 text-sm bg-background border border-border rounded-md"
          >
            <option value="">All Providers</option>
            <option value="aws">AWS</option>
            <option value="azure">Azure</option>
            <option value="gcp">GCP</option>
            <option value="kubernetes">Kubernetes</option>
            <option value="docker">Docker</option>
          </select>
        </div>

        <div className="space-y-1 max-h-[400px] overflow-y-auto">
          {(search ? policies.filter(p =>
            p.check_id?.toLowerCase().includes(search.toLowerCase()) ||
            p.check_name?.toLowerCase().includes(search.toLowerCase())
          ) : policies).map((p, i) => (
            <div key={i} className="p-2 bg-background/50 rounded border border-border hover:bg-accent/30">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono text-muted-foreground">{p.check_id}</span>
                <span className="text-xs px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400">
                  {p.framework}
                </span>
                <span className="text-xs text-muted-foreground">{p.provider}</span>
              </div>
              <div className="text-sm font-medium mt-1">{p.check_name}</div>
              <div className="text-xs text-muted-foreground font-mono">{p.resource_type}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Shared UI components
// ─────────────────────────────────────────────────────────────────────────
function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("bg-card border border-border rounded-xl p-4", className)}>
      {children}
    </div>
  );
}

function StatCard({ label, value, icon: Icon, color }: {
  label: string;
  value: React.ReactNode;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
}) {
  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-muted-foreground">{label}</span>
        <Icon className={cn("h-4 w-4", color)} />
      </div>
      <div className={cn("text-2xl font-bold", typeof value === "string" && color)}>
        {value}
      </div>
    </div>
  );
}

function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center py-12">
      <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
    </div>
  );
}

function ErrorBox({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl">
      <div className="flex items-center gap-2 text-red-400 mb-2">
        <AlertTriangle className="h-4 w-4" />
        <span className="text-sm font-semibold">Error</span>
      </div>
      <pre className="text-xs text-red-300 whitespace-pre-wrap font-mono mb-3">{message}</pre>
      <button
        onClick={onRetry}
        className="px-3 py-1.5 bg-red-600 text-white rounded-md text-xs font-medium hover:bg-red-700"
      >
        Retry
      </button>
    </div>
  );
}

function EmptyState({ message, icon: Icon = AlertTriangle, action }: {
  message: string;
  icon?: React.ComponentType<{ className?: string }>;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-8 text-center">
      <Icon className="h-8 w-8 text-muted-foreground mb-2" />
      <p className="text-sm text-muted-foreground">{message}</p>
      {action}
    </div>
  );
}
