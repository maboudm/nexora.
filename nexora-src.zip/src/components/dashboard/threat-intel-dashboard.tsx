"use client";

import { useEffect, useState } from "react";
import { Globe, AlertCircle, Search, Users, Bug, Database, Activity } from "lucide-react";
import { gateway } from "@/lib/gateway";

interface ThreatIntelStats {
  total_iocs: number;
  by_type: Record<string, number>;
  by_severity: Record<string, number>;
  total_alerts: number;
  total_matches: number;
  threat_actors_tracked: number;
  malware_families_tracked: number;
}

interface ThreatActor {
  actor_id: string;
  name: string;
  aliases: string[];
  country: string;
  motivation: string;
  target_industries: string[];
  target_geographies: string[];
  mitre_tactics: string[];
  mitre_techniques: string[];
  known_malware: string[];
  description: string;
}

const SEVERITY_COLORS: Record<string, string> = {
  critical: "#ef4444",
  malicious: "#f97316",
  suspicious: "#f59e0b",
  clean: "#10b981",
};

const COUNTRY_FLAGS: Record<string, string> = {
  Russia: "🇷🇺", "North Korea": "🇰🇵", China: "🇨🇳",
  "Russia/Ukraine": "🇷🇺", Iran: "🇮🇷",
};

export function ThreatIntelDashboard({ token }: { token: string }) {
  const [stats, setStats] = useState<ThreatIntelStats | null>(null);
  const [actors, setActors] = useState<ThreatActor[]>([]);
  const [query, setQuery] = useState("");
  const [queryResult, setQueryResult] = useState<any>(null);
  const [querying, setQuerying] = useState(false);
  const [loading, setLoading] = useState(true);
  const [selectedActor, setSelectedActor] = useState<ThreatActor | null>(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const [s, a] = await Promise.all([
        gateway.getThreatIntelStats(),
        gateway.listThreatActors(),
      ]);
      setStats(s);
      setActors(a);
    } catch (e) {
      console.error("Failed to load threat intel:", e);
    } finally {
      setLoading(false);
    }
  }

  async function handleQuery() {
    if (!query.trim()) return;
    setQuerying(true);
    try {
      const result = await gateway.queryThreatIntel(query.trim());
      setQueryResult(result);
    } catch (e) {
      console.error("Query failed:", e);
      setQueryResult({ matched: false, error: "Query failed" });
    } finally {
      setQuerying(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-primary/30 border-t-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Total IOCs</span>
            <Database className="h-4 w-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{stats?.total_iocs || 0}</div>
        </div>
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Threat Actors</span>
            <Users className="h-4 w-4 text-purple-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{stats?.threat_actors_tracked || 0}</div>
        </div>
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Malware Families</span>
            <Bug className="h-4 w-4 text-red-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{stats?.malware_families_tracked || 0}</div>
        </div>
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Total Matches</span>
            <Activity className="h-4 w-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{stats?.total_matches || 0}</div>
        </div>
      </div>

      {/* IOC Lookup */}
      <div className="rounded-lg border border-border/60 bg-card p-6">
        <h3 className="text-sm font-medium text-muted-foreground mb-3 flex items-center gap-2">
          <Search className="h-4 w-4" />
          IOC Lookup
        </h3>
        <div className="flex gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleQuery()}
            placeholder="Enter IP, domain, hash, or URL (e.g., 185.220.101.5)"
            className="flex-1 px-3 py-2 rounded-md border border-border/60 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
          <button
            onClick={handleQuery}
            disabled={querying || !query.trim()}
            className="px-4 py-2 rounded-md text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          >
            {querying ? "Searching..." : "Search"}
          </button>
        </div>
        {queryResult && (
          <div className="mt-4">
            {queryResult.matched ? (
              <div className="rounded-md border p-4" style={{ borderColor: SEVERITY_COLORS[queryResult.ioc?.severity] || "#f59e0b", backgroundColor: `${SEVERITY_COLORS[queryResult.ioc?.severity] || "#f59e0b"}10` }}>
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle className="h-5 w-5" style={{ color: SEVERITY_COLORS[queryResult.ioc?.severity] }} />
                  <span className="font-semibold uppercase" style={{ color: SEVERITY_COLORS[queryResult.ioc?.severity] }}>
                    {queryResult.ioc?.severity} — Match Found
                  </span>
                </div>
                <p className="text-sm mt-2">{queryResult.ioc?.description}</p>
                <div className="grid grid-cols-2 gap-3 mt-3 text-xs">
                  <div>
                    <span className="text-muted-foreground">Reputation:</span>
                    <span className="font-semibold ml-2">{queryResult.ioc?.reputation_score}/100</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Country:</span>
                    <span className="font-semibold ml-2">{queryResult.ioc?.country || "Unknown"}</span>
                  </div>
                  {queryResult.threat_actors?.length > 0 && (
                    <div>
                      <span className="text-muted-foreground">Threat Actors:</span>
                      <span className="font-semibold ml-2">{queryResult.threat_actors.join(", ")}</span>
                    </div>
                  )}
                  {queryResult.malware_families?.length > 0 && (
                    <div>
                      <span className="text-muted-foreground">Malware:</span>
                      <span className="font-semibold ml-2">{queryResult.malware_families.join(", ")}</span>
                    </div>
                  )}
                  {queryResult.ioc?.mitre_attack_ids?.length > 0 && (
                    <div className="col-span-2">
                      <span className="text-muted-foreground">MITRE ATT&CK:</span>
                      <span className="font-mono ml-2">{queryResult.ioc.mitre_attack_ids.join(", ")}</span>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="rounded-md border border-emerald-500/30 bg-emerald-500/5 p-4 text-sm text-emerald-700 dark:text-emerald-400">
                ✓ No threats found for "{queryResult.query_value || query}". This artifact appears clean.
              </div>
            )}
          </div>
        )}
      </div>

      {/* Threat Actors */}
      <div className="rounded-lg border border-border/60 bg-card">
        <div className="p-4 border-b border-border/40">
          <h3 className="text-sm font-medium flex items-center gap-2">
            <Globe className="h-4 w-4" />
            Tracked Threat Actors ({actors.length})
          </h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-4">
          {actors.map(actor => (
            <div
              key={actor.actor_id}
              onClick={() => setSelectedActor(selectedActor?.actor_id === actor.actor_id ? null : actor)}
              className="rounded-md border border-border/40 p-3 cursor-pointer hover:border-primary transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="text-sm font-medium">
                    {COUNTRY_FLAGS[actor.country] || "🌐"} {actor.name}
                  </h4>
                  <p className="text-xs text-muted-foreground mt-1">{actor.country} · {actor.motivation}</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{actor.description}</p>
              <div className="flex flex-wrap gap-1 mt-2">
                {actor.known_malware.slice(0, 3).map(m => (
                  <span key={m} className="rounded bg-red-500/10 px-1.5 py-0.5 text-xs text-red-600">{m}</span>
                ))}
              </div>
              {selectedActor?.actor_id === actor.actor_id && (
                <div className="mt-3 pt-3 border-t border-border/40 text-xs space-y-2">
                  <div>
                    <span className="text-muted-foreground">Aliases:</span> {actor.aliases.join(", ")}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Targets:</span> {actor.target_industries.join(", ")}
                  </div>
                  <div>
                    <span className="text-muted-foreground">Geographies:</span> {actor.target_geographies.join(", ")}
                  </div>
                  <div>
                    <span className="text-muted-foreground">MITRE Tactics:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {actor.mitre_tactics.map(t => (
                        <span key={t} className="rounded bg-blue-500/10 px-1.5 py-0.5 font-mono">{t}</span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">MITRE Techniques:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {actor.mitre_techniques.map(t => (
                        <span key={t} className="rounded bg-purple-500/10 px-1.5 py-0.5 font-mono">{t}</span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
