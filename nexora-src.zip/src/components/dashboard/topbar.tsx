"use client";

import { Play, RefreshCw, Database } from "lucide-react";
import type { ScanResult } from "@/lib/scanner";
import { cn } from "@/lib/utils";

interface TopbarProps {
  scanResult: ScanResult | null;
  scanning: boolean;
  onRunScan: () => void;
  scannerStatus: "up" | "down" | "checking";
  user: { id: string; email: string; name: string; role: string };
}

export function Topbar({
  scanResult,
  scanning,
  onRunScan,
  scannerStatus,
  user,
}: TopbarProps) {
  return (
    <header className="h-16 shrink-0 border-b border-border/60 bg-card/40 backdrop-blur-sm flex items-center justify-between px-6">
      <div className="flex items-center gap-6">
        <div>
          <h1 className="text-sm font-semibold">
            AWS Account <span className="font-mono text-muted-foreground ml-1">123456789012</span>
            <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-500 font-mono uppercase tracking-wider">
              Live (moto)
            </span>
          </h1>
          <p className="text-xs text-muted-foreground">
            {scanResult
              ? `Last scan: ${scanResult.duration_ms}ms · ${scanResult.scanners_run.join(", ")} · ${scanResult.summary.total_findings} findings`
              : "No scan yet"}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Scanner mode indicator */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Database className="h-3.5 w-3.5" />
          <span>boto3 → moto</span>
        </div>

        {/* Run scan button */}
        <button
          onClick={onRunScan}
          disabled={scanning || scannerStatus === "down"}
          className={cn(
            "inline-flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors",
            "bg-primary text-primary-foreground hover:bg-primary/90",
            "disabled:opacity-50 disabled:cursor-not-allowed",
          )}
        >
          {scanning ? (
            <>
              <RefreshCw className="h-4 w-4 animate-spin" />
              Scanning…
            </>
          ) : (
            <>
              <Play className="h-4 w-4" />
              Run Scan
            </>
          )}
        </button>
      </div>
    </header>
  );
}
