"use client";

import { useEffect, useState, useCallback } from "react";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid,
  AreaChart, Area, BarChart, Bar, Cell,
} from "recharts";
import { TrendingUp, TrendingDown, Minus, Shield, Target, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

interface PostureProps {
  token: string;
}

interface PostureData {
  current: number;
  delta: number;
  trend: string;
  history: Array<{
    date: string;
    score: number;
    findings: number;
    critical: number;
    high: number;
    medium: number;
    low: number;
  }>;
  stats: {
    scans_last_7_days: number;
    scans_last_30_days: number;
    avg_score_7_day: number | null;
    avg_score_30_day: number | null;
    best_score: number | null;
    worst_score: number | null;
  };
}

export function PosturePanel({ token }: PostureProps) {
  const [data, setData] = useState<PostureData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/posture", {
        headers: { Authorization: `Bearer ${token}` },
        cache: "no-store",
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const d = await res.json();
      setData(d);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load posture data");
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary/30 border-t-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-700 dark:text-red-300">
        {error}
        <button onClick={load} className="ml-3 underline">Retry</button>
      </div>
    );
  }

  if (!data || data.history.length === 0) {
    return (
      <div className="rounded-lg border border-border/60 bg-card p-12 text-center text-sm text-muted-foreground">
        No posture data yet. Run a scan to start tracking your security posture over time.
      </div>
    );
  }

  const chartData = data.history.map((h) => ({
    date: new Date(h.date).toLocaleDateString(),
    score: h.score,
    findings: h.findings,
    critical: h.critical,
    high: h.high,
  }));

  const TrendIcon = data.trend === "improving" ? TrendingUp : data.trend === "declining" ? TrendingDown : Minus;
  const trendColor = data.trend === "improving" ? "text-emerald-500" : data.trend === "declining" ? "text-red-500" : "text-muted-foreground";
  const scoreColor = data.current >= 80 ? "text-emerald-500" : data.current >= 60 ? "text-amber-500" : "text-red-500";

  return (
    <div className="space-y-6">
      {/* Hero score */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="rounded-lg border border-border/60 bg-card p-6 lg:col-span-1">
          <p className="text-xs uppercase tracking-widest text-muted-foreground">Current Posture Score</p>
          <div className="flex items-baseline gap-3 mt-2">
            <span className={cn("text-5xl font-bold tabular-nums", scoreColor)}>{Math.round(data.current)}</span>
            <span className="text-lg text-muted-foreground">/ 100</span>
          </div>
          <div className={cn("flex items-center gap-1.5 mt-2 text-sm", trendColor)}>
            <TrendIcon className="h-4 w-4" />
            <span>
              {data.delta > 0 ? `+${data.delta.toFixed(1)}` : data.delta.toFixed(1)} since last scan
            </span>
          </div>
          <div className="mt-4 pt-4 border-t border-border/40 text-xs text-muted-foreground">
            Score = 100 − (critical×10 + high×5 + medium×2 + low×0.5)
          </div>
        </div>

        <div className="rounded-lg border border-border/60 bg-card p-6 lg:col-span-2">
          <p className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Posture Score Trend</p>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="scoreGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a3862f" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#a3862f" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" strokeOpacity={0.1} />
                <XAxis dataKey="date" stroke="currentColor" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="currentColor" fontSize={11} tickLine={false} axisLine={false} domain={[0, 100]} />
                <Tooltip
                  contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }}
                />
                <Area type="monotone" dataKey="score" stroke="#a3862f" strokeWidth={2} fill="url(#scoreGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={<Shield className="h-4 w-4" />} label="Best Score" value={data.stats.best_score?.toFixed(1) ?? "—"} color="emerald" />
        <StatCard icon={<AlertTriangle className="h-4 w-4" />} label="Worst Score" value={data.stats.worst_score?.toFixed(1) ?? "—"} color="red" />
        <StatCard icon={<Target className="h-4 w-4" />} label="7-day Avg" value={data.stats.avg_score_7_day?.toFixed(1) ?? "—"} color="amber" />
        <StatCard icon={<Target className="h-4 w-4" />} label="30-day Avg" value={data.stats.avg_score_30_day?.toFixed(1) ?? "—"} color="blue" />
      </div>

      {/* Findings over time */}
      <div className="rounded-lg border border-border/60 bg-card p-6">
        <p className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Findings Over Time</p>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="currentColor" strokeOpacity={0.1} />
              <XAxis dataKey="date" stroke="currentColor" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="currentColor" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip
                contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }}
              />
              <Bar dataKey="critical" stackId="a" fill="#ef4444" name="Critical" />
              <Bar dataKey="high" stackId="a" fill="#f97316" name="High" />
              <Bar dataKey="medium" stackId="a" fill="#f59e0b" name="Medium" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Scan history table */}
      <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
        <div className="p-4 border-b border-border/40">
          <p className="text-xs uppercase tracking-widest text-muted-foreground">Scan History ({data.history.length} scans)</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 border-b border-border/60">
              <tr>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Date</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Score</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Total</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Critical</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">High</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Medium</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Low</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/40">
              {[...data.history].reverse().map((h, i) => (
                <tr key={i} className="hover:bg-accent/30">
                  <td className="px-3 py-2 font-mono text-xs">{new Date(h.date).toLocaleString()}</td>
                  <td className="px-3 py-2">
                    <span className={cn(
                      "font-mono font-semibold tabular-nums",
                      h.score >= 80 ? "text-emerald-500" : h.score >= 60 ? "text-amber-500" : "text-red-500",
                    )}>{h.score.toFixed(1)}</span>
                  </td>
                  <td className="px-3 py-2 tabular-nums">{h.findings}</td>
                  <td className="px-3 py-2 text-red-400 tabular-nums">{h.critical}</td>
                  <td className="px-3 py-2 text-orange-400 tabular-nums">{h.high}</td>
                  <td className="px-3 py-2 text-amber-400 tabular-nums">{h.medium}</td>
                  <td className="px-3 py-2 text-blue-400 tabular-nums">{h.low}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color }: {
  icon: React.ReactNode;
  label: string;
  value: string;
  color: "emerald" | "red" | "amber" | "blue";
}) {
  const colorMap = {
    emerald: "text-emerald-500 bg-emerald-500/10 border-emerald-500/20",
    red: "text-red-500 bg-red-500/10 border-red-500/20",
    amber: "text-amber-500 bg-amber-500/10 border-amber-500/20",
    blue: "text-blue-500 bg-blue-500/10 border-blue-500/20",
  };
  return (
    <div className="rounded-lg border border-border/60 bg-card p-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</p>
          <p className="text-2xl font-semibold tabular-nums mt-1">{value}</p>
        </div>
        <div className={cn("h-8 w-8 rounded-md border flex items-center justify-center", colorMap[color])}>
          {icon}
        </div>
      </div>
    </div>
  );
}
