"use client";

import { useEffect, useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import { Loader2, AlertCircle, Wrench, User, Calendar, MessageSquare } from "lucide-react";

interface RemediationsProps {
  token: string;
}

interface Remediation {
  id: string;
  status: string;
  priority: string;
  comment: string | null;
  dueDate: string | null;
  createdAt: string;
  updatedAt: string;
  finding: {
    id: string;
    ruleId: string;
    title: string;
    severity: string;
    compliance: string;
    resource: { arn: string; name: string; type: string };
  };
  assignedTo: { id: string; name: string; email: string } | null;
}

const STATUS_COLORS: Record<string, string> = {
  open: "bg-blue-500/15 text-blue-400 border-blue-500/30",
  in_progress: "bg-amber-500/15 text-amber-400 border-amber-500/30",
  resolved: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
  wont_fix: "bg-muted text-muted-foreground border-border/60",
};

const PRIORITY_COLORS: Record<string, string> = {
  critical: "bg-red-500/15 text-red-400",
  high: "bg-orange-500/15 text-orange-400",
  medium: "bg-amber-500/15 text-amber-400",
  low: "bg-blue-500/15 text-blue-400",
};

export function RemediationsPanel({ token }: RemediationsProps) {
  const [remediations, setRemediations] = useState<Remediation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>("all");

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const url = filter === "all" ? "/api/remediations" : `/api/remediations?status=${filter}`;
      const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` }, cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const d = await res.json();
      setRemediations(d.remediations || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load remediations");
    } finally {
      setLoading(false);
    }
  }, [token, filter]);

  useEffect(() => {
    load();
  }, [load]);

  const updateStatus = async (id: string, status: string) => {
    try {
      await fetch(`/api/remediations/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ status }),
      });
      load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Update failed");
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-md bg-primary/15 border border-primary/30 flex items-center justify-center text-primary">
            <Wrench className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <h2 className="text-sm font-semibold">Remediation Workflow</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Track findings from detection to resolution. Assign owners, set priorities, and monitor SLA compliance.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            {["all", "open", "in_progress", "resolved", "wont_fix"].map((s) => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={cn(
                  "px-2.5 py-1.5 rounded-md font-medium transition-colors capitalize",
                  filter === s ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-accent",
                )}
              >
                {s === "all" ? "All" : s.replace("_", " ")}
              </button>
            ))}
          </div>
        </div>
      </div>

      {loading && (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      {error && (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-700 dark:text-red-300 flex items-center gap-2">
          <AlertCircle className="h-4 w-4" /> {error}
        </div>
      )}

      {!loading && remediations.length === 0 && (
        <div className="rounded-lg border border-border/60 bg-card p-12 text-center text-sm text-muted-foreground">
          No remediations yet. From the Findings tab, click &quot;Create Remediation&quot; to track a finding through to resolution.
        </div>
      )}

      {!loading && remediations.length > 0 && (
        <div className="space-y-3">
          {remediations.map((rem) => (
            <div key={rem.id} className="rounded-lg border border-border/60 bg-card p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={cn("px-2 py-0.5 rounded text-[10px] font-medium uppercase tracking-wider border", STATUS_COLORS[rem.status])}>
                      {rem.status.replace("_", " ")}
                    </span>
                    <span className={cn("px-2 py-0.5 rounded text-[10px] font-medium uppercase tracking-wider", PRIORITY_COLORS[rem.priority])}>
                      {rem.priority}
                    </span>
                    <span className="font-mono text-xs text-muted-foreground">{rem.finding.ruleId}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">{rem.finding.compliance}</span>
                  </div>
                  <p className="text-sm font-medium">{rem.finding.title}</p>
                  <p className="text-xs text-muted-foreground font-mono mt-1 truncate">{rem.finding.resource.arn}</p>

                  <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-muted-foreground">
                    {rem.assignedTo && (
                      <span className="flex items-center gap-1">
                        <User className="h-3 w-3" /> {rem.assignedTo.name}
                      </span>
                    )}
                    {rem.dueDate && (
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" /> Due {new Date(rem.dueDate).toLocaleDateString()}
                      </span>
                    )}
                    {rem.comment && (
                      <span className="flex items-center gap-1">
                        <MessageSquare className="h-3 w-3" /> {rem.comment}
                      </span>
                    )}
                    <span>Created {new Date(rem.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="flex flex-col gap-1 shrink-0">
                  <select
                    value={rem.status}
                    onChange={(e) => updateStatus(rem.id, e.target.value)}
                    className="px-2 py-1 rounded-md border border-border/60 bg-background text-xs focus:outline-none focus:ring-2 focus:ring-primary/40"
                  >
                    <option value="open">Open</option>
                    <option value="in_progress">In Progress</option>
                    <option value="resolved">Resolved</option>
                    <option value="wont_fix">Won&apos;t Fix</option>
                  </select>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
