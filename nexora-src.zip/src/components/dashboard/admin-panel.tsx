"use client";

import { useEffect, useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import { Loader2, AlertCircle, Settings as SettingsIcon, Calendar, Bell, Key, Copy, Check } from "lucide-react";

interface AdminProps {
  token: string;
  user: { role: string };
}

export function AdminPanel({ token, user }: AdminProps) {
  const [tab, setTab] = useState<"schedules" | "webhooks" | "apikeys">("schedules");
  const isAdmin = user.role === "admin";

  if (!isAdmin) {
    return (
      <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-4 text-sm text-amber-700 dark:text-amber-400">
        Admin access required to manage schedules, webhooks, and API keys.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <div className="flex items-start gap-3 mb-4">
          <div className="h-9 w-9 rounded-md bg-primary/15 border border-primary/30 flex items-center justify-center text-primary">
            <SettingsIcon className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-sm font-semibold">Administration</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Manage scheduled scans, alert webhooks, and API keys for programmatic integration.
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          {([
            { id: "schedules", label: "Scheduled Scans", icon: Calendar },
            { id: "webhooks", label: "Alert Webhooks", icon: Bell },
            { id: "apikeys", label: "API Keys", icon: Key },
          ] as const).map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "inline-flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-colors",
                tab === t.id ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-accent",
              )}
            >
              <t.icon className="h-3.5 w-3.5" /> {t.label}
            </button>
          ))}
        </div>
      </div>

      {tab === "schedules" && <SchedulesTab token={token} />}
      {tab === "webhooks" && <WebhooksTab token={token} />}
      {tab === "apikeys" && <ApiKeysTab token={token} />}
    </div>
  );
}

function SchedulesTab({ token }: { token: string }) {
  const [schedules, setSchedules] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: "", cron: "0 2 * * *", scanners: ["iam", "s3", "sg", "k8s"] });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/schedules", { headers: { Authorization: `Bearer ${token}` } });
      const d = await res.json();
      setSchedules(d.schedules || []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const create = async () => {
    await fetch("/api/schedules", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(form),
    });
    setForm({ name: "", cron: "0 2 * * *", scanners: ["iam", "s3", "sg", "k8s"] });
    setShowCreate(false);
    load();
  };

  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <button onClick={() => setShowCreate(!showCreate)} className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground">
          New Schedule
        </button>
      </div>
      {showCreate && (
        <div className="rounded-lg border border-border/60 bg-card p-4 space-y-3">
          <input placeholder="Schedule name (e.g. Daily 2am)" value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full px-3 py-2 rounded-md border border-border/60 bg-background text-sm" />
          <input placeholder="Cron expression" value={form.cron}
            onChange={(e) => setForm({ ...form, cron: e.target.value })}
            className="w-full px-3 py-2 rounded-md border border-border/60 bg-background text-sm font-mono" />
          <p className="text-xs text-muted-foreground">Cron format: minute hour day month weekday (e.g., &quot;0 2 * * *&quot; = daily at 2am)</p>
          <button onClick={create} className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground">Create</button>
        </div>
      )}
      {!loading && schedules.length === 0 && (
        <div className="rounded-lg border border-border/60 bg-card p-8 text-center text-sm text-muted-foreground">
          No scheduled scans configured. Create one to run automatic daily/weekly scans.
        </div>
      )}
      {!loading && schedules.length > 0 && (
        <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 border-b border-border/60">
              <tr>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground">Name</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground">Cron</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground">Scanners</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground">Enabled</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground">Last Run</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/40">
              {schedules.map((s) => (
                <tr key={s.id} className="hover:bg-accent/30">
                  <td className="px-3 py-2">{s.name}</td>
                  <td className="px-3 py-2 font-mono text-xs">{s.cron}</td>
                  <td className="px-3 py-2 text-xs">{s.scanners}</td>
                  <td className="px-3 py-2">
                    <span className={cn("px-1.5 py-0.5 rounded text-[10px]", s.enabled ? "bg-emerald-500/15 text-emerald-400" : "bg-muted text-muted-foreground")}>
                      {s.enabled ? "Enabled" : "Disabled"}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-xs text-muted-foreground">{s.lastRunAt ? new Date(s.lastRunAt).toLocaleString() : "Never"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function WebhooksTab({ token }: { token: string }) {
  const [webhooks, setWebhooks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: "", url: "", eventType: "critical_finding", severityFilter: "critical" });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/webhooks", { headers: { Authorization: `Bearer ${token}` } });
      const d = await res.json();
      setWebhooks(d.webhooks || []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const create = async () => {
    await fetch("/api/webhooks", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(form),
    });
    setForm({ name: "", url: "", eventType: "critical_finding", severityFilter: "critical" });
    setShowCreate(false);
    load();
  };

  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <button onClick={() => setShowCreate(!showCreate)} className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground">
          New Webhook
        </button>
      </div>
      {showCreate && (
        <div className="rounded-lg border border-border/60 bg-card p-4 space-y-3">
          <input placeholder="Webhook name" value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full px-3 py-2 rounded-md border border-border/60 bg-background text-sm" />
          <input placeholder="https://hooks.slack.com/services/..." value={form.url}
            onChange={(e) => setForm({ ...form, url: e.target.value })}
            className="w-full px-3 py-2 rounded-md border border-border/60 bg-background text-sm font-mono" />
          <select value={form.eventType} onChange={(e) => setForm({ ...form, eventType: e.target.value })}
            className="px-3 py-2 rounded-md border border-border/60 bg-background text-sm">
            <option value="critical_finding">Critical Finding Detected</option>
            <option value="new_scan_complete">New Scan Completed</option>
            <option value="posture_drop">Posture Score Dropped</option>
          </select>
          <button onClick={create} className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground">Create</button>
        </div>
      )}
      {!loading && webhooks.length === 0 && (
        <div className="rounded-lg border border-border/60 bg-card p-8 text-center text-sm text-muted-foreground">
          No alert webhooks configured. Create one to receive Slack/Teams/email alerts when critical findings are detected.
        </div>
      )}
      {!loading && webhooks.length > 0 && (
        <div className="space-y-2">
          {webhooks.map((w) => (
            <div key={w.id} className="rounded-lg border border-border/60 bg-card p-3">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium">{w.name}</p>
                  <p className="text-xs font-mono text-muted-foreground truncate mt-1 max-w-md">{w.url}</p>
                  <div className="flex gap-2 mt-2 text-xs">
                    <span className="px-1.5 py-0.5 rounded bg-muted text-muted-foreground">{w.eventType}</span>
                    <span className="px-1.5 py-0.5 rounded bg-muted text-muted-foreground">filter: {w.severityFilter}</span>
                    <span className={cn("px-1.5 py-0.5 rounded", w.enabled ? "bg-emerald-500/15 text-emerald-400" : "bg-muted text-muted-foreground")}>
                      {w.enabled ? "Enabled" : "Disabled"}
                    </span>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">{w.lastTriggeredAt ? `Last: ${new Date(w.lastTriggeredAt).toLocaleString()}` : "Never triggered"}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ApiKeysTab({ token }: { token: string }) {
  const [keys, setKeys] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [newKey, setNewKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: "", permissions: "read" });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/api-keys", { headers: { Authorization: `Bearer ${token}` } });
      const d = await res.json();
      setKeys(d.apiKeys || []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const create = async () => {
    const res = await fetch("/api/api-keys", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(form),
    });
    const d = await res.json();
    setNewKey(d.key);
    setForm({ name: "", permissions: "read" });
    setShowCreate(false);
    load();
  };

  const copyKey = () => {
    if (newKey) {
      navigator.clipboard.writeText(newKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-3">
      {newKey && (
        <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-4">
          <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-400 mb-2">API Key Created (copy now — shown only once)</p>
          <div className="flex items-center gap-2">
            <code className="flex-1 px-3 py-2 rounded bg-background text-xs font-mono break-all">{newKey}</code>
            <button onClick={copyKey} className="px-3 py-2 rounded-md text-xs font-medium bg-primary text-primary-foreground">
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            </button>
          </div>
          <button onClick={() => setNewKey(null)} className="mt-2 text-xs text-muted-foreground hover:text-foreground">Dismiss</button>
        </div>
      )}

      <div className="flex justify-end">
        <button onClick={() => setShowCreate(!showCreate)} className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground">
          New API Key
        </button>
      </div>

      {showCreate && (
        <div className="rounded-lg border border-border/60 bg-card p-4 space-y-3">
          <input placeholder="Key name (e.g. SIEM integration)" value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full px-3 py-2 rounded-md border border-border/60 bg-background text-sm" />
          <select value={form.permissions} onChange={(e) => setForm({ ...form, permissions: e.target.value })}
            className="px-3 py-2 rounded-md border border-border/60 bg-background text-sm">
            <option value="read">Read (list scans, findings)</option>
            <option value="write">Write (trigger scans, update findings)</option>
            <option value="admin">Admin (full access)</option>
          </select>
          <button onClick={create} className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground">Create</button>
        </div>
      )}

      {!loading && keys.length === 0 && (
        <div className="rounded-lg border border-border/60 bg-card p-8 text-center text-sm text-muted-foreground">
          No API keys configured. Create one to integrate with your SIEM, ticketing system, or automation tools.
        </div>
      )}

      {!loading && keys.length > 0 && (
        <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 border-b border-border/60">
              <tr>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground">Name</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground">Key</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground">Permissions</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground">Last Used</th>
                <th className="px-3 py-2 text-left text-[10px] uppercase tracking-widest text-muted-foreground">Created</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/40">
              {keys.map((k) => (
                <tr key={k.id} className="hover:bg-accent/30">
                  <td className="px-3 py-2">{k.name}</td>
                  <td className="px-3 py-2 font-mono text-xs">{k.keyPrefix}••••••••</td>
                  <td className="px-3 py-2">
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-muted text-muted-foreground uppercase">{k.permissions}</span>
                  </td>
                  <td className="px-3 py-2 text-xs text-muted-foreground">{k.lastUsedAt ? new Date(k.lastUsedAt).toLocaleString() : "Never"}</td>
                  <td className="px-3 py-2 text-xs text-muted-foreground">{new Date(k.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
