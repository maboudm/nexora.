"use client";

import { useEffect, useState } from "react";
import { FileText, Download, FileSpreadsheet, FileJson, File } from "lucide-react";
import { gateway } from "@/lib/gateway";

interface ReportType {
  type: string;
  name: string;
  description: string;
  formats: string[];
}

interface Report {
  report_id: string;
  report_type: string;
  format: string;
  title: string;
  file_path: string;
  file_size_bytes: number;
  generated_at: number;
}

const FORMAT_ICONS: Record<string, typeof FileText> = {
  pdf: FileText,
  excel: FileSpreadsheet,
  json: FileJson,
  csv: File,
};

export function ReportingDashboard({ token }: { token: string }) {
  const [types, setTypes] = useState<ReportType[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState<string | null>(null);
  const [genStatus, setGenStatus] = useState<string | null>(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const [t, r] = await Promise.all([
        gateway.listReportTypes(),
        gateway.listReports(20),
      ]);
      setTypes(t);
      setReports(r);
    } catch (e) {
      console.error("Failed to load reports:", e);
    } finally {
      setLoading(false);
    }
  }

  async function generate(reportType: string, format: string) {
    setGenerating(`${reportType}-${format}`);
    setGenStatus(null);
    try {
      const result = await gateway.generateReport({
        report_type: reportType,
        format,
        title: `${reportType.replace("_", " ").title()} Report`,
        data: {
          // Sample data for demo — in production, gather from all engines
          posture_score: {
            overall_score: 67.5, grade: "D", trend: "improving",
            industry_benchmark: 80, percentile: 25,
            factors: [
              { factor_name: "Compliance", score: 78.5, weight: 0.25, weighted_score: 19.6, findings_count: 8 },
              { factor_name: "Vulnerability", score: 55, weight: 0.2, weighted_score: 11, findings_count: 12 },
              { factor_name: "Exposure", score: 60, weight: 0.2, weighted_score: 12, findings_count: 9 },
            ],
            top_recommendations: [
              { action: "Fix 2 critical vulnerabilities", priority: "P1", impact: 12 },
              { action: "Enable encryption on 2 assets", priority: "P1", impact: 8 },
            ],
          },
          summary: { total: 12, critical: 2, high: 4, medium: 4, low: 2 },
          findings: [
            { id: "f1", title: "Log4Shell", severity: "critical", category: "vuln", resource_type: "package", resource_name: "log4j", region: "global", rule_id: "CVE-2021-44228", description: "RCE", remediation: "Upgrade to 2.17.1", status: "open", detected_at: Date.now() },
          ],
          assets: [],
          assessments: [],
        },
      });
      setGenStatus(`✓ ${result.title} generated (${result.file_size_bytes} bytes)`);
      load(); // refresh list
    } catch (e) {
      setGenStatus(`✗ Failed: ${e instanceof Error ? e.message : "Unknown error"}`);
    } finally {
      setGenerating(null);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-primary/30 border-t-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Generate reports */}
      <div className="rounded-lg border border-border/60 bg-card p-6">
        <h3 className="text-sm font-medium text-muted-foreground mb-4">Generate Report</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {types.map(t => (
            <div key={t.type} className="rounded-md border border-border/40 p-4">
              <h4 className="text-sm font-medium">{t.name}</h4>
              <p className="text-xs text-muted-foreground mt-1">{t.description}</p>
              <div className="flex gap-2 mt-3">
                {t.formats.map(fmt => {
                  const Icon = FORMAT_ICONS[fmt] || File;
                  return (
                    <button
                      key={fmt}
                      onClick={() => generate(t.type, fmt)}
                      disabled={generating === `${t.type}-${fmt}`}
                      className="inline-flex items-center gap-1.5 rounded-md border border-border/60 px-3 py-1.5 text-xs font-medium hover:bg-muted/50 disabled:opacity-50"
                    >
                      <Icon className="h-3.5 w-3.5" />
                      {fmt.toUpperCase()}
                      {generating === `${t.type}-${fmt}` && " ..."}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
        {genStatus && (
          <div className="mt-4 rounded-md border border-border/40 bg-muted/30 p-3 text-sm">
            {genStatus}
          </div>
        )}
      </div>

      {/* Recent reports */}
      <div className="rounded-lg border border-border/60 bg-card">
        <div className="p-4 border-b border-border/40">
          <h3 className="text-sm font-medium">Recent Reports ({reports.length})</h3>
        </div>
        {reports.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">
            No reports generated yet. Generate one above.
          </div>
        ) : (
          <div className="divide-y divide-border/40">
            {reports.map(r => {
              const Icon = FORMAT_ICONS[r.format] || File;
              return (
                <div key={r.report_id} className="p-4 flex items-center gap-3">
                  <Icon className="h-5 w-5 text-muted-foreground" />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-medium truncate">{r.title}</h4>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                      <span className="uppercase">{r.format}</span>
                      <span>{(r.file_size_bytes / 1024).toFixed(1)} KB</span>
                      <span>{new Date(r.generated_at).toLocaleString()}</span>
                    </div>
                  </div>
                  <a
                    href={`/api/download?path=${encodeURIComponent(r.file_path)}`}
                    className="inline-flex items-center gap-1 rounded-md border border-border/60 px-2.5 py-1 text-xs font-medium hover:bg-muted/50"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Download
                  </a>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
