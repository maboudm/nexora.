"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Calendar, Plus, Trash2, Play, Mail, AlertCircle, CheckCircle2,
  Clock, RefreshCw, Loader2, Send,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SchedulesPanelProps {
  token: string;
}

export function SchedulesPanel({ token }: SchedulesPanelProps) {
  const [schedules, setSchedules] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [smtpStatus, setSmtpStatus] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [cloudAccounts, setCloudAccounts] = useState<any[]>([]);

  // New schedule form
  const [name, setName] = useState("Daily Scan");
  const [cloudAccountId, setCloudAccountId] = useState("");
  const [frequency, setFrequency] = useState("daily");
  const [hour, setHour] = useState(2);
  const [alertEmail, setAlertEmail] = useState("");
  const [testEmailAddr, setTestEmailAddr] = useState("");
  const [testEmailStatus, setTestEmailStatus] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [s, a, smtp, accts] = await Promise.all([
        apiCall<any[]>(token, "/v1/schedules"),
        apiCall<any[]>(token, "/v1/schedules/alerts/history?limit=20"),
        apiCall<any>(token, "/v1/schedules/smtp/status"),
        apiCall<any[]>(token, "/v1/cloud-accounts"),
      ]);
      setSchedules(s);
      setAlerts(a);
      setSmtpStatus(smtp);
      setCloudAccounts(accts);
      if (accts.length > 0 && !cloudAccountId) {
        setCloudAccountId(accts[0].account_id);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const createSchedule = async () => {
    try {
      await apiCall(token, "/v1/schedules", {
        method: "POST",
        body: JSON.stringify({
          cloud_account_id: cloudAccountId,
          name,
          frequency,
          hour,
          alert_email: alertEmail,
          scanners: ["iam", "s3", "ec2", "rds", "eks", "lambda", "cloudtrail"],
        }),
      });
      setShowCreate(false);
      load();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const deleteSchedule = async (id: string) => {
    if (!confirm("Delete this schedule?")) return;
    try {
      await apiCall(token, `/v1/schedules/${id}`, { method: "DELETE" });
      load();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const toggleSchedule = async (id: string, enable: boolean) => {
    try {
      await apiCall(token, `/v1/schedules/${id}/toggle?enable=${enable}`, { method: "POST" });
      load();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const runNow = async (id: string) => {
    try {
      await apiCall(token, `/v1/schedules/${id}/run-now`, { method: "POST" });
      alert("Scan queued — will start within 60 seconds");
    } catch (err: any) {
      setError(err.message);
    }
  };

  const sendTestEmail = async () => {
    setTestEmailStatus("sending");
    try {
      const r = await apiCall<any>(token, `/v1/schedules/test-email?email=${encodeURIComponent(testEmailAddr)}`, {
        method: "POST",
      });
      setTestEmailStatus(r.success ? "sent" : "failed");
    } catch (err: any) {
      setTestEmailStatus(`error: ${err.message}`);
    }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Scheduled Scans & Email Alerts</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Automatically scan your cloud accounts on a schedule and get email alerts when critical findings are detected.
        </p>
      </div>

      {error && (
        <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-sm text-red-400">
          <AlertCircle className="h-4 w-4 inline mr-2" />{error}
        </div>
      )}

      {/* SMTP status */}
      <div className={cn(
        "p-4 rounded-xl border",
        smtpStatus?.configured
          ? "bg-green-500/10 border-green-500/30"
          : "bg-amber-500/10 border-amber-500/30"
      )}>
        <div className="flex items-center gap-3 mb-2">
          {smtpStatus?.configured ? (
            <CheckCircle2 className="h-5 w-5 text-green-400" />
          ) : (
            <AlertCircle className="h-5 w-5 text-amber-400" />
          )}
          <div>
            <div className="text-sm font-semibold">
              SMTP {smtpStatus?.configured ? "Configured" : "Not Configured"}
            </div>
            <div className="text-xs text-muted-foreground">
              {smtpStatus?.configured
                ? `${smtpStatus.user_set ? "User set" : ""} · ${smtpStatus.host}:${smtpStatus.port}`
                : "Set SMTP_USER + SMTP_PASSWORD env vars to enable email alerts"
              }
            </div>
          </div>
        </div>

        {/* Test email */}
        <div className="flex items-center gap-2 mt-3">
          <input
            type="email"
            placeholder="your@email.com"
            value={testEmailAddr}
            onChange={(e) => setTestEmailAddr(e.target.value)}
            className="flex-1 px-3 py-1.5 text-sm bg-background border border-border rounded-md"
          />
          <button
            onClick={sendTestEmail}
            disabled={!testEmailAddr || testEmailStatus === "sending"}
            className="px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 disabled:opacity-50 flex items-center gap-1"
          >
            {testEmailStatus === "sending" ? <Loader2 className="h-3 w-3 animate-spin" /> : <Send className="h-3 w-3" />}
            Test
          </button>
        </div>
        {testEmailStatus === "sent" && (
          <div className="text-xs text-green-400 mt-1">✓ Test email sent! Check your inbox.</div>
        )}
        {testEmailStatus === "failed" && (
          <div className="text-xs text-red-400 mt-1">✗ Failed — check SMTP credentials</div>
        )}
      </div>

      {/* Schedules list */}
      <div className="bg-card border border-border rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">Schedules ({schedules.length})</h3>
          <button
            onClick={() => setShowCreate(!showCreate)}
            className="px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 flex items-center gap-1"
          >
            <Plus className="h-4 w-4" /> New Schedule
          </button>
        </div>

        {showCreate && (
          <div className="mb-4 p-4 bg-background/50 rounded-lg border border-border space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted-foreground">Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-2 py-1 text-sm bg-background border border-border rounded-md mt-1"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Cloud Account</label>
                <select
                  value={cloudAccountId}
                  onChange={(e) => setCloudAccountId(e.target.value)}
                  className="w-full px-2 py-1 text-sm bg-background border border-border rounded-md mt-1"
                >
                  {cloudAccounts.map(a => (
                    <option key={a.account_id} value={a.account_id}>{a.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Frequency</label>
                <select
                  value={frequency}
                  onChange={(e) => setFrequency(e.target.value)}
                  className="w-full px-2 py-1 text-sm bg-background border border-border rounded-md mt-1"
                >
                  <option value="hourly">Hourly</option>
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Hour (0-23, for daily/weekly/monthly)</label>
                <input
                  type="number"
                  min={0}
                  max={23}
                  value={hour}
                  onChange={(e) => setHour(Number(e.target.value))}
                  className="w-full px-2 py-1 text-sm bg-background border border-border rounded-md mt-1"
                />
              </div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Alert Email (leave empty for no email)</label>
              <input
                type="email"
                value={alertEmail}
                onChange={(e) => setAlertEmail(e.target.value)}
                placeholder="you@company.com"
                className="w-full px-2 py-1 text-sm bg-background border border-border rounded-md mt-1"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={createSchedule}
                className="px-3 py-1.5 bg-green-600 text-white rounded-md text-sm font-medium hover:bg-green-700"
              >
                Create Schedule
              </button>
              <button
                onClick={() => setShowCreate(false)}
                className="px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {schedules.length === 0 ? (
          <div className="text-center py-8 text-sm text-muted-foreground">
            <Calendar className="h-8 w-8 mx-auto mb-2 opacity-50" />
            No schedules yet. Create one to automate your scans.
          </div>
        ) : (
          <div className="space-y-2">
            {schedules.map(s => (
              <div key={s.schedule_id} className="p-3 bg-background/50 rounded-lg border border-border">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium">{s.name}</span>
                      <span className="text-xs px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 capitalize">
                        {s.frequency}
                      </span>
                      <span className={cn(
                        "text-xs px-1.5 py-0.5 rounded border",
                        s.enabled
                          ? "bg-green-500/10 border-green-500/30 text-green-400"
                          : "bg-gray-500/10 border-gray-500/30 text-gray-400"
                      )}>
                        {s.enabled ? "Active" : "Disabled"}
                      </span>
                      {s.alert_email && (
                        <span className="text-xs px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-400 flex items-center gap-1">
                          <Mail className="h-3 w-3" /> {s.alert_email}
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      Next run: {s.next_run ? new Date(s.next_run * 1000).toLocaleString() : "—"}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Last run: {s.last_run ? new Date(s.last_run * 1000).toLocaleString() : "never"} · Runs: {s.run_count}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => runNow(s.schedule_id)}
                      title="Run now"
                      className="p-1.5 hover:bg-accent rounded-md"
                    >
                      <Play className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => toggleSchedule(s.schedule_id, !s.enabled)}
                      title={s.enabled ? "Disable" : "Enable"}
                      className="p-1.5 hover:bg-accent rounded-md"
                    >
                      <Clock className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => deleteSchedule(s.schedule_id)}
                      title="Delete"
                      className="p-1.5 hover:bg-red-500/20 rounded-md text-red-400"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Alert history */}
      {alerts.length > 0 && (
        <div className="bg-card border border-border rounded-xl p-4">
          <h3 className="text-sm font-semibold mb-3">Recent Email Alerts</h3>
          <div className="space-y-2">
            {alerts.map(a => (
              <div key={a.alert_id} className="p-2 bg-background/50 rounded border border-border">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={cn(
                    "text-xs px-1.5 py-0.5 rounded border font-bold",
                    a.status === "sent" ? "bg-green-500/10 border-green-500/30 text-green-400" :
                    "bg-red-500/10 border-red-500/30 text-red-400"
                  )}>
                    {a.status.toUpperCase()}
                  </span>
                  <span className="text-sm">{a.subject}</span>
                  <span className="text-xs text-muted-foreground ml-auto">
                    {new Date(a.sent_at * 1000).toLocaleString()}
                  </span>
                </div>
                {a.error && <div className="text-xs text-red-400 mt-1">{a.error}</div>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

async function apiCall<T>(token: string, path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`/api/gateway-proxy/${path.replace(/^\//, "")}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...options.headers,
    },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "Request failed");
    throw new Error(`${res.status}: ${text}`);
  }
  return res.json();
}
