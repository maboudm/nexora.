"use client";

import { useEffect, useState } from "react";
import type { ScanResult } from "@/lib/scanner";
import { cn } from "@/lib/utils";
import { History, RefreshCw, CheckCircle2, AlertCircle, Clock } from "lucide-react";

interface ScanHistoryPanelProps {
  token: string;
  onRescanComplete: (result: ScanResult) => void;
}

interface ScanRecord {
  id: string;
  taskId: string;
  status: string;
  scannerTypes: string;
  findingsCount: number;
  criticalCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  durationMs: number;
  createdAt: string;
  completedAt: string | null;
  triggeredBy: { name: string; email: string };
  account: { provider: string; accountId: string; alias: string };
}

export function ScanHistoryPanel({ token, onRescanComplete }: ScanHistoryPanelProps) {
  const [scans, setScans] = useState<ScanRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loadingTaskId, setLoadingTaskId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/scans", {
        headers: { Authorization: `Bearer ${token}` },
        cache: "no-store",
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setScans(data.scans || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load scans");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [token]);

  // Re-load a completed scan's result into the dashboard
  async function viewScan(scan: ScanRecord) {
    if (scan.status !== "completed") return;
    setLoadingTaskId(scan.taskId);
    try {
      const res = await fetch(`/api/scans/${scan.taskId}`, {
        headers: { Authorization: `Bearer ${token}` },
        cache: "no-store",
      });
      const data = await res.json();
      if (data.result) {
        onRescanComplete(data.result);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load scan result");
    } finally {
      setLoadingTaskId(null);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-muted-foreground">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary/30 border-t-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-700 dark:text-red-300">
        {error}
        <button onClick={load} className="ml-3 underline">
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-md bg-primary/15 border border-primary/30 flex items-center justify-center text-primary">
            <History className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <h2 className="text-sm font-semibold">Scan History</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              All scans persisted in the Prisma database. Click any completed scan to view its findings, resources, and attack graph.
            </p>
          </div>
          <button onClick={load} className="text-xs text-muted-foreground hover:text-foreground">
            <RefreshCw className="h-4 w-4" />
          </button>
        </div>
      </div>

      {scans.length === 0 ? (
        <div className="rounded-lg border border-border/60 bg-card p-12 text-center text-sm text-muted-foreground">
          No scans yet. Click <span className="font-medium text-foreground">Run Scan</span> in the top bar to start.
        </div>
      ) : (
        <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 border-b border-border/60">
              <tr>
                <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">
                  Status
                </th>
                <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">
                  Started
                </th>
                <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">
                  Duration
                </th>
                <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">
                  Scanners
                </th>
                <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">
                  Findings
                </th>
                <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">
                  Severity
                </th>
                <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">
                  Triggered By
                </th>
                <th className="px-3 py-2.5" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border/40">
              {scans.map((scan) => (
                <tr key={scan.id} className="hover:bg-accent/30 transition-colors">
                  <td className="px-3 py-2.5">
                    <StatusPill status={scan.status} />
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs font-mono">
                      {new Date(scan.createdAt).toLocaleString()}
                    </span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs font-mono">{scan.durationMs}ms</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs">{scan.scannerTypes}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs font-semibold tabular-nums">{scan.findingsCount}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex gap-1.5 text-[10px] font-mono">
                      {scan.criticalCount > 0 && (
                        <span className="px-1.5 py-0.5 rounded bg-red-500/15 text-red-400">{scan.criticalCount}C</span>
                      )}
                      {scan.highCount > 0 && (
                        <span className="px-1.5 py-0.5 rounded bg-orange-500/15 text-orange-400">{scan.highCount}H</span>
                      )}
                      {scan.mediumCount > 0 && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400">{scan.mediumCount}M</span>
                      )}
                      {scan.lowCount > 0 && (
                        <span className="px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-400">{scan.lowCount}L</span>
                      )}
                    </div>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="text-xs">
                      <p>{scan.triggeredBy?.name}</p>
                      <p className="text-[10px] text-muted-foreground">{scan.triggeredBy?.email}</p>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    {scan.status === "completed" && (
                      <button
                        onClick={() => viewScan(scan)}
                        disabled={loadingTaskId === scan.taskId}
                        className="text-xs text-primary hover:underline disabled:opacity-50"
                      >
                        {loadingTaskId === scan.taskId ? "Loading…" : "View"}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  if (status === "completed") {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest text-emerald-500">
        <CheckCircle2 className="h-3 w-3" />
        Completed
      </span>
    );
  }
  if (status === "failed") {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest text-red-500">
        <AlertCircle className="h-3 w-3" />
        Failed
      </span>
    );
  }
  if (status === "running" || status === "queued") {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest text-amber-500">
        <Clock className="h-3 w-3" />
        {status}
      </span>
    );
  }
  return <span className="text-[10px] uppercase tracking-widest text-muted-foreground">{status}</span>;
}
