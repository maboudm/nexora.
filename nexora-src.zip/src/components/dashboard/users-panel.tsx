"use client";

import { useEffect, useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import { Loader2, AlertCircle, Users, UserPlus, KeyRound } from "lucide-react";

interface UsersProps {
  token: string;
  user: { id: string; email: string; name: string; role: string };
}

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  createdAt: string;
}

const ROLE_COLORS: Record<string, string> = {
  admin: "bg-red-500/15 text-red-400",
  analyst: "bg-amber-500/15 text-amber-400",
  viewer: "bg-blue-500/15 text-blue-400",
};

export function UsersPanel({ token, user }: UsersProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [newUser, setNewUser] = useState({ email: "", name: "", password: "", role: "analyst" });

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/users", { headers: { Authorization: `Bearer ${token}` }, cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const d = await res.json();
      setUsers(d.users || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load users");
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    load();
  }, [load]);

  const createUser = async () => {
    setError(null);
    try {
      const res = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(newUser),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `HTTP ${res.status}`);
      }
      setNewUser({ email: "", name: "", password: "", role: "analyst" });
      setShowCreate(false);
      load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to create user");
    }
  };

  const isAdmin = user.role === "admin";

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-border/60 bg-card p-4">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-md bg-primary/15 border border-primary/30 flex items-center justify-center text-primary">
            <Users className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <h2 className="text-sm font-semibold">User Management</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Role-based access control: admins manage users and settings; analysts run scans and manage findings; viewers can only read.
            </p>
          </div>
          {isAdmin && (
            <button
              onClick={() => setShowCreate(!showCreate)}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <UserPlus className="h-3.5 w-3.5" /> New User
            </button>
          )}
        </div>
      </div>

      {!isAdmin && (
        <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-700 dark:text-amber-400">
          You need admin role to manage users. Your role: <b>{user.role}</b>
        </div>
      )}

      {showCreate && isAdmin && (
        <div className="rounded-lg border border-border/60 bg-card p-4 space-y-3">
          <h3 className="text-sm font-semibold">Create New User</h3>
          <div className="grid grid-cols-2 gap-3">
            <input
              placeholder="Full name"
              value={newUser.name}
              onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
              className="px-3 py-2 rounded-md border border-border/60 bg-background text-sm"
            />
            <input
              placeholder="Email"
              type="email"
              value={newUser.email}
              onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
              className="px-3 py-2 rounded-md border border-border/60 bg-background text-sm"
            />
            <input
              placeholder="Password"
              type="password"
              value={newUser.password}
              onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
              className="px-3 py-2 rounded-md border border-border/60 bg-background text-sm"
            />
            <select
              value={newUser.role}
              onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
              className="px-3 py-2 rounded-md border border-border/60 bg-background text-sm"
            >
              <option value="admin">Admin</option>
              <option value="analyst">Analyst</option>
              <option value="viewer">Viewer</option>
            </select>
          </div>
          <div className="flex gap-2">
            <button onClick={createUser} className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground">Create</button>
            <button onClick={() => setShowCreate(false)} className="px-3 py-1.5 rounded-md text-xs font-medium bg-muted text-muted-foreground">Cancel</button>
          </div>
        </div>
      )}

      {error && (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-700 dark:text-red-300 flex items-center gap-2">
          <AlertCircle className="h-4 w-4" /> {error}
        </div>
      )}

      {!loading && (
        <div className="rounded-lg border border-border/60 bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 border-b border-border/60">
              <tr>
                <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Name</th>
                <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Email</th>
                <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Role</th>
                <th className="px-3 py-2.5 text-left text-[10px] uppercase tracking-widest text-muted-foreground font-medium">Created</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/40">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-accent/30">
                  <td className="px-3 py-2.5">
                    {u.name}
                    {u.id === user.id && <span className="ml-2 text-[10px] text-muted-foreground">(you)</span>}
                  </td>
                  <td className="px-3 py-2.5 font-mono text-xs">{u.email}</td>
                  <td className="px-3 py-2.5">
                    <span className={cn("px-2 py-0.5 rounded text-[10px] uppercase tracking-wider font-medium", ROLE_COLORS[u.role])}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-xs text-muted-foreground">{new Date(u.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
