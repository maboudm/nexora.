"use client";

import { useEffect, useState } from "react";
import { Bug, Shield, Network, AlertTriangle, GitBranch, Zap } from "lucide-react";
import { gateway } from "@/lib/gateway";

interface CVEStats {
  total_cves: number;
  by_severity: Record<string, number>;
}

interface BlastStats {
  total_nodes: number;
  total_edges: number;
  density: number;
  internet_exposed_count: number;
  critical_assets_count: number;
  average_degree: number;
}

interface CriticalPath {
  path_id: string;
  source_asset_name: string;
  target_asset_name: string;
  path_names: string[];
  length: number;
  risk_score: number;
  relationships: string[];
}

interface PrivescMethod {
  method: string;
  actions: string[];
  description: string;
  mitre: string;
  risk: string;
}

export function SecurityEnginesDashboard({ token }: { token: string }) {
  const [cveStats, setCveStats] = useState<CVEStats | null>(null);
  const [blastStats, setBlastStats] = useState<BlastStats | null>(null);
  const [criticalPaths, setCriticalPaths] = useState<CriticalPath[]>([]);
  const [privescMethods, setPrivescMethods] = useState<PrivescMethod[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const [cve, blast, paths, privesc] = await Promise.all([
        gateway.getCVEStats().catch(() => null),
        gateway.getBlastRadiusGraphStats().catch(() => null),
        gateway.getCriticalPaths(5).catch(() => []),
        gateway.listPrivescMethods().catch(() => []),
      ]);
      setCveStats(cveStats);
      setBlastStats(blast);
      setCriticalPaths(paths);
      setPrivescMethods(privesc);
    } catch (e) {
      console.error("Failed to load:", e);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-primary/30 border-t-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">CVE Database</span>
            <Bug className="h-4 w-4 text-red-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{cveStats?.total_cves || 0}</div>
          <div className="text-xs text-muted-foreground mt-1">tracked vulnerabilities</div>
        </div>
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Graph Nodes</span>
            <Network className="h-4 w-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{blastStats?.total_nodes || 0}</div>
          <div className="text-xs text-muted-foreground mt-1">{blastStats?.total_edges || 0} relationships</div>
        </div>
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Critical Paths</span>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{criticalPaths.length}</div>
          <div className="text-xs text-muted-foreground mt-1">internet → critical asset</div>
        </div>
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Privesc Methods</span>
            <Shield className="h-4 w-4 text-purple-500" />
          </div>
          <div className="text-2xl font-bold mt-2">{privescMethods.length}</div>
          <div className="text-xs text-muted-foreground mt-1">detection patterns</div>
        </div>
      </div>

      {/* CVE severity breakdown */}
      {cveStats && (
        <div className="rounded-lg border border-border/60 bg-card p-4">
          <h3 className="text-sm font-medium text-muted-foreground mb-3">CVE Severity Distribution</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
            {["critical", "high", "medium", "low", "none"].map(sev => {
              const count = cveStats.by_severity[sev] || 0;
              const colors: Record<string, string> = {
                critical: "#ef4444", high: "#f97316", medium: "#f59e0b", low: "#3b82f6", none: "#6b7280",
              };
              return (
                <div key={sev} className="rounded-md border border-border/40 p-3 text-center">
                  <div className="text-xs uppercase text-muted-foreground">{sev}</div>
                  <div className="text-2xl font-bold" style={{ color: colors[sev] }}>{count}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Critical attack paths */}
      <div className="rounded-lg border border-border/60 bg-card">
        <div className="p-4 border-b border-border/40">
          <h3 className="text-sm font-medium flex items-center gap-2">
            <GitBranch className="h-4 w-4 text-red-500" />
            Critical Attack Paths (Internet → Critical Asset)
          </h3>
        </div>
        {criticalPaths.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">
            No critical paths detected. Load assets into the blast radius graph to see attack paths.
          </div>
        ) : (
          <div className="divide-y divide-border/40">
            {criticalPaths.map(p => (
              <div key={p.path_id} className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-red-500/10 px-2 py-0.5 text-xs font-medium text-red-600">
                      Risk: {p.risk_score}
                    </span>
                    <span className="text-xs text-muted-foreground">{p.length} hops</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap text-sm">
                  {p.path_names.map((name, i) => (
                    <span key={i} className="flex items-center gap-2">
                      <span className={`rounded px-2 py-1 ${i === 0 ? "bg-blue-500/10 text-blue-600" : i === p.path_names.length - 1 ? "bg-red-500/10 text-red-600" : "bg-muted"}`}>
                        {name}
                      </span>
                      {i < p.path_names.length - 1 && <span className="text-muted-foreground">→</span>}
                    </span>
                  ))}
                </div>
                <div className="flex flex-wrap gap-1 mt-2">
                  {p.relationships.map((r, i) => (
                    <span key={i} className="rounded bg-purple-500/10 px-1.5 py-0.5 text-xs text-purple-600 font-mono">
                      {r}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Privilege escalation methods */}
      <div className="rounded-lg border border-border/60 bg-card">
        <div className="p-4 border-b border-border/40">
          <h3 className="text-sm font-medium flex items-center gap-2">
            <Zap className="h-4 w-4 text-amber-500" />
            CIEM Privilege Escalation Detection Methods
          </h3>
        </div>
        <div className="divide-y divide-border/40">
          {privescMethods.map(m => (
            <div key={m.method} className="p-4">
              <div className="flex items-center justify-between mb-1">
                <h4 className="text-sm font-medium">{m.method}</h4>
                <span className="rounded bg-red-500/10 px-2 py-0.5 text-xs text-red-600 font-mono">
                  {m.mitre}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mb-2">{m.description}</p>
              <div className="flex flex-wrap gap-1">
                {m.actions.map(a => (
                  <span key={a} className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono">
                    {a}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
