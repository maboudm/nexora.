"use client";

import { useEffect, useState, useRef, useCallback } from "react";

interface AlertMessage {
  type: string;
  channel?: string;
  data?: any;
  timestamp?: number;
  client_id?: string;
  channels?: string[];
}

interface UseWebSocketOptions {
  token: string | null;
  channels?: string[];
  onAlert?: (msg: AlertMessage) => void;
}

/**
 * React hook for WebSocket real-time alerts.
 *
 * Connects to the gateway WebSocket via Next.js proxy.
 * Automatically reconnects on disconnect.
 *
 * Usage:
 *   const { alerts, connected, send } = useWebSocket({
 *     token,
 *     channels: ["detections", "threat_intel"],
 *     onAlert: (msg) => console.log("Alert:", msg),
 *   });
 */
export function useWebSocket({ token, channels = ["detections", "threat_intel", "cwpp", "findings"], onAlert }: UseWebSocketOptions) {
  const [connected, setConnected] = useState(false);
  const [alerts, setAlerts] = useState<AlertMessage[]>([]);
  const [stats, setStats] = useState<any>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeout = useRef<NodeJS.Timeout>();
  const onAlertRef = useRef(onAlert);
  onAlertRef.current = onAlert;

  const connect = useCallback(() => {
    if (!token) return;
    // Use Next.js proxy path which handles the WS upgrade
    // We need to connect to the gateway directly via WS
    const gatewayUrl = process.env.NEXT_PUBLIC_GATEWAY_URL ||
      (typeof window !== "undefined" ? window.location.origin.replace(/:\d+$/, ":8000") : "http://localhost:8000");
    const wsUrl = gatewayUrl.replace(/^http/, "ws") + `/ws/alerts?token=${encodeURIComponent(token)}`;

    try {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setConnected(true);
        // Subscribe to requested channels
        ws.send(JSON.stringify({ action: "subscribe", channels }));
      };

      ws.onmessage = (event) => {
        try {
          const msg: AlertMessage = JSON.parse(event.data);
          if (msg.type === "alert") {
            setAlerts(prev => [msg, ...prev].slice(0, 100)); // keep last 100
            onAlertRef.current?.(msg);
          } else if (msg.type === "stats") {
            setStats(msg.data);
          }
        } catch (e) {
          console.error("Failed to parse WS message:", e);
        }
      };

      ws.onclose = () => {
        setConnected(false);
        // Reconnect after 5s
        reconnectTimeout.current = setTimeout(connect, 5000);
      };

      ws.onerror = (e) => {
        console.error("WebSocket error:", e);
      };
    } catch (e) {
      console.error("Failed to connect WebSocket:", e);
      reconnectTimeout.current = setTimeout(connect, 5000);
    }
  }, [token]);

  useEffect(() => {
    connect();
    return () => {
      if (reconnectTimeout.current) clearTimeout(reconnectTimeout.current);
      wsRef.current?.close();
    };
  }, [connect]);

  const send = useCallback((message: any) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    }
  }, []);

  const subscribe = useCallback((newChannels: string[]) => {
    send({ action: "subscribe", channels: newChannels });
  }, [send]);

  const clearAlerts = useCallback(() => setAlerts([]), []);

  return { connected, alerts, stats, send, subscribe, clearAlerts };
}
