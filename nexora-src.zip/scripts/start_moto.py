"""
moto server wrapper - runs moto in standalone mode on port 5000.

moto implements the actual AWS API wire protocol. When boto3 is configured
with endpoint_url=http://localhost:5000, all AWS SDK calls go to moto
instead of real AWS. The scanner uses the same boto3 calls it would use
against real AWS - only the endpoint differs.

This is the same technique AWS's own SDK tests use.
"""
import os
import sys
import subprocess


def start_moto_server():
    """Start moto_server on port 5000 in the background."""
    print("[moto] Starting AWS API emulator on port 5000...")
    proc = subprocess.Popen(
        [sys.executable, "-m", "moto.server", "-p", "5000", "-H", "0.0.0.0"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    return proc


if __name__ == "__main__":
    import time
    proc = start_moto_server()
    print(f"[moto] Started PID {proc.pid}")
    # Wait for it to be ready
    import urllib.request
    for _ in range(20):
        try:
            urllib.request.urlopen("http://localhost:5000/moto-api/", timeout=1)
            print("[moto] Ready at http://localhost:5000")
            break
        except Exception:
            time.sleep(0.5)
    else:
        print("[moto] Failed to start", file=sys.stderr)
        sys.exit(1)
