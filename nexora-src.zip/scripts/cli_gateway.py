#!/usr/bin/env python3
"""
Sentinel CNAPP — Lightweight CLI Gateway.

Processes a single API request and exits. No long-running process needed.
This is the reliable approach for sandboxed environments that kill
background processes.

Usage:
  python3 cli_gateway.py <method> <path> [body_json] [auth_token]

Output: JSON response on stdout

Example:
  python3 cli_gateway.py POST /v1/auth/login '{"email":"a@b.com","password":"x"}'
  python3 cli_gateway.py GET /v1/cloud-accounts '' "eyJhbG..."
"""
import sys
import os
import json
import time

# Set environment
os.environ.setdefault("AUDIT_MASTER_KEY", "a" * 64)
os.environ.setdefault("JWT_SECRET", "sentinel-cnapp-jwt-secret-2026-change-me-32chars")
os.environ.setdefault("MASTER_ENCRYPTION_KEY", "a" * 64)

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "backend"))

# Suppress logging
import logging
logging.disable(logging.WARNING)


def main():
    if len(sys.argv) < 3:
        print(json.dumps({"error": "Usage: cli_gateway.py <method> <path> [body] [token]"}))
        sys.exit(1)

    method = sys.argv[1].upper()
    path = sys.argv[2]
    body_str = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] else "{}"
    token = sys.argv[4] if len(sys.argv) > 4 else None

    try:
        body = json.loads(body_str) if body_str else {}
    except json.JSONDecodeError:
        body = {}

    try:
        # Import the gateway app components
        from gateway.app import (
            app, store, audit_engine, compliance_engine, event_bus,
            notification_engine, ai_engine, dspm_engine, container_engine,
            kspm_engine, iac_engine, cwpp_agent, remediator_engine,
            ciem_engine, vulnerability_engine, threat_intel_engine,
            asset_inventory_engine, realtime_engine, policy_engine,
            blast_radius_engine, posture_engine, reporting_engine,
            websocket_manager,
            hash_password, verify_password, create_jwt_token, verify_jwt_token,
            TenantUser, CloudAccount, ScanRecord, AuditCategory, AuditOutcome, AuditSeverity,
        )
        from dataclasses import asdict
        import uuid

        # --- Route handling ---
        # Auth: login
        if method == "POST" and path == "/v1/auth/login":
            user = store.get_user_by_email(body.get("email", ""))
            if not user or not verify_password(body.get("password", ""), user.password_hash):
                print(json.dumps({"detail": "Invalid credentials"}))
                sys.exit(1)
            token = create_jwt_token(user)
            store.update_last_login(user.user_id)
            print(json.dumps({
                "token": token,
                "user": user.to_dict(),
                "expires_in": 86400,
            }))
            return

        # For all other routes, verify token
        if not token:
            print(json.dumps({"detail": "Not authenticated"}))
            sys.exit(1)

        try:
            payload = verify_jwt_token(token)
        except Exception:
            print(json.dumps({"detail": "Invalid token"}))
            sys.exit(1)

        user = store.get_user(payload["user_id"])
        if not user:
            print(json.dumps({"detail": "User not found"}))
            sys.exit(1)

        # Cloud accounts
        if method == "GET" and path == "/v1/cloud-accounts":
            accounts = store.list_cloud_accounts(user.tenant_id)
            print(json.dumps([
                {
                    "account_id": a.account_id, "name": a.name,
                    "provider": a.provider, "external_id": a.external_id,
                    "credential_type": a.credential_type, "role_arn": a.role_arn,
                    "regions": a.regions, "status": a.status,
                    "last_scan_at": a.last_scan_at, "created_at": a.created_at,
                } for a in accounts
            ]))
            return

        # Scans
        if method == "POST" and path == "/v1/scans":
            account = store.get_cloud_account(body.get("cloud_account_id", ""), user.tenant_id)
            if not account:
                print(json.dumps({"detail": "Cloud account not found"}))
                sys.exit(1)
            scan_id = str(uuid.uuid4())
            scan = ScanRecord(
                scan_id=scan_id, tenant_id=user.tenant_id,
                workspace_id=account.workspace_id,
                cloud_account_id=account.account_id, status="queued",
            )
            store.add_scan(scan)
            # Run scan synchronously (since we're a CLI)
            from gateway.app import _execute_scan
            _execute_scan(scan_id, user.tenant_id, account, body.get("scanners", ["iam", "s3", "sg", "eks"]))
            print(json.dumps({"scan_id": scan_id, "status": "completed"}))
            return

        if method == "GET" and path.startswith("/v1/scans/"):
            scan_id = path.split("/")[-1]
            scan = store.get_scan(scan_id, user.tenant_id)
            if not scan:
                print(json.dumps({"detail": "Scan not found"}))
                sys.exit(1)
            print(json.dumps(asdict(scan)))
            return

        if method == "GET" and path == "/v1/scans":
            scans = store.list_scans(user.tenant_id)
            print(json.dumps([
                {
                    "scan_id": s.scan_id, "cloud_account_id": s.cloud_account_id,
                    "status": s.status, "started_at": s.started_at,
                    "completed_at": s.completed_at, "total_assets": s.total_assets,
                    "total_findings": s.total_findings,
                    "findings_by_severity": s.findings_by_severity,
                    "error": s.error,
                } for s in scans
            ]))
            return

        # Detection stats
        if method == "GET" and path == "/v1/detection/stats":
            print(json.dumps(realtime_engine.get_stats()))
            return

        if method == "GET" and path == "/v1/detection/rules":
            print(json.dumps(realtime_engine.list_rules()))
            return

        if method == "GET" and path == "/v1/detection/detections":
            detections = realtime_engine.list_detections(tenant_id=user.tenant_id, limit=100)
            print(json.dumps([asdict(d) for d in detections]))
            return

        # Threat intel
        if method == "GET" and path == "/v1/threat-intel/stats":
            print(json.dumps(threat_intel_engine.get_stats()))
            return

        if method == "GET" and path == "/v1/threat-intel/threat-actors":
            print(json.dumps(threat_intel_engine.list_threat_actors()))
            return

        if method == "POST" and path == "/v1/threat-intel/query":
            match = threat_intel_engine.query(body.get("value", ""), body.get("ioc_type"))
            alert = None
            if match.matched:
                alert = threat_intel_engine.create_alert(
                    user.tenant_id, body.get("value", ""), match, body.get("source_context", ""),
                )
            result = {
                "matched": match.matched,
                "ioc": asdict(match.ioc) if match.ioc else None,
                "threat_actors": match.threat_actors,
                "malware_families": match.malware_families,
                "enrichment": match.enrichment,
                "alert_id": alert.alert_id if alert else None,
            }
            print(json.dumps(result))
            return

        # Vulnerability
        if method == "GET" and path == "/v1/vulnerability/cve-db-stats":
            print(json.dumps(vulnerability_engine.cve_db_stats()))
            return

        # CIEM
        if method == "GET" and path == "/v1/ciem/escalation-methods":
            print(json.dumps(ciem_engine.list_privilege_escalation_methods()))
            return

        # Posture
        if method == "GET" and path == "/v1/posture/benchmarks":
            print(json.dumps(posture_engine.get_benchmarks()))
            return

        if method == "POST" and path == "/v1/posture/calculate":
            posture = posture_engine.calculate(
                tenant_id=user.tenant_id,
                compliance_data=body.get("compliance_data", {}),
                vulnerability_data=body.get("vulnerability_data", {}),
                exposure_data=body.get("exposure_data", {}),
                identity_data=body.get("identity_data", {}),
                data_protection_data=body.get("data_protection_data", {}),
                detection_data=body.get("detection_data", {}),
                industry=body.get("industry", "general"),
            )
            print(json.dumps(asdict(posture)))
            return

        # Reports
        if method == "GET" and path == "/v1/reports/types":
            print(json.dumps(reporting_engine.list_report_types()))
            return

        if method == "GET" and path == "/v1/reports":
            print(json.dumps(reporting_engine.list_reports(tenant_id=user.tenant_id)))
            return

        # Multi-cloud
        if method == "GET" and path == "/v1/multi-cloud/providers":
            print(json.dumps([
                {"provider": "aws", "name": "Amazon Web Services", "status": "production"},
                {"provider": "azure", "name": "Microsoft Azure", "status": "beta"},
                {"provider": "gcp", "name": "Google Cloud Platform", "status": "beta"},
            ]))
            return

        # Audit
        if method == "GET" and path == "/v1/audit/verify":
            print(json.dumps(audit_engine.verify_chain(user.tenant_id)))
            return

        if method == "GET" and path == "/v1/audit":
            entries = audit_engine.query(tenant_id=user.tenant_id, limit=100)
            print(json.dumps([e.to_dict() for e in entries]))
            return

        # Compliance
        if method == "GET" and path == "/v1/compliance/frameworks":
            print(json.dumps(compliance_engine.list_frameworks()))
            return

        # AI
        if method == "GET" and path == "/v1/ai/conversations":
            convs = ai_engine.list_conversations(user.tenant_id, user_id=user.user_id)
            print(json.dumps([
                {"conversation_id": c.conversation_id, "title": c.title,
                 "created_at": c.created_at, "updated_at": c.updated_at,
                 "message_count": len(c.messages)}
                for c in convs
            ]))
            return

        # Vulnerability NVD sync
        if method == "POST" and path == "/v1/vulnerability/sync-nvd":
            from vulnerability.nvd_client import get_nvd_client
            client = get_nvd_client()
            stats = client.sync_database(max_results=200, days_back=7)
            print(json.dumps(stats))
            return

        if method == "GET" and path == "/v1/vulnerability/search":
            from vulnerability.nvd_client import get_nvd_client
            from urllib.parse import urlparse, parse_qs
            qs = parse_qs(urlparse(path + "?" + body_str).query) if "?" in body_str else {}
            client = get_nvd_client()
            results = client.search_cves(
                query=qs.get("q", [""])[0],
                severity=qs.get("severity", [None])[0],
                min_score=float(qs.get("min_score", ["0"])[0]),
                limit=int(qs.get("limit", ["50"])[0]),
            )
            print(json.dumps(results))
            return

        # Unknown route
        print(json.dumps({"detail": f"Not found: {method} {path}"}))
        sys.exit(1)

    except Exception as e:
        import traceback
        print(json.dumps({"error": str(e), "traceback": traceback.format_exc()[-500:]}))
        sys.exit(1)


if __name__ == "__main__":
    main()
