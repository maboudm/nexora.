#!/usr/bin/env python3
"""Sentinel Gateway Keepalive Daemon.

Watches the gateway process and restarts it if it dies.
Also ensures the gateway stays running even when the sandbox
kills background processes.
"""
import os
import subprocess
import sys
import time
import signal

PROJECT_DIR = "/home/z/my-project"
PYTHON = "/home/z/.venv/bin/python3"
GATEWAY_CMD = [
    PYTHON, "-m", "uvicorn", "backend.gateway.app:app",
    "--host", "0.0.0.0", "--port", "8000", "--log-level", "warning",
]
LOG_FILE = "/tmp/gateway.log"
PID_FILE = "/tmp/sentinel-gateway.pid"

# Set required env vars
os.environ["AUDIT_MASTER_KEY"] = os.environ.get("AUDIT_MASTER_KEY") or \
    __import__("secrets").token_hex(32)
os.environ["JWT_SECRET"] = os.environ.get("JWT_SECRET", "sentinel-cnapp-jwt-secret-2026-change-me-32chars")
os.environ["MASTER_ENCRYPTION_KEY"] = os.environ.get("MASTER_ENCRYPTION_KEY") or \
    __import__("secrets").token_hex(32)

def is_gateway_up() -> bool:
    try:
        import urllib.request
        req = urllib.request.urlopen("http://localhost:8000/health", timeout=2)
        return req.status == 200
    except Exception:
        return False

def start_gateway() -> subprocess.Popen:
    log_fd = open(LOG_FILE, "a")
    proc = subprocess.Popen(
        GATEWAY_CMD,
        cwd=PROJECT_DIR,
        stdout=log_fd,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,  # detach from this process group
        env=os.environ.copy(),
    )
    with open(PID_FILE, "w") as f:
        f.write(str(proc.pid))
    return proc

def main():
    print(f"[keepalive] Starting gateway keepalive daemon (PID {os.getpid()})")
    proc = None
    restart_count = 0
    max_restarts_per_minute = 10
    restart_times = []

    while True:
        # Check if gateway is responding
        if not is_gateway_up():
            now = time.time()
            # Trim restart times older than 60s
            restart_times = [t for t in restart_times if now - t < 60]
            if len(restart_times) >= max_restarts_per_minute:
                print(f"[keepalive] Too many restarts ({len(restart_times)}/min), waiting 30s...")
                time.sleep(30)
                continue

            print(f"[keepalive] Gateway is down, restarting... (attempt {len(restart_times)+1})")
            # Kill any existing process
            if proc and proc.poll() is None:
                try:
                    proc.kill()
                    proc.wait(timeout=5)
                except Exception:
                    pass
            # Start fresh
            try:
                proc = start_gateway()
                restart_times.append(now)
                print(f"[keepalive] Started gateway (PID {proc.pid})")
                # Wait for it to come up
                for _ in range(15):
                    if is_gateway_up():
                        print("[keepalive] Gateway is healthy")
                        break
                    time.sleep(1)
                else:
                    print("[keepalive] Gateway failed to start within 15s")
            except Exception as e:
                print(f"[keepalive] Failed to start gateway: {e}")
        time.sleep(5)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("[keepalive] Shutting down")
        sys.exit(0)
