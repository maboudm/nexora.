"""
Supervisor daemon for the scanner service (port 3030).

Same double-fork pattern as moto_supervisor.py. The scanner needs:
  - moto running on port 5000 (moto_supervisor handles that)
  - AWS_ENDPOINT_URL env var set (so boto3 talks to moto)
  - AWS resources provisioned in moto (provision.py)

This supervisor starts the scanner with the right env vars and restarts
it if it dies.
"""
import os
import sys
import time
import subprocess
import urllib.request

SCANNER_DIR = "/home/z/my-project/mini-services/scanner"
LOG_FILE = "/home/z/my-project/scanner.log"
PORT = 3030


def is_running():
    try:
        r = urllib.request.urlopen(f"http://127.0.0.1:{PORT}/health", timeout=5)
        return r.status == 200
    except Exception:
        return False


def wait_for_moto():
    """Don't start scanner until moto is reachable."""
    for _ in range(60):
        try:
            r = urllib.request.urlopen("http://127.0.0.1:5000/moto-api/", timeout=2)
            if r.status == 200:
                return True
        except Exception:
            pass
        time.sleep(2)
    return False


def provision_aws():
    """Run provision.py to ensure AWS resources exist in moto."""
    env = os.environ.copy()
    env["AWS_ENDPOINT_URL"] = "http://127.0.0.1:5000"
    env["AWS_ACCESS_KEY_ID"] = "test"
    env["AWS_SECRET_ACCESS_KEY"] = "test"
    env["AWS_DEFAULT_REGION"] = "us-east-1"
    try:
        with open(LOG_FILE, "a") as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Provisioning AWS resources...\n")
        subprocess.run(
            [sys.executable, "provision.py"],
            cwd=SCANNER_DIR,
            env=env,
            stdout=open(LOG_FILE, "a"),
            stderr=subprocess.STDOUT,
            timeout=60,
        )
    except Exception as e:
        with open(LOG_FILE, "a") as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Provision failed: {e}\n")


def start_uvicorn():
    env = os.environ.copy()
    env["AWS_ENDPOINT_URL"] = "http://127.0.0.1:5000"
    env["AWS_ACCESS_KEY_ID"] = "test"
    env["AWS_SECRET_ACCESS_KEY"] = "test"
    env["AWS_DEFAULT_REGION"] = "us-east-1"
    log = open(LOG_FILE, "a")
    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", str(PORT), "--workers", "1"],
        cwd=SCANNER_DIR,
        env=env,
        stdout=log,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    return proc


_provisioned = False


if __name__ == "__main__":
    # Double-fork for daemon
    os.chdir("/")
    if os.fork() != 0:
        os._exit(0)
    os.setsid()
    if os.fork() != 0:
        os._exit(0)

    while True:
        if not wait_for_moto():
            time.sleep(5)
            continue
        if not _provisioned:
            provision_aws()
            _provisioned = True
        if not is_running():
            try:
                proc = start_uvicorn()
                with open(LOG_FILE, "a") as f:
                    f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Supervisor: started scanner PID {proc.pid}\n")
            except Exception as e:
                with open(LOG_FILE, "a") as f:
                    f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Supervisor: failed to start: {e}\n")
        time.sleep(5)
