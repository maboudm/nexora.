"""
Validate all 6 Phase-7 engines end-to-end.
"""
import sys
sys.path.insert(0, "/home/z/my-project")

import time
import json

print("=" * 70)
print("SENTINEL CNAPP — Phase 7 Engine Validation")
print("=" * 70)

TENANT = "tenant-test-001"

# =========================================================================
# Feature 1: Drift Detection
# =========================================================================
print("\n[1/6] Drift Detection Engine...")
from backend.drift_detection.engine import engine as drift_engine, DriftType

baseline_assets = [
    {"id": "sg-001", "type": "security_group", "name": "web-sg",
     "metadata": {"ingress_rules": [{"port": 443, "cidr": "0.0.0.0/0"}],
                  "egress_rules": [{"port": "all", "cidr": "0.0.0.0/0"}]}},
    {"id": "s3-001", "type": "s3_bucket", "name": "public-data",
     "metadata": {"public_access": False, "encryption": True, "versioning": True}},
    {"id": "iam-001", "type": "iam_role", "name": "admin-role",
     "metadata": {"attached_policies": ["ReadOnlyAccess"], "mfa_active": True}},
]
r = drift_engine.capture_baseline(TENANT, baseline_assets, scan_id="scan-001")
print(f"  ✓ Baseline captured: {r['captured_assets']} assets")

# Now mutate state: open SSH + remove S3 encryption + grant admin
mutated_assets = [
    {"id": "sg-001", "type": "security_group", "name": "web-sg",
     "metadata": {"ingress_rules": [{"port": 443, "cidr": "0.0.0.0/0"}, {"port": 22, "cidr": "0.0.0.0/0"}],
                  "egress_rules": [{"port": "all", "cidr": "0.0.0.0/0"}]}},
    {"id": "s3-001", "type": "s3_bucket", "name": "public-data",
     "metadata": {"public_access": False, "encryption": False, "versioning": True}},
    {"id": "iam-001", "type": "iam_role", "name": "admin-role",
     "metadata": {"attached_policies": ["AdministratorAccess"], "mfa_active": True}},
    # New asset created
    {"id": "ec2-001", "type": "ec2_instance", "name": "web-server-1",
     "metadata": {"public_ip": "1.2.3.4", "instance_type": "t3.medium"}},
]
r = drift_engine.detect_drift(TENANT, mutated_assets, scan_id="scan-002")
print(f"  ✓ Drift detected: {r['total_drifts']} events, {r['high_risk_drift_count']} high-risk")
print(f"    by_type: {r['by_type']}")
print(f"    by_severity: {r['by_severity']}")
stats = drift_engine.get_stats(TENANT, window_hours=24)
print(f"  ✓ Stats: velocity={stats['drift_velocity_per_hour']} drifts/hour")

# =========================================================================
# Feature 2: Finding Prioritization
# =========================================================================
print("\n[2/6] Finding Prioritization Engine...")
from backend.finding_prioritization.engine import engine as prio_engine

findings = [
    {"id": "f1", "title": "S3 bucket publicly accessible", "severity": "critical",
     "asset_id": "s3-001", "cvss_score": 9.1, "epss_score": 0.45, "threat_intel_match": True,
     "category": "data_exposure"},
    {"id": "f2", "title": "Outdated OpenSSL on EC2", "severity": "high",
     "asset_id": "ec2-001", "cvss_score": 7.5, "epss_score": 0.32, "threat_intel_match": True,
     "category": "vulnerability"},
    {"id": "f3", "title": "Root account has access key", "severity": "critical",
     "asset_id": "iam-001", "cvss_score": 9.8, "epss_score": 0.12, "threat_intel_match": False,
     "category": "identity_risk"},
    {"id": "f4", "title": "Missing tag on dev EC2", "severity": "low",
     "asset_id": "ec2-dev-1", "cvss_score": 2.1, "epss_score": 0.01, "threat_intel_match": False,
     "category": "compliance_violation"},
    {"id": "f5", "title": "SG open to SSH from internet", "severity": "high",
     "asset_id": "sg-001", "cvss_score": 8.2, "epss_score": 0.78, "threat_intel_match": True,
     "category": "network_exposure"},
]
assets_for_findings = [
    {"id": "s3-001", "type": "s3_bucket", "tags": {"tier": "tier_0"}, "metadata": {"public_access": True}},
    {"id": "ec2-001", "type": "ec2_instance", "tags": {"tier": "tier_1"}, "metadata": {"public_ip": "1.2.3.4"}},
    {"id": "iam-001", "type": "iam_role", "tags": {"tier": "tier_0"}, "metadata": {}},
    {"id": "ec2-dev-1", "type": "ec2_instance", "tags": {"tier": "tier_3"}, "metadata": {}},
    {"id": "sg-001", "type": "security_group", "tags": {"tier": "tier_1"}, "metadata": {"ingress_rules": [{"port": 22}]}},
]
prioritized = prio_engine.prioritize(TENANT, findings, assets_for_findings)
print(f"  ✓ Prioritized {len(prioritized)} findings")
for p in prioritized[:3]:
    print(f"    #{p.risk_score:>7.1f} [{p.risk_band:>8}] {p.title[:50]:50} (effort={p.fix_effort_hours}h, RROI={p.risk_reduction_per_hour:.1f})")

plan = prio_engine.build_fix_plan(TENANT, prioritized, budget_hours=20.0)
print(f"  ✓ Fix plan: budget={plan.budget_hours}h, used={plan.used_hours}h, risk_reduction={plan.total_risk_reduction}")
print(f"    Selected: {len(plan.selected_findings)} findings | Quick wins: {len(plan.quick_wins)}")
stats = prio_engine.get_stats(TENANT, prioritized)
print(f"  ✓ Stats: total_risk={stats['total_risk_score']}, total_effort={stats['total_fix_effort_hours']}h")

# =========================================================================
# Feature 3: Kill Chain Attack Path
# =========================================================================
print("\n[3/6] Attack Path / Kill Chain Engine...")
from backend.kill_chain.engine import engine as kill_engine

kc_assets = [
    {"id": "internet", "name": "Internet", "type": "external",
     "metadata": {"internet_facing": True}},
    {"id": "lb-001", "name": "Public ALB", "type": "load_balancer",
     "metadata": {"public_ip": "1.2.3.5", "internet_facing": True}},
    {"id": "ec2-web", "name": "Web Server", "type": "ec2_instance",
     "metadata": {"public_ip": "1.2.3.6", "internet_facing": True},
     "tags": {"tier": "tier_1"}},
    {"id": "ec2-app", "name": "App Server", "type": "ec2_instance",
     "metadata": {}, "tags": {"tier": "tier_1"}},
    {"id": "iam-role-app", "name": "AppRole", "type": "iam_role",
     "metadata": {}, "tags": {"tier": "tier_0"}},
    {"id": "rds-prod", "name": "Production DB", "type": "rds_instance",
     "metadata": {}, "tags": {"tier": "tier_0"}},
    {"id": "s3-customer", "name": "Customer Data", "type": "s3_bucket",
     "metadata": {}, "tags": {"tier": "tier_0"}},
]
kill_engine.add_assets(TENANT, kc_assets)

kc_edges = [
    {"source": "lb-001", "target": "ec2-web", "type": "network_access"},
    {"source": "ec2-web", "target": "ec2-app", "type": "network_access"},
    {"source": "ec2-app", "target": "iam-role-app", "type": "attached_to"},
    {"source": "iam-role-app", "target": "rds-prod", "type": "iam_policy_grant"},
    {"source": "ec2-app", "target": "rds-prod", "type": "reads_from"},
    {"source": "iam-role-app", "target": "s3-customer", "type": "iam_policy_grant"},
    {"source": "ec2-app", "target": "s3-customer", "type": "writes_to"},
]
kill_engine.add_edges(TENANT, kc_edges)

paths = kill_engine.find_attack_paths(TENANT, source_asset_id="lb-001")
print(f"  ✓ Found {len(paths)} attack paths from 'Public ALB' to crown jewels")
for p in paths[:3]:
    print(f"    risk={p.risk_score:>7.1f} P={p.path_probability:.3f} len={p.path_length} phases={p.kill_chain_phases}")
    print(f"      {p.summary}")

summary = kill_engine.get_kill_chain_summary(TENANT)
print(f"  ✓ Summary: {summary['total_paths']} paths, {summary['sources_count']} sources, {summary['targets_count']} targets")
print(f"    by_phase: {summary['by_phase']}")
viz = kill_engine.get_visualization_data(TENANT, max_paths=5)
print(f"  ✓ Viz data: {len(viz['nodes'])} nodes, {len(viz['edges'])} edges")

# =========================================================================
# Feature 4: Evidence Vault
# =========================================================================
print("\n[4/6] Evidence Vault Engine...")
from backend.evidence_vault.engine import engine as vault_engine, EvidenceStatus

# Ingest evidence for CIS-1.1 (root MFA) over 3 scans
evidence_records = [
    {"framework": "cis_aws_v3", "control_id": "CIS-1.1",
     "control_description": "Ensure root MFA is enabled",
     "status": "pass", "resource_id": "root-account", "resource_type": "iam_root",
     "resource_name": "Root", "scan_id": "scan-001",
     "evidence_payload": {"mfa_active": True, "virtual_mfa": True}, "notes": "First scan"},
    {"framework": "cis_aws_v3", "control_id": "CIS-1.1",
     "control_description": "Ensure root MFA is enabled",
     "status": "fail", "resource_id": "root-account", "resource_type": "iam_root",
     "resource_name": "Root", "scan_id": "scan-002",
     "evidence_payload": {"mfa_active": False, "virtual_mfa": False}, "notes": "MFA was removed"},
    {"framework": "cis_aws_v3", "control_id": "CIS-1.1",
     "control_description": "Ensure root MFA is enabled",
     "status": "pass", "resource_id": "root-account", "resource_type": "iam_root",
     "resource_name": "Root", "scan_id": "scan-003",
     "evidence_payload": {"mfa_active": True, "virtual_mfa": True}, "notes": "MFA restored"},
    {"framework": "cis_aws_v3", "control_id": "CIS-2.1",
     "control_description": "Ensure S3 buckets have encryption at rest",
     "status": "pass", "resource_id": "s3-001", "resource_type": "s3_bucket",
     "resource_name": "public-data", "scan_id": "scan-003",
     "evidence_payload": {"encryption": "AES256"}, "notes": ""},
    {"framework": "pci_dss_v4", "control_id": "PCI-3.4",
     "control_description": "Render PAN unreadable wherever stored",
     "status": "pass", "resource_id": "rds-prod", "resource_type": "rds_instance",
     "resource_name": "Production DB", "scan_id": "scan-003",
     "evidence_payload": {"encryption": "KMS", "kms_key_id": "arn:aws:kms:..."}, "notes": ""},
]
r = vault_engine.ingest_batch(TENANT, evidence_records)
print(f"  ✓ Ingested {r['ingested']} evidence records, chain_length={r['chain_length']}")

verify = vault_engine.verify_chain(TENANT)
print(f"  ✓ Chain verified: {verify['verified']} (length={verify['chain_length']})")

pkg = vault_engine.generate_evidence_package(TENANT, "cis_aws_v3", "CIS-1.1")
print(f"  ✓ Evidence package: {pkg['total_records']} records, {pkg['compliance_percentage']}% pass, verified={pkg['chain_verified']}")

stats = vault_engine.get_stats(TENANT)
print(f"  ✓ Stats: {stats['total_records']} records across {len(stats['by_framework'])} frameworks")

# =========================================================================
# Feature 5: Workflow Integration
# =========================================================================
print("\n[5/6] Workflow Integration Engine...")
from backend.workflow_integration.engine import engine as wf_engine, IntegrationType

# Register integrations
jira = wf_engine.register_integration(
    TENANT, IntegrationType.JIRA, "Prod Jira",
    {"url": "https://sentinel.atlassian.net/rest/api/3/issue",
     "project_key": "SEC", "email": "sec@sentinel.io", "api_token": "fake-token"}
)
slack = wf_engine.register_integration(
    TENANT, IntegrationType.SLACK, "Sec Slack",
    {"webhook_url": "https://hooks.slack.com/services/FAKE", "channel": "#security-alerts"}
)
print(f"  ✓ Registered {len(wf_engine.list_integrations(TENANT))} integrations")

# Create tickets from findings
ticket1 = wf_engine.create_ticket_from_finding(TENANT, findings[0], jira["integration_id"])
print(f"  ✓ Jira ticket: state={ticket1['state']}, external_id={ticket1['external_ticket_id']}")
ticket2 = wf_engine.create_ticket_from_finding(TENANT, findings[4], slack["integration_id"])
print(f"  ✓ Slack ticket: state={ticket2['state']}")

# Simulate inbound webhook from Jira saying ticket was resolved
inbound = wf_engine.receive_webhook(
    TENANT, jira["integration_id"],
    payload={"issue": {"key": ticket1["external_ticket_id"] or "TEST-1",
                       "fields": {"status": {"name": "Done"}}}},
)
print(f"  ✓ Inbound webhook received: {inbound.get('new_state', inbound.get('error'))}")

# Stats
stats = wf_engine.get_stats(TENANT)
print(f"  ✓ Stats: {stats['total_tickets']} tickets, {stats['open_tickets']} open, {stats['resolved_tickets']} resolved")

# =========================================================================
# Feature 6: Multi-Account AWS Organizations
# =========================================================================
print("\n[6/6] Multi-Account AWS Organizations Engine...")
from backend.multi_account.engine import engine as org_engine

disc = org_engine.discover_via_organizations(
    tenant_id=TENANT,
    management_account_id="123456789012",
    management_account_email="aws-mgmt@sentinel.io",
    role_name="SentinelAuditRole",
)
print(f"  ✓ Discovered {disc['total_accounts']} accounts ({disc['new_accounts']} new)")

org_engine.seed_demo_metrics(TENANT, disc["org_id"])

rollup = org_engine.compute_org_rollup(TENANT, disc["org_id"])
print(f"  ✓ Org rollup: weighted_posture={rollup['weighted_posture_score']}/100, "
      f"weighted_compliance={rollup['weighted_compliance_score']}/100")
print(f"    total_resources={rollup['total_resources']}, total_findings={rollup['total_findings']}")
print(f"    weakest accounts: {[a['account_name'] for a in rollup['weakest_accounts'][:3]]}")

stats = org_engine.get_stats(TENANT)
print(f"  ✓ Stats: {stats['total_organizations']} orgs, {stats['total_accounts']} accounts, by_criticality={stats['by_criticality']}")

print("\n" + "=" * 70)
print("ALL 6 ENGINES VALIDATED SUCCESSFULLY")
print("=" * 70)
