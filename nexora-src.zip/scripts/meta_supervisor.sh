#!/bin/bash
# Meta-supervisor: ensures all three service supervisors stay alive.
# This is the only thing we need to keep running.

LOG=/home/z/my-project/meta_supervisor.log
while true; do
  # Next.js supervisor
  if ! pgrep -f "nextjs_supervisor.sh" > /dev/null; then
    echo "[$(date)] Restarting Next.js supervisor" >> $LOG
    setsid bash /home/z/my-project/scripts/nextjs_supervisor.sh > /dev/null 2>&1 < /dev/null &
    disown
  fi
  # moto supervisor
  if ! pgrep -f "moto_supervisor.py" > /dev/null; then
    echo "[$(date)] Restarting moto supervisor" >> $LOG
    setsid python3 /home/z/my-project/scripts/moto_supervisor.py > /dev/null 2>&1 < /dev/null &
    disown
  fi
  # scanner supervisor
  if ! pgrep -f "scanner_supervisor.py" > /dev/null; then
    echo "[$(date)] Restarting scanner supervisor" >> $LOG
    setsid python3 /home/z/my-project/scripts/scanner_supervisor.py > /dev/null 2>&1 < /dev/null &
    disown
  fi
  sleep 10
done
