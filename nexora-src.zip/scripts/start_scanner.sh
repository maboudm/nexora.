#!/bin/bash
# Watchdog for scanner service - keeps it alive and ensures moto is provisioned.
# Sets AWS_ENDPOINT_URL so the scanner's boto3 calls talk to the local moto server.
LOG=/home/z/my-project/scanner.log
SCANNER_DIR=/home/z/my-project/mini-services/scanner

# Wait for moto to be up before starting scanner
for i in {1..30}; do
  if curl -sf http://127.0.0.1:5000/moto-api/ > /dev/null 2>&1; then
    break
  fi
  sleep 1
done

# Provision AWS resources once (idempotent - skips if already created)
cd $SCANNER_DIR
if ! AWS_ENDPOINT_URL=http://127.0.0.1:5000 python3 -c "
from collectors import collect_all
data = collect_all()
assert len(data['iam_roles']) >= 4, 'IAM not provisioned'
" 2>/dev/null; then
  echo "[$(date)] Provisioning AWS resources..." >> $LOG
  AWS_ENDPOINT_URL=http://127.0.0.1:5000 python3 provision.py >> $LOG 2>&1
fi

# Start scanner with AWS_ENDPOINT_URL set
while true; do
  if ! pgrep -f "uvicorn main:app --host 127.0.0.1 --port 3030" > /dev/null; then
    echo "[$(date)] Starting scanner service..." >> $LOG
    cd $SCANNER_DIR
    AWS_ENDPOINT_URL=http://127.0.0.1:5000 \
    AWS_ACCESS_KEY_ID=test \
    AWS_SECRET_ACCESS_KEY=test \
    AWS_DEFAULT_REGION=us-east-1 \
    python3 -m uvicorn main:app --host 127.0.0.1 --port 3030 --workers 1 >> $LOG 2>&1 &
    PID=$!
    disown
    echo "[$(date)] Started PID $PID" >> $LOG
    sleep 3
  fi
  sleep 5
done
