"""
Supervisor daemon for the moto AWS API emulator (port 5000).

Same pattern as scanner_supervisor.py - keeps moto alive because the
sandbox kills background processes when they're not "watched".
"""
import os
import sys
import time
import subprocess
import urllib.request


def is_running():
    try:
        r = urllib.request.urlopen("http://127.0.0.1:5000/moto-api/", timeout=2)
        return r.status == 200
    except Exception:
        return False


def start_moto():
    log = open("/home/z/my-project/moto.log", "a")
    proc = subprocess.Popen(
        [sys.executable, "-m", "moto.server", "-p", "5000", "-H", "127.0.0.1"],
        stdout=log,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    return proc


if __name__ == "__main__":
    # Double-fork for daemon
    os.chdir("/")
    if os.fork() != 0:
        os._exit(0)
    os.setsid()
    if os.fork() != 0:
        os._exit(0)

    while True:
        if not is_running():
            try:
                proc = start_moto()
                with open("/home/z/my-project/moto.log", "a") as f:
                    f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Supervisor: started moto PID {proc.pid}\n")
            except Exception as e:
                with open("/home/z/my-project/moto.log", "a") as f:
                    f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Supervisor: failed to start: {e}\n")
        time.sleep(3)
