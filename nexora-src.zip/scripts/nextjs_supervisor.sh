#!/bin/bash
# Watchdog for Next.js dev server (port 3000).
# Restarts it if it dies. Uses node directly (more stable than bun in this sandbox).

LOG=/home/z/my-project/dev.log
PROJECT_DIR=/home/z/my-project
NEXT_BIN=$PROJECT_DIR/node_modules/.bin/next

while true; do
  if ! curl -sf --max-time 3 http://127.0.0.1:3000/ > /dev/null 2>&1; then
    echo "[$(date)] Next.js not responding, starting..." >> $LOG
    pkill -f "next dev" 2>/dev/null
    sleep 1
    cd $PROJECT_DIR
    setsid bash -c "exec $NEXT_BIN dev -p 3000" >> $LOG 2>&1 < /dev/null &
    disown
    sleep 15
    if curl -sf --max-time 5 http://127.0.0.1:3000/ > /dev/null 2>&1; then
      echo "[$(date)] Next.js is up" >> $LOG
    else
      echo "[$(date)] Next.js failed to start, will retry" >> $LOG
    fi
  fi
  sleep 5
done
