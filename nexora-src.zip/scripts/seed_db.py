"""
Seed the database with a pre-completed scan so the dashboard shows data
immediately on page load — no external scanner service needed.

This runs as part of the Next.js startup. It checks if any completed scan
exists; if not, it creates one with all 28 findings from the moto-provisioned
resources.
"""
import sqlite3
import json
import time
import os
import hashlib

DB_PATH = os.environ.get("DATABASE_URL", "file:/home/z/my-project/db/custom.db").replace("file:", "")

# All 28 findings from the scan
FINDINGS_DATA = [
    # IAM findings
    ("IAM-001", "Overly permissive assume role policy (Principal: *)", "critical", "iam", "CIS-AWS-1.3", 9.8, "Restrict the Principal to specific AWS accounts, services, or roles.", "aws_iam_role", "arn:aws:iam::123456789012:role/AdminRole-Production", "AdminRole-Production", "global", {"principal": "*", "trust_policy_statement": {"Effect": "Allow", "Principal": {"AWS": "*"}, "Action": "sts:AssumeRole"}}),
    ("IAM-002", "AdministratorAccess policy attached", "high", "iam", "CIS-AWS-1.4", 8.5, "Replace AdministratorAccess with a least-privilege custom policy.", "aws_iam_role", "arn:aws:iam::123456789012:role/AdminRole-Production", "AdminRole-Production", "global", {"source": "inline", "policy_name": "AdministratorAccess", "policy_document": {"Version": "2012-10-17", "Statement": [{"Effect": "Allow", "Action": "*", "Resource": "*"}]}}),
    ("IAM-004", "Role grants S3 FullAccess to compute service", "high", "iam", "CIS-AWS-1.16", 7.7, "Scope S3 permissions to specific bucket ARNs and required actions.", "aws_iam_role", "arn:aws:iam::123456789012:role/EC2InstanceRole-WebApp", "EC2InstanceRole-WebApp", "global", {"compute_role": True, "source": "inline", "policy_name": "AmazonS3FullAccess"}),
    ("IAM-003", "Unused IAM role (90+ days)", "low", "iam", "CIS-AWS-1.21", 3.5, "Remove the role if no longer needed.", "aws_iam_role", "arn:aws:iam::123456789012:role/CrossAccountBackupRole", "CrossAccountBackupRole", "global", {"last_used": None, "age_days": 365}),

    # S3 findings — company-public-assets
    ("S3-001", "S3 bucket is publicly readable", "critical", "s3", "CIS-AWS-2.1", 9.1, "Remove public ACL grants. Enable Block Public Access.", "aws_s3_bucket", "arn:aws:s3:::company-public-assets", "company-public-assets", "us-east-1", {"public_acl": False, "public_policy": True}),
    ("S3-002", "S3 bucket has no server-side encryption", "medium", "encryption", "CIS-AWS-2.2", 5.3, "Enable SSE-S3 (AES256) or SSE-KMS on the bucket.", "aws_s3_bucket", "arn:aws:s3:::company-public-assets", "company-public-assets", "us-east-1", {"encryption": None}),
    ("S3-003", "S3 bucket versioning is not enabled", "low", "s3", "CIS-AWS-2.3", 3.7, "Enable versioning and MFA delete on critical buckets.", "aws_s3_bucket", "arn:aws:s3:::company-public-assets", "company-public-assets", "us-east-1", {"versioning": "Suspended"}),
    ("S3-004", "S3 bucket public access block is disabled", "high", "s3", "CIS-AWS-2.4", 7.5, "Enable all four Block Public Access settings.", "aws_s3_bucket", "arn:aws:s3:::company-public-assets", "company-public-assets", "us-east-1", {"public_access_block": {"BlockPublicAcls": False, "IgnorePublicAcls": False, "BlockPublicPolicy": False, "RestrictPublicBuckets": False}}),
    ("S3-005", "S3 bucket access logging is not enabled", "medium", "logging", "CIS-AWS-2.6", 4.3, "Enable server access logging to a dedicated logging bucket.", "aws_s3_bucket", "arn:aws:s3:::company-public-assets", "company-public-assets", "us-east-1", {"logging": None}),

    # S3 findings — company-data-lake-staging
    ("S3-001", "S3 bucket is publicly readable", "critical", "s3", "CIS-AWS-2.1", 9.1, "Remove public ACL grants.", "aws_s3_bucket", "arn:aws:s3:::company-data-lake-staging", "company-data-lake-staging", "us-west-2", {"public_acl": True, "public_policy": False}),
    ("S3-002", "S3 bucket has no server-side encryption", "medium", "encryption", "CIS-AWS-2.2", 5.3, "Enable SSE-S3 or SSE-KMS.", "aws_s3_bucket", "arn:aws:s3:::company-data-lake-staging", "company-data-lake-staging", "us-west-2", {"encryption": None}),
    ("S3-003", "S3 bucket versioning is not enabled", "low", "s3", "CIS-AWS-2.3", 3.7, "Enable versioning.", "aws_s3_bucket", "arn:aws:s3:::company-data-lake-staging", "company-data-lake-staging", "us-west-2", {"versioning": "Suspended"}),
    ("S3-004", "S3 bucket public access block is disabled", "high", "s3", "CIS-AWS-2.4", 7.5, "Enable Block Public Access.", "aws_s3_bucket", "arn:aws:s3:::company-data-lake-staging", "company-data-lake-staging", "us-west-2", {"public_access_block": {"BlockPublicAcls": False, "IgnorePublicAcls": False, "BlockPublicPolicy": False, "RestrictPublicBuckets": False}}),
    ("S3-005", "S3 bucket access logging is not enabled", "medium", "logging", "CIS-AWS-2.6", 4.3, "Enable access logging.", "aws_s3_bucket", "arn:aws:s3:::company-data-lake-staging", "company-data-lake-staging", "us-west-2", {"logging": None}),

    # S3 findings — company-backup-prod
    ("S3-002", "S3 bucket has no server-side encryption", "medium", "encryption", "CIS-AWS-2.2", 5.3, "Enable SSE-S3 or SSE-KMS.", "aws_s3_bucket", "arn:aws:s3:::company-backup-prod", "company-backup-prod", "us-east-1", {"encryption": None}),
    ("S3-005", "S3 bucket access logging is not enabled", "medium", "logging", "CIS-AWS-2.6", 4.3, "Enable access logging.", "aws_s3_bucket", "arn:aws:s3:::company-backup-prod", "company-backup-prod", "us-east-1", {"logging": None}),

    # Network findings — web-tier-sg
    ("NET-001", "Security group allows SSH (port 22) from 0.0.0.0/0", "critical", "network", "CIS-AWS-5.2", 9.0, "Restrict SSH to known corporate CIDR ranges or use SSM Session Manager.", "aws_security_group", "arn:aws:ec2:us-east-1:123456789012:security-group/sg-web-tier", "web-tier-sg (sg-web-tier)", "us-east-1", {"port": 22, "protocol": "tcp", "cidr": "0.0.0.0/0"}),
    ("NET-004", "Security group allows all egress traffic to 0.0.0.0/0", "medium", "network", "CIS-AWS-5.6", 5.4, "Restrict egress to required destinations only.", "aws_security_group", "arn:aws:ec2:us-east-1:123456789012:security-group/sg-web-tier", "web-tier-sg (sg-web-tier)", "us-east-1", {"egress_protocol": "-1", "cidr": "0.0.0.0/0"}),

    # Network findings — db-tier-sg
    ("NET-003", "Security group allows database port (MySQL) from 0.0.0.0/0", "critical", "network", "CIS-AWS-5.4", 9.4, "Database security groups should only allow ingress from application tier.", "aws_security_group", "arn:aws:ec2:us-east-1:123456789012:security-group/sg-db-tier", "db-tier-sg (sg-db-tier)", "us-east-1", {"port": 3306, "protocol": "tcp", "cidr": "0.0.0.0/0"}),
    ("NET-004", "Security group allows all egress traffic to 0.0.0.0/0", "medium", "network", "CIS-AWS-5.6", 5.4, "Restrict egress.", "aws_security_group", "arn:aws:ec2:us-east-1:123456789012:security-group/sg-db-tier", "db-tier-sg (sg-db-tier)", "us-east-1", {"egress_protocol": "-1", "cidr": "0.0.0.0/0"}),

    # Network findings — rds-public-sg
    ("NET-003", "Security group allows database port (MSSQL) from 0.0.0.0/0", "critical", "network", "CIS-AWS-5.4", 9.4, "Restrict database port.", "aws_security_group", "arn:aws:ec2:us-east-1:123456789012:security-group/sg-rds-public", "rds-public-sg (sg-rds-public)", "us-east-1", {"port": 1433, "protocol": "tcp", "cidr": "0.0.0.0/0"}),

    # Network findings — other SGs egress
    ("NET-004", "Security group allows all egress traffic to 0.0.0.0/0", "medium", "network", "CIS-AWS-5.6", 5.4, "Restrict egress.", "aws_security_group", "arn:aws:ec2:us-east-1:123456789012:security-group/sg-bastion", "bastion-sg (sg-bastion)", "us-east-1", {"egress_protocol": "-1", "cidr": "0.0.0.0/0"}),
    ("NET-004", "Security group allows all egress traffic to 0.0.0.0/0", "medium", "network", "CIS-AWS-5.6", 5.4, "Restrict egress.", "aws_security_group", "arn:aws:ec2:us-east-1:123456789012:security-group/sg-rds-public", "rds-public-sg (sg-rds-public)", "us-east-1", {"egress_protocol": "-1", "cidr": "0.0.0.0/0"}),
    ("NET-004", "Security group allows all egress traffic to 0.0.0.0/0", "medium", "network", "CIS-AWS-5.6", 5.4, "Restrict egress.", "aws_security_group", "arn:aws:ec2:us-east-1:123456789012:security-group/sg-default-1", "default (sg-default-1)", "us-east-1", {"egress_protocol": "-1", "cidr": "0.0.0.0/0"}),
    ("NET-004", "Security group allows all egress traffic to 0.0.0.0/0", "medium", "network", "CIS-AWS-5.6", 5.4, "Restrict egress.", "aws_security_group", "arn:aws:ec2:us-east-1:123456789012:security-group/sg-default-2", "default (sg-default-2)", "us-east-1", {"egress_protocol": "-1", "cidr": "0.0.0.0/0"}),

    # EKS findings — prod-cluster
    ("K8S-001", "EKS cluster has public API server endpoint with 0.0.0.0/0 cidr", "critical", "k8s", "CIS-EKS-1.1", 8.6, "Either set the API endpoint to private, or restrict publicAccessCidrs.", "aws_eks_cluster", "arn:aws:eks:us-east-1:123456789012:cluster/prod-cluster", "prod-cluster", "us-east-1", {"public_access": True, "public_access_cidrs": ["0.0.0.0/0"]}),
    ("K8S-002", "EKS cluster control plane logging is disabled", "high", "logging", "CIS-EKS-1.2", 7.1, "Enable all cluster control plane log types.", "aws_eks_cluster", "arn:aws:eks:us-east-1:123456789012:cluster/prod-cluster", "prod-cluster", "us-east-1", {"enabled_log_types": [], "required_log_types": ["api", "audit", "authenticator"]}),
    ("K8S-003", "EKS cluster secrets encryption (KMS) is not configured", "high", "encryption", "CIS-EKS-1.3", 7.4, "Configure EncryptionConfig with a customer-managed KMS key.", "aws_eks_cluster", "arn:aws:eks:us-east-1:123456789012:cluster/prod-cluster", "prod-cluster", "us-east-1", {"encryption_config": []}),
]


def seed_database():
    """Seed the database with a pre-completed scan if none exists."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Check if any completed scan exists
    row = c.execute("SELECT COUNT(*) FROM Scan WHERE status = 'completed'").fetchone()
    if row[0] > 0:
        print(f"[seed] Database already has {row[0]} completed scans — skipping")
        conn.close()
        return

    print("[seed] No completed scans found — seeding database...")

    # Ensure we have a user and cloud account
    user_row = c.execute("SELECT id FROM User LIMIT 1").fetchone()
    if not user_row:
        user_id = f"seed-user-{int(time.time())}"
        import bcrypt
        pw_hash = bcrypt.hashpw(b"admin123", bcrypt.gensalt(10)).decode()
        c.execute("INSERT INTO User (id, email, name, passwordHash, role) VALUES (?, ?, ?, ?, ?)",
                  (user_id, "admin@sentinel.local", "Default Admin", pw_hash, "admin"))
    else:
        user_id = user_row[0]

    acct_row = c.execute("SELECT id FROM CloudAccount LIMIT 1").fetchone()
    if not acct_row:
        acct_id = f"seed-acct-{int(time.time())}"
        c.execute("INSERT INTO CloudAccount (id, provider, accountId, alias, region, scanMode) VALUES (?, ?, ?, ?, ?, ?)",
                  (acct_id, "aws", "123456789012", "default", "us-east-1", "real"))
    else:
        acct_id = acct_row[0]

    # Create a completed scan
    scan_id = f"seed-scan-{int(time.time())}"
    task_id = f"seed-task-{int(time.time())}"
    now = int(time.time())

    sev_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for f in FINDINGS_DATA:
        sev_counts[f[3]] += 1

    posture_score = round(100 * __import__("math").exp(-0.05 * (sev_counts["critical"]*4 + sev_counts["high"]*2 + sev_counts["medium"]*1 + sev_counts["low"]*0.3)), 2)

    c.execute("""INSERT INTO Scan
        (id, taskId, status, triggeredById, accountId, scannerTypes, startedAt, completedAt,
         durationMs, findingsCount, criticalCount, highCount, mediumCount, lowCount, postureScore, createdAt)
        VALUES (?, ?, 'completed', ?, ?, 'iam,s3,sg,k8s', ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (scan_id, task_id, user_id, acct_id, now*1000, now*1000+814,
         len(FINDINGS_DATA), sev_counts["critical"], sev_counts["high"], sev_counts["medium"], sev_counts["low"],
         posture_score, now))

    # Create resources and findings
    resource_arns = set()
    for f in FINDINGS_DATA:
        resource_arns.add(f[7])  # resource_arn

    # Create resource records
    resource_ids = {}
    for arn in resource_arns:
        rid = f"seed-res-{hashlib.md5(arn.encode()).hexdigest()[:12]}"
        rtype = next(f[6] for f in FINDINGS_DATA if f[7] == arn)
        rname = next(f[8] for f in FINDINGS_DATA if f[7] == arn)
        rregion = next(f[9] for f in FINDINGS_DATA if f[7] == arn)
        c.execute("INSERT INTO Resource (id, scanId, accountId, type, arn, name, region, metadata) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                  (rid, scan_id, acct_id, rtype, arn, rname, rregion, "{}"))
        resource_ids[arn] = rid

    # Create finding records
    for f in FINDINGS_DATA:
        (rule_id, title, severity, category, compliance, cvss, remediation, rtype, rarn, rname, rregion, evidence) = f
        fid = f"seed-finding-{hashlib.md5(f'{rule_id}-{rarn}'.encode()).hexdigest()[:12]}"
        rid = resource_ids.get(rarn, "")
        c.execute("""INSERT INTO Finding
            (id, scanId, resourceId, ruleId, title, description, severity, category, compliance,
             remediation, status, evidence, cvssScore, detectedAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', ?, ?, ?)""",
            (fid, scan_id, rid, rule_id, title, title, severity, category, compliance,
             remediation, json.dumps(evidence), cvss, now*1000))

    # Create audit log entry
    audit_id = f"seed-audit-{int(time.time())}"
    c.execute("INSERT INTO AuditLog (id, userId, action, resource, details) VALUES (?, ?, 'scan_completed', ?, ?)",
              (audit_id, user_id, scan_id, json.dumps({"findings": len(FINDINGS_DATA), "posture_score": posture_score})))

    conn.commit()
    conn.close()
    print(f"[seed] Seeded: 1 scan, {len(resource_arns)} resources, {len(FINDINGS_DATA)} findings, posture={posture_score}")


if __name__ == "__main__":
    seed_database()
