#!/usr/bin/env python3
"""
Create all database tables in SQLite directly (bypassing Prisma).

This creates the production database schema that the gateway uses
for persistent storage. Data survives gateway restarts.
"""
import sqlite3
import os

DB_PATH = "/home/z/my-project/db/custom.db"

def create_schema():
    # Remove old DB
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")

    # ─── Identity ───
    # Table names MUST match Prisma model names (PascalCase)
    conn.executescript("""
    CREATE TABLE "Organization" (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        ownerId TEXT,
        logoUrl TEXT,
        primaryColor TEXT DEFAULT '#a3862f',
        timezone TEXT DEFAULT 'UTC',
        currency TEXT DEFAULT 'USD',
        retentionDays INTEGER DEFAULT 365,
        status TEXT DEFAULT 'active',
        version INTEGER DEFAULT 1,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        updatedAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        deletedAt TEXT
    );

    CREATE TABLE "Workspace" (
        id TEXT PRIMARY KEY,
        organizationId TEXT NOT NULL,
        name TEXT NOT NULL,
        slug TEXT NOT NULL,
        description TEXT,
        status TEXT DEFAULT 'active',
        version INTEGER DEFAULT 1,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        updatedAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        deletedAt TEXT,
        UNIQUE(organizationId, slug)
    );

    CREATE TABLE "User" (
        id TEXT PRIMARY KEY,
        organizationId TEXT NOT NULL,
        email TEXT NOT NULL,
        name TEXT NOT NULL,
        passwordHash TEXT,
        status TEXT DEFAULT 'active',
        avatarUrl TEXT,
        jobTitle TEXT,
        department TEXT,
        lastLoginAt TEXT,
        lastLoginIp TEXT,
        failedLoginAttempts INTEGER DEFAULT 0,
        lockedUntil TEXT,
        mfaEnabled INTEGER DEFAULT 0,
        version INTEGER DEFAULT 1,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        updatedAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        deletedAt TEXT,
        UNIQUE(organizationId, email)
    );

    CREATE TABLE "Role" (
        id TEXT PRIMARY KEY,
        organizationId TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        isSystem INTEGER DEFAULT 0,
        version INTEGER DEFAULT 1,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        updatedAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        UNIQUE(organizationId, name)
    );

    CREATE TABLE "UserRole" (
        id TEXT PRIMARY KEY,
        userId TEXT NOT NULL,
        roleId TEXT NOT NULL,
        workspaceId TEXT,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        UNIQUE(userId, roleId, workspaceId)
    );

    CREATE TABLE "Session" (
        id TEXT PRIMARY KEY,
        userId TEXT NOT NULL,
        tokenHash TEXT UNIQUE NOT NULL,
        refreshTokenHash TEXT UNIQUE,
        ipAddress TEXT,
        userAgent TEXT,
        expiresAt TEXT NOT NULL,
        refreshExpiresAt TEXT,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        revokedAt TEXT
    );

    CREATE TABLE "ApiKey" (
        id TEXT PRIMARY KEY,
        organizationId TEXT NOT NULL,
        userId TEXT NOT NULL,
        name TEXT NOT NULL,
        keyHash TEXT UNIQUE NOT NULL,
        keyPrefix TEXT,
        permissions TEXT DEFAULT '["read"]',
        rateLimitPerMin INTEGER DEFAULT 60,
        ipWhitelist TEXT DEFAULT '[]',
        lastUsedAt TEXT,
        expiresAt TEXT,
        status TEXT DEFAULT 'active',
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        revokedAt TEXT
    );

    CREATE TABLE "CloudAccount" (
        id TEXT PRIMARY KEY,
        organizationId TEXT NOT NULL,
        workspaceId TEXT NOT NULL,
        provider TEXT NOT NULL,
        externalAccountId TEXT,
        alias TEXT,
        name TEXT NOT NULL,
        credentialType TEXT DEFAULT 'assume_role',
        roleArn TEXT,
        externalId TEXT,
        regions TEXT DEFAULT '["us-east-1"]',
        scanMode TEXT DEFAULT 'real',
        status TEXT DEFAULT 'active',
        lastScanAt TEXT,
        totalAssets INTEGER DEFAULT 0,
        totalFindings INTEGER DEFAULT 0,
        version INTEGER DEFAULT 1,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        updatedAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        deletedAt TEXT,
        UNIQUE(organizationId, workspaceId, provider, externalAccountId)
    );

    CREATE TABLE "Scan" (
        id TEXT PRIMARY KEY,
        organizationId TEXT NOT NULL,
        workspaceId TEXT NOT NULL,
        cloudAccountId TEXT NOT NULL,
        triggeredById TEXT,
        taskId TEXT,
        status TEXT DEFAULT 'queued',
        scanMode TEXT DEFAULT 'real',
        scannerTypes TEXT DEFAULT '["iam","s3","sg","k8s"]',
        regions TEXT DEFAULT '[]',
        startedAt TEXT,
        completedAt TEXT,
        durationMs INTEGER,
        totalAssets INTEGER DEFAULT 0,
        totalFindings INTEGER DEFAULT 0,
        criticalCount INTEGER DEFAULT 0,
        highCount INTEGER DEFAULT 0,
        mediumCount INTEGER DEFAULT 0,
        lowCount INTEGER DEFAULT 0,
        postureScore REAL,
        error TEXT,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
    );

    CREATE INDEX "Scan_organizationId_idx" ON "Scan"(organizationId);
    CREATE INDEX "Scan_cloudAccountId_idx" ON "Scan"(cloudAccountId);
    CREATE INDEX "Scan_status_idx" ON "Scan"(status);

    CREATE TABLE "Finding" (
        id TEXT PRIMARY KEY,
        organizationId TEXT NOT NULL,
        workspaceId TEXT NOT NULL,
        scanId TEXT,
        resourceId TEXT,
        ruleId TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        severity TEXT NOT NULL,
        category TEXT,
        compliance TEXT DEFAULT '',
        cvssScore REAL DEFAULT 0,
        remediation TEXT,
        evidence TEXT DEFAULT '{}',
        status TEXT DEFAULT 'open',
        detectedAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        resolvedAt TEXT,
        assignedToId TEXT,
        resolvedById TEXT,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        updatedAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
    );

    CREATE INDEX "Finding_organizationId_idx" ON "Finding"(organizationId);
    CREATE INDEX "Finding_scanId_idx" ON "Finding"(scanId);
    CREATE INDEX "Finding_severity_idx" ON "Finding"(severity);
    CREATE INDEX "Finding_status_idx" ON "Finding"(status);

    CREATE TABLE "Resource" (
        id TEXT PRIMARY KEY,
        scanId TEXT NOT NULL,
        accountId TEXT NOT NULL,
        type TEXT NOT NULL,
        arn TEXT NOT NULL,
        name TEXT NOT NULL,
        region TEXT NOT NULL,
        metadata TEXT DEFAULT '{}',
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
    );

    CREATE INDEX "Resource_scanId_idx" ON "Resource"(scanId);

    CREATE TABLE "AuditLog" (
        id TEXT PRIMARY KEY,
        userId TEXT,
        organizationId TEXT NOT NULL,
        action TEXT NOT NULL,
        resource TEXT,
        resourceId TEXT,
        details TEXT DEFAULT '{}',
        ipAddress TEXT,
        userAgent TEXT,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
    );

    CREATE INDEX "AuditLog_organizationId_idx" ON "AuditLog"(organizationId);
    CREATE INDEX "AuditLog_userId_idx" ON "AuditLog"(userId);
    CREATE INDEX "AuditLog_action_idx" ON "AuditLog"(action);

    CREATE TABLE "Subscription" (
        id TEXT PRIMARY KEY,
        organizationId TEXT NOT NULL,
        plan TEXT DEFAULT 'starter',
        status TEXT DEFAULT 'active',
        priceCents INTEGER DEFAULT 200,
        billingCycle TEXT DEFAULT 'monthly',
        stripeCustomerId TEXT,
        stripeSubscriptionId TEXT,
        currentPeriodStart TEXT,
        currentPeriodEnd TEXT,
        canceledAt TEXT,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
        updatedAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
    );

    CREATE TABLE "UsageRecord" (
        id TEXT PRIMARY KEY,
        organizationId TEXT NOT NULL,
        date TEXT NOT NULL,
        scansCount INTEGER DEFAULT 0,
        assetsScanned INTEGER DEFAULT 0,
        findingsCount INTEGER DEFAULT 0,
        apiCalls INTEGER DEFAULT 0,
        createdAt TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
    );

    CREATE INDEX "UsageRecord_organizationId_date_idx" ON "UsageRecord"(organizationId, date);
    """)

    # ─── Seed default data ───
    import hashlib
    password_hash = hashlib.sha256(b"sentinel-salt:admin123").hexdigest()
    org_id = "00000000-0000-0000-0000-000000000001"
    user_id = "00000000-0000-0000-0000-000000000002"
    ws_id = "00000000-0000-0000-0000-000000000003"
    acct_id = "00000000-0000-0000-0000-000000000004"
    role_id = "00000000-0000-0000-0000-000000000005"

    conn.executescript(f"""
    INSERT INTO "Organization" (id, name, slug, ownerId) VALUES
        ('{org_id}', 'Demo Organization', 'demo-org', '{user_id}');

    INSERT INTO "User" (id, organizationId, email, name, passwordHash, status) VALUES
        ('{user_id}', '{org_id}', 'admin@sentinel.demo', 'Demo Admin', '{password_hash}', 'active');

    INSERT INTO "Workspace" (id, organizationId, name, slug) VALUES
        ('{ws_id}', '{org_id}', 'Default', 'default');

    INSERT INTO "CloudAccount" (id, organizationId, workspaceId, provider, name, externalAccountId, credentialType, regions, status) VALUES
        ('{acct_id}', '{org_id}', '{ws_id}', 'aws', 'Production AWS', '123456789012', 'assume_role', '["us-east-1","us-west-2"]', 'active');

    INSERT INTO "Role" (id, organizationId, name, description, isSystem) VALUES
        ('{role_id}', '{org_id}', 'owner', 'Full access', 1);

    INSERT INTO "UserRole" (userId, roleId) VALUES ('{user_id}', '{role_id}');

    INSERT INTO "Subscription" (id, organizationId, plan, status, priceCents, billingCycle) VALUES
        ('00000000-0000-0000-0000-000000000006', '{org_id}', 'starter', 'active', 200, 'monthly');
    """)

    conn.commit()

    # Count tables
    tables = conn.execute("SELECT count(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
    print(f"✓ {tables} tables created in {DB_PATH}")
    print(f"✓ Demo user seeded: admin@sentinel.demo / admin123")
    print(f"✓ Demo cloud account: Production AWS")
    print(f"✓ Subscription: starter plan, $2.00/month")
    print(f"✓ DB size: {os.path.getsize(DB_PATH) / 1024:.1f} KB")

    conn.close()

if __name__ == "__main__":
    create_schema()
