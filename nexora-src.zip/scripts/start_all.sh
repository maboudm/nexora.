#!/bin/bash
# All-in-one service launcher for Sentinel CNAPP.
# Starts moto, scanner, and Next.js — all as supervised daemons.
# Idempotent: safe to re-run.

set -e

LOG_DIR=/home/z/my-project
cd /home/z/my-project

# ── 1. Kill any existing instances ──
echo "[1/4] Cleaning up existing processes..."
pkill -f "nextjs_supervisor" 2>/dev/null || true
pkill -f "next dev" 2>/dev/null || true
pkill -f "scanner_supervisor" 2>/dev/null || true
pkill -f "uvicorn main:app" 2>/dev/null || true
pkill -f "moto_supervisor" 2>/dev/null || true
pkill -f "moto.server" 2>/dev/null || true
sleep 2

# ── 2. Verify Python deps are installed (reinstall if missing) ──
echo "[2/4] Verifying Python dependencies..."
if ! python3 -c "import moto, fastapi, boto3, networkx" 2>/dev/null; then
  echo "  Reinstalling Python deps..."
  pip3 install --quiet "moto[server,iam,s3,ec2,eks,sts]" flask fastapi "uvicorn[standard]" pydantic boto3 networkx pyjwt pypdf reportlab 2>&1 | tail -3
fi
echo "  Python deps OK"

# ── 3. Verify .env has JWT_SECRET ──
echo "[3/4] Verifying environment..."
if ! grep -q "JWT_SECRET" /home/z/my-project/.env 2>/dev/null; then
  echo "" >> /home/z/my-project/.env
  echo "JWT_SECRET=sentinel-cnapp-jwt-secret-change-me-in-production-2026-07-04-x9k2m7p4" >> /home/z/my-project/.env
fi
echo "  .env OK"

# ── 4. Start all three supervisors ──
echo "[4/4] Starting services..."

# moto supervisor (daemonizes itself)
python3 /home/z/my-project/scripts/moto_supervisor.py
echo "  moto supervisor launched"

# Wait for moto to be reachable (up to 30s)
for i in $(seq 1 30); do
  if curl -sf --max-time 2 http://127.0.0.1:5000/moto-api/ > /dev/null 2>&1; then
    echo "  moto is up (after ${i}s)"
    break
  fi
  sleep 1
done

# Scanner supervisor (waits for moto, provisions AWS, then starts uvicorn)
python3 /home/z/my-project/scripts/scanner_supervisor.py
echo "  scanner supervisor launched"

# Wait for scanner to be reachable (up to 60s — provisioning takes time)
for i in $(seq 1 60); do
  if curl -sf --max-time 2 http://127.0.0.1:3030/health > /dev/null 2>&1; then
    echo "  scanner is up (after ${i}s)"
    break
  fi
  sleep 1
done

# Next.js — start directly (no supervisor needed for dev)
cd /home/z/my-project
setsid bash -c 'exec bun run dev' > /home/z/my-project/dev.log 2>&1 < /dev/null &
disown
echo "  Next.js launched"

# Wait for Next.js (up to 30s)
for i in $(seq 1 30); do
  if curl -sf --max-time 2 http://localhost:3000/ > /dev/null 2>&1; then
    echo "  Next.js is up (after ${i}s)"
    break
  fi
  sleep 1
done

# ── Final status ──
echo ""
echo "=== Service Status ==="
curl -s --max-time 3 -o /dev/null -w "moto      (5000): HTTP %{http_code}\n" http://127.0.0.1:5000/moto-api/ 2>&1 || echo "moto      (5000): DOWN"
curl -s --max-time 3 -o /dev/null -w "scanner   (3030): HTTP %{http_code}\n" http://127.0.0.1:3030/health 2>&1 || echo "scanner   (3030): DOWN"
curl -s --max-time 3 -o /dev/null -w "Next.js   (3000): HTTP %{http_code}\n" http://localhost:3000/ 2>&1 || echo "Next.js   (3000): DOWN"
echo ""
echo "Login: admin@sentinel.local / admin123"
echo "URL:   http://localhost:3000"
