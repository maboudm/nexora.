#!/usr/bin/env bash
# Sentinel CNAPP — Keep both gateway + frontend alive
# Run this in background: setsid bash scripts/keep_alive.sh &
cd /home/z/my-project

export AUDIT_MASTER_KEY="${AUDIT_MASTER_KEY:-$(python3 -c "import secrets; print(secrets.token_hex(32))")}"
export JWT_SECRET="sentinel-cnapp-jwt-secret-2026-change-me-32chars"
export MASTER_ENCRYPTION_KEY="$AUDIT_MASTER_KEY"

while true; do
    # Check gateway
    if ! curl -s --max-time 2 http://localhost:8000/health > /dev/null 2>&1; then
        echo "[$(date +%H:%M:%S)] Starting gateway..."
        setsid /home/z/.venv/bin/python3 -m uvicorn backend.gateway.app:app --host 0.0.0.0 --port 8000 --log-level error > /tmp/gateway.log 2>&1 < /dev/null &
        disown
        sleep 5
    fi
    # Check frontend
    if ! curl -s --max-time 2 http://localhost:3000 > /dev/null 2>&1; then
        echo "[$(date +%H:%M:%S)] Starting frontend..."
        setsid bun run dev > /tmp/frontend.log 2>&1 < /dev/null &
        disown
        sleep 5
    fi
    sleep 10
done
