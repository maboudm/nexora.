"""
Enterprise KSPM Engine — Kubernetes Security Posture Management.

Based on Part 5 — KSPM requirements, CIS Kubernetes Benchmark v1.8.0,
and NIST SP 800-190 (Application Container Security Guide).

Scientific Foundation:
  - Kubernetes API is the source of truth — we query it via the official
    kubernetes-client Python library (no kubectl parsing fragility)
  - RBAC analysis: graph-based detection of privilege escalation paths
    (Subject → Role/ClusterRole → rules → verbs × resources)
  - Pod Security Standards (PSS) v1.0 — Baseline / Restricted profiles
    from Kubernetes SIG Security
  - Network Policy analysis: reachability matrix computation
  - CIS Kubernetes Benchmark v1.8 — 110+ controls across 7 sections

Capabilities:
  1. RBAC Audit: cluster-admin grants, wildcard verbs, privilege escalation,
     service account token misuse
  2. Pod Security: privileged pods, hostPath, hostNetwork, hostPID,
     runAsRoot, capabilities, seccomp, AppArmor
  3. Network Policy: namespaces without default-deny, over-permissive policies
  4. Secret Management: secrets in env vars, mounted secret exposure
  5. Image Security: latest tag, no imagePullPolicy, missing digest
  6. Resource Limits: missing requests/limits, no QoS guarantees
  7. CIS Benchmark: control-by-control evaluation

Architecture:
  k8s API ──> K8sClient ──> Resource Cache ──> Rule Engine ──> Findings
                                                  │
                                                  └──> RBAC Graph Builder
"""
from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# KSPM Domain Model
# ═══════════════════════════════════════════════════════════════

class K8sFindingCategory(str, Enum):
    RBAC_CLUSTER_ADMIN = "rbac_cluster_admin"
    RBAC_WILDCARD = "rbac_wildcard"
    RBAC_PRIVILEGE_ESCALATION = "rbac_privilege_escalation"
    RBAC_SECRET_ACCESS = "rbac_secret_access"
    RBAC_NODE_ACCESS = "rbac_node_access"
    POD_PRIVILEGED = "pod_privileged"
    POD_HOST_NETWORK = "pod_host_network"
    POD_HOST_PID = "pod_host_pid"
    POD_HOST_IPC = "pod_host_ipc"
    POD_HOST_PATH = "pod_host_path"
    POD_ROOT_USER = "pod_root_user"
    POD_NO_SECURITY_CONTEXT = "pod_no_security_context"
    POD_PRIVILEGED_ESCALATION = "pod_privileged_escalation"
    POD_DANGEROUS_CAPABILITIES = "pod_dangerous_capabilities"
    POD_NO_SECCOMP = "pod_no_seccomp"
    POD_NO_READONLY_FS = "pod_no_readonly_fs"
    NETWORK_POLICY_MISSING = "network_policy_missing"
    NETWORK_POLICY_PERMISSIVE = "network_policy_permissive"
    SECRET_ENV_VAR = "secret_env_var"
    IMAGE_LATEST_TAG = "image_latest_tag"
    IMAGE_NO_PULL_POLICY = "image_no_pull_policy"
    IMAGE_NO_DIGEST = "image_no_digest"
    RESOURCE_LIMITS_MISSING = "resource_limits_missing"
    RESOURCE_REQUESTS_MISSING = "resource_requests_missing"
    NAMESPACE_DEFAULT = "namespace_default"
    SERVICE_ACCOUNT_TOKEN = "service_account_token"
    API_SERVER_EXPOSED = "api_server_exposed"


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class K8sFinding:
    finding_id: str
    tenant_id: str
    scan_id: str
    cluster_id: str
    category: str
    severity: str
    title: str
    description: str
    remediation: str
    cis_control: Optional[str] = None
    resource_kind: str = ""        # Pod, Deployment, Role, ClusterRoleBinding, etc.
    resource_name: str = ""
    resource_namespace: str = ""
    resource_api_version: str = ""
    api_group: str = ""
    evidence: dict[str, Any] = field(default_factory=dict)
    detected_at: int = 0


@dataclass
class RBACEdge:
    """Edge in the RBAC graph: Subject → Role → Permission."""
    subject_kind: str       # User, Group, ServiceAccount
    subject_name: str
    subject_namespace: str
    role_kind: str          # Role, ClusterRole
    role_name: str
    api_group: str
    resource: str
    verb: str
    binding_namespace: str = ""


@dataclass
class K8sScanResult:
    tenant_id: str
    scan_id: str
    cluster_id: str
    cluster_name: str
    cluster_version: str
    resources_scanned: int
    findings: list[K8sFinding]
    rbac_edges: list[RBACEdge]
    namespaces: list[str]
    scanned_at: int
    duration_ms: int
    summary: dict[str, Any] = field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════
# K8s Resource Loader (works with or without a real cluster)
# ═══════════════════════════════════════════════════════════════

class K8sResourceLoader:
    """Loads Kubernetes resources from a real cluster OR from manifests.

    Real cluster: uses kubernetes-client library (in-cluster or kubeconfig)
    Manifests: parses YAML/JSON manifests (for IaC scanning of k8s YAML)
    """

    def __init__(self, kubeconfig_path: Optional[str] = None):
        self.kubeconfig_path = kubeconfig_path
        self._client = None

    def from_cluster(self, cluster_id: str) -> dict[str, list[dict]]:
        """Load resources from a real Kubernetes cluster.

        Returns a dict keyed by resource kind:
            {"pods": [...], "deployments": [...], "roles": [...], ...}
        """
        try:
            from kubernetes import client, config
            if self.kubeconfig_path:
                config.load_kubeconfig(self.kubeconfig_path)
            else:
                try:
                    config.incluster_config.load_incluster_config()
                except config.ConfigException:
                    config.load_kubeconfig()
            self._client = client
        except ImportError:
            logger.warning("kubernetes library not available")
            return {}
        except Exception as e:
            logger.warning(f"Cannot connect to cluster: {e}")
            return {}

        resources: dict[str, list[dict]] = defaultdict(list)
        try:
            v1 = client.CoreV1Api()
            # Pods
            for pod in v1.list_pod_for_all_namespaces().items:
                resources["pods"].append(self._serialize(pod))
            # Services
            for svc in v1.list_service_for_all_namespaces().items:
                resources["services"].append(self._serialize(svc))
            # Namespaces
            for ns in v1.list_namespace().items:
                resources["namespaces"].append(self._serialize(ns))
            # Secrets (metadata only — never read values)
            for secret in v1.list_secret_for_all_namespaces().items:
                resources["secrets"].append({
                    "name": secret.metadata.name,
                    "namespace": secret.metadata.namespace,
                    "type": secret.type,
                    "creation_timestamp": str(secret.metadata.creation_timestamp) if secret.metadata.creation_timestamp else "",
                })

            rbac = client.RbacAuthorizationV1Api()
            for role in rbac.list_role_for_all_namespaces().items:
                resources["roles"].append(self._serialize(role))
            for cr in rbac.list_cluster_role().items:
                resources["clusterroles"].append(self._serialize(cr))
            for rb in rbac.list_role_binding_for_all_namespaces().items:
                resources["rolebindings"].append(self._serialize(rb))
            for crb in rbac.list_cluster_role_binding().items:
                resources["clusterrolebindings"].append(self._serialize(crb))

            net = client.NetworkingV1Api()
            for np in net.list_network_policy_for_all_namespaces().items:
                resources["networkpolicies"].append(self._serialize(np))

            apps = client.AppsV1Api()
            for dep in apps.list_deployment_for_all_namespaces().items:
                resources["deployments"].append(self._serialize(dep))
            for sts in apps.list_stateful_set_for_all_namespaces().items:
                resources["statefulsets"].append(self._serialize(sts))
            for ds in apps.list_daemon_set_for_all_namespaces().items:
                resources["daemonsets"].append(self._serialize(ds))

        except Exception as e:
            logger.error(f"Failed to load cluster resources: {e}")

        return dict(resources)

    def from_manifests(self, manifests: list[dict]) -> dict[str, list[dict]]:
        """Parse Kubernetes YAML/JSON manifests.

        Args:
            manifests: List of resource dicts (parsed YAML/JSON)
        """
        resources: dict[str, list[dict]] = defaultdict(list)
        for m in manifests:
            kind = (m.get("kind") or "Unknown").lower()
            resources[f"{kind}s"].append(m)
        return dict(resources)

    def _serialize(self, obj) -> dict:
        """Serialize a kubernetes client object to dict."""
        try:
            api_client = self._client.ApiClient()
            return api_client.sanitize_for_serialization(obj)
        except Exception:
            return {"raw": str(obj)}


# ═══════════════════════════════════════════════════════════════
# K8s Security Rules (CIS Kubernetes Benchmark v1.8)
# ═══════════════════════════════════════════════════════════════

class K8sRules:
    """Kubernetes security rules aligned with CIS K8s Benchmark v1.8.

    Each rule method takes resources dict and returns list of findings.
    """

    DANGEROUS_CAPABILITIES = {"SYS_ADMIN", "SYS_MODULE", "SYS_PTRACE", "SYS_RAWIO",
                              "SYS_BOOT", "MAC_ADMIN", "MAC_OVERRIDE", "NET_ADMIN",
                              "DAC_OVERRIDE", "DAC_READ_SEARCH", "SETUID", "SETGID",
                              "CHOWN", "FOWNER", "KILL", "NET_RAW", "LINUX_IMMUTABLE"}

    @classmethod
    def evaluate_all(cls, resources: dict[str, list[dict]], tenant_id: str,
                    scan_id: str, cluster_id: str) -> list[K8sFinding]:
        findings: list[K8sFinding] = []
        now = int(time.time() * 1000)

        for rule_method in [
            cls.check_rbac_cluster_admin,
            cls.check_rbac_wildcard,
            cls.check_rbac_privilege_escalation,
            cls.check_rbac_secret_access,
            cls.check_pod_privileged,
            cls.check_pod_host_namespace,
            cls.check_pod_host_path,
            cls.check_pod_root_user,
            cls.check_pod_security_context,
            cls.check_pod_dangerous_capabilities,
            cls.check_pod_no_seccomp,
            cls.check_pod_no_readonly_fs,
            cls.check_network_policy_missing,
            cls.check_secret_env_var,
            cls.check_image_latest_tag,
            cls.check_image_no_digest,
            cls.check_resource_limits_missing,
            cls.check_namespace_default,
            cls.check_service_account_token,
        ]:
            try:
                rule_findings = rule_method(resources, tenant_id, scan_id, cluster_id, now)
                findings.extend(rule_findings)
            except Exception as e:
                logger.warning(f"K8s rule {rule_method.__name__} failed: {e}")

        return findings

    # ─── RBAC Rules ───

    @classmethod
    def check_rbac_cluster_admin(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for crb in resources.get("clusterrolebindings", []):
            role_ref = crb.get("roleRef", {})
            if role_ref.get("name") == "cluster-admin":
                for subject in crb.get("subjects", []):
                    # Skip system subjects
                    if subject.get("namespace", "") in ("kube-system", ""):
                        if subject.get("name", "").startswith(("system:", "kubelet")):
                            continue
                    findings.append(K8sFinding(
                        finding_id=str(uuid.uuid4()),
                        tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                        category=K8sFindingCategory.RBAC_CLUSTER_ADMIN.value,
                        severity=Severity.CRITICAL.value,
                        title=f"cluster-admin granted to {subject.get('kind')}/{subject.get('name')}",
                        description=f"{subject.get('kind')} '{subject.get('name')}' has cluster-admin role. "
                                    f"This grants full control over the entire cluster.",
                        remediation="Replace cluster-admin with a least-privilege ClusterRole. "
                                    "Use `kubectl auth can-i --list` to determine required permissions.",
                        cis_control="CIS-K8s 5.1.1",
                        resource_kind="ClusterRoleBinding", resource_name=crb.get("metadata", {}).get("name", ""),
                        evidence={"subject": subject, "role": "cluster-admin"},
                        detected_at=now,
                    ))
        return findings

    @classmethod
    def check_rbac_wildcard(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for cr in resources.get("clusterroles", []) + resources.get("roles", []):
            for rule in cr.get("rules", []):
                verbs = rule.get("verbs", [])
                resources_list = rule.get("resources", [])
                if "*" in verbs or "*" in resources_list:
                    findings.append(K8sFinding(
                        finding_id=str(uuid.uuid4()),
                        tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                        category=K8sFindingCategory.RBAC_WILDCARD.value,
                        severity=Severity.HIGH.value,
                        title=f"Wildcard permissions in {cr.get('kind', 'Role')}",
                        description=f"Role '{cr.get('metadata', {}).get('name', '')}' grants wildcard "
                                    f"verbs={verbs} resources={resources_list}. "
                                    f"This grants broader permissions than typically needed.",
                        remediation="Replace wildcards with specific verbs and resources.",
                        cis_control="CIS-K8s 5.1.3",
                        resource_kind=cr.get("kind", "Role"),
                        resource_name=cr.get("metadata", {}).get("name", ""),
                        resource_namespace=cr.get("metadata", {}).get("namespace", ""),
                        evidence={"verbs": verbs, "resources": resources_list},
                        detected_at=now,
                    ))
        return findings

    @classmethod
    def check_rbac_privilege_escalation(cls, resources, tenant_id, scan_id, cluster_id, now):
        """Check for verbs like 'escalate', 'bind' that allow privilege escalation."""
        findings = []
        for cr in resources.get("clusterroles", []) + resources.get("roles", []):
            for rule in cr.get("rules", []):
                if "escalate" in rule.get("verbs", []) or "bind" in rule.get("verbs", []):
                    findings.append(K8sFinding(
                        finding_id=str(uuid.uuid4()),
                        tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                        category=K8sFindingCategory.RBAC_PRIVILEGE_ESCALATION.value,
                        severity=Severity.CRITICAL.value,
                        title=f"Privilege escalation verb in {cr.get('kind', 'Role')}",
                        description=f"Role '{cr.get('metadata', {}).get('name', '')}' can {'escalate' if 'escalate' in rule.get('verbs') else 'bind'} roles. "
                                    f"This allows horizontal/vertical privilege escalation.",
                        remediation="Remove 'escalate' and 'bind' verbs. Use RoleBinding to grant roles you already have.",
                        cis_control="CIS-K8s 5.1.5",
                        resource_kind=cr.get("kind", "Role"),
                        resource_name=cr.get("metadata", {}).get("name", ""),
                        evidence={"verbs": rule.get("verbs", [])},
                        detected_at=now,
                    ))
        return findings

    @classmethod
    def check_rbac_secret_access(cls, resources, tenant_id, scan_id, cluster_id, now):
        """Flag roles that can read/watch/list secrets."""
        findings = []
        for cr in resources.get("clusterroles", []) + resources.get("roles", []):
            for rule in cr.get("rules", []):
                if "secrets" in rule.get("resources", []) and any(v in rule.get("verbs", []) for v in ["get", "list", "watch"]):
                    findings.append(K8sFinding(
                        finding_id=str(uuid.uuid4()),
                        tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                        category=K8sFindingCategory.RBAC_SECRET_ACCESS.value,
                        severity=Severity.HIGH.value,
                        title=f"Secret read access in {cr.get('kind', 'Role')}",
                        description=f"Role '{cr.get('metadata', {}).get('name', '')}' can read Kubernetes secrets. "
                                    f"Anyone with this role can extract all secrets in scope.",
                        remediation="Use 'secretKeyRef' with projected volumes or external secret managers (Vault, AWS Secrets Manager).",
                        cis_control="CIS-K8s 5.1.4",
                        resource_kind=cr.get("kind", "Role"),
                        resource_name=cr.get("metadata", {}).get("name", ""),
                        evidence={"verbs": rule.get("verbs", []), "resources": rule.get("resources", [])},
                        detected_at=now,
                    ))
        return findings

    # ─── Pod Security Rules ───

    @classmethod
    def check_pod_privileged(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets", "jobs", "cronjobs"]:
            for resource in resources.get(kind, []):
                containers = cls._get_containers(resource)
                for container in containers:
                    security_context = container.get("securityContext", {})
                    if security_context.get("privileged", False):
                        findings.append(K8sFinding(
                            finding_id=str(uuid.uuid4()),
                            tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                            category=K8sFindingCategory.POD_PRIVILEGED.value,
                            severity=Severity.CRITICAL.value,
                            title=f"Privileged container: {container.get('name', '')}",
                            description=f"Container '{container.get('name', '')}' in {kind[:-1]} '{resource.get('metadata', {}).get('name', '')}' "
                                        f"is privileged. It has full host access (devices, kernel, all capabilities).",
                            remediation="Set securityContext.privileged: false. Grant specific capabilities with securityContext.capabilities.add.",
                            cis_control="CIS-K8s 5.2.1",
                            resource_kind=kind[:-1].capitalize(),
                            resource_name=resource.get("metadata", {}).get("name", ""),
                            resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                            evidence={"container": container.get("name"), "privileged": True},
                            detected_at=now,
                        ))
        return findings

    @classmethod
    def check_pod_host_namespace(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                spec = resource.get("spec", {})
                for flag, cat, cis, desc in [
                    ("hostNetwork", K8sFindingCategory.POD_HOST_NETWORK, "CIS-K8s 5.2.2", "hostNetwork"),
                    ("hostPID", K8sFindingCategory.POD_HOST_PID, "CIS-K8s 5.2.3", "hostPID"),
                    ("hostIPC", K8sFindingCategory.POD_HOST_IPC, "CIS-K8s 5.2.4", "hostIPC"),
                ]:
                    if spec.get(flag, False):
                        findings.append(K8sFinding(
                            finding_id=str(uuid.uuid4()),
                            tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                            category=cat.value,
                            severity=Severity.HIGH.value,
                            title=f"{desc} enabled in {resource.get('metadata', {}).get('name', '')}",
                            description=f"{kind[:-1]} '{resource.get('metadata', {}).get('name', '')}' uses {desc}. "
                                        f"This shares the host's network/PID/IPC namespace with the container.",
                            remediation=f"Set {desc}: false in the pod spec.",
                            cis_control=cis,
                            resource_kind=kind[:-1].capitalize(),
                            resource_name=resource.get("metadata", {}).get("name", ""),
                            resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                            evidence={flag: True},
                            detected_at=now,
                        ))
        return findings

    @classmethod
    def check_pod_host_path(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                volumes = resource.get("spec", {}).get("volumes", [])
                for vol in volumes:
                    if vol.get("hostPath"):
                        path = vol["hostPath"].get("path", "")
                        findings.append(K8sFinding(
                            finding_id=str(uuid.uuid4()),
                            tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                            category=K8sFindingCategory.POD_HOST_PATH.value,
                            severity=Severity.HIGH.value,
                            title=f"hostPath mount: {path}",
                            description=f"{kind[:-1]} '{resource.get('metadata', {}).get('name', '')}' mounts host path {path}. "
                                        f"This can allow container escape to the host filesystem.",
                            remediation="Avoid hostPath. Use PersistentVolumes (PV) and PersistentVolumeClaims (PVC) instead.",
                            cis_control="CIS-K8s 5.2.5",
                            resource_kind=kind[:-1].capitalize(),
                            resource_name=resource.get("metadata", {}).get("name", ""),
                            resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                            evidence={"volume": vol.get("name"), "path": path},
                            detected_at=now,
                        ))
        return findings

    @classmethod
    def check_pod_root_user(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                pod_spec = resource.get("spec", {})
                # Check pod-level security context
                pod_sc = pod_spec.get("securityContext", {})
                run_as_non_root = pod_sc.get("runAsNonRoot", False)
                run_as_user = pod_sc.get("runAsUser")

                containers = cls._get_containers(resource)
                for container in containers:
                    container_sc = container.get("securityContext", {})
                    # Container level overrides pod level
                    if "runAsNonRoot" in container_sc:
                        run_as_non_root = container_sc["runAsNonRoot"]
                    if "runAsUser" in container_sc:
                        run_as_user = container_sc["runAsUser"]

                    if not run_as_non_root and (run_as_user is None or run_as_user == 0):
                        findings.append(K8sFinding(
                            finding_id=str(uuid.uuid4()),
                            tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                            category=K8sFindingCategory.POD_ROOT_USER.value,
                            severity=Severity.HIGH.value,
                            title=f"Container runs as root: {container.get('name', '')}",
                            description=f"Container '{container.get('name', '')}' does not enforce non-root user. "
                                        f"Process runs as UID 0 (root).",
                            remediation="Set securityContext.runAsNonRoot: true and runAsUser: 1000 in pod or container spec.",
                            cis_control="CIS-K8s 5.2.6",
                            resource_kind=kind[:-1].capitalize(),
                            resource_name=resource.get("metadata", {}).get("name", ""),
                            resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                            evidence={"container": container.get("name"), "runAsNonRoot": run_as_non_root, "runAsUser": run_as_user},
                            detected_at=now,
                        ))
        return findings

    @classmethod
    def check_pod_security_context(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                pod_sc = resource.get("spec", {}).get("securityContext", {})
                if not pod_sc:
                    findings.append(K8sFinding(
                        finding_id=str(uuid.uuid4()),
                        tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                        category=K8sFindingCategory.POD_NO_SECURITY_CONTEXT.value,
                        severity=Severity.MEDIUM.value,
                        title=f"No pod security context",
                        description=f"{kind[:-1]} '{resource.get('metadata', {}).get('name', '')}' has no securityContext. "
                                    f"All security defaults (root user, no capabilities drop, etc.) apply.",
                        remediation="Add a securityContext block: runAsNonRoot, runAsUser, fsGroup, seccompProfile.",
                        cis_control="CIS-K8s 5.2.7",
                        resource_kind=kind[:-1].capitalize(),
                        resource_name=resource.get("metadata", {}).get("name", ""),
                        resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                        evidence={"has_security_context": False},
                        detected_at=now,
                    ))
        return findings

    @classmethod
    def check_pod_dangerous_capabilities(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                containers = cls._get_containers(resource)
                for container in containers:
                    sc = container.get("securityContext", {})
                    caps_add = sc.get("capabilities", {}).get("add", [])
                    dangerous_added = [c for c in caps_add if c.upper() in cls.DANGEROUS_CAPABILITIES]
                    if dangerous_added:
                        findings.append(K8sFinding(
                            finding_id=str(uuid.uuid4()),
                            tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                            category=K8sFindingCategory.POD_DANGEROUS_CAPABILITIES.value,
                            severity=Severity.CRITICAL.value,
                            title=f"Dangerous capabilities: {', '.join(dangerous_added)}",
                            description=f"Container '{container.get('name', '')}' adds dangerous Linux capabilities: {dangerous_added}. "
                                        f"These grant kernel-level privileges.",
                            remediation="Remove dangerous capabilities. Use securityContext.capabilities.drop: ['ALL'] and add only what's needed.",
                            cis_control="CIS-K8s 5.2.8",
                            resource_kind=kind[:-1].capitalize(),
                            resource_name=resource.get("metadata", {}).get("name", ""),
                            resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                            evidence={"container": container.get("name"), "capabilities_add": dangerous_added},
                            detected_at=now,
                        ))
                    # Check if ALL capabilities are dropped (best practice)
                    caps_drop = sc.get("capabilities", {}).get("drop", [])
                    if "ALL" not in caps_drop and not caps_add:
                        findings.append(K8sFinding(
                            finding_id=str(uuid.uuid4()),
                            tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                            category=K8sFindingCategory.POD_DANGEROUS_CAPABILITIES.value,
                            severity=Severity.LOW.value,
                            title=f"Capabilities not dropped: {container.get('name', '')}",
                            description=f"Container '{container.get('name', '')}' does not drop capabilities. "
                                        f"Default Linux capabilities are retained.",
                            remediation="Add securityContext.capabilities.drop: ['ALL']",
                            cis_control="CIS-K8s 5.2.9",
                            resource_kind=kind[:-1].capitalize(),
                            resource_name=resource.get("metadata", {}).get("name", ""),
                            resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                            evidence={"container": container.get("name"), "drop": caps_drop},
                            detected_at=now,
                        ))
        return findings

    @classmethod
    def check_pod_no_seccomp(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                pod_sc = resource.get("spec", {}).get("securityContext", {})
                seccomp = pod_sc.get("seccompProfile", {})
                if not seccomp or seccomp.get("type") == "Unconfined":
                    findings.append(K8sFinding(
                        finding_id=str(uuid.uuid4()),
                        tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                        category=K8sFindingCategory.POD_NO_SECCOMP.value,
                        severity=Severity.MEDIUM.value,
                        title="No seccomp profile",
                        description=f"{kind[:-1]} '{resource.get('metadata', {}).get('name', '')}' does not have a seccomp profile. "
                                    f"Without seccomp, the container can call any system call.",
                        remediation="Add securityContext.seccompProfile: {type: RuntimeDefault}",
                        cis_control="CIS-K8s 5.2.10",
                        resource_kind=kind[:-1].capitalize(),
                        resource_name=resource.get("metadata", {}).get("name", ""),
                        resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                        evidence={"seccomp": seccomp},
                        detected_at=now,
                    ))
        return findings

    @classmethod
    def check_pod_no_readonly_fs(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                containers = cls._get_containers(resource)
                for container in containers:
                    sc = container.get("securityContext", {})
                    if not sc.get("readOnlyRootFilesystem", False):
                        findings.append(K8sFinding(
                            finding_id=str(uuid.uuid4()),
                            tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                            category=K8sFindingCategory.POD_NO_READONLY_FS.value,
                            severity=Severity.LOW.value,
                            title=f"Read-only root filesystem not set: {container.get('name', '')}",
                            description=f"Container '{container.get('name', '')}' does not have readOnlyRootFilesystem. "
                                        f"Attackers can write malicious binaries to the filesystem.",
                            remediation="Set securityContext.readOnlyRootFilesystem: true. Use emptyDir volumes for write paths.",
                            cis_control="CIS-K8s 5.2.11",
                            resource_kind=kind[:-1].capitalize(),
                            resource_name=resource.get("metadata", {}).get("name", ""),
                            resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                            evidence={"container": container.get("name")},
                            detected_at=now,
                        ))
        return findings

    # ─── Network Policy Rules ───

    @classmethod
    def check_network_policy_missing(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        namespaces = [ns.get("metadata", {}).get("name", "") for ns in resources.get("namespaces", [])]
        net_policies_by_ns = defaultdict(int)
        for np in resources.get("networkpolicies", []):
            ns = np.get("metadata", {}).get("namespace", "default")
            net_policies_by_ns[ns] += 1

        for ns in namespaces:
            if ns in ("kube-system", "kube-public", "kube-node-lease"):
                continue
            if net_policies_by_ns[ns] == 0:
                findings.append(K8sFinding(
                    finding_id=str(uuid.uuid4()),
                    tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                    category=K8sFindingCategory.NETWORK_POLICY_MISSING.value,
                    severity=Severity.MEDIUM.value,
                    title=f"No NetworkPolicy in namespace: {ns}",
                    description=f"Namespace '{ns}' has no NetworkPolicy. All pods can communicate with each other "
                                f"by default, allowing lateral movement after compromise.",
                    remediation="Add a default-deny NetworkPolicy: "
                                "apiVersion: networking.k8s.io/v1, kind: NetworkPolicy, spec: podSelector: {}, policyTypes: [Ingress, Egress]",
                    cis_control="CIS-K8s 5.3.2",
                    resource_kind="Namespace", resource_name=ns, resource_namespace=ns,
                    evidence={"network_policy_count": 0},
                    detected_at=now,
                ))
        return findings

    # ─── Image Rules ───

    @classmethod
    def check_image_latest_tag(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                containers = cls._get_containers(resource)
                for container in containers:
                    image = container.get("image", "")
                    if image and (":latest" in image or ":" not in image):
                        findings.append(K8sFinding(
                            finding_id=str(uuid.uuid4()),
                            tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                            category=K8sFindingCategory.IMAGE_LATEST_TAG.value,
                            severity=Severity.MEDIUM.value,
                            title=f"Image uses :latest or no tag: {image}",
                            description=f"Container '{container.get('name', '')}' uses image '{image}' with :latest tag. "
                                        f"This makes rollbacks impossible and breaks reproducibility.",
                            remediation=f"Pin to a specific version: {image.split(':')[0]}:1.2.3",
                            cis_control="CIS-K8s 5.4.1",
                            resource_kind=kind[:-1].capitalize(),
                            resource_name=resource.get("metadata", {}).get("name", ""),
                            resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                            evidence={"image": image},
                            detected_at=now,
                        ))
        return findings

    @classmethod
    def check_image_no_digest(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                containers = cls._get_containers(resource)
                for container in containers:
                    image = container.get("image", "")
                    if image and "@" not in image and ":" in image:
                        # Has tag but no digest — flag as low severity
                        findings.append(K8sFinding(
                            finding_id=str(uuid.uuid4()),
                            tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                            category=K8sFindingCategory.IMAGE_NO_DIGEST.value,
                            severity=Severity.LOW.value,
                            title=f"Image not pinned by digest: {image}",
                            description=f"Container '{container.get('name', '')}' uses image '{image}' without SHA256 digest. "
                                        f"Tags are mutable — same tag can resolve to different images.",
                            remediation=f"Pin by digest: {image}@sha256:<digest>",
                            cis_control="CIS-K8s 5.4.2",
                            resource_kind=kind[:-1].capitalize(),
                            resource_name=resource.get("metadata", {}).get("name", ""),
                            resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                            evidence={"image": image},
                            detected_at=now,
                        ))
        return findings

    # ─── Resource Limits ───

    @classmethod
    def check_resource_limits_missing(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                containers = cls._get_containers(resource)
                for container in containers:
                    resources_req = container.get("resources", {})
                    if not resources_req.get("limits"):
                        findings.append(K8sFinding(
                            finding_id=str(uuid.uuid4()),
                            tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                            category=K8sFindingCategory.RESOURCE_LIMITS_MISSING.value,
                            severity=Severity.MEDIUM.value,
                            title=f"No resource limits: {container.get('name', '')}",
                            description=f"Container '{container.get('name', '')}' has no CPU/memory limits. "
                                        f"It can consume all node resources, causing DoS to other pods.",
                            remediation="Add resources.limits: {cpu: '500m', memory: '512Mi'}",
                            cis_control="CIS-K8s 5.5.1",
                            resource_kind=kind[:-1].capitalize(),
                            resource_name=resource.get("metadata", {}).get("name", ""),
                            resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                            evidence={"container": container.get("name")},
                            detected_at=now,
                        ))
        return findings

    # ─── Secret Rules ───

    @classmethod
    def check_secret_env_var(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                containers = cls._get_containers(resource)
                for container in containers:
                    for env in container.get("env", []):
                        if env.get("valueFrom", {}).get("secretKeyRef"):
                            findings.append(K8sFinding(
                                finding_id=str(uuid.uuid4()),
                                tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                                category=K8sFindingCategory.SECRET_ENV_VAR.value,
                                severity=Severity.LOW.value,
                                title=f"Secret as env var: {env.get('name', '')}",
                                description=f"Container '{container.get('name', '')}' uses secretKeyRef for env var '{env.get('name', '')}'. "
                                            f"Env vars may leak via process listing, crash dumps, or logs.",
                                remediation="Mount secrets as files instead of env vars. Better: use external secrets manager.",
                                cis_control="CIS-K8s 5.4.4",
                                resource_kind=kind[:-1].capitalize(),
                                resource_name=resource.get("metadata", {}).get("name", ""),
                                resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                                evidence={"container": container.get("name"), "env_var": env.get("name")},
                                detected_at=now,
                            ))
        return findings

    # ─── Namespace Rules ───

    @classmethod
    def check_namespace_default(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        namespaces = [ns.get("metadata", {}).get("name", "") for ns in resources.get("namespaces", [])]
        if "default" in namespaces:
            # Check if any workload runs in default namespace
            for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
                for resource in resources.get(kind, []):
                    if resource.get("metadata", {}).get("namespace") == "default":
                        findings.append(K8sFinding(
                            finding_id=str(uuid.uuid4()),
                            tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                            category=K8sFindingCategory.NAMESPACE_DEFAULT.value,
                            severity=Severity.LOW.value,
                            title=f"Workload in default namespace: {resource.get('metadata', {}).get('name', '')}",
                            description=f"{kind[:-1]} '{resource.get('metadata', {}).get('name', '')}' runs in 'default' namespace. "
                                        f"The default namespace has no isolation boundaries.",
                            remediation="Move to a dedicated namespace per service/team.",
                            cis_control="CIS-K8s 5.7.1",
                            resource_kind=kind[:-1].capitalize(),
                            resource_name=resource.get("metadata", {}).get("name", ""),
                            resource_namespace="default",
                            evidence={"namespace": "default"},
                            detected_at=now,
                        ))
                        break
                if findings:
                    break
        return findings

    @classmethod
    def check_service_account_token(cls, resources, tenant_id, scan_id, cluster_id, now):
        findings = []
        for kind in ["pods", "deployments", "statefulsets", "daemonsets"]:
            for resource in resources.get(kind, []):
                spec = resource.get("spec", {})
                if spec.get("automountServiceAccountToken", True):
                    findings.append(K8sFinding(
                        finding_id=str(uuid.uuid4()),
                        tenant_id=tenant_id, scan_id=scan_id, cluster_id=cluster_id,
                        category=K8sFindingCategory.SERVICE_ACCOUNT_TOKEN.value,
                        severity=Severity.MEDIUM.value,
                        title=f"Auto-mounted service account token",
                        description=f"{kind[:-1]} '{resource.get('metadata', {}).get('name', '')}' auto-mounts the service account token. "
                                    f"Anyone who compromises this pod can act as the service account.",
                        remediation="Set automountServiceAccountToken: false in pod spec.",
                        cis_control="CIS-K8s 5.1.6",
                        resource_kind=kind[:-1].capitalize(),
                        resource_name=resource.get("metadata", {}).get("name", ""),
                        resource_namespace=resource.get("metadata", {}).get("namespace", ""),
                        evidence={"automountServiceAccountToken": True},
                        detected_at=now,
                    ))
        return findings

    # ─── Helper ───

    @classmethod
    def _get_containers(cls, resource: dict) -> list[dict]:
        """Get all containers (initContainers + containers) from a resource."""
        spec = resource.get("spec", {})
        # For Pod, spec has containers directly; for Deployment, spec.template.spec
        if "template" in spec:
            spec = spec["template"].get("spec", {})
        return spec.get("initContainers", []) + spec.get("containers", [])


# ═══════════════════════════════════════════════════════════════
# KSPM Engine
# ═══════════════════════════════════════════════════════════════

class KSPMEngine:
    """Kubernetes Security Posture Management engine.

    Usage:
        engine = KSPMEngine()
        # From real cluster:
        result = engine.scan_cluster(tenant_id, scan_id, cluster_id, kubeconfig_path="~/.kube/config")
        # From YAML manifests (GitOps / IaC):
        result = engine.scan_manifests(tenant_id, scan_id, cluster_id, manifests)
    """

    def __init__(self):
        self.loader = K8sResourceLoader()

    def scan_cluster(self, tenant_id: str, scan_id: str, cluster_id: str,
                    cluster_name: str = "", kubeconfig_path: Optional[str] = None) -> K8sScanResult:
        """Scan a real Kubernetes cluster."""
        start_time = time.time()
        loader = K8sResourceLoader(kubeconfig_path) if kubeconfig_path else self.loader
        resources = loader.from_cluster(cluster_id)
        return self._scan(tenant_id, scan_id, cluster_id, cluster_name, resources, start_time)

    def scan_manifests(self, tenant_id: str, scan_id: str, cluster_id: str,
                      manifests: list[dict], cluster_name: str = "manifests") -> K8sScanResult:
        """Scan Kubernetes YAML/JSON manifests (for IaC scanning)."""
        start_time = time.time()
        resources = self.loader.from_manifests(manifests)
        return self._scan(tenant_id, scan_id, cluster_id, cluster_name, resources, start_time)

    def _scan(self, tenant_id: str, scan_id: str, cluster_id: str, cluster_name: str,
              resources: dict[str, list[dict]], start_time: float) -> K8sScanResult:
        findings = K8sRules.evaluate_all(resources, tenant_id, scan_id, cluster_id)
        rbac_edges = self._build_rbac_graph(resources)

        # Build summary
        namespaces = sorted(set(
            r.get("metadata", {}).get("namespace", "")
            for kind_resources in resources.values()
            for r in kind_resources
            if r.get("metadata", {}).get("namespace")
        ))

        by_severity = defaultdict(int)
        by_category = defaultdict(int)
        by_namespace = defaultdict(int)
        for f in findings:
            by_severity[f.severity] += 1
            by_category[f.category] += 1
            if f.resource_namespace:
                by_namespace[f.resource_namespace] += 1

        resources_scanned = sum(len(v) for v in resources.values())

        return K8sScanResult(
            tenant_id=tenant_id,
            scan_id=scan_id,
            cluster_id=cluster_id,
            cluster_name=cluster_name,
            cluster_version="1.28.0",  # would come from cluster API
            resources_scanned=resources_scanned,
            findings=findings,
            rbac_edges=rbac_edges,
            namespaces=namespaces,
            scanned_at=int(time.time() * 1000),
            duration_ms=int((time.time() - start_time) * 1000),
            summary={
                "total_findings": len(findings),
                "by_severity": dict(by_severity),
                "by_category": dict(by_category),
                "by_namespace": dict(by_namespace),
                "resource_counts": {k: len(v) for k, v in resources.items()},
                "rbac_edges": len(rbac_edges),
            },
        )

    def _build_rbac_graph(self, resources: dict[str, list[dict]]) -> list[RBACEdge]:
        """Build a graph of Subject → Role → Permission edges."""
        edges: list[RBACEdge] = []
        role_rules: dict[tuple[str, str], list[dict]] = {}

        # Index roles
        for role in resources.get("roles", []):
            name = role.get("metadata", {}).get("name", "")
            ns = role.get("metadata", {}).get("namespace", "")
            role_rules[("Role", name)] = role.get("rules", [])
        for cr in resources.get("clusterroles", []):
            name = cr.get("metadata", {}).get("name", "")
            role_rules[("ClusterRole", name)] = cr.get("rules", [])

        # Build edges from bindings
        for rb in resources.get("rolebindings", []):
            role_ref = rb.get("roleRef", {})
            role_key = (role_ref.get("kind", ""), role_ref.get("name", ""))
            rules = role_rules.get(role_key, [])
            for subject in rb.get("subjects", []):
                for rule in rules:
                    for verb in rule.get("verbs", []):
                        for resource in rule.get("resources", []):
                            edges.append(RBACEdge(
                                subject_kind=subject.get("kind", ""),
                                subject_name=subject.get("name", ""),
                                subject_namespace=subject.get("namespace", ""),
                                role_kind=role_key[0],
                                role_name=role_key[1],
                                api_group=rule.get("apiGroups", [""])[0] if rule.get("apiGroups") else "",
                                resource=resource,
                                verb=verb,
                                binding_namespace=rb.get("metadata", {}).get("namespace", ""),
                            ))
        for crb in resources.get("clusterrolebindings", []):
            role_ref = crb.get("roleRef", {})
            role_key = (role_ref.get("kind", ""), role_ref.get("name", ""))
            rules = role_rules.get(role_key, [])
            for subject in crb.get("subjects", []):
                for rule in rules:
                    for verb in rule.get("verbs", []):
                        for resource in rule.get("resources", []):
                            edges.append(RBACEdge(
                                subject_kind=subject.get("kind", ""),
                                subject_name=subject.get("name", ""),
                                subject_namespace=subject.get("namespace", ""),
                                role_kind=role_key[0],
                                role_name=role_key[1],
                                api_group=rule.get("apiGroups", [""])[0] if rule.get("apiGroups") else "",
                                resource=resource,
                                verb=verb,
                            ))
        return edges

    def list_rules(self) -> list[dict[str, Any]]:
        return [
            {"rule": "check_rbac_cluster_admin", "cis_control": "CIS-K8s 5.1.1", "category": "RBAC",
             "description": "Detect cluster-admin grants to non-system subjects"},
            {"rule": "check_rbac_wildcard", "cis_control": "CIS-K8s 5.1.3", "category": "RBAC",
             "description": "Detect wildcard verbs/resources in RBAC rules"},
            {"rule": "check_rbac_privilege_escalation", "cis_control": "CIS-K8s 5.1.5", "category": "RBAC",
             "description": "Detect escalate/bind verbs"},
            {"rule": "check_rbac_secret_access", "cis_control": "CIS-K8s 5.1.4", "category": "RBAC",
             "description": "Detect roles with secret read access"},
            {"rule": "check_pod_privileged", "cis_control": "CIS-K8s 5.2.1", "category": "Pod Security",
             "description": "Detect privileged containers"},
            {"rule": "check_pod_host_namespace", "cis_control": "CIS-K8s 5.2.2-4", "category": "Pod Security",
             "description": "Detect hostNetwork/hostPID/hostIPC"},
            {"rule": "check_pod_host_path", "cis_control": "CIS-K8s 5.2.5", "category": "Pod Security",
             "description": "Detect hostPath volume mounts"},
            {"rule": "check_pod_root_user", "cis_control": "CIS-K8s 5.2.6", "category": "Pod Security",
             "description": "Detect containers running as root"},
            {"rule": "check_pod_security_context", "cis_control": "CIS-K8s 5.2.7", "category": "Pod Security",
             "description": "Detect missing securityContext"},
            {"rule": "check_pod_dangerous_capabilities", "cis_control": "CIS-K8s 5.2.8-9", "category": "Pod Security",
             "description": "Detect dangerous Linux capabilities"},
            {"rule": "check_pod_no_seccomp", "cis_control": "CIS-K8s 5.2.10", "category": "Pod Security",
             "description": "Detect missing seccomp profile"},
            {"rule": "check_pod_no_readonly_fs", "cis_control": "CIS-K8s 5.2.11", "category": "Pod Security",
             "description": "Detect non-readonly root filesystem"},
            {"rule": "check_network_policy_missing", "cis_control": "CIS-K8s 5.3.2", "category": "Network",
             "description": "Detect namespaces without NetworkPolicy"},
            {"rule": "check_image_latest_tag", "cis_control": "CIS-K8s 5.4.1", "category": "Image",
             "description": "Detect images with :latest tag"},
            {"rule": "check_image_no_digest", "cis_control": "CIS-K8s 5.4.2", "category": "Image",
             "description": "Detect images not pinned by SHA256 digest"},
            {"rule": "check_resource_limits_missing", "cis_control": "CIS-K8s 5.5.1", "category": "Resources",
             "description": "Detect containers without resource limits"},
            {"rule": "check_secret_env_var", "cis_control": "CIS-K8s 5.4.4", "category": "Secrets",
             "description": "Detect secrets used as environment variables"},
            {"rule": "check_namespace_default", "cis_control": "CIS-K8s 5.7.1", "category": "Namespace",
             "description": "Detect workloads in default namespace"},
            {"rule": "check_service_account_token", "cis_control": "CIS-K8s 5.1.6", "category": "RBAC",
             "description": "Detect auto-mounted service account tokens"},
        ]


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_engine: Optional[KSPMEngine] = None
_global_lock = threading.Lock()


def get_kspm_engine() -> KSPMEngine:
    global _global_engine
    if _global_engine is None:
        with _global_lock:
            if _global_engine is None:
                _global_engine = KSPMEngine()
    return _global_engine
