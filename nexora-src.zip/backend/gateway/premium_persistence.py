"""
Premium Engine Persistence — SQLite-backed storage for the 6 premium features.

Survives gateway restarts:
  - Drift events + baselines
  - Evidence vault records (hash chain)
  - Workflow integrations + tickets + sync events
  - Kill chain attack paths
  - Multi-account organizations + accounts
  - Finding prioritization fix plans

Each engine calls save_*() on mutations and load_*() on startup.
All tables are tenant-scoped (tenant_id is always part of the primary key).
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from collections import defaultdict
from contextlib import contextmanager
from typing import Any, Optional
from uuid import uuid4

DB_PATH = os.environ.get(
    "SENTINEL_DB_PATH",
    "/home/z/my-project/db/sentinel.db",
)

_lock = threading.RLock()


@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_premium_tables() -> None:
    """Create premium feature tables if they don't exist."""
    with get_db() as conn:
        # Drift detection
        conn.execute("""
            CREATE TABLE IF NOT EXISTS drift_events (
                event_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                asset_id TEXT NOT NULL,
                asset_type TEXT,
                asset_name TEXT,
                drift_type TEXT,
                field_path TEXT,
                old_value TEXT,
                new_value TEXT,
                risk_weight INTEGER,
                severity TEXT,
                timestamp REAL,
                scan_id TEXT,
                notes TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_drift_tenant ON drift_events(tenant_id, timestamp DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_drift_asset ON drift_events(tenant_id, asset_id)")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS drift_baselines (
                tenant_id TEXT NOT NULL,
                asset_id TEXT NOT NULL,
                asset_type TEXT,
                asset_name TEXT,
                config TEXT,
                state_hash TEXT,
                timestamp REAL,
                scan_id TEXT,
                PRIMARY KEY (tenant_id, asset_id)
            )
        """)

        # Evidence vault
        conn.execute("""
            CREATE TABLE IF NOT EXISTS evidence_records (
                record_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                framework TEXT NOT NULL,
                control_id TEXT NOT NULL,
                control_description TEXT,
                status TEXT,
                resource_id TEXT,
                resource_type TEXT,
                resource_name TEXT,
                evidence_payload TEXT,
                collected_at REAL,
                scan_id TEXT,
                prev_hash TEXT,
                record_hash TEXT,
                signature TEXT,
                notes TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_evidence_tenant ON evidence_records(tenant_id, collected_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_evidence_control ON evidence_records(tenant_id, framework, control_id)")

        # Workflow integrations
        conn.execute("""
            CREATE TABLE IF NOT EXISTS workflow_integrations (
                integration_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                type TEXT,
                name TEXT,
                config TEXT,
                enabled INTEGER DEFAULT 1,
                created_at REAL,
                last_used REAL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS workflow_tickets (
                ticket_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                integration_id TEXT,
                integration_type TEXT,
                external_ticket_id TEXT,
                external_url TEXT,
                finding_id TEXT,
                finding_title TEXT,
                finding_severity TEXT,
                asset_id TEXT,
                asset_name TEXT,
                state TEXT,
                sync_direction TEXT,
                last_synced_at REAL,
                created_at REAL,
                updated_at REAL,
                payload_snapshot TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tickets_tenant ON workflow_tickets(tenant_id, created_at DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tickets_finding ON workflow_tickets(tenant_id, finding_id)")

        # Kill chain
        conn.execute("""
            CREATE TABLE IF NOT EXISTS kill_chain_paths (
                path_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                source_asset_id TEXT,
                source_asset_name TEXT,
                target_asset_id TEXT,
                target_asset_name TEXT,
                target_tier TEXT,
                hops_json TEXT,
                path_probability REAL,
                path_length INTEGER,
                kill_chain_phases_json TEXT,
                risk_score REAL,
                created_at REAL,
                summary TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_kc_tenant ON kill_chain_paths(tenant_id, risk_score DESC)")

        # Multi-account
        conn.execute("""
            CREATE TABLE IF NOT EXISTS multi_account_orgs (
                org_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                management_account_id TEXT,
                management_account_email TEXT,
                feature_set TEXT,
                last_discovery_at REAL,
                auto_onboard_enabled INTEGER DEFAULT 1,
                accounts_json TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS multi_account_accounts (
                account_id TEXT NOT NULL,
                tenant_id TEXT NOT NULL,
                account_name TEXT,
                email TEXT,
                status TEXT,
                joined_method TEXT,
                joined_timestamp REAL,
                parent_id TEXT,
                parent_org_id TEXT,
                criticality TEXT,
                role_arn TEXT,
                last_discovered_at REAL,
                last_scanned_at REAL,
                resource_count INTEGER DEFAULT 0,
                findings_count INTEGER DEFAULT 0,
                critical_findings_count INTEGER DEFAULT 0,
                posture_score REAL DEFAULT 0,
                compliance_score REAL DEFAULT 0,
                is_management INTEGER DEFAULT 0,
                PRIMARY KEY (tenant_id, account_id)
            )
        """)

        # Fix plans
        conn.execute("""
            CREATE TABLE IF NOT EXISTS fix_plans (
                plan_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                budget_hours REAL,
                used_hours REAL,
                remaining_hours REAL,
                total_risk_reduction REAL,
                selected_json TEXT,
                skipped_json TEXT,
                quick_wins_json TEXT,
                created_at REAL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_plans_tenant ON fix_plans(tenant_id, created_at DESC)")


# ─────────────────────────────────────────────────────────────────────────
# Drift Detection persistence
# ─────────────────────────────────────────────────────────────────────────
def save_drift_event(tenant_id: str, event: dict) -> None:
    with _lock, get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO drift_events
            (event_id, tenant_id, asset_id, asset_type, asset_name, drift_type,
             field_path, old_value, new_value, risk_weight, severity, timestamp,
             scan_id, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            event.get("event_id", str(uuid4())),
            tenant_id,
            event.get("asset_id", ""),
            event.get("asset_type", ""),
            event.get("asset_name", ""),
            event.get("drift_type", ""),
            event.get("field_path"),
            json.dumps(event.get("old_value")) if event.get("old_value") is not None else None,
            json.dumps(event.get("new_value")) if event.get("new_value") is not None else None,
            event.get("risk_weight", 0),
            event.get("severity", "info"),
            event.get("timestamp", time.time()),
            event.get("scan_id"),
            event.get("notes", ""),
        ))


def load_drift_events(tenant_id: str, limit: int = 5000) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM drift_events WHERE tenant_id = ? ORDER BY timestamp DESC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            if d.get("old_value"):
                try: d["old_value"] = json.loads(d["old_value"])
                except: pass
            if d.get("new_value"):
                try: d["new_value"] = json.loads(d["new_value"])
                except: pass
            out.append(d)
        return out


def save_drift_baseline(tenant_id: str, asset_id: str, state: dict) -> None:
    with _lock, get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO drift_baselines
            (tenant_id, asset_id, asset_type, asset_name, config, state_hash, timestamp, scan_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            tenant_id, asset_id,
            state.get("asset_type", ""),
            state.get("asset_name", ""),
            json.dumps(state.get("config", {}), default=str),
            state.get("state_hash", ""),
            state.get("timestamp", time.time()),
            state.get("scan_id"),
        ))


def load_drift_baselines(tenant_id: str) -> dict[str, dict]:
    """Returns asset_id -> state dict."""
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM drift_baselines WHERE tenant_id = ?",
            (tenant_id,),
        ).fetchall()
        out = {}
        for r in rows:
            d = dict(r)
            try:
                d["config"] = json.loads(d.get("config", "{}"))
            except Exception:
                d["config"] = {}
            out[d["asset_id"]] = d
        return out


# ─────────────────────────────────────────────────────────────────────────
# Evidence Vault persistence
# ─────────────────────────────────────────────────────────────────────────
def save_evidence_record(tenant_id: str, rec: dict) -> None:
    with _lock, get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO evidence_records
            (record_id, tenant_id, framework, control_id, control_description,
             status, resource_id, resource_type, resource_name, evidence_payload,
             collected_at, scan_id, prev_hash, record_hash, signature, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            rec.get("record_id", str(uuid4())),
            tenant_id,
            rec.get("framework", ""),
            rec.get("control_id", ""),
            rec.get("control_description", ""),
            rec.get("status", "pass"),
            rec.get("resource_id", ""),
            rec.get("resource_type", ""),
            rec.get("resource_name", ""),
            json.dumps(rec.get("evidence_payload", {}), default=str),
            rec.get("collected_at", time.time()),
            rec.get("scan_id"),
            rec.get("prev_hash", "0"*64),
            rec.get("record_hash", ""),
            rec.get("signature", ""),
            rec.get("notes", ""),
        ))


def load_evidence_records(tenant_id: str, limit: int = 10000) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM evidence_records WHERE tenant_id = ? ORDER BY collected_at ASC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["evidence_payload"] = json.loads(d.get("evidence_payload", "{}"))
            except Exception:
                d["evidence_payload"] = {}
            out.append(d)
        return out


# ─────────────────────────────────────────────────────────────────────────
# Workflow persistence
# ─────────────────────────────────────────────────────────────────────────
def save_integration(tenant_id: str, integ: dict) -> None:
    with _lock, get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO workflow_integrations
            (integration_id, tenant_id, type, name, config, enabled, created_at, last_used)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            integ.get("integration_id", str(uuid4())),
            tenant_id,
            integ.get("type", ""),
            integ.get("name", ""),
            json.dumps(integ.get("config", {}), default=str),
            1 if integ.get("enabled", True) else 0,
            integ.get("created_at", time.time()),
            integ.get("last_used", 0),
        ))


def load_integrations(tenant_id: str) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM workflow_integrations WHERE tenant_id = ?",
            (tenant_id,),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["config"] = json.loads(d.get("config", "{}"))
            except Exception:
                d["config"] = {}
            d["enabled"] = bool(d.get("enabled", 1))
            out.append(d)
        return out


def save_ticket(tenant_id: str, ticket: dict) -> None:
    with _lock, get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO workflow_tickets
            (ticket_id, tenant_id, integration_id, integration_type,
             external_ticket_id, external_url, finding_id, finding_title,
             finding_severity, asset_id, asset_name, state, sync_direction,
             last_synced_at, created_at, updated_at, payload_snapshot)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            ticket.get("ticket_id", str(uuid4())),
            tenant_id,
            ticket.get("integration_id", ""),
            ticket.get("integration_type", ""),
            ticket.get("external_ticket_id"),
            ticket.get("external_url"),
            ticket.get("finding_id", ""),
            ticket.get("finding_title", ""),
            ticket.get("finding_severity", ""),
            ticket.get("asset_id", ""),
            ticket.get("asset_name", ""),
            ticket.get("state", "open"),
            ticket.get("sync_direction", "outbound"),
            ticket.get("last_synced_at", time.time()),
            ticket.get("created_at", time.time()),
            ticket.get("updated_at", time.time()),
            json.dumps(ticket.get("payload_snapshot", {}), default=str),
        ))


def load_tickets(tenant_id: str, limit: int = 5000) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM workflow_tickets WHERE tenant_id = ? ORDER BY created_at DESC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["payload_snapshot"] = json.loads(d.get("payload_snapshot", "{}"))
            except Exception:
                d["payload_snapshot"] = {}
            out.append(d)
        return out


# ─────────────────────────────────────────────────────────────────────────
# Kill chain persistence
# ─────────────────────────────────────────────────────────────────────────
def save_kill_chain_path(tenant_id: str, path: dict) -> None:
    with _lock, get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO kill_chain_paths
            (path_id, tenant_id, source_asset_id, source_asset_name,
             target_asset_id, target_asset_name, target_tier, hops_json,
             path_probability, path_length, kill_chain_phases_json,
             risk_score, created_at, summary)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            path.get("path_id", str(uuid4())),
            tenant_id,
            path.get("source_asset_id", ""),
            path.get("source_asset_name", ""),
            path.get("target_asset_id", ""),
            path.get("target_asset_name", ""),
            path.get("target_tier", ""),
            json.dumps(path.get("hops", []), default=str),
            path.get("path_probability", 0),
            path.get("path_length", 0),
            json.dumps(path.get("kill_chain_phases", [])),
            path.get("risk_score", 0),
            path.get("created_at", time.time()),
            path.get("summary", ""),
        ))


def load_kill_chain_paths(tenant_id: str, limit: int = 500) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM kill_chain_paths WHERE tenant_id = ? ORDER BY risk_score DESC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["hops"] = json.loads(d.get("hops_json", "[]"))
            except Exception:
                d["hops"] = []
            try:
                d["kill_chain_phases"] = json.loads(d.get("kill_chain_phases_json", "[]"))
            except Exception:
                d["kill_chain_phases"] = []
            out.append(d)
        return out


# ─────────────────────────────────────────────────────────────────────────
# Multi-account persistence
# ─────────────────────────────────────────────────────────────────────────
def save_org(tenant_id: str, org: dict) -> None:
    with _lock, get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO multi_account_orgs
            (org_id, tenant_id, management_account_id, management_account_email,
             feature_set, last_discovery_at, auto_onboard_enabled, accounts_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            org.get("org_id", str(uuid4())),
            tenant_id,
            org.get("management_account_id", ""),
            org.get("management_account_email", ""),
            org.get("feature_set", "ALL"),
            org.get("last_discovery_at", time.time()),
            1 if org.get("auto_onboard_enabled", True) else 0,
            json.dumps(org.get("accounts", []), default=str),
        ))


def load_orgs(tenant_id: str) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM multi_account_orgs WHERE tenant_id = ?",
            (tenant_id,),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["accounts"] = json.loads(d.get("accounts_json", "[]"))
            except Exception:
                d["accounts"] = []
            d["auto_onboard_enabled"] = bool(d.get("auto_onboard_enabled", 1))
            out.append(d)
        return out


def save_account(tenant_id: str, acct: dict) -> None:
    with _lock, get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO multi_account_accounts
            (account_id, tenant_id, account_name, email, status, joined_method,
             joined_timestamp, parent_id, parent_org_id, criticality, role_arn,
             last_discovered_at, last_scanned_at, resource_count, findings_count,
             critical_findings_count, posture_score, compliance_score, is_management)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            acct.get("account_id", ""),
            tenant_id,
            acct.get("account_name", ""),
            acct.get("email", ""),
            acct.get("status", "ACTIVE"),
            acct.get("joined_method", "CREATED"),
            acct.get("joined_timestamp", time.time()),
            acct.get("parent_id", ""),
            acct.get("parent_org_id", ""),
            acct.get("criticality", "production"),
            acct.get("role_arn", ""),
            acct.get("last_discovered_at", time.time()),
            acct.get("last_scanned_at", 0),
            acct.get("resource_count", 0),
            acct.get("findings_count", 0),
            acct.get("critical_findings_count", 0),
            acct.get("posture_score", 0),
            acct.get("compliance_score", 0),
            1 if acct.get("is_management", False) else 0,
        ))


def load_accounts(tenant_id: str) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM multi_account_accounts WHERE tenant_id = ?",
            (tenant_id,),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["is_management"] = bool(d.get("is_management", 0))
            out.append(d)
        return out


# ─────────────────────────────────────────────────────────────────────────
# Fix plans persistence
# ─────────────────────────────────────────────────────────────────────────
def save_fix_plan(tenant_id: str, plan: dict) -> None:
    with _lock, get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO fix_plans
            (plan_id, tenant_id, budget_hours, used_hours, remaining_hours,
             total_risk_reduction, selected_json, skipped_json, quick_wins_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            plan.get("plan_id", str(uuid4())),
            tenant_id,
            plan.get("budget_hours", 0),
            plan.get("used_hours", 0),
            plan.get("remaining_hours", 0),
            plan.get("total_risk_reduction", 0),
            json.dumps(plan.get("selected_findings", []), default=str),
            json.dumps(plan.get("skipped_findings", []), default=str),
            json.dumps(plan.get("quick_wins", []), default=str),
            plan.get("created_at", time.time()),
        ))


def load_fix_plans(tenant_id: str, limit: int = 100) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM fix_plans WHERE tenant_id = ? ORDER BY created_at DESC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["selected_findings"] = json.loads(d.get("selected_json", "[]"))
            except Exception:
                d["selected_findings"] = []
            try:
                d["skipped_findings"] = json.loads(d.get("skipped_json", "[]"))
            except Exception:
                d["skipped_findings"] = []
            try:
                d["quick_wins"] = json.loads(d.get("quick_wins_json", "[]"))
            except Exception:
                d["quick_wins"] = []
            out.append(d)
        return out
