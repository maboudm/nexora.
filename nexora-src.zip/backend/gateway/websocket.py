"""
WebSocket Real-time Alert Server.

Streams security alerts to connected dashboard clients in real-time.
Alerts come from:
  - Real-time Detection Engine (CloudTrail detections)
  - Threat Intel Engine (IOC matches)
  - CWPP Agent (runtime threats)
  - Event Bus (finding.created, scan.completed, etc.)

Architecture:
  Client ──WS──> WebSocket Server ──subscribe──> Event Bus
                                                ↓
  Client ←─WS─── WebSocket Server ←──alert───── Event Bus

Protocol:
  Client → Server: {"action": "subscribe", "channels": ["detections", "threat_intel", "cwpp"]}
  Server → Client: {"type": "alert", "channel": "detections", "data": {...}}
  Server → Client: {"type": "stats", "data": {...}} (every 10s)
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from dataclasses import asdict
from typing import Any, Optional

from fastapi import WebSocket, WebSocketDisconnect

logger = logging.getLogger(__name__)


class WebSocketManager:
    """Manages WebSocket connections and broadcasts alerts.

    Each connection subscribes to channels. When an alert is published
    to a channel, all subscribed clients receive it in real-time.

    Channels:
      - detections: real-time CloudTrail detection alerts
      - threat_intel: IOC match alerts
      - cwpp: runtime workload threats
      - findings: new security findings
      - scans: scan lifecycle events (started, completed, failed)
      - compliance: compliance drift alerts
      - system: system health + stats (broadcast every 10s)
    """

    def __init__(self):
        # client_id → {websocket, channels, tenant_id, user_id}
        self._clients: dict[str, dict[str, Any]] = {}
        self._lock = asyncio.Lock()
        self._stats = {
            "total_connections": 0,
            "current_connections": 0,
            "total_messages_sent": 0,
            "total_alerts_broadcast": 0,
        }

    async def connect(
        self,
        websocket: WebSocket,
        tenant_id: str,
        user_id: str,
        channels: Optional[list[str]] = None,
    ) -> str:
        """Accept a new WebSocket connection."""
        await websocket.accept()
        client_id = str(uuid.uuid4())
        async with self._lock:
            self._clients[client_id] = {
                "websocket": websocket,
                "channels": set(channels or ["detections", "threat_intel", "cwpp", "findings", "scans"]),
                "tenant_id": tenant_id,
                "user_id": user_id,
                "connected_at": int(time.time() * 1000),
            }
            self._stats["total_connections"] += 1
            self._stats["current_connections"] = len(self._clients)
        logger.info(f"WebSocket client {client_id[:8]} connected (tenant: {tenant_id})")
        # Send welcome message
        await websocket.send_json({
            "type": "connected",
            "client_id": client_id,
            "channels": list(self._clients[client_id]["channels"]),
            "timestamp": int(time.time() * 1000),
        })
        return client_id

    async def disconnect(self, client_id: str) -> None:
        """Disconnect a client."""
        async with self._lock:
            self._clients.pop(client_id, None)
            self._stats["current_connections"] = len(self._clients)
        logger.info(f"WebSocket client {client_id[:8]} disconnected")

    async def subscribe(self, client_id: str, channels: list[str]) -> None:
        """Subscribe a client to additional channels."""
        async with self._lock:
            client = self._clients.get(client_id)
            if client:
                client["channels"].update(channels)

    async def unsubscribe(self, client_id: str, channels: list[str]) -> None:
        """Unsubscribe a client from channels."""
        async with self._lock:
            client = self._clients.get(client_id)
            if client:
                client["channels"].difference_update(channels)

    async def broadcast(self, channel: str, data: dict[str, Any], tenant_id: Optional[str] = None) -> int:
        """Broadcast a message to all clients subscribed to a channel.

        Args:
            channel: The channel to broadcast on
            data: The message payload
            tenant_id: If set, only broadcast to clients of this tenant

        Returns:
            Number of clients the message was sent to
        """
        message = {
            "type": "alert",
            "channel": channel,
            "data": data,
            "timestamp": int(time.time() * 1000),
        }
        sent_count = 0
        disconnected = []

        async with self._lock:
            clients = list(self._clients.items())

        for client_id, client in clients:
            # Tenant isolation
            if tenant_id and client["tenant_id"] != tenant_id:
                continue
            # Channel subscription
            if channel not in client["channels"]:
                continue
            try:
                await client["websocket"].send_json(message)
                sent_count += 1
            except Exception as e:
                logger.warning(f"Failed to send to client {client_id[:8]}: {e}")
                disconnected.append(client_id)

        # Clean up disconnected clients
        for cid in disconnected:
            await self.disconnect(cid)

        async with self._lock:
            self._stats["total_messages_sent"] += sent_count
            if channel != "system":
                self._stats["total_alerts_broadcast"] += 1

        return sent_count

    async def send_to_client(self, client_id: str, message: dict[str, Any]) -> bool:
        """Send a message to a specific client."""
        async with self._lock:
            client = self._clients.get(client_id)
        if not client:
            return False
        try:
            await client["websocket"].send_json(message)
            return True
        except Exception:
            await self.disconnect(client_id)
            return False

    async def handle_client(self, client_id: str, websocket: WebSocket) -> None:
        """Handle incoming messages from a client."""
        try:
            while True:
                message = await websocket.receive_json()
                action = message.get("action")
                if action == "subscribe":
                    channels = message.get("channels", [])
                    await self.subscribe(client_id, channels)
                    await websocket.send_json({
                        "type": "subscribed",
                        "channels": list(self._clients.get(client_id, {}).get("channels", set())),
                    })
                elif action == "unsubscribe":
                    channels = message.get("channels", [])
                    await self.unsubscribe(client_id, channels)
                    await websocket.send_json({
                        "type": "unsubscribed",
                        "channels": list(self._clients.get(client_id, {}).get("channels", set())),
                    })
                elif action == "ping":
                    await websocket.send_json({"type": "pong", "timestamp": int(time.time() * 1000)})
                elif action == "stats":
                    await websocket.send_json({"type": "stats", "data": self.get_stats()})
        except WebSocketDisconnect:
            await self.disconnect(client_id)
        except Exception as e:
            logger.error(f"WebSocket error for client {client_id[:8]}: {e}")
            await self.disconnect(client_id)

    def get_stats(self) -> dict[str, Any]:
        return {
            **self._stats,
            "channels": list({ch for c in self._clients.values() for ch in c["channels"]}),
        }

    def get_client_count(self) -> int:
        return len(self._clients)


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_manager: Optional[WebSocketManager] = None


def get_websocket_manager() -> WebSocketManager:
    global _global_manager
    if _global_manager is None:
        _global_manager = WebSocketManager()
    return _global_manager
