"""
SQLite Persistence Layer — survives gateway restarts.

Since PostgreSQL isn't available in this environment, we use SQLite
for durable storage. This ensures scans, findings, and audit logs
persist across gateway restarts.

Tables:
  - users (login credentials)
  - scans (scan records + findings)
  - audit_entries (immutable hash-chained audit log)
  - detections (real-time detection alerts)
  - websocket_clients (track active WS connections)
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from typing import Any, Optional

DB_PATH = "/home/z/my-project/db/sentinel.db"

_lock = threading.Lock()


@contextmanager
def get_db():
    """Get a SQLite connection with row factory."""
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    """Initialize the database schema."""
    with get_db() as conn:
        # Users
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                email TEXT NOT NULL,
                name TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT DEFAULT 'viewer',
                status TEXT DEFAULT 'active',
                created_at INTEGER,
                last_login INTEGER,
                UNIQUE(tenant_id, email)
            )
        """)
        # Scans
        conn.execute("""
            CREATE TABLE IF NOT EXISTS scans (
                scan_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                workspace_id TEXT,
                cloud_account_id TEXT,
                status TEXT DEFAULT 'queued',
                started_at INTEGER,
                completed_at INTEGER,
                total_assets INTEGER DEFAULT 0,
                total_findings INTEGER DEFAULT 0,
                findings_by_severity TEXT,
                assets_json TEXT,
                findings_json TEXT,
                attack_graph_json TEXT,
                error TEXT,
                created_at INTEGER DEFAULT (strftime('%s','now') * 1000)
            )
        """)
        # Cloud accounts
        conn.execute("""
            CREATE TABLE IF NOT EXISTS cloud_accounts (
                account_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                workspace_id TEXT,
                provider TEXT NOT NULL,
                name TEXT NOT NULL,
                external_id TEXT,
                credential_type TEXT,
                role_arn TEXT,
                regions TEXT,
                status TEXT DEFAULT 'active',
                last_scan_at INTEGER,
                created_at INTEGER,
                updated_at INTEGER DEFAULT 0
            )
        """)
        # Audit entries (immutable)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_entries (
                entry_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                actor_type TEXT,
                actor_id TEXT,
                actor_ip TEXT,
                category TEXT,
                action TEXT,
                outcome TEXT,
                severity TEXT,
                target_type TEXT,
                target_id TEXT,
                target_name TEXT,
                description TEXT,
                details TEXT,
                sequence INTEGER,
                prev_hash TEXT,
                entry_hash TEXT,
                signature TEXT
            )
        """)
        # Detections
        conn.execute("""
            CREATE TABLE IF NOT EXISTS detections (
                detection_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                rule_id TEXT,
                rule_name TEXT,
                severity TEXT,
                category TEXT,
                description TEXT,
                source_ip TEXT,
                detected_at INTEGER,
                data_json TEXT
            )
        """)
        # Reports
        conn.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                report_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                report_type TEXT,
                format TEXT,
                title TEXT,
                file_path TEXT,
                file_size_bytes INTEGER,
                generated_at INTEGER,
                generated_by TEXT
            )
        """)
        # Indexes
        conn.execute("CREATE INDEX IF NOT EXISTS idx_scans_tenant ON scans(tenant_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_tenant ON audit_entries(tenant_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_sequence ON audit_entries(tenant_id, sequence)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_detections_tenant ON detections(tenant_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_detections_severity ON detections(severity)")

        # Migration: add updated_at column if missing (for older DBs)
        try:
            conn.execute("ALTER TABLE cloud_accounts ADD COLUMN updated_at INTEGER DEFAULT 0")
        except sqlite3.OperationalError:
            pass  # Column already exists


def seed_demo_data() -> None:
    """Seed demo user + cloud account if not exists.

    NOTE: app.py's seed_demo_data() also handles this with DETERMINISTIC UUIDs
    (critical for JWT token validity across process restarts in CLI gateway
    mode). This function is a fallback for direct DB initialization without
    going through the gateway. It is intentionally a no-op if app.py has
    already seeded the data.
    """
    import hashlib
    with get_db() as conn:
        # Check if demo user exists — if so, do nothing (app.py already seeded)
        row = conn.execute("SELECT user_id FROM users WHERE email = ?", ("admin@nexora.io",)).fetchone()
        if row:
            return
        # Only seed if DB is completely empty (standalone init without gateway)
        password_hash = hashlib.sha256(b"nexora-salt:admin123").hexdigest()
        user_id = "00000000-0000-0000-0000-000000000001"
        conn.execute(
            "INSERT INTO users (user_id, tenant_id, email, name, password_hash, role, status, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (user_id, "org-default", "admin@nexora.io", "Demo Admin", password_hash, "owner", "active", int(time.time() * 1000)),
        )
        # Create demo cloud account with deterministic ID
        conn.execute(
            "INSERT INTO cloud_accounts (account_id, tenant_id, workspace_id, provider, name, external_id, credential_type, role_arn, regions, status, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            ("00000000-0000-0000-0000-000000000002", "org-default",
             "00000000-0000-0000-0000-000000000003", "aws", "Production AWS",
             "123456789012", "assume_role",
             "arn:aws:iam::123456789012:role/NexoraScanner",
             '["us-east-1", "us-west-2"]', "active", int(time.time() * 1000)),
        )


# ═══════════════════════════════════════════════════════════════
# User operations
# ═══════════════════════════════════════════════════════════════

def get_user_by_email(email: str) -> Optional[dict]:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        return dict(row) if row else None


def get_user(user_id: str) -> Optional[dict]:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
        return dict(row) if row else None


def update_last_login(user_id: str) -> None:
    with get_db() as conn:
        conn.execute("UPDATE users SET last_login = ? WHERE user_id = ?", (int(time.time() * 1000), user_id))


def list_users(tenant_id: str) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM users WHERE tenant_id = ? ORDER BY created_at", (tenant_id,)).fetchall()
        return [dict(r) for r in rows]


def create_user(tenant_id: str, email: str, name: str, password_hash: str, role: str = "viewer") -> dict:
    user_id = str(uuid.uuid4())
    with get_db() as conn:
        conn.execute(
            "INSERT INTO users (user_id, tenant_id, email, name, password_hash, role, status, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (user_id, tenant_id, email, name, password_hash, role, "active", int(time.time() * 1000)),
        )
    return get_user(user_id)  # type: ignore


# ═══════════════════════════════════════════════════════════════
# Cloud account operations
# ═══════════════════════════════════════════════════════════════

def list_cloud_accounts(tenant_id: str) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM cloud_accounts WHERE tenant_id = ?", (tenant_id,)).fetchall()
        return [dict(r) for r in rows]


def create_cloud_account(tenant_id: str, provider: str, name: str, external_id: str,
                         credential_type: str, regions: list[str]) -> dict:
    account_id = str(uuid.uuid4())
    with get_db() as conn:
        conn.execute(
            "INSERT INTO cloud_accounts (account_id, tenant_id, workspace_id, provider, name, external_id, "
            "credential_type, regions, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (account_id, tenant_id, str(uuid.uuid4()), provider, name, external_id,
             credential_type, json.dumps(regions), "active", int(time.time() * 1000)),
        )
    with get_db() as conn:
        row = conn.execute("SELECT * FROM cloud_accounts WHERE account_id = ?", (account_id,)).fetchone()
        return dict(row)  # type: ignore


# ═══════════════════════════════════════════════════════════════
# Scan operations
# ═══════════════════════════════════════════════════════════════

def save_scan(scan: dict) -> None:
    with get_db() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO scans "
            "(scan_id, tenant_id, workspace_id, cloud_account_id, status, started_at, completed_at, "
            "total_assets, total_findings, findings_by_severity, assets_json, findings_json, attack_graph_json, error) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                scan["scan_id"], scan["tenant_id"], scan.get("workspace_id"),
                scan.get("cloud_account_id"), scan["status"],
                scan.get("started_at"), scan.get("completed_at"),
                scan.get("total_assets", 0), scan.get("total_findings", 0),
                json.dumps(scan.get("findings_by_severity", {})),
                json.dumps(scan.get("assets", [])),
                json.dumps(scan.get("findings", [])),
                json.dumps(scan.get("attack_graph")),
                scan.get("error"),
            ),
        )


def get_scan(scan_id: str, tenant_id: str) -> Optional[dict]:
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM scans WHERE scan_id = ? AND tenant_id = ?",
            (scan_id, tenant_id),
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["findings_by_severity"] = json.loads(d.get("findings_by_severity") or "{}")
        d["assets"] = json.loads(d.get("assets_json") or "[]")
        d["findings"] = json.loads(d.get("findings_json") or "[]")
        d["attack_graph"] = json.loads(d.get("attack_graph_json") or "null")
        return d


def list_scans(tenant_id: str, limit: int = 50) -> list[dict]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT scan_id, tenant_id, cloud_account_id, status, started_at, completed_at, "
            "total_assets, total_findings, findings_by_severity, error FROM scans "
            "WHERE tenant_id = ? ORDER BY COALESCE(started_at, 0) DESC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["findings_by_severity"] = json.loads(d.get("findings_by_severity") or "{}")
            result.append(d)
        return result


def get_latest_scan(tenant_id: str) -> Optional[dict]:
    scans = list_scans(tenant_id, 1)
    if not scans:
        return None
    return get_scan(scans[0]["scan_id"], tenant_id)


# ═══════════════════════════════════════════════════════════════
# Detection operations
# ═══════════════════════════════════════════════════════════════

def save_detection(detection: dict) -> None:
    with get_db() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO detections "
            "(detection_id, tenant_id, rule_id, rule_name, severity, category, description, source_ip, detected_at, data_json) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                detection["detection_id"], detection.get("tenant_id", ""),
                detection.get("rule_id"), detection.get("rule_name"),
                detection.get("severity"), detection.get("category"),
                detection.get("description"), detection.get("source_ip"),
                detection.get("detected_at"), json.dumps(detection, default=str),
            ),
        )


def list_detections(tenant_id: str, severity: Optional[str] = None, limit: int = 100) -> list[dict]:
    with get_db() as conn:
        if severity:
            rows = conn.execute(
                "SELECT data_json FROM detections WHERE tenant_id = ? AND severity = ? "
                "ORDER BY detected_at DESC LIMIT ?",
                (tenant_id, severity, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT data_json FROM detections WHERE tenant_id = ? "
                "ORDER BY detected_at DESC LIMIT ?",
                (tenant_id, limit),
            ).fetchall()
        return [json.loads(r["data_json"]) for r in rows]


# Initialize on import
init_db()
seed_demo_data()
