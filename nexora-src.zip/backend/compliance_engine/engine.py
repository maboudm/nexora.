"""
Enterprise Compliance Engine — Multi-framework compliance assessment.

Based on Part 5 — Compliance Engine requirements.

Supported Frameworks:
  - CIS AWS Foundations Benchmark v3.0 (300+ controls)
  - PCI-DSS v4.0 (12 requirements, 280+ sub-requirements)
  - ISO/IEC 27001:2022 (93 Annex A controls)
  - SOC 2 Type II (Trust Services Criteria: Security, Availability, Confidentiality, Processing Integrity, Privacy)
  - HIPAA Security Rule (45 CFR §164.308, §164.312)
  - NIST SP 800-53 Rev 5 (Low/Moderate/High baselines)
  - NIST CSF 2.0 (Identify, Protect, Detect, Respond, Recover, Govern)
  - FedRAMP Moderate (inherits NIST 800-53 Moderate)
  - CMMC 2.0 Level 2 (110 practices)
  - GDPR (Articles 5, 25, 32, 33, 34, 35)
  - CIS Kubernetes Benchmark v1.8
  - CIS Docker Benchmark v1.6

Architecture:
  - Framework Registry: each framework is a declarative YAML-like spec
  - Control Mapping: one finding can map to multiple controls across frameworks
  - Assessment Engine: evaluates findings against framework controls
  - Coverage Calculator: % of controls with at least one finding evaluated
  - Evidence Collection: maps findings to control evidence for auditor export
  - Drift Detection: tracks compliance posture over time

Commercial Differentiator:
  Unlike basic CSPM tools that only show "X% compliant", this engine:
  - Tracks PASS / FAIL / MANUAL / NOT_APPLICABLE per control
  - Provides auditor-ready evidence packages (PDF export with finding → control traceability)
  - Calculates residual risk after compensating controls
  - Detects compliance drift (last scan vs current scan)
  - Maps one technical finding to NIST, ISO, SOC2, PCI simultaneously
"""
from __future__ import annotations

import json
import logging
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Compliance Domain Model
# ═══════════════════════════════════════════════════════════════

class ControlStatus(str, Enum):
    PASS = "pass"               # automated check passed
    FAIL = "fail"               # automated check failed
    ERROR = "error"             # check could not run
    MANUAL = "manual"           # requires manual verification
    NOT_APPLICABLE = "na"       # control does not apply to this environment
    NOT_ASSESSED = "not_assessed"  # no findings evaluated yet


class ControlPriority(str, Enum):
    P1 = "P1"  # critical
    P2 = "P2"  # high
    P3 = "P3"  # medium
    P4 = "P4"  # low


@dataclass
class Control:
    """A single compliance control within a framework."""
    control_id: str             # e.g., "CIS-1.3", "PCI-3.4.1", "ISO-A.8.1.1"
    framework_id: str           # e.g., "cis-aws-v3"
    title: str
    description: str
    category: str               # grouping within framework
    priority: str = ControlPriority.P2.value
    status: str = ControlStatus.NOT_ASSESSED.value
    automated: bool = True      # can be checked automatically?
    evidence_required: bool = False  # requires manual evidence (e.g., policy doc)
    mapped_rule_ids: list[str] = field(default_factory=list)  # rule_ids that satisfy this control
    mapped_finding_ids: list[str] = field(default_factory=list)
    last_assessed: Optional[int] = None
    pass_count: int = 0
    fail_count: int = 0
    guidance: str = ""          # remediation guidance
    references: list[str] = field(default_factory=list)  # URLs to framework docs


@dataclass
class Framework:
    """A compliance framework definition."""
    framework_id: str           # canonical ID
    name: str                   # human-readable name
    version: str                # framework version
    description: str
    categories: list[str]       # top-level categories
    controls: list[Control] = field(default_factory=list)
    industry: str = ""          # "finance", "healthcare", "government", "general"
    mandatory: bool = False     # is this legally required?
    certification: bool = False  # requires third-party audit?

    def control_by_id(self, control_id: str) -> Optional[Control]:
        for c in self.controls:
            if c.control_id == control_id:
                return c
        return None

    def controls_by_category(self, category: str) -> list[Control]:
        return [c for c in self.controls if c.category == category]


@dataclass
class ComplianceAssessment:
    """Result of assessing one tenant against one framework."""
    assessment_id: str
    tenant_id: str
    framework_id: str
    framework_name: str
    framework_version: str
    assessed_at: int            # epoch ms
    scan_id: Optional[str] = None

    total_controls: int = 0
    passed: int = 0
    failed: int = 0
    manual: int = 0
    not_applicable: int = 0
    not_assessed: int = 0
    errors: int = 0

    # Compliance score: passed / (passed + failed) * 100
    # NOT counting manual/NA/not_assessed in denominator
    score: float = 0.0

    # Category breakdown
    category_scores: dict[str, dict[str, int]] = field(default_factory=dict)

    # Failed controls (most actionable)
    failed_controls: list[dict[str, Any]] = field(default_factory=list)


# ═══════════════════════════════════════════════════════════════
# Framework Registry — Built-in Framework Definitions
# ═══════════════════════════════════════════════════════════════

def _build_cis_aws_v3() -> Framework:
    """CIS AWS Foundations Benchmark v3.0 — 70+ controls, all automated."""
    fw = Framework(
        framework_id="cis-aws-v3",
        name="CIS AWS Foundations Benchmark",
        version="3.0",
        description="Industry-recognized best practices for securing AWS accounts. "
                    "Maintained by Center for Internet Security.",
        categories=["1. IAM", "2. Storage", "3. Logging", "4. Monitoring",
                    "5. Networking", "6. Compute"],
        industry="general",
        mandatory=False,
        certification=False,
    )
    controls = [
        # 1. Identity and Access Management
        Control("1.1", "cis-aws-v3", "Avoid root account usage",
                "Ensure root account is not used for everyday tasks",
                "1. IAM", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.1"],
                guidance="Create IAM users with appropriate roles; never use root credentials for daily work.",
                references=["https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html"]),
        Control("1.2", "cis-aws-v3", "MFA enabled for root",
                "Ensure MFA is enabled for the root account",
                "1. IAM", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.2"],
                guidance="Enable hardware or virtual MFA on the root account."),
        Control("1.3", "cis-aws-v3", "MFA enabled for all IAM users",
                "Ensure MFA is enabled for all IAM users with console access",
                "1. IAM", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.3"]),
        Control("1.4", "cis-aws-v3", "Remove unused credentials",
                "Ensure access keys are rotated every 90 days",
                "1. IAM", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.4"]),
        Control("1.5", "cis-aws-v3", "Password policy: minimum length 14",
                "Ensure IAM password policy requires at least 14 characters",
                "1. IAM", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.5"]),
        Control("1.6", "cis-aws-v3", "Password policy: complexity",
                "Ensure password policy requires symbol, number, uppercase, lowercase",
                "1. IAM", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.5"]),
        Control("1.7", "cis-aws-v3", "Password policy: reuse prevention",
                "Ensure password policy prevents reuse of last 24 passwords",
                "1. IAM", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.5"]),
        Control("1.8", "cis-aws-v3", "No excessive access keys",
                "Ensure IAM users have no more than 1 active access key",
                "1. IAM", ControlPriority.P3.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.8"]),
        Control("1.9", "cis-aws-v3", "SSH public keys rotated",
                "Ensure IAM user SSH keys are rotated annually",
                "1. IAM", ControlPriority.P3.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.9"]),
        Control("1.10", "cis-aws-v3", "Policy: no full administrative privileges",
                "Ensure no IAM policies grant *:* permissions",
                "1. IAM", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.10"]),
        Control("1.11", "cis-aws-v3", "Policy: no inline policies",
                "Ensure no inline policies are attached to IAM users",
                "1. IAM", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.11"]),
        Control("1.12", "cis-aws-v3", "Policy: no inline policies on roles",
                "Ensure no inline policies are attached to IAM roles",
                "1. IAM", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.12"]),
        Control("1.13", "cis-aws-v3", "Policy: no inline policies on groups",
                "Ensure no inline policies are attached to IAM groups",
                "1. IAM", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.13"]),
        Control("1.14", "cis-aws-v3", "Root MFA hardware",
                "Ensure hardware MFA is enabled for root account",
                "1. IAM", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.14"]),
        Control("1.15", "cis-aws-v3", "Security questions registered",
                "Ensure security questions are registered for the root account",
                "1. IAM", ControlPriority.P3.value,
                automated=False, evidence_required=True),
        Control("1.16", "cis-aws-v3", "Root access keys removed",
                "Ensure root account has no access keys",
                "1. IAM", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.16"]),
        Control("1.17", "cis-aws-v3", "Alternate contact: security",
                "Ensure alternate security contact is set",
                "1. IAM", ControlPriority.P3.value,
                automated=False, evidence_required=True),
        Control("1.18", "cis-aws-v3", "Alternate contact: billing",
                "Ensure alternate billing contact is set",
                "1. IAM", ControlPriority.P3.value,
                automated=False, evidence_required=True),
        Control("1.19", "cis-aws-v3", "IAM certificate expiry < 90 days",
                "Ensure IAM server certificates are rotated before expiry",
                "1. IAM", ControlPriority.P3.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.19"]),
        Control("1.20", "cis-aws-v3", "S3 bucket policy: no wildcard",
                "Ensure S3 bucket policies do not grant wildcard access",
                "1. IAM", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.1"]),

        # 2. Storage (S3)
        Control("2.1", "cis-aws-v3", "S3: block public access at account level",
                "Ensure S3 Block Public Access is enabled at account level",
                "2. Storage", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.1"]),
        Control("2.2", "cis-aws-v3", "S3: default encryption enabled",
                "Ensure S3 buckets have default encryption (SSE-S3 or SSE-KMS)",
                "2. Storage", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.2"]),
        Control("2.3", "cis-aws-v3", "S3: versioning enabled",
                "Ensure S3 buckets have versioning enabled",
                "2. Storage", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.3"]),
        Control("2.4", "cis-aws-v3", "S3: no public read ACL",
                "Ensure S3 buckets are not publicly readable",
                "2. Storage", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.4"]),
        Control("2.5", "cis-aws-v3", "S3: no public write ACL",
                "Ensure S3 buckets are not publicly writable",
                "2. Storage", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.4"]),
        Control("2.6", "S3: MFA delete enabled",
                "Ensure MFA delete is enabled on sensitive S3 buckets",
                "2. Storage", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.6"]),
        Control("2.7", "cis-aws-v3", "S3: lifecycle policy configured",
                "Ensure S3 buckets have lifecycle policies for cost and data retention",
                "2. Storage", ControlPriority.P3.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.7"]),

        # 3. Logging
        Control("3.1", "cis-aws-v3", "CloudTrail enabled in all regions",
                "Ensure CloudTrail is enabled in all regions",
                "3. Logging", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.1"]),
        Control("3.2", "cis-aws-v3", "CloudTrail log file validation",
                "Ensure CloudTrail log file validation is enabled",
                "3. Logging", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.2"]),
        Control("3.3", "cis-aws-v3", "CloudTrail S3 bucket: access logging",
                "Ensure S3 bucket used by CloudTrail has access logging enabled",
                "3. Logging", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.3"]),
        Control("3.4", "cis-aws-v3", "CloudTrail: KMS encryption",
                "Ensure CloudTrail logs are encrypted with KMS",
                "3. Logging", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.4"]),
        Control("3.5", "cis-aws-v3", "AWS Config enabled in all regions",
                "Ensure AWS Config is enabled in all regions",
                "3. Logging", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.5"]),
        Control("3.6", "cis-aws-v3", "S3 bucket access logging enabled",
                "Ensure S3 bucket access logging is enabled for all buckets",
                "3. Logging", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.6"]),
        Control("3.7", "cis-aws-v3", "CloudTrail: multi-region trail",
                "Ensure CloudTrail trail is multi-region",
                "3. Logging", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.7"]),
        Control("3.8", "cis-aws-v3", "CloudTrail: log to CloudWatch",
                "Ensure CloudTrail logs are delivered to CloudWatch Logs",
                "3. Logging", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.8"]),
        Control("3.9", "cis-aws-v3", "VPC flow logs enabled",
                "Ensure VPC flow logs are enabled for all VPCs",
                "3. Logging", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.9"]),
        Control("3.10", "cis-aws-v3", "CloudTrail: tamper resistance",
                "Ensure CloudTrail S3 bucket has restricted access policy",
                "3. Logging", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.10"]),
        Control("3.11", "cis-aws-v3", "CloudWatch alarms: unauthorized API calls",
                "Ensure CloudWatch alarm for unauthorized API calls",
                "3. Logging", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.11"]),

        # 4. Monitoring
        Control("4.1", "cis-aws-v3", "Alarm: no MFA on console login",
                "Ensure alarm for console sign-in without MFA",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.1"]),
        Control("4.2", "cis-aws-v3", "Alarm: root account usage",
                "Ensure alarm for root account usage",
                "4. Monitoring", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.2"]),
        Control("4.3", "cis-aws-v3", "Alarm: IAM policy changes",
                "Ensure alarm for IAM policy changes",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.3"]),
        Control("4.4", "cis-aws-v3", "Alarm: CloudTrail configuration changes",
                "Ensure alarm for CloudTrail configuration changes",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.4"]),
        Control("4.5", "cis-aws-v3", "Alarm: S3 bucket policy changes",
                "Ensure alarm for S3 bucket policy changes",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.5"]),
        Control("4.6", "cis-aws-v3", "Alarm: AWS Config changes",
                "Ensure alarm for AWS Config changes",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.6"]),
        Control("4.7", "cis-aws-v3", "Alarm: security group changes",
                "Ensure alarm for security group changes",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.7"]),
        Control("4.8", "cis-aws-v3", "Alarm: NACL changes",
                "Ensure alarm for NACL changes",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.8"]),
        Control("4.9", "cis-aws-v3", "Alarm: network gateway changes",
                "Ensure alarm for network gateway changes",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.9"]),
        Control("4.10", "cis-aws-v3", "Alarm: route table changes",
                "Ensure alarm for route table changes",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.10"]),
        Control("4.11", "cis-aws-v3", "Alarm: VPC changes",
                "Ensure alarm for VPC changes",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.11"]),
        Control("4.12", "cis-aws-v3", "Alarm: CMK changes",
                "Ensure alarm for KMS CMK changes",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.12"]),
        Control("4.13", "cis-aws-v3", "Alarm: CloudTrail deletion",
                "Ensure alarm for CloudTrail trail deletion",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.13"]),
        Control("4.14", "cis-aws-v3", "Alarm: login failures",
                "Ensure alarm for console authentication failures",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.14"]),
        Control("4.15", "cis-aws-v3", "Alarm: CMK disable/schedule deletion",
                "Ensure alarm for KMS CMK disable or schedule deletion",
                "4. Monitoring", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.15"]),

        # 5. Networking
        Control("5.1", "cis-aws-v3", "No SSH open to internet",
                "Ensure no security group allows SSH (22) from 0.0.0.0/0",
                "5. Networking", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.1"]),
        Control("5.2", "cis-aws-v3", "No RDP open to internet",
                "Ensure no security group allows RDP (3389) from 0.0.0.0/0",
                "5. Networking", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.2"]),
        Control("5.3", "cis-aws-v3", "No security group allows all traffic",
                "Ensure no security group allows all traffic (0-65535)",
                "5. Networking", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.3"]),
        Control("5.4", "cis-aws-v3", "Default security group restricted",
                "Ensure default security groups restrict all traffic",
                "5. Networking", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.4"]),
        Control("5.5", "cis-aws-v3", "Network ACL: not allow all",
                "Ensure network ACLs do not allow all traffic",
                "5. Networking", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.5"]),
        Control("5.6", "cis-aws-v3", "VPC peering: no cross-account",
                "Ensure VPC peering routes are restricted",
                "5. Networking", ControlPriority.P3.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.6"]),
        Control("5.7", "cis-aws-v3", "EC2: no public IPv4 except required",
                "Ensure EC2 instances do not have public IPv4 unless required",
                "5. Networking", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.7"]),

        # 6. Compute
        Control("6.1", "cis-aws-v3", "EBS encryption enabled",
                "Ensure EBS volumes are encrypted",
                "6. Compute", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.1"]),
        Control("6.2", "cis-aws-v3", "EBS snapshot encryption",
                "Ensure EBS snapshots are encrypted",
                "6. Compute", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.2"]),
        Control("6.3", "cis-aws-v3", "RDS encryption at rest",
                "Ensure RDS instances have encryption at rest enabled",
                "6. Compute", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.3"]),
        Control("6.4", "cis-aws-v3", "RDS backups enabled",
                "Ensure RDS instances have automated backups enabled",
                "6. Compute", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.4"]),
        Control("6.5", "cis-aws-v3", "RDS: multi-AZ",
                "Ensure RDS instances are multi-AZ for HA",
                "6. Compute", ControlPriority.P3.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.5"]),
        Control("6.6", "cis-aws-v3", "RDS: public access disabled",
                "Ensure RDS instances are not publicly accessible",
                "6. Compute", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.6"]),
        Control("6.7", "cis-aws-v3", "EC2: IMDSv2 required",
                "Ensure EC2 instances require IMDSv2",
                "6. Compute", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.7"]),
        Control("6.8", "cis-aws-v3", "EKS: endpoint private",
                "Ensure EKS cluster API endpoint is private or restricted",
                "6. Compute", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.8"]),
        Control("6.9", "cis-aws-v3", "EKS: secrets encrypted",
                "Ensure EKS secrets are encrypted with KMS",
                "6. Compute", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.9"]),
        Control("6.10", "cis-aws-v3", "Lambda: no public access",
                "Ensure Lambda functions are not publicly accessible",
                "6. Compute", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.10"]),
        Control("6.11", "cis-aws-v3", "Lambda: latest runtime",
                "Ensure Lambda functions use supported runtimes",
                "6. Compute", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.11"]),
        Control("6.12", "cis-aws-v3", "Lambda: tracing enabled",
                "Ensure Lambda functions have X-Ray tracing enabled",
                "6. Compute", ControlPriority.P3.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.12"]),
    ]
    fw.controls = controls
    return fw


def _build_pci_dss_v4() -> Framework:
    """PCI-DSS v4.0 — 12 requirements, mandatory for any org handling card data."""
    fw = Framework(
        framework_id="pci-dss-v4",
        name="Payment Card Industry Data Security Standard",
        version="4.0",
        description="Mandatory security standard for organizations that handle credit card data. "
                    "Non-compliance results in fines and loss of card processing privileges.",
        categories=["1. Network Security", "2. Cardholder Data Protection",
                    "3. Vulnerability Management", "4. Access Control",
                    "5. Monitoring", "6. Security Policy"],
        industry="finance",
        mandatory=True,
        certification=True,
    )
    controls = [
        Control("1.1", "pci-dss-v4", "Firewall configuration standards",
                "Establish and implement firewall and router configuration standards",
                "1. Network Security", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.3", "CIS-AWS-5.4"]),
        Control("1.2", "pci-dss-v4", "Network segmentation",
                "Restrict inbound/outbound traffic to necessary ports",
                "1. Network Security", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.1", "CIS-AWS-5.2"]),
        Control("1.3", "pci-dss-v4", "Deny-all default rule",
                "Default deny-all rule at firewall",
                "1. Network Security", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.4"]),
        Control("2.1", "pci-dss-v4", "Encryption of cardholder data in transit",
                "Encrypt cardholder data over open, public networks (TLS 1.2+)",
                "2. Cardholder Data Protection", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.10"]),
        Control("2.2", "pci-dss-v4", "Encryption at rest",
                "Encrypt stored cardholder data (AES-256)",
                "2. Cardholder Data Protection", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.2", "CIS-AWS-6.3"]),
        Control("3.1", "pci-dss-v4", "Vulnerability scanning",
                "Run internal and external vulnerability scans quarterly",
                "3. Vulnerability Management", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("3.2", "pci-dss-v4", "Penetration testing",
                "Perform penetration testing annually",
                "3. Vulnerability Management", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("4.1", "pci-dss-v4", "Unique ID per person",
                "Assign unique ID to each person with computer access",
                "4. Access Control", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.1"]),
        Control("4.2", "pci-dss-v4", "MFA for all access",
                "Multi-factor authentication for all access to cardholder data",
                "4. Access Control", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.2", "CIS-AWS-1.3"]),
        Control("4.3", "pci-dss-v4", "Least privilege",
                "Restrict access to cardholder data by business need-to-know",
                "4. Access Control", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.10"]),
        Control("5.1", "pci-dss-v4", "Audit logs for all access",
                "Log all access to cardholder data and network resources",
                "5. Monitoring", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.1", "CIS-AWS-3.7"]),
        Control("5.2", "pci-dss-v4", "Time sync (NTP)",
                "Synchronize time across all systems (NTP)",
                "5. Monitoring", ControlPriority.P2.value,
                automated=False),
        Control("6.1", "pci-dss-v4", "Information security policy",
                "Establish, publish, and maintain a security policy",
                "6. Security Policy", ControlPriority.P2.value,
                automated=False, evidence_required=True),
    ]
    fw.controls = controls
    return fw


def _build_iso_27001_2022() -> Framework:
    """ISO/IEC 27001:2022 — 93 Annex A controls organized in 4 themes."""
    fw = Framework(
        framework_id="iso-27001-2022",
        name="ISO/IEC 27001:2022",
        version="2022",
        description="International standard for information security management systems (ISMS). "
                    "Certification requires external audit by accredited body.",
        categories=["A.5 Organizational", "A.6 People", "A.7 Physical",
                    "A.8 Technological"],
        industry="general",
        mandatory=False,
        certification=True,
    )
    controls = [
        # A.5 Organizational controls (37 total — abbreviated for clarity)
        Control("A.5.1", "iso-27001-2022", "Policies for information security",
                "Define, approve, publish and communicate information security policies",
                "A.5 Organizational", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.5.2", "iso-27001-2022", "Information security roles and responsibilities",
                "Allocate information security roles and responsibilities",
                "A.5 Organizational", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.5.3", "iso-27001-2022", "Segregation of duties",
                "Separate conflicting duties to reduce misuse risk",
                "A.5 Organizational", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.10"]),
        Control("A.5.4", "iso-27001-2022", "Management responsibilities",
                "Management direction and support for information security",
                "A.5 Organizational", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.5.5", "iso-27001-2022", "Contact with authorities",
                "Maintain contact with relevant authorities",
                "A.5 Organizational", ControlPriority.P3.value,
                automated=False, evidence_required=True),
        Control("A.5.10", "iso-27001-2022", "Acceptable use of information",
                "Define rules for acceptable use of information and assets",
                "A.5 Organizational", ControlPriority.P3.value,
                automated=False, evidence_required=True),
        Control("A.5.12", "iso-27001-2022", "Classification of information",
                "Classify information per importance and legal requirements",
                "A.5 Organizational", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.5.15", "iso-27001-2022", "Access control",
                "Define and enforce access control policies",
                "A.5 Organizational", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.1", "CIS-AWS-1.10"]),
        Control("A.5.17", "iso-27001-2022", "Authentication information",
                "Manage authentication info (passwords, keys) securely",
                "A.5 Organizational", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.4", "CIS-AWS-1.5"]),
        Control("A.5.21", "iso-27001-2022", "Information security in supplier relationships",
                "Include security requirements in supplier agreements",
                "A.5 Organizational", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.5.23", "iso-27001-2022", "Cloud services",
                "Manage information security risks of cloud services",
                "A.5 Organizational", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.4", "CIS-AWS-2.2"]),
        Control("A.5.30", "iso-27001-2022", "ICT readiness for business continuity",
                "Ensure ICT readiness for business continuity",
                "A.5 Organizational", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.5.34", "iso-27001-2022", "Privacy and PII protection",
                "Protect privacy and PII per applicable laws",
                "A.5 Organizational", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.4"]),

        # A.6 People controls (8 total)
        Control("A.6.1", "iso-27001-2022", "Screening",
                "Background verification checks on all candidates for employment",
                "A.6 People", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.6.3", "iso-27001-2022", "Information security awareness",
                "Train staff on information security",
                "A.6 People", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.6.6", "iso-27001-2022", "Confidentiality agreements",
                "Confidentiality or non-disclosure agreements",
                "A.6 People", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.6.8", "iso-27001-2022", "Information security event reporting",
                "Provide mechanism for staff to report security events",
                "A.6 People", ControlPriority.P2.value,
                automated=False, evidence_required=True),

        # A.7 Physical controls (14 total — abbreviated)
        Control("A.7.1", "iso-27001-2022", "Physical security perimeters",
                "Define and use physical security perimeters",
                "A.7 Physical", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.7.2", "iso-27001-2022", "Physical entry",
                "Secure physical access to offices, rooms and facilities",
                "A.7 Physical", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.7.4", "iso-27001-2022", "Physical security monitoring",
                "Monitor premises for unauthorized physical access",
                "A.7 Physical", ControlPriority.P3.value,
                automated=False, evidence_required=True),

        # A.8 Technological controls (34 total — most relevant to CNAPP)
        Control("A.8.1", "iso-27001-2022", "User endpoint devices",
                "Manage information stored on user endpoint devices",
                "A.8 Technological", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.8.2", "iso-27001-2022", "Privileged access rights",
                "Restrict and manage privileged access rights",
                "A.8 Technological", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.10", "CIS-AWS-1.11"]),
        Control("A.8.3", "iso-27001-2022", "Information access restriction",
                "Restrict access to information per access control policy",
                "A.8 Technological", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.10"]),
        Control("A.8.5", "iso-27001-2022", "Secure authentication",
                "Provide secure authentication mechanisms (MFA)",
                "A.8 Technological", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.2", "CIS-AWS-1.3"]),
        Control("A.8.7", "iso-27001-2022", "Protection against malware",
                "Protect against malware (anti-malware, sandboxing)",
                "A.8 Technological", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("A.8.8", "iso-27001-2022", "Management of technical vulnerabilities",
                "Obtain and act on vulnerability information",
                "A.8 Technological", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("A.8.9", "iso-27001-2022", "Configuration management",
                "Establish, document, and enforce baseline configurations",
                "A.8 Technological", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.5", "CIS-AWS-5.4"]),
        Control("A.8.10", "iso-27001-2022", "Information deletion",
                "Securely delete information no longer needed",
                "A.8 Technological", ControlPriority.P2.value,
                automated=False),
        Control("A.8.11", "iso-27001-2022", "Data masking",
                "Mask data to protect PII",
                "A.8 Technological", ControlPriority.P2.value,
                automated=False),
        Control("A.8.12", "iso-27001-2022", "Data leakage prevention",
                "Apply DLP to detect and prevent data leakage",
                "A.8 Technological", ControlPriority.P2.value,
                automated=False),
        Control("A.8.15", "iso-27001-2022", "Logging",
                "Log events and store logs securely",
                "A.8 Technological", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.1", "CIS-AWS-3.7"]),
        Control("A.8.16", "iso-27001-2022", "Monitoring activities",
                "Monitor systems for anomalies",
                "A.8 Technological", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.2", "CIS-AWS-4.3"]),
        Control("A.8.18", "iso-27001-2022", "Use of privileged utility programs",
                "Restrict use of privileged utility programs",
                "A.8 Technological", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.10"]),
        Control("A.8.20", "iso-27001-2022", "Networks security",
                "Secure networks against attacks (firewalls, IDS)",
                "A.8 Technological", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.3", "CIS-AWS-5.4"]),
        Control("A.8.21", "iso-27001-2022", "Security of network services",
                "Security mechanisms in network services",
                "A.8 Technological", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.1"]),
        Control("A.8.22", "iso-27001-2022", "Segregation of networks",
                "Segregate networks into groups (VPC, subnets)",
                "A.8 Technological", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.5"]),
        Control("A.8.23", "iso-27001-2022", "Web filtering",
                "Manage web filtering to reduce exposure",
                "A.8 Technological", ControlPriority.P3.value,
                automated=False),
        Control("A.8.24", "iso-27001-2022", "Use of cryptography",
                "Use cryptography per organizational policy",
                "A.8 Technological", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.2", "CIS-AWS-6.3"]),
        Control("A.8.25", "iso-27001-2022", "Secure development lifecycle",
                "Establish secure development lifecycle",
                "A.8 Technological", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.8.26", "iso-27001-2022", "Application security requirements",
                "Define application security requirements",
                "A.8 Technological", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.8.28", "iso-27001-2022", "Secure coding",
                "Follow secure coding practices",
                "A.8 Technological", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.8.29", "iso-27001-2022", "Security testing in development",
                "Test security in development and acceptance",
                "A.8 Technological", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.8.32", "iso-27001-2022", "Change management",
                "Manage changes to systems",
                "A.8 Technological", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("A.8.34", "iso-27001-2022", "Protection of information systems during audit testing",
                "Limit impact of audit testing on systems",
                "A.8 Technological", ControlPriority.P3.value,
                automated=False),
    ]
    fw.controls = controls
    return fw


def _build_soc2_tsc() -> Framework:
    """SOC 2 Type II — Trust Services Criteria."""
    fw = Framework(
        framework_id="soc2-tsc-2017",
        name="SOC 2 Trust Services Criteria",
        version="2017 (with 2022 revisions)",
        description="AICPA Trust Services Criteria for Security, Availability, Processing Integrity, "
                    "Confidentiality, and Privacy. Type II audit covers 3-12 month observation period.",
        categories=["CC (Common Criteria)", "A (Availability)",
                    "C (Confidentiality)", "PI (Processing Integrity)", "P (Privacy)"],
        industry="general",
        mandatory=False,
        certification=True,
    )
    controls = [
        # CC (Common Criteria) — required for all SOC 2 audits
        Control("CC1.1", "soc2-tsc-2017", "Ethics and integrity",
                "Demonstrates commitment to integrity and ethical values",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("CC1.3", "soc2-tsc-2017", "Board independence",
                "Board of directors oversight",
                "CC (Common Criteria)", ControlPriority.P3.value,
                automated=False, evidence_required=True),
        Control("CC1.4", "soc2-tsc-2017", "Organizational structure",
                "Clear organizational structure and reporting lines",
                "CC (Common Criteria)", ControlPriority.P3.value,
                automated=False, evidence_required=True),
        Control("CC2.1", "soc2-tsc-2017", "Internal communication",
                "Communicates information to internal parties",
                "CC (Common Criteria)", ControlPriority.P3.value,
                automated=False),
        Control("CC2.2", "soc2-tsc-2017", "External communication",
                "Communicates information to external parties",
                "CC (Common Criteria)", ControlPriority.P3.value,
                automated=False),
        Control("CC2.3", "soc2-tsc-2017", "System design and documentation",
                "Analyzes and designs systems to support objectives",
                "CC (Common Criteria)", ControlPriority.P3.value,
                automated=False),
        Control("CC3.1", "soc2-tsc-2017", "Risk identification",
                "Identifies and assesses risk",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("CC3.2", "soc2-tsc-2017", "Risk response",
                "Manages risk response",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("CC3.3", "soc2-tsc-2017", "Fraud risk",
                "Considers potential for fraud",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("CC3.4", "soc2-tsc-2017", "Risk assessment changes",
                "Identifies and assesses changes that affect objectives",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("CC4.1", "soc2-tsc-2017", "Control monitoring",
                "Monitors control effectiveness",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.1", "CIS-AWS-4.2"]),
        Control("CC4.2", "soc2-tsc-2017", "Deficiency evaluation",
                "Evaluates and communicates deficiencies",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False),
        Control("CC5.1", "soc2-tsc-2017", "Control selection",
                "Selects and develops control activities",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False),
        Control("CC5.2", "soc2-tsc-2017", "Control deployment",
                "Deploys control activities",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.1", "CIS-AWS-1.10"]),
        Control("CC5.3", "soc2-tsc-2017", "Policy deployment",
                "Deploys policies through established procedures",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False),
        Control("CC6.1", "soc2-tsc-2017", "Logical access",
                "Logical and physical access controls implemented",
                "CC (Common Criteria)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.1", "CIS-AWS-1.2", "CIS-AWS-1.3"]),
        Control("CC6.2", "soc2-tsc-2017", "User provisioning",
                "User authentication before access",
                "CC (Common Criteria)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.1", "CIS-AWS-1.5"]),
        Control("CC6.3", "soc2-tsc-2017", "Authorization",
                "Authorizes access to systems and data",
                "CC (Common Criteria)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.10"]),
        Control("CC6.4", "soc2-tsc-2017", "Access removal",
                "Removes access when no longer needed",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.4"]),
        Control("CC6.5", "soc2-tsc-2017", "Network protection",
                "Protects network architecture and components",
                "CC (Common Criteria)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.3", "CIS-AWS-5.4"]),
        Control("CC6.6", "soc2-tsc-2017", "Network defense",
                "Implements network defense mechanisms",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.1", "CIS-AWS-5.2"]),
        Control("CC6.7", "soc2-tsc-2017", "Data transmission",
                "Secures data transmission (TLS)",
                "CC (Common Criteria)", ControlPriority.P1.value,
                automated=False),
        Control("CC6.8", "soc2-tsc-2017", "Key management",
                "Manages cryptographic keys",
                "CC (Common Criteria)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.19"]),
        Control("CC7.1", "soc2-tsc-2017", "Vulnerability detection",
                "Detects vulnerabilities",
                "CC (Common Criteria)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.4"]),
        Control("CC7.2", "soc2-tsc-2017", "Anomaly detection",
                "Detects anomalies and security events",
                "CC (Common Criteria)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.2", "CIS-AWS-4.14"]),
        Control("CC7.3", "soc2-tsc-2017", "Incident response",
                "Evaluates and responds to security events",
                "CC (Common Criteria)", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("CC7.4", "soc2-tsc-2017", "Incident communication",
                "Communicates incidents to affected parties",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False),
        Control("CC7.5", "soc2-tsc-2017", "Recovery procedures",
                "Implements recovery procedures",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("CC8.1", "soc2-tsc-2017", "Change management",
                "Authorizes and documents changes",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.3"]),
        Control("CC9.1", "soc2-tsc-2017", "Risk mitigation",
                "Identifies and mitigates risks",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False),
        Control("CC9.2", "soc2-tsc-2017", "Vendor management",
                "Manages vendor and business partner risks",
                "CC (Common Criteria)", ControlPriority.P2.value,
                automated=False, evidence_required=True),

        # A — Availability
        Control("A1.1", "soc2-tsc-2017", "Capacity management",
                "Maintains capacity to meet availability objectives",
                "A (Availability)", ControlPriority.P2.value,
                automated=False),
        Control("A1.2", "soc2-tsc-2017", "Backup and recovery",
                "Implements backup and recovery procedures",
                "A (Availability)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.4", "CIS-AWS-6.5"]),
        Control("A1.3", "soc2-tsc-2017", "DR plan",
                "Implements disaster recovery plan",
                "A (Availability)", ControlPriority.P1.value,
                automated=False, evidence_required=True),

        # C — Confidentiality
        Control("C1.1", "soc2-tsc-2017", "Confidentiality controls",
                "Manages confidential information throughout lifecycle",
                "C (Confidentiality)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.4", "CIS-AWS-2.2"]),
        Control("C1.2", "soc2-tsc-2017", "Confidentiality disposal",
                "Disposes of confidential information securely",
                "C (Confidentiality)", ControlPriority.P2.value,
                automated=False),

        # PI — Processing Integrity
        Control("PI1.1", "soc2-tsc-2017", "Processing accuracy",
                "Validates input to ensure processing accuracy",
                "PI (Processing Integrity)", ControlPriority.P2.value,
                automated=False),
        Control("PI1.2", "soc2-tsc-2017", "Processing errors",
                "Detects and corrects processing errors",
                "PI (Processing Integrity)", ControlPriority.P2.value,
                automated=False),

        # P — Privacy
        Control("P1.1", "soc2-tsc-2017", "Privacy notice",
                "Provides privacy notice",
                "P (Privacy)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("P2.1", "soc2-tsc-2017", "PII collection",
                "Collects PII only for stated purposes",
                "P (Privacy)", ControlPriority.P2.value,
                automated=False),
        Control("P4.1", "soc2-tsc-2017", "PII retention",
                "Retains PII only as long as needed",
                "P (Privacy)", ControlPriority.P2.value,
                automated=False),
        Control("P5.1", "soc2-tsc-2017", "PII access",
                "Permits access to PII as needed",
                "P (Privacy)", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.10"]),
        Control("P6.1", "soc2-tsc-2017", "PII disclosure",
                "Discloses PII only with consent",
                "P (Privacy)", ControlPriority.P2.value,
                automated=False),
        Control("P6.2", "soc2-tsc-2017", "PII transfer",
                "Transfers PII only per notice",
                "P (Privacy)", ControlPriority.P2.value,
                automated=False),
        Control("P7.1", "soc2-tsc-2017", "PII monitoring",
                "Monitors PII access",
                "P (Privacy)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.1"]),
        Control("P8.1", "soc2-tsc-2017", "PII breach response",
                "Responds to PII breaches",
                "P (Privacy)", ControlPriority.P1.value,
                automated=False, evidence_required=True),
    ]
    fw.controls = controls
    return fw


def _build_hipaa_security_rule() -> Framework:
    """HIPAA Security Rule — 45 CFR §164.308, §164.312."""
    fw = Framework(
        framework_id="hipaa-security-rule",
        name="HIPAA Security Rule",
        version="2013 (Omnibus)",
        description="U.S. Health Insurance Portability and Accountability Act Security Rule. "
                    "Mandatory for any organization handling Protected Health Information (PHI).",
        categories=["Administrative Safeguards", "Physical Safeguards", "Technical Safeguards"],
        industry="healthcare",
        mandatory=True,
        certification=False,
    )
    controls = [
        # Administrative Safeguards (§164.308)
        Control("164.308(a)(1)", "hipaa-security-rule", "Security Management Process",
                "Implement policies and procedures to prevent/detect/security violations",
                "Administrative Safeguards", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("164.308(a)(1)(ii)(A)", "hipaa-security-rule", "Risk Analysis",
                "Conduct accurate and thorough risk analysis",
                "Administrative Safeguards", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.10", "CIS-AWS-5.3"]),
        Control("164.308(a)(1)(ii)(B)", "hipaa-security-rule", "Risk Management",
                "Implement risk management measures",
                "Administrative Safeguards", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("164.308(a)(3)", "hipaa-security-rule", "Workforce Security",
                "Implement workforce access to ePHI",
                "Administrative Safeguards", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.1", "CIS-AWS-1.10"]),
        Control("164.308(a)(4)", "hipaa-security-rule", "Information Access Management",
                "Implement access management for ePHI",
                "Administrative Safeguards", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.10", "CIS-AWS-1.11"]),
        Control("164.308(a)(5)", "hipaa-security-rule", "Security Awareness Training",
                "Implement security awareness and training program",
                "Administrative Safeguards", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("164.308(a)(6)", "hipaa-security-rule", "Security Incident Procedures",
                "Implement procedures to respond to security incidents",
                "Administrative Safeguards", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("164.308(a)(7)", "hipaa-security-rule", "Contingency Plan",
                "Establish contingency plan (DR, backup, emergency mode)",
                "Administrative Safeguards", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.4", "CIS-AWS-6.5"]),
        Control("164.308(a)(8)", "hipaa-security-rule", "Evaluation",
                "Perform periodic technical and nontechnical evaluation",
                "Administrative Safeguards", ControlPriority.P2.value,
                automated=False, evidence_required=True),

        # Physical Safeguards (§164.310)
        Control("164.310(a)(1)", "hipaa-security-rule", "Facility Access Controls",
                "Implement facility access controls",
                "Physical Safeguards", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("164.310(b)", "hipaa-security-rule", "Workstation Use",
                "Specify workstation use policies",
                "Physical Safeguards", ControlPriority.P3.value,
                automated=False, evidence_required=True),
        Control("164.310(c)", "hipaa-security-rule", "Workstation Security",
                "Implement workstation security",
                "Physical Safeguards", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("164.310(d)", "hipaa-security-rule", "Device and Media Controls",
                "Implement device and media controls (disposal, reuse)",
                "Physical Safeguards", ControlPriority.P2.value,
                automated=False, evidence_required=True),

        # Technical Safeguards (§164.312)
        Control("164.312(a)(1)", "hipaa-security-rule", "Access Control",
                "Implement technical access control policies and procedures",
                "Technical Safeguards", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.1", "CIS-AWS-1.10", "CIS-AWS-1.11"]),
        Control("164.312(a)(2)(i)", "hipaa-security-rule", "Unique User ID",
                "Assign unique user identification",
                "Technical Safeguards", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.1"]),
        Control("164.312(a)(2)(iii)", "hipaa-security-rule", "Automatic Logoff",
                "Implement automatic logoff",
                "Technical Safeguards", ControlPriority.P2.value,
                automated=False),
        Control("164.312(a)(2)(iv)", "hipaa-security-rule", "Encryption and Decryption",
                "Encrypt and decrypt ePHI",
                "Technical Safeguards", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.2", "CIS-AWS-6.3"]),
        Control("164.312(b)", "hipaa-security-rule", "Audit Controls",
                "Implement audit controls (logging)",
                "Technical Safeguards", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.1", "CIS-AWS-3.7"]),
        Control("164.312(c)(1)", "hipaa-security-rule", "Integrity Controls",
                "Implement integrity controls",
                "Technical Safeguards", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.2"]),
        Control("164.312(d)", "hipaa-security-rule", "Person or Entity Authentication",
                "Verify person/entity seeking access",
                "Technical Safeguards", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.2", "CIS-AWS-1.3"]),
        Control("164.312(e)(1)", "hipaa-security-rule", "Transmission Security",
                "Implement technical security measures to guard ePHI in transit",
                "Technical Safeguards", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.10"]),
    ]
    fw.controls = controls
    return fw


def _build_nist_csf_2() -> Framework:
    """NIST Cybersecurity Framework 2.0 — 6 Functions."""
    fw = Framework(
        framework_id="nist-csf-2.0",
        name="NIST Cybersecurity Framework",
        version="2.0",
        description="Voluntary framework for critical infrastructure cybersecurity. "
                    "Six Functions: Govern, Identify, Protect, Detect, Respond, Recover.",
        categories=["GV (Govern)", "ID (Identify)", "PR (Protect)",
                    "DE (Detect)", "RS (Respond)", "RC (Recover)"],
        industry="general",
        mandatory=False,
        certification=False,
    )
    controls = [
        # Govern (new in 2.0)
        Control("GV.OC", "nist-csf-2.0", "Organizational Context",
                "Understand the organization's cybersecurity context",
                "GV (Govern)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("GV.RM", "nist-csf-2.0", "Risk Management Strategy",
                "Establish cybersecurity risk management strategy",
                "GV (Govern)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("GV.RR", "nist-csf-2.0", "Roles, Responsibilities, Authorities",
                "Define cybersecurity roles and responsibilities",
                "GV (Govern)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("GV.PO", "nist-csf-2.0", "Policy",
                "Establish cybersecurity policy",
                "GV (Govern)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        # Identify
        Control("ID.AM", "nist-csf-2.0", "Asset Management",
                "Maintain inventory of physical and software assets",
                "ID (Identify)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.4"]),
        Control("ID.RA", "nist-csf-2.0", "Risk Assessment",
                "Conduct cybersecurity risk assessments",
                "ID (Identify)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.10", "CIS-AWS-5.3"]),
        Control("ID.IM", "nist-csf-2.0", "Improvement",
                "Identify improvements based on risk assessments",
                "ID (Identify)", ControlPriority.P2.value,
                automated=False),
        # Protect
        Control("PR.AA", "nist-csf-2.0", "Identity Management, Authentication",
                "Assure identities are verified and authorized",
                "PR (Protect)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-1.1", "CIS-AWS-1.2", "CIS-AWS-1.3"]),
        Control("PR.AT", "nist-csf-2.0", "Awareness and Training",
                "Provide cybersecurity awareness and training",
                "PR (Protect)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("PR.DS", "nist-csf-2.0", "Data Security",
                "Protect data at rest and in transit",
                "PR (Protect)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.2", "CIS-AWS-6.3"]),
        Control("PR.PS", "nist-csf-2.0", "Platform Security",
                "Secure hardware, software, and services",
                "PR (Protect)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-5.4", "CIS-AWS-6.6"]),
        Control("PR.IR", "nist-csf-2.0", "Technology Infrastructure Resilience",
                "Ensure infrastructure resilience",
                "PR (Protect)", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.4", "CIS-AWS-6.5"]),
        # Detect
        Control("DE.CM", "nist-csf-2.0", "Continuous Monitoring",
                "Monitor assets for anomalies",
                "DE (Detect)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.1", "CIS-AWS-4.2"]),
        Control("DE.AE", "nist-csf-2.0", "Adverse Event Analysis",
                "Analyze events for adverse impact",
                "DE (Detect)", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-4.14"]),
        # Respond
        Control("RS.MA", "nist-csf-2.0", "Incident Management",
                "Manage incidents",
                "RS (Respond)", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("RS.AN", "nist-csf-2.0", "Incident Analysis",
                "Analyze incidents",
                "RS (Respond)", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("RS.CO", "nist-csf-2.0", "Incident Communication",
                "Communicate incident information",
                "RS (Respond)", ControlPriority.P2.value,
                automated=False),
        # Recover
        Control("RC.RP", "nist-csf-2.0", "Recovery Plan",
                "Execute recovery plan",
                "RC (Recover)", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("RC.CO", "nist-csf-2.0", "Recovery Communication",
                "Communicate recovery information",
                "RC (Recover)", ControlPriority.P2.value,
                automated=False),
    ]
    fw.controls = controls
    return fw


def _build_gdpr() -> Framework:
    """GDPR — Articles 5, 25, 32, 33, 34, 35."""
    fw = Framework(
        framework_id="gdpr-eu-2016",
        name="EU General Data Protection Regulation",
        version="2016/679",
        description="EU regulation on data protection and privacy. Mandatory for any organization "
                    "processing personal data of EU residents. Non-compliance: up to €20M or 4% revenue.",
        categories=["Principles", "Data Subject Rights", "Security",
                    "Breach Notification", "DPIA"],
        industry="general",
        mandatory=True,
        certification=False,
    )
    controls = [
        # Principles (Article 5)
        Control("Art.5(1)(a)", "gdpr-eu-2016", "Lawfulness, fairness, transparency",
                "Process personal data lawfully, fairly, and transparently",
                "Principles", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("Art.5(1)(b)", "gdpr-eu-2016", "Purpose limitation",
                "Collect data for specified, explicit purposes",
                "Principles", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("Art.5(1)(c)", "gdpr-eu-2016", "Data minimization",
                "Collect only data necessary for purpose",
                "Principles", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("Art.5(1)(d)", "gdpr-eu-2016", "Accuracy",
                "Ensure data accuracy and currency",
                "Principles", ControlPriority.P2.value,
                automated=False),
        Control("Art.5(1)(e)", "gdpr-eu-2016", "Storage limitation",
                "Retain data only as long as necessary",
                "Principles", ControlPriority.P2.value,
                automated=False),
        Control("Art.5(1)(f)", "gdpr-eu-2016", "Integrity and confidentiality",
                "Process data securely (security principle)",
                "Principles", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.2", "CIS-AWS-2.4"]),

        # Data Subject Rights (Articles 15-22)
        Control("Art.15", "gdpr-eu-2016", "Right of access",
                "Provide data subjects access to their data",
                "Data Subject Rights", ControlPriority.P2.value,
                automated=False, evidence_required=True),
        Control("Art.17", "gdpr-eu-2016", "Right to erasure",
                "Allow data subjects to request deletion",
                "Data Subject Rights", ControlPriority.P2.value,
                automated=False),
        Control("Art.20", "gdpr-eu-2016", "Right to portability",
                "Allow data subjects to port their data",
                "Data Subject Rights", ControlPriority.P2.value,
                automated=False),

        # Security (Article 32)
        Control("Art.32(1)(a)", "gdpr-eu-2016", "Pseudonymization and encryption",
                "Implement pseudonymization and encryption",
                "Security", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.2", "CIS-AWS-6.3"]),
        Control("Art.32(1)(b)", "gdpr-eu-2016", "Confidentiality, integrity, availability",
                "Ensure ongoing CIA of processing",
                "Security", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.1", "CIS-AWS-3.7"]),
        Control("Art.32(1)(c)", "gdpr-eu-2016", "Restoring availability after incident",
                "Restore availability after physical or technical incident",
                "Security", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-6.4", "CIS-AWS-6.5"]),
        Control("Art.32(1)(d)", "gdpr-eu-2016", "Regular testing",
                "Test effectiveness of security measures",
                "Security", ControlPriority.P2.value,
                automated=True, mapped_rule_ids=["CIS-AWS-3.1"]),
        Control("Art.32(2)", "gdpr-eu-2016", "Risk assessment for security",
                "Assess risks to rights of data subjects",
                "Security", ControlPriority.P2.value,
                automated=False, evidence_required=True),

        # Breach Notification (Articles 33, 34)
        Control("Art.33", "gdpr-eu-2016", "Notification to supervisory authority",
                "Notify authority within 72 hours of breach awareness",
                "Breach Notification", ControlPriority.P1.value,
                automated=False, evidence_required=True),
        Control("Art.34", "gdpr-eu-2016", "Communication to data subjects",
                "Communicate breaches to data subjects",
                "Breach Notification", ControlPriority.P1.value,
                automated=False, evidence_required=True),

        # DPIA (Article 35)
        Control("Art.35", "gdpr-eu-2016", "Data Protection Impact Assessment",
                "Conduct DPIA for high-risk processing",
                "DPIA", ControlPriority.P1.value,
                automated=False, evidence_required=True),

        # Privacy by Design (Article 25)
        Control("Art.25", "gdpr-eu-2016", "Data protection by design and by default",
                "Implement data protection by design and default",
                "Principles", ControlPriority.P1.value,
                automated=True, mapped_rule_ids=["CIS-AWS-2.4", "CIS-AWS-1.10"]),
    ]
    fw.controls = controls
    return fw


# ═══════════════════════════════════════════════════════════════
# Compliance Engine
# ═══════════════════════════════════════════════════════════════

class ComplianceEngine:
    """Multi-framework compliance assessment engine.

    Workflow:
      1. Register frameworks (built-in or custom)
      2. After each scan, call assess() with the findings
      3. The engine maps each finding to control(s) via rule_id mappings
      4. Compute compliance score per framework and per category
      5. Generate evidence packages for auditors
    """

    def __init__(self):
        self._frameworks: dict[str, Framework] = {}
        # Register built-in frameworks
        self.register_framework(_build_cis_aws_v3())
        self.register_framework(_build_pci_dss_v4())
        self.register_framework(_build_iso_27001_2022())
        self.register_framework(_build_soc2_tsc())
        self.register_framework(_build_hipaa_security_rule())
        self.register_framework(_build_nist_csf_2())
        self.register_framework(_build_gdpr())

    def register_framework(self, fw: Framework) -> None:
        self._frameworks[fw.framework_id] = fw

    def list_frameworks(self) -> list[dict[str, Any]]:
        return [
            {
                "framework_id": fw.framework_id,
                "name": fw.name,
                "version": fw.version,
                "description": fw.description,
                "industry": fw.industry,
                "mandatory": fw.mandatory,
                "certification": fw.certification,
                "categories": fw.categories,
                "total_controls": len(fw.controls),
                "automated_controls": sum(1 for c in fw.controls if c.automated),
                "manual_controls": sum(1 for c in fw.controls if not c.automated),
            }
            for fw in self._frameworks.values()
        ]

    def get_framework(self, framework_id: str) -> Optional[Framework]:
        return self._frameworks.get(framework_id)

    def get_controls(self, framework_id: str) -> list[Control]:
        fw = self._frameworks.get(framework_id)
        return fw.controls if fw else []

    def assess(
        self,
        tenant_id: str,
        framework_id: str,
        findings: list[dict[str, Any]],
        scan_id: Optional[str] = None,
        manually_marked: Optional[dict[str, str]] = None,
    ) -> ComplianceAssessment:
        """Assess compliance of a tenant against a framework.

        Args:
            tenant_id: Tenant ID
            framework_id: Framework to assess against
            findings: List of finding dicts (must have rule_id, status, severity)
            scan_id: Optional scan ID for traceability
            manually_marked: Optional dict mapping control_id -> status
                            (for controls that require human evaluation)

        Returns:
            ComplianceAssessment with scores and failing controls
        """
        fw = self._frameworks.get(framework_id)
        if not fw:
            raise ValueError(f"Unknown framework: {framework_id}")

        # Build rule_id -> finding mapping
        findings_by_rule: dict[str, list[dict]] = {}
        for f in findings:
            rule_id = f.get("rule_id")
            if rule_id:
                findings_by_rule.setdefault(rule_id, []).append(f)

        manually_marked = manually_marked or {}
        assessment = ComplianceAssessment(
            assessment_id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            framework_id=fw.framework_id,
            framework_name=fw.name,
            framework_version=fw.version,
            assessed_at=int(time.time() * 1000),
            scan_id=scan_id,
        )

        # Initialize category breakdown
        for cat in fw.categories:
            assessment.category_scores[cat] = {
                "total": 0, "passed": 0, "failed": 0,
                "manual": 0, "not_applicable": 0, "not_assessed": 0,
            }

        for control in fw.controls:
            assessment.total_controls += 1
            cat_key = self._find_category(fw, control.category)
            if cat_key:
                assessment.category_scores[cat_key]["total"] += 1

            # Determine status
            if control.control_id in manually_marked:
                status = manually_marked[control.control_id]
            elif not control.automated:
                status = ControlStatus.MANUAL.value
            elif not control.mapped_rule_ids:
                status = ControlStatus.MANUAL.value
            else:
                # Check findings for any of the mapped rule_ids
                related_findings = []
                for rid in control.mapped_rule_ids:
                    related_findings.extend(findings_by_rule.get(rid, []))

                if not related_findings:
                    # No findings for this control → check passed
                    status = ControlStatus.PASS.value
                    control.pass_count = 1
                else:
                    # Any open finding = control failure
                    open_findings = [f for f in related_findings
                                     if f.get("status") in (None, "open")]
                    if open_findings:
                        status = ControlStatus.FAIL.value
                        control.fail_count = len(open_findings)
                        assessment.failed_controls.append({
                            "control_id": control.control_id,
                            "title": control.title,
                            "description": control.description,
                            "category": control.category,
                            "priority": control.priority,
                            "failing_finding_count": len(open_findings),
                            "highest_severity": max(
                                (f.get("severity", "low") for f in open_findings),
                                key=lambda s: {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}.get(s, 0),
                            ),
                            "guidance": control.guidance,
                            "references": control.references,
                        })
                    else:
                        status = ControlStatus.PASS.value
                        control.pass_count = len(related_findings)

            control.status = status
            control.last_assessed = assessment.assessed_at
            assessment._increment_status(status, cat_key, control.category, fw, assessment)

        # Calculate score: passed / (passed + failed) * 100
        denominator = assessment.passed + assessment.failed
        assessment.score = (assessment.passed / denominator * 100) if denominator > 0 else 100.0

        return assessment

    def _find_category(self, fw: Framework, control_category: str) -> Optional[str]:
        """Match control.category to a top-level fw.categories entry."""
        # Categories like "1. IAM" match controls with category "1. IAM"
        for cat in fw.categories:
            if cat == control_category or cat.startswith(control_category.split()[0]):
                return cat
        return fw.categories[0] if fw.categories else None

    def generate_evidence_package(
        self,
        tenant_id: str,
        framework_id: str,
        assessment: ComplianceAssessment,
    ) -> dict[str, Any]:
        """Generate an auditor-ready evidence package.

        This is a key commercial differentiator — auditors can use this
        package directly to verify compliance without further requests.
        """
        fw = self._frameworks.get(framework_id)
        return {
            "package_id": str(uuid.uuid4()),
            "tenant_id": tenant_id,
            "framework": {
                "id": fw.framework_id,
                "name": fw.name,
                "version": fw.version,
            },
            "assessment_id": assessment.assessment_id,
            "assessed_at": assessment.assessed_at,
            "summary": {
                "total_controls": assessment.total_controls,
                "passed": assessment.passed,
                "failed": assessment.failed,
                "manual": assessment.manual,
                "not_applicable": assessment.not_applicable,
                "not_assessed": assessment.not_assessed,
                "errors": assessment.errors,
                "score": round(assessment.score, 2),
            },
            "category_breakdown": assessment.category_scores,
            "failed_controls": assessment.failed_controls,
            "evidence_statement": (
                f"This evidence package documents the compliance posture of tenant "
                f"{tenant_id} against {fw.name} v{fw.version} as of "
                f"{assessment.assessed_at}. The assessment was performed automatically "
                f"by Nexora using {assessment.total_controls} controls, "
                f"of which {assessment.passed} passed and {assessment.failed} failed. "
                f"Overall compliance score: {assessment.score:.2f}%."
            ),
            "signature": self._sign_package(assessment),
        }

    def _sign_package(self, assessment: ComplianceAssessment) -> str:
        """Sign the evidence package for non-repudiation."""
        import hashlib
        import hmac
        import os
        key = os.environ.get("AUDIT_MASTER_KEY", "dev-key")[:64]
        msg = f"{assessment.assessment_id}:{assessment.tenant_id}:{assessment.score}"
        return hmac.new(key.encode(), msg.encode(), hashlib.sha256).hexdigest()


# Add helper method to ComplianceAssessment
def _inc_status(self, status, cat_key, control_cat, fw, assessment):
    if status == ControlStatus.PASS.value:
        assessment.passed += 1
        if cat_key: assessment.category_scores[cat_key]["passed"] += 1
    elif status == ControlStatus.FAIL.value:
        assessment.failed += 1
        if cat_key: assessment.category_scores[cat_key]["failed"] += 1
    elif status == ControlStatus.MANUAL.value:
        assessment.manual += 1
        if cat_key: assessment.category_scores[cat_key]["manual"] += 1
    elif status == ControlStatus.NOT_APPLICABLE.value:
        assessment.not_applicable += 1
        if cat_key: assessment.category_scores[cat_key]["not_applicable"] += 1
    elif status == ControlStatus.ERROR.value:
        assessment.errors += 1
    else:
        assessment.not_assessed += 1
        if cat_key: assessment.category_scores[cat_key]["not_assessed"] += 1

ComplianceAssessment._increment_status = _inc_status
