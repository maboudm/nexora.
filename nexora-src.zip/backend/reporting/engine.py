"""
Enterprise Reporting Engine — PDF/Excel/JSON report generation.

Based on Part 12 — Reporting Engine requirements.

Capabilities:
  1. Executive Summary Report: 1-page overview for C-suite
     - Posture score with grade
     - Trend chart
     - Top 5 risks
     - Compliance status
  2. Technical Findings Report: detailed for security teams
     - All findings with severity, CVSS, remediation
     - Filtered by category, severity, asset
  3. Compliance Report: framework-by-framework breakdown
     - Pass/Fail per control
     - Evidence package
  4. Attack Path Report: graph visualization + critical paths
  5. Asset Inventory Report: full asset listing with criticality
  6. Custom Report Builder: pick sections, generate on-demand

Output Formats:
  - PDF (ReportLab): for executive distribution
  - Excel (openpyxl): for analyst data manipulation
  - JSON: for API integration
  - CSV: for SIEM ingestion

Templates:
  Reports use a consistent template system. Each template specifies:
    - Title, subtitle, header logo
    - Sections (each with a renderer)
    - Footer with page numbers + classification
"""
from __future__ import annotations

import csv
import io
import json
import logging
import os
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Reporting Domain Model
# ═══════════════════════════════════════════════════════════════

class ReportType(str, Enum):
    EXECUTIVE_SUMMARY = "executive_summary"
    TECHNICAL_FINDINGS = "technical_findings"
    COMPLIANCE = "compliance"
    ATTACK_PATH = "attack_path"
    ASSET_INVENTORY = "asset_inventory"
    POSTURE_SCORE = "posture_score"
    CUSTOM = "custom"


class ReportFormat(str, Enum):
    PDF = "pdf"
    EXCEL = "excel"
    JSON = "json"
    CSV = "csv"


@dataclass
class ReportRequest:
    """Request to generate a report."""
    report_type: str           # ReportType value
    format: str                # ReportFormat value
    tenant_id: str
    tenant_name: str = "Tenant"
    title: str = ""
    subtitle: str = ""
    period_start: Optional[int] = None
    period_end: Optional[int] = None
    filters: dict[str, Any] = field(default_factory=dict)
    sections: list[str] = field(default_factory=list)  # for custom reports
    classification: str = "Confidential"
    generated_by: str = "system"


@dataclass
class ReportResult:
    """Result of report generation."""
    report_id: str
    report_type: str
    format: str
    tenant_id: str
    title: str
    file_path: str             # path to generated file
    file_size_bytes: int
    generated_at: int
    generated_by: str
    duration_ms: int
    metadata: dict[str, Any] = field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════
# PDF Report Generator (ReportLab)
# ═══════════════════════════════════════════════════════════════

class PDFReportGenerator:
    """Generate PDF reports using ReportLab.

    Layout:
      - Cover page with title, classification, date
      - Table of contents (for multi-section reports)
      - Executive summary (1 page)
      - Detailed sections
      - Footer with page numbers + "Confidential"
    """

    def __init__(self):
        from reportlab.lib.pagesizes import letter, A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch, cm
        from reportlab.lib import colors
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
            PageBreak, Image, ListFlowable, ListItem,
        )
        self.letter = letter
        self.A4 = A4
        self.inch = inch
        self.cm = cm
        self.colors = colors
        self.SimpleDocTemplate = SimpleDocTemplate
        self.Paragraph = Paragraph
        self.Spacer = Spacer
        self.Table = Table
        self.TableStyle = TableStyle
        self.PageBreak = PageBreak
        self.getSampleStyleSheet = getSampleStyleSheet
        self.ParagraphStyle = ParagraphStyle

    def generate(self, request: ReportRequest, data: dict[str, Any], output_path: str) -> str:
        """Generate a PDF report."""
        styles = self.getSampleStyleSheet()
        # Custom styles
        title_style = self.ParagraphStyle(
            "CustomTitle", parent=styles["Title"],
            fontSize=28, spaceAfter=30, textColor=self.colors.HexColor("#1a365d"),
        )
        heading_style = self.ParagraphStyle(
            "CustomHeading", parent=styles["Heading1"],
            fontSize=16, spaceAfter=12, textColor=self.colors.HexColor("#2c5282"),
        )
        body_style = self.ParagraphStyle(
            "CustomBody", parent=styles["BodyText"],
            fontSize=10, spaceAfter=6, leading=14,
        )
        classification_style = self.ParagraphStyle(
            "Classification", parent=styles["Normal"],
            fontSize=9, textColor=self.colors.red, alignment=2,  # right
        )

        doc = self.SimpleDocTemplate(
            output_path, pagesize=self.letter,
            leftMargin=0.75 * self.inch, rightMargin=0.75 * self.inch,
            topMargin=0.75 * self.inch, bottomMargin=0.75 * self.inch,
            title=request.title, author="Nexora",
        )

        story = []

        # Cover page
        story.append(self.Spacer(1, 2 * self.inch))
        story.append(self.Paragraph(request.title or "Security Report", title_style))
        story.append(self.Spacer(1, 0.25 * self.inch))
        if request.subtitle:
            story.append(self.Paragraph(request.subtitle, heading_style))
        story.append(self.Spacer(1, 0.5 * self.inch))
        story.append(self.Paragraph(
            f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
            body_style,
        ))
        story.append(self.Paragraph(f"Tenant: {request.tenant_name}", body_style))
        if request.period_start and request.period_end:
            start = datetime.fromtimestamp(request.period_start / 1000, tz=timezone.utc).strftime("%Y-%m-%d")
            end = datetime.fromtimestamp(request.period_end / 1000, tz=timezone.utc).strftime("%Y-%m-%d")
            story.append(self.Paragraph(f"Period: {start} to {end}", body_style))
        story.append(self.Spacer(1, 1 * self.inch))
        story.append(self.Paragraph(f"CLASSIFICATION: {request.classification}", classification_style))
        story.append(self.PageBreak())

        # Sections based on report type
        if request.report_type == ReportType.EXECUTIVE_SUMMARY.value:
            self._render_executive_summary(story, data, styles, heading_style, body_style)
        elif request.report_type == ReportType.TECHNICAL_FINDINGS.value:
            self._render_technical_findings(story, data, styles, heading_style, body_style)
        elif request.report_type == ReportType.COMPLIANCE.value:
            self._render_compliance_report(story, data, styles, heading_style, body_style)
        elif request.report_type == ReportType.POSTURE_SCORE.value:
            self._render_posture_report(story, data, styles, heading_style, body_style)
        elif request.report_type == ReportType.ASSET_INVENTORY.value:
            self._render_asset_inventory(story, data, styles, heading_style, body_style)
        else:
            self._render_generic(story, data, styles, heading_style, body_style)

        # Build with footer
        def add_footer(canvas, doc):
            canvas.saveState()
            canvas.setFont("Helvetica", 8)
            canvas.setFillColor(self.colors.grey)
            canvas.drawString(
                0.75 * self.inch, 0.5 * self.inch,
                f"{request.classification} — Nexora",
            )
            canvas.drawRightString(
                self.letter[0] - 0.75 * self.inch, 0.5 * self.inch,
                f"Page {doc.page}",
            )
            canvas.restoreState()

        doc.build(story, onFirstPage=add_footer, onLaterPages=add_footer)
        return output_path

    def _render_executive_summary(self, story, data, styles, heading_style, body_style):
        """Render executive summary section."""
        # Posture score
        posture = data.get("posture_score", {})
        if posture:
            story.append(self.Paragraph("1. Security Posture Overview", heading_style))
            score = posture.get("overall_score", 0)
            grade = posture.get("grade", "F")
            trend = posture.get("trend", "new")
            story.append(self.Paragraph(
                f"<b>Overall Score: {score}/100 (Grade: {grade})</b><br/>"
                f"Trend: {trend}<br/>"
                f"Industry Benchmark: {posture.get('industry_benchmark', 'N/A')}<br/>"
                f"Percentile: {posture.get('percentile', 'N/A')}th",
                body_style,
            ))
            story.append(self.Spacer(1, 0.2 * self.inch))

            # Factor breakdown table
            factors = posture.get("factors", [])
            if factors:
                factor_data = [["Factor", "Score", "Weight", "Findings"]]
                for f in factors:
                    factor_data.append([
                        f["factor_name"],
                        f"{f['score']:.1f}",
                        f"{f['weight']*100:.0f}%",
                        str(f.get("findings_count", 0)),
                    ])
                t = self.Table(factor_data, colWidths=[2 * self.inch, 1 * self.inch, 1 * self.inch, 1.5 * self.inch])
                t.setStyle(self.TableStyle([
                    ("BACKGROUND", (0, 0), (-1, 0), self.colors.HexColor("#2c5282")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), self.colors.white),
                    ("FONTSIZE", (0, 0), (-1, -1), 9),
                    ("GRID", (0, 0), (-1, -1), 0.5, self.colors.grey),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [self.colors.white, self.colors.HexColor("#f7fafc")]),
                ]))
                story.append(t)
                story.append(self.Spacer(1, 0.3 * self.inch))

        # Top risks
        story.append(self.Paragraph("2. Top Security Risks", heading_style))
        risks = data.get("top_risks", [])
        if risks:
            risk_data = [["Risk", "Severity", "Affected Assets", "Status"]]
            for r in risks[:10]:
                risk_data.append([
                    r.get("title", "")[:50],
                    r.get("severity", "").upper(),
                    str(r.get("affected_count", 0)),
                    r.get("status", "open"),
                ])
            t = self.Table(risk_data, colWidths=[3 * self.inch, 1 * self.inch, 1.2 * self.inch, 1 * self.inch])
            t.setStyle(self.TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), self.colors.HexColor("#2c5282")),
                ("TEXTCOLOR", (0, 0), (-1, 0), self.colors.white),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("GRID", (0, 0), (-1, -1), 0.5, self.colors.grey),
            ]))
            story.append(t)
        else:
            story.append(self.Paragraph("No critical risks identified.", body_style))
        story.append(self.Spacer(1, 0.3 * self.inch))

        # Recommendations
        story.append(self.Paragraph("3. Recommended Actions", heading_style))
        recs = posture.get("top_recommendations", [])
        for rec in recs[:5]:
            story.append(self.Paragraph(
                f"<b>[{rec.get('priority', 'P3')}]</b> {rec.get('action', '')} "
                f"(Impact: +{rec.get('impact', 0)} points)",
                body_style,
            ))
        if not recs:
            story.append(self.Paragraph("No recommendations — posture is excellent.", body_style))

    def _render_technical_findings(self, story, data, styles, heading_style, body_style):
        """Render technical findings section."""
        story.append(self.Paragraph("1. Findings Summary", heading_style))
        summary = data.get("summary", {})
        story.append(self.Paragraph(
            f"Total Findings: {summary.get('total', 0)}<br/>"
            f"Critical: {summary.get('critical', 0)}<br/>"
            f"High: {summary.get('high', 0)}<br/>"
            f"Medium: {summary.get('medium', 0)}<br/>"
            f"Low: {summary.get('low', 0)}",
            body_style,
        ))
        story.append(self.Spacer(1, 0.2 * self.inch))

        story.append(self.Paragraph("2. Detailed Findings", heading_style))
        findings = data.get("findings", [])
        for i, f in enumerate(findings[:50], 1):  # cap at 50 for PDF size
            sev_color = self.colors.red if f.get("severity") == "critical" else \
                       self.colors.orange if f.get("severity") == "high" else \
                       self.colors.HexColor("#d69e2e") if f.get("severity") == "medium" else \
                       self.colors.blue
            sev_style = self.ParagraphStyle(
                f"Sev{i}", parent=body_style, textColor=sev_color, fontSize=10,
            )
            story.append(self.Paragraph(
                f"<b>{i}. [{f.get('severity', '').upper()}] {f.get('title', 'Untitled')}</b>",
                sev_style,
            ))
            story.append(self.Paragraph(
                f"Resource: {f.get('resource_type', '')} / {f.get('resource_name', '')}<br/>"
                f"Region: {f.get('region', '')}<br/>"
                f"Rule: {f.get('rule_id', '')}<br/>"
                f"Description: {f.get('description', '')[:200]}<br/>"
                f"Remediation: {f.get('remediation', '')[:200]}",
                body_style,
            ))
            story.append(self.Spacer(1, 0.15 * self.inch))

    def _render_compliance_report(self, story, data, styles, heading_style, body_style):
        """Render compliance report section."""
        story.append(self.Paragraph("1. Compliance Overview", heading_style))
        assessments = data.get("assessments", [])
        if not assessments:
            story.append(self.Paragraph("No compliance assessments available.", body_style))
            return

        # Summary table
        comp_data = [["Framework", "Version", "Score", "Passed", "Failed", "Manual"]]
        for a in assessments:
            comp_data.append([
                a.get("framework_name", "")[:30],
                a.get("framework_version", ""),
                f"{a.get('score', 0):.1f}%",
                str(a.get("passed", 0)),
                str(a.get("failed", 0)),
                str(a.get("manual", 0)),
            ])
        t = self.Table(comp_data, colWidths=[2 * self.inch, 0.8 * self.inch, 0.8 * self.inch,
                                            0.7 * self.inch, 0.7 * self.inch, 0.7 * self.inch])
        t.setStyle(self.TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), self.colors.HexColor("#2c5282")),
            ("TEXTCOLOR", (0, 0), (-1, 0), self.colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("GRID", (0, 0), (-1, -1), 0.5, self.colors.grey),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [self.colors.white, self.colors.HexColor("#f7fafc")]),
        ]))
        story.append(t)
        story.append(self.Spacer(1, 0.3 * self.inch))

        # Failed controls per framework
        story.append(self.Paragraph("2. Failed Controls Detail", heading_style))
        for a in assessments:
            failed = a.get("failed_controls", [])
            if not failed:
                continue
            story.append(self.Paragraph(
                f"<b>{a.get('framework_name', '')}</b>",
                self.ParagraphStyle("SubHeading", parent=body_style, fontSize=12, spaceBefore=10),
            ))
            fc_data = [["Control ID", "Title", "Severity", "Guidance"]]
            for fc in failed[:20]:
                fc_data.append([
                    fc.get("control_id", ""),
                    fc.get("title", "")[:40],
                    fc.get("highest_severity", "").upper(),
                    fc.get("guidance", "")[:60],
                ])
            t = self.Table(fc_data, colWidths=[1 * self.inch, 2.2 * self.inch, 0.8 * self.inch, 2.5 * self.inch])
            t.setStyle(self.TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), self.colors.HexColor("#4a5568")),
                ("TEXTCOLOR", (0, 0), (-1, 0), self.colors.white),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("GRID", (0, 0), (-1, -1), 0.5, self.colors.grey),
            ]))
            story.append(t)
            story.append(self.Spacer(1, 0.2 * self.inch))

    def _render_posture_report(self, story, data, styles, heading_style, body_style):
        """Render posture score report."""
        posture = data.get("posture_score", {})
        if not posture:
            story.append(self.Paragraph("No posture score data available.", body_style))
            return

        story.append(self.Paragraph("1. Overall Posture Score", heading_style))
        story.append(self.Paragraph(
            f"<para alignment='center'><font size='48' color='#1a365d'>"
            f"<b>{posture.get('overall_score', 0):.1f}</b></font></para>",
            body_style,
        ))
        story.append(self.Paragraph(
            f"<para alignment='center'><font size='24' color='#2c5282'>"
            f"Grade: {posture.get('grade', 'F')}</font></para>",
            body_style,
        ))
        story.append(self.Spacer(1, 0.3 * self.inch))

        story.append(self.Paragraph("2. Factor Breakdown", heading_style))
        factors = posture.get("factors", [])
        for f in factors:
            story.append(self.Paragraph(
                f"<b>{f['factor_name']}</b>: {f['score']:.1f}/100 "
                f"(weight: {f['weight']*100:.0f}%, weighted: {f['weighted_score']:.1f})",
                body_style,
            ))
        story.append(self.Spacer(1, 0.2 * self.inch))

        story.append(self.Paragraph("3. Quick Wins", heading_style))
        quick_wins = posture.get("quick_wins", [])
        for qw in quick_wins:
            story.append(self.Paragraph(
                f"<b>[{qw.get('effort', 'medium').upper()} effort]</b> "
                f"{qw.get('action', '')} (Impact: +{qw.get('impact', 0)} points)",
                body_style,
            ))
        story.append(self.Spacer(1, 0.2 * self.inch))

        story.append(self.Paragraph("4. Industry Benchmark", heading_style))
        story.append(self.Paragraph(
            f"Your score: {posture.get('overall_score', 0):.1f}<br/>"
            f"Industry average: {posture.get('industry_benchmark', 0):.1f}<br/>"
            f"Percentile: {posture.get('percentile', 0)}th "
            f"(you are {'above' if posture.get('overall_score', 0) >= posture.get('industry_benchmark', 0) else 'below'} average)",
            body_style,
        ))

    def _render_asset_inventory(self, story, data, styles, heading_style, body_style):
        """Render asset inventory report."""
        story.append(self.Paragraph("1. Inventory Summary", heading_style))
        summary = data.get("summary", {})
        story.append(self.Paragraph(
            f"Total Assets: {summary.get('total_assets', 0)}<br/>"
            f"By Provider: {summary.get('by_provider', {})}<br/>"
            f"By Criticality: {summary.get('by_criticality', {})}<br/>"
            f"Internet-Exposed: {summary.get('internet_exposed_count', 0)}<br/>"
            f"Contains PII: {summary.get('contains_pii_count', 0)}",
            body_style,
        ))
        story.append(self.Spacer(1, 0.2 * self.inch))

        story.append(self.Paragraph("2. Critical Assets", heading_style))
        assets = data.get("assets", [])
        critical_assets = [a for a in assets if a.get("criticality") in ("critical", "high")]
        if critical_assets:
            asset_data = [["Name", "Type", "Provider", "Region", "Criticality", "PII"]]
            for a in critical_assets[:30]:
                asset_data.append([
                    a.get("name", "")[:30],
                    a.get("universal_type", "")[:20],
                    a.get("provider", ""),
                    a.get("region", ""),
                    a.get("criticality", ""),
                    "Yes" if a.get("contains_pii") else "No",
                ])
            t = self.Table(asset_data, colWidths=[1.5 * self.inch, 1.3 * self.inch, 0.8 * self.inch,
                                                 0.8 * self.inch, 0.8 * self.inch, 0.5 * self.inch])
            t.setStyle(self.TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), self.colors.HexColor("#2c5282")),
                ("TEXTCOLOR", (0, 0), (-1, 0), self.colors.white),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("GRID", (0, 0), (-1, -1), 0.5, self.colors.grey),
            ]))
            story.append(t)
        else:
            story.append(self.Paragraph("No critical assets identified.", body_style))

    def _render_generic(self, story, data, styles, heading_style, body_style):
        """Generic data dump for custom reports."""
        for key, value in data.items():
            story.append(self.Paragraph(key.replace("_", " ").title(), heading_style))
            story.append(self.Paragraph(
                f"<pre>{json.dumps(value, indent=2, default=str)[:2000]}</pre>",
                body_style,
            ))
            story.append(self.Spacer(1, 0.2 * self.inch))


# ═══════════════════════════════════════════════════════════════
# Excel Report Generator (openpyxl)
# ═══════════════════════════════════════════════════════════════

class ExcelReportGenerator:
    """Generate Excel reports using openpyxl.

    Each report type creates a multi-sheet workbook with:
      - Summary sheet
      - Detailed data sheets
      - Charts (where applicable)
    """

    def generate(self, request: ReportRequest, data: dict[str, Any], output_path: str) -> str:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter

        wb = Workbook()
        # Styles
        header_font = Font(bold=True, color="FFFFFF", size=11)
        header_fill = PatternFill(start_color="2C5282", end_color="2C5282", fill_type="solid")
        title_font = Font(bold=True, size=16, color="1A365D")
        thin_border = Border(
            left=Side(style="thin", color="CCCCCC"),
            right=Side(style="thin", color="CCCCCC"),
            top=Side(style="thin", color="CCCCCC"),
            bottom=Side(style="thin", color="CCCCCC"),
        )

        # Summary sheet
        ws = wb.active
        ws.title = "Summary"
        ws["A1"] = request.title or "Security Report"
        ws["A1"].font = title_font
        ws["A2"] = f"Tenant: {request.tenant_name}"
        ws["A3"] = f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}"
        ws["A4"] = f"Classification: {request.classification}"

        # Report-type-specific sheets
        if request.report_type == ReportType.TECHNICAL_FINDINGS.value:
            self._add_findings_sheet(wb, data, header_font, header_fill, thin_border)
        elif request.report_type == ReportType.COMPLIANCE.value:
            self._add_compliance_sheet(wb, data, header_font, header_fill, thin_border)
        elif request.report_type == ReportType.ASSET_INVENTORY.value:
            self._add_assets_sheet(wb, data, header_font, header_fill, thin_border)
        elif request.report_type == ReportType.POSTURE_SCORE.value:
            self._add_posture_sheet(wb, data, header_font, header_fill, thin_border)
        else:
            self._add_generic_sheet(wb, data, header_font, header_fill, thin_border)

        # Auto-adjust column widths
        for ws in wb.worksheets:
            for column in ws.columns:
                max_length = 0
                column_letter = get_column_letter(column[0].column)
                for cell in column:
                    try:
                        if cell.value:
                            max_length = max(max_length, len(str(cell.value)))
                    except Exception:
                        pass
                adjusted_width = min(max_length + 2, 50)
                ws.column_dimensions[column_letter].width = adjusted_width

        wb.save(output_path)
        return output_path

    def _add_findings_sheet(self, wb, data, header_font, header_fill, border):
        ws = wb.create_sheet("Findings")
        headers = ["ID", "Title", "Severity", "Category", "Resource Type", "Resource Name",
                   "Region", "Rule ID", "Description", "Remediation", "Status", "Detected At"]
        for col, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=h)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = border

        findings = data.get("findings", [])
        for row_idx, f in enumerate(findings, 2):
            ws.cell(row=row_idx, column=1, value=f.get("id", "")).border = border
            ws.cell(row=row_idx, column=2, value=f.get("title", "")).border = border
            ws.cell(row=row_idx, column=3, value=f.get("severity", "")).border = border
            ws.cell(row=row_idx, column=4, value=f.get("category", "")).border = border
            ws.cell(row=row_idx, column=5, value=f.get("resource_type", "")).border = border
            ws.cell(row=row_idx, column=6, value=f.get("resource_name", "")).border = border
            ws.cell(row=row_idx, column=7, value=f.get("region", "")).border = border
            ws.cell(row=row_idx, column=8, value=f.get("rule_id", "")).border = border
            ws.cell(row=row_idx, column=9, value=f.get("description", "")[:500]).border = border
            ws.cell(row=row_idx, column=10, value=f.get("remediation", "")[:500]).border = border
            ws.cell(row=row_idx, column=11, value=f.get("status", "")).border = border
            ws.cell(row=row_idx, column=12, value=f.get("detected_at", "")).border = border

    def _add_compliance_sheet(self, wb, data, header_font, header_fill, border):
        ws = wb.create_sheet("Compliance")
        headers = ["Framework", "Version", "Total Controls", "Passed", "Failed", "Manual",
                   "Score %", "Failed Control ID", "Failed Control Title", "Severity", "Guidance"]
        for col, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=h)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = border

        row_idx = 2
        for a in data.get("assessments", []):
            failed_controls = a.get("failed_controls", [])
            if not failed_controls:
                ws.cell(row=row_idx, column=1, value=a.get("framework_name", "")).border = border
                ws.cell(row=row_idx, column=2, value=a.get("framework_version", "")).border = border
                ws.cell(row=row_idx, column=3, value=a.get("total_controls", 0)).border = border
                ws.cell(row=row_idx, column=4, value=a.get("passed", 0)).border = border
                ws.cell(row=row_idx, column=5, value=a.get("failed", 0)).border = border
                ws.cell(row=row_idx, column=6, value=a.get("manual", 0)).border = border
                ws.cell(row=row_idx, column=7, value=f"{a.get('score', 0):.1f}%").border = border
                row_idx += 1
            else:
                for fc in failed_controls:
                    ws.cell(row=row_idx, column=1, value=a.get("framework_name", "")).border = border
                    ws.cell(row=row_idx, column=2, value=a.get("framework_version", "")).border = border
                    ws.cell(row=row_idx, column=3, value=a.get("total_controls", 0)).border = border
                    ws.cell(row=row_idx, column=4, value=a.get("passed", 0)).border = border
                    ws.cell(row=row_idx, column=5, value=a.get("failed", 0)).border = border
                    ws.cell(row=row_idx, column=6, value=a.get("manual", 0)).border = border
                    ws.cell(row=row_idx, column=7, value=f"{a.get('score', 0):.1f}%").border = border
                    ws.cell(row=row_idx, column=8, value=fc.get("control_id", "")).border = border
                    ws.cell(row=row_idx, column=9, value=fc.get("title", "")).border = border
                    ws.cell(row=row_idx, column=10, value=fc.get("highest_severity", "")).border = border
                    ws.cell(row=row_idx, column=11, value=fc.get("guidance", "")[:200]).border = border
                    row_idx += 1

    def _add_assets_sheet(self, wb, data, header_font, header_fill, border):
        ws = wb.create_sheet("Assets")
        headers = ["Name", "ARN", "Type", "Provider", "Region", "Criticality", "Criticality Score",
                   "Internet Exposed", "Contains PII", "Contains Secrets", "Encrypted"]
        for col, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=h)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = border

        for row_idx, a in enumerate(data.get("assets", []), 2):
            ws.cell(row=row_idx, column=1, value=a.get("name", "")).border = border
            ws.cell(row=row_idx, column=2, value=a.get("arn", "")).border = border
            ws.cell(row=row_idx, column=3, value=a.get("universal_type", "")).border = border
            ws.cell(row=row_idx, column=4, value=a.get("provider", "")).border = border
            ws.cell(row=row_idx, column=5, value=a.get("region", "")).border = border
            ws.cell(row=row_idx, column=6, value=a.get("criticality", "")).border = border
            ws.cell(row=row_idx, column=7, value=a.get("criticality_score", 0)).border = border
            ws.cell(row=row_idx, column=8, value="Yes" if a.get("internet_exposed") else "No").border = border
            ws.cell(row=row_idx, column=9, value="Yes" if a.get("contains_pii") else "No").border = border
            ws.cell(row=row_idx, column=10, value="Yes" if a.get("contains_secrets") else "No").border = border
            ws.cell(row=row_idx, column=11, value="Yes" if a.get("encrypted") else "No").border = border

    def _add_posture_sheet(self, wb, data, header_font, header_fill, border):
        ws = wb.create_sheet("Posture Score")
        posture = data.get("posture_score", {})
        ws["A1"] = "Overall Score"
        ws["B1"] = posture.get("overall_score", 0)
        ws["A2"] = "Grade"
        ws["B2"] = posture.get("grade", "")
        ws["A3"] = "Trend"
        ws["B3"] = posture.get("trend", "")
        ws["A4"] = "Industry Benchmark"
        ws["B4"] = posture.get("industry_benchmark", 0)
        ws["A5"] = "Percentile"
        ws["B5"] = posture.get("percentile", 0)

        # Factor breakdown
        ws["A7"] = "Factor"
        ws["B7"] = "Score"
        ws["C7"] = "Weight"
        ws["D7"] = "Weighted Score"
        ws["E7"] = "Findings Count"
        for col in range(1, 6):
            ws.cell(row=7, column=col).font = header_font
            ws.cell(row=7, column=col).fill = header_fill

        for row_idx, f in enumerate(posture.get("factors", []), 8):
            ws.cell(row=row_idx, column=1, value=f.get("factor_name", "")).border = border
            ws.cell(row=row_idx, column=2, value=f.get("score", 0)).border = border
            ws.cell(row=row_idx, column=3, value=f"{f.get('weight', 0)*100:.0f}%").border = border
            ws.cell(row=row_idx, column=4, value=f.get("weighted_score", 0)).border = border
            ws.cell(row=row_idx, column=5, value=f.get("findings_count", 0)).border = border

        # Recommendations
        rec_start = 8 + len(posture.get("factors", [])) + 2
        ws.cell(row=rec_start, column=1, value="Recommendations").font = title_font = header_font
        ws.cell(row=rec_start, column=1).fill = header_fill
        ws.cell(row=rec_start, column=2, value="Priority").font = header_font
        ws.cell(row=rec_start, column=2).fill = header_fill
        ws.cell(row=rec_start, column=3, value="Impact").font = header_font
        ws.cell(row=rec_start, column=3).fill = header_fill
        for row_idx, rec in enumerate(posture.get("top_recommendations", []), rec_start + 1):
            ws.cell(row=row_idx, column=1, value=rec.get("action", "")).border = border
            ws.cell(row=row_idx, column=2, value=rec.get("priority", "")).border = border
            ws.cell(row=row_idx, column=3, value=rec.get("impact", 0)).border = border

    def _add_generic_sheet(self, wb, data, header_font, header_fill, border):
        ws = wb.create_sheet("Data")
        for row_idx, (key, value) in enumerate(data.items(), 1):
            ws.cell(row=row_idx, column=1, value=key).font = header_font
            ws.cell(row=row_idx, column=1).fill = header_fill
            ws.cell(row=row_idx, column=2, value=json.dumps(value, default=str, indent=2)[:30000])


# ═══════════════════════════════════════════════════════════════
# Reporting Engine
# ═══════════════════════════════════════════════════════════════

class ReportingEngine:
    """Multi-format report generation engine.

    Usage:
        engine = ReportingEngine()
        result = engine.generate_report(request, data)
        # result.file_path → download path
    """

    def __init__(self, output_dir: str = "/home/z/my-project/download/reports"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self._reports: list[ReportResult] = []
        self._lock = threading.RLock()
        self._pdf_generator = PDFReportGenerator()
        self._excel_generator = ExcelReportGenerator()

    def generate_report(self, request: ReportRequest, data: dict[str, Any]) -> ReportResult:
        """Generate a report in the requested format."""
        start_time = time.time()
        report_id = str(uuid.uuid4())
        ext = {"pdf": ".pdf", "excel": ".xlsx", "json": ".json", "csv": ".csv"}[request.format]
        filename = f"{request.report_type}_{request.tenant_id}_{int(time.time())}{ext}"
        output_path = os.path.join(self.output_dir, filename)

        if request.format == ReportFormat.PDF.value:
            self._pdf_generator.generate(request, data, output_path)
        elif request.format == ReportFormat.EXCEL.value:
            self._excel_generator.generate(request, data, output_path)
        elif request.format == ReportFormat.JSON.value:
            with open(output_path, "w") as f:
                json.dump({
                    "report_id": report_id,
                    "request": asdict(request),
                    "data": data,
                    "generated_at": int(time.time() * 1000),
                }, f, indent=2, default=str)
        elif request.format == ReportFormat.CSV.value:
            self._generate_csv(request, data, output_path)
        else:
            raise ValueError(f"Unknown format: {request.format}")

        file_size = os.path.getsize(output_path)
        result = ReportResult(
            report_id=report_id,
            report_type=request.report_type,
            format=request.format,
            tenant_id=request.tenant_id,
            title=request.title or f"{request.report_type} Report",
            file_path=output_path,
            file_size_bytes=file_size,
            generated_at=int(time.time() * 1000),
            generated_by=request.generated_by,
            duration_ms=int((time.time() - start_time) * 1000),
        )

        with self._lock:
            self._reports.append(result)

        return result

    def _generate_csv(self, request: ReportRequest, data: dict[str, Any], output_path: str) -> None:
        """Generate CSV (findings or assets)."""
        with open(output_path, "w", newline="") as f:
            writer = csv.writer(f)
            if "findings" in data:
                findings = data["findings"]
                if findings:
                    writer.writerow(findings[0].keys())
                    for finding in findings:
                        writer.writerow([
                            str(v)[:200] if v else "" for v in finding.values()
                        ])
            elif "assets" in data:
                assets = data["assets"]
                if assets:
                    writer.writerow(assets[0].keys())
                    for asset in assets:
                        writer.writerow([
                            str(v)[:200] if v else "" for v in asset.values()
                        ])
            else:
                # Generic: flatten first level
                writer.writerow(["Key", "Value"])
                for k, v in data.items():
                    writer.writerow([k, str(v)[:1000]])

    def list_reports(
        self,
        tenant_id: Optional[str] = None,
        report_type: Optional[str] = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        with self._lock:
            reports = list(self._reports)
        if tenant_id:
            reports = [r for r in reports if r.tenant_id == tenant_id]
        if report_type:
            reports = [r for r in reports if r.report_type == report_type]
        return [
            {
                "report_id": r.report_id,
                "report_type": r.report_type,
                "format": r.format,
                "title": r.title,
                "file_path": r.file_path,
                "file_size_bytes": r.file_size_bytes,
                "generated_at": r.generated_at,
                "duration_ms": r.duration_ms,
            }
            for r in reversed(reports)
        ][:limit]

    def get_report(self, report_id: str) -> Optional[ReportResult]:
        with self._lock:
            for r in self._reports:
                if r.report_id == report_id:
                    return r
        return None

    def list_report_types(self) -> list[dict[str, Any]]:
        return [
            {"type": ReportType.EXECUTIVE_SUMMARY.value, "name": "Executive Summary",
             "description": "1-page overview for C-suite — posture score, top risks, recommendations",
             "formats": ["pdf", "excel"]},
            {"type": ReportType.TECHNICAL_FINDINGS.value, "name": "Technical Findings",
             "description": "Detailed findings with severity, CVSS, remediation steps",
             "formats": ["pdf", "excel", "csv", "json"]},
            {"type": ReportType.COMPLIANCE.value, "name": "Compliance Report",
             "description": "Framework-by-framework breakdown with pass/fail per control",
             "formats": ["pdf", "excel"]},
            {"type": ReportType.POSTURE_SCORE.value, "name": "Posture Score Report",
             "description": "Multi-factor score breakdown with recommendations and benchmarks",
             "formats": ["pdf", "excel"]},
            {"type": ReportType.ASSET_INVENTORY.value, "name": "Asset Inventory",
             "description": "Full asset listing with criticality, exposure, and classification",
             "formats": ["excel", "csv", "json"]},
            {"type": ReportType.ATTACK_PATH.value, "name": "Attack Path Report",
             "description": "Critical paths from internet to sensitive assets",
             "formats": ["pdf", "json"]},
        ]


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_engine: Optional[ReportingEngine] = None
_global_lock = threading.Lock()


def get_reporting_engine() -> ReportingEngine:
    global _global_engine
    if _global_engine is None:
        with _global_lock:
            if _global_engine is None:
                _global_engine = ReportingEngine()
    return _global_engine
