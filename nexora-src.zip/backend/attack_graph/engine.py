"""Attack Graph Engine — builds attack paths from asset relationships and findings.

Based on Part 2, 8 — Attack Graph Engine and Part 8 — Graph Engine.

Builds a directed graph where:
  - Nodes: assets (IAM roles, S3 buckets, EC2 instances, security groups)
  - Edges: relationships (attached_sg, assumes_role, can_access_s3, public_ingress)

Then finds attack paths: Internet → SG (public ingress) → EC2 → IAM Role → S3/Secrets

Each path gets a risk score and blast radius.
"""
from __future__ import annotations

import hashlib
import json
import logging
from collections import defaultdict, deque
from typing import Any

from core.models import Asset, AssetRelationship, AttackPath, Finding

logger = logging.getLogger(__name__)


class AttackGraphEngine:
    """Builds and analyzes attack path graphs.

    Uses BFS to find all paths from the "internet" node to sensitive assets,
    bounded by a maximum depth to prevent infinite loops.

    Usage:
        engine = AttackGraphEngine()
        paths = engine.build_attack_paths(assets, relationships, findings)
    """

    def __init__(self, max_depth: int = 6):
        self.max_depth = max_depth

    def build_attack_paths(
        self,
        assets: list[Asset],
        relationships: list[AssetRelationship],
        findings: list[Finding],
    ) -> list[AttackPath]:
        """Build attack paths from internet to sensitive assets.

        Algorithm:
        1. Build adjacency list from relationships
        2. Identify entry points (internet → SG with public ingress findings)
        3. Identify target assets (S3 buckets, secrets, KMS keys, admin roles)
        4. BFS from each entry point to find paths to targets
        5. Score each path based on findings along the path
        6. Deduplicate by path hash
        """
        # Build adjacency list
        adjacency: dict[str, list[tuple[str, str]]] = defaultdict(list)
        for rel in relationships:
            adjacency[rel.from_asset_arn].append((rel.to_asset_arn, rel.relationship_type))

        # Build findings lookup by asset ARN
        findings_by_arn: dict[str, list[Finding]] = defaultdict(list)
        for f in findings:
            findings_by_arn[f.asset_arn].append(f)

        # Build asset lookup
        assets_by_arn = {a.arn: a for a in assets}

        # Identify entry points: security groups with public ingress findings
        internet_arn = "aws::internet"
        entry_points: list[str] = []

        for asset in assets:
            if asset.resource_type != "aws_security_group":
                continue
            sg_findings = findings_by_arn.get(asset.arn, [])
            has_public = any(f.rule_id.startswith("NET-00") for f in sg_findings)
            if has_public:
                adjacency[internet_arn].append((asset.arn, "public_ingress"))
                entry_points.append(asset.arn)

        # Also check EKS clusters with public API
        for asset in assets:
            if asset.resource_type != "aws_eks_cluster":
                continue
            eks_findings = findings_by_arn.get(asset.arn, [])
            if any(f.rule_id == "K8S-001" for f in eks_findings):
                adjacency[internet_arn].append((asset.arn, "public_api_endpoint"))
                entry_points.append(asset.arn)

        # Also check public S3 buckets
        for asset in assets:
            if asset.resource_type != "aws_s3_bucket":
                continue
            s3_findings = findings_by_arn.get(asset.arn, [])
            if any(f.rule_id == "S3-001" for f in s3_findings):
                adjacency[internet_arn].append((asset.arn, "public_bucket"))
                entry_points.append(asset.arn)

        # Identify target assets: S3, Secrets, KMS, admin roles
        target_types = {"aws_s3_bucket", "aws_secretsmanager_secret", "aws_kms_key", "aws_rds_instance"}
        target_arns = {a.arn for a in assets if a.resource_type in target_types}

        # Also consider IAM roles with admin access as targets (privilege escalation)
        for asset in assets:
            if asset.resource_type == "aws_iam_role":
                role_findings = findings_by_arn.get(asset.arn, [])
                if any(f.rule_id in ("IAM-001", "IAM-002") for f in role_findings):
                    target_arns.add(asset.arn)

        # BFS from internet to find all attack paths
        all_paths: list[AttackPath] = []
        seen_path_hashes: set[str] = set()

        for target_arn in target_arns:
            paths = self._bfs_paths(adjacency, internet_arn, target_arn)

            for path_nodes in paths:
                # Build edges from path
                path_edges = []
                for i in range(len(path_nodes) - 1):
                    src = path_nodes[i]
                    tgt = path_nodes[i + 1]
                    # Find the edge label
                    label = "connected"
                    for neighbor, edge_label in adjacency.get(src, []):
                        if neighbor == tgt:
                            label = edge_label
                            break
                    path_edges.append({"source": src, "target": tgt, "label": label})

                # Collect findings along the path
                path_finding_ids: list[str] = []
                path_finding_rules: list[str] = []
                for node_arn in path_nodes:
                    for f in findings_by_arn.get(node_arn, []):
                        path_finding_ids.append(f.id)
                        path_finding_rules.append(f.rule_id)

                # Compute path hash for dedup
                path_str = "->".join(path_nodes)
                path_hash = hashlib.sha256(path_str.encode()).hexdigest()

                if path_hash in seen_path_hashes:
                    continue
                seen_path_hashes.add(path_hash)

                # Compute blast radius
                blast_radius = self._compute_blast_radius(path_nodes, assets_by_arn, findings_by_arn)

                # Compute risk score
                risk_score = self._compute_path_risk(path_finding_rules, findings_by_arn, path_nodes)

                attack_path = AttackPath(
                    path=[{"node": arn, "type": assets_by_arn.get(arn, Asset(arn=arn, name=arn, type="external")).resource_type if arn != internet_arn else "external"} for arn in path_nodes],
                    edges=path_edges,
                    length=len(path_nodes) - 1,
                    findings=path_finding_rules,
                    risk_score=risk_score,
                    blast_radius=blast_radius,
                )
                all_paths.append(attack_path)

        # Sort by risk score (highest first)
        all_paths.sort(key=lambda p: p.risk_score, reverse=True)

        logger.info(f"Attack graph: {len(all_paths)} paths found (entry points: {len(entry_points)}, targets: {len(target_arns)})")
        return all_paths

    def _bfs_paths(self, adjacency: dict[str, list], start: str, target: str) -> list[list[str]]:
        """BFS to find all paths from start to target, bounded by max_depth."""
        if start == target:
            return [[start]]

        paths: list[list[str]] = []
        queue: deque[tuple[list[str], set[str]]] = deque()
        queue.append(([start], {start}))

        while queue:
            path, visited = queue.popleft()

            if len(path) > self.max_depth:
                continue

            current = path[-1]
            for neighbor, _ in adjacency.get(current, []):
                if neighbor == target:
                    paths.append(path + [neighbor])
                elif neighbor not in visited:
                    queue.append((path + [neighbor], visited | {neighbor}))

        return paths

    def _compute_blast_radius(
        self,
        path_nodes: list[str],
        assets_by_arn: dict[str, Asset],
        findings_by_arn: dict[str, list[Finding]],
    ) -> dict[str, Any]:
        """Compute blast radius for an attack path."""
        affected_assets: list[str] = []
        affected_services: set[str] = set()
        sensitive_data = False

        for arn in path_nodes:
            asset = assets_by_arn.get(arn)
            if asset:
                affected_assets.append(asset.name)
                affected_services.add(asset.service)
                if asset.resource_type in ("aws_s3_bucket", "aws_secretsmanager_secret", "aws_rds_instance"):
                    sensitive_data = True

        # Check for sensitive data findings
        for arn in path_nodes:
            for f in findings_by_arn.get(arn, []):
                if f.category == "secret" or f.rule_id.startswith("S3-001"):
                    sensitive_data = True

        return {
            "affected_assets": affected_assets,
            "affected_services": list(affected_services),
            "sensitive_data": sensitive_data,
            "path_length": len(path_nodes) - 1,
        }

    def _compute_path_risk(
        self,
        finding_rules: list[str],
        findings_by_arn: dict[str, list[Finding]],
        path_nodes: list[str],
    ) -> float:
        """Compute risk score for an attack path.

        Higher score = more dangerous path.
        """
        score = 0.0

        # Critical findings add more
        for rule_id in finding_rules:
            if rule_id.startswith("NET-001") or rule_id.startswith("NET-002") or rule_id.startswith("NET-003"):
                score += 30  # Public port = very dangerous
            elif rule_id.startswith("S3-001"):
                score += 25  # Public bucket
            elif rule_id == "IAM-001":
                score += 30  # Principal:*
            elif rule_id == "IAM-002":
                score += 25  # AdminAccess
            elif rule_id == "IAM-004":
                score += 20  # S3 FullAccess on compute
            elif rule_id == "K8S-001":
                score += 25  # Public EKS API
            else:
                score += 5

        # Longer paths are less likely to be exploited (more steps = more detection)
        length_penalty = max(0, len(path_nodes) - 3) * 5
        score -= length_penalty

        return max(0, min(100, score))

    def build_graph_summary(self, paths: list[AttackPath]) -> dict[str, Any]:
        """Build a summary of the attack graph for dashboard display."""
        return {
            "total_paths": len(paths),
            "critical_paths": sum(1 for p in paths if p.risk_score >= 70),
            "high_risk_paths": sum(1 for p in paths if 50 <= p.risk_score < 70),
            "medium_risk_paths": sum(1 for p in paths if 30 <= p.risk_score < 50),
            "low_risk_paths": sum(1 for p in paths if p.risk_score < 30),
            "max_risk_score": max((p.risk_score for p in paths), default=0),
            "avg_risk_score": sum(p.risk_score for p in paths) / len(paths) if paths else 0,
            "affected_assets": list(set(
                node["node"]
                for p in paths
                for node in p.path
                if node["type"] != "external"
            )),
            "entry_points": list(set(
                p.path[1]["node"] if len(p.path) > 1 else ""
                for p in paths
                if len(p.path) > 1
            )),
        }
