"""
Enterprise Remediator Engine — Auto-remediation with 3-tier approval model.

Based on Part 6 — Remediation requirements and NIST SP 800-137
(Information Security Continuous Monitoring).

Architecture:
  ┌─────────────────────┐
  │ Finding Detected    │
  └──────────┬──────────┘
             │
  ┌──────────▼──────────┐
  │ Remediator Suggests │  ← generates remediation plan
  └──────────┬──────────┘
             │
  ┌──────────▼──────────┐
  │     TIER 1: SUGGEST │  ← AI-generated, requires human action
  │     TIER 2: APPROVAL│  ← generated, requires human approval, then applied
  │     TIER 3: AUTO    │  ← generated and applied automatically
  └──────────┬──────────┘
             │
  ┌──────────▼──────────┐
  │   Apply Remediation │  ← executes via Terraform / AWS CLI / API
  └──────────┬──────────┘
             │
  ┌──────────▼──────────┐
  │     Verify Fix      │  ← re-scan to confirm finding is resolved
  └──────────┬──────────┘
             │
  ┌──────────▼──────────┐
  │   SUCCESS / FAIL    │
  │   (rollback on fail)│
  └─────────────────────┘

Tiers (Part 6 — Auto Remediation):
  - SUGGEST (Tier 1): AI generates instructions + CLI commands. User applies manually.
    Use case: complex changes requiring human judgment (e.g., IAM policy rewrite)
  - APPROVAL (Tier 2): System generates Terraform. User approves. System applies.
    Use case: medium-risk changes (e.g., enable S3 encryption, restrict SG)
  - AUTO (Tier 3): System generates + applies automatically. Rollback on failure.
    Use case: low-risk, high-volume changes (e.g., delete default SG rules,
    enable CloudTrail logging, rotate KMS keys)

Safety Guarantees:
  - Every remediation is logged in the immutable audit chain
  - Pre-application backup: state is saved before changes
  - Automatic rollback: if verification fails, state is restored
  - Rate limiting: max N remediations per hour per tenant
  - Blast radius limit: max M resources changed per remediation
  - Idempotent: re-running a remediation is safe
  - Dry-run mode: plan only, no apply
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import subprocess
import tempfile
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Remediator Domain Model
# ═══════════════════════════════════════════════════════════════

class RemediationTier(str, Enum):
    SUGGEST = "suggest"          # Tier 1: human applies manually
    APPROVAL = "approval"        # Tier 2: system generates, human approves, system applies
    AUTO = "auto"                # Tier 3: system generates and applies automatically


class RemediationStatus(str, Enum):
    PROPOSED = "proposed"        # generated, waiting for approval (Tier 2) or schedule (Tier 3)
    APPROVED = "approved"        # human approved, ready to apply
    REJECTED = "rejected"        # human rejected
    APPLYING = "applying"        # in progress
    APPLIED = "applied"          # successfully applied
    VERIFIED = "verified"        # post-apply scan confirmed fix
    FAILED = "failed"            # apply failed
    ROLLED_BACK = "rolled_back"  # apply failed and rollback succeeded
    ROLLBACK_FAILED = "rollback_failed"  # apply failed AND rollback failed (CRITICAL)


class RemediationType(str, Enum):
    TERRAFORM_APPLY = "terraform_apply"
    AWS_CLI = "aws_cli"
    AWS_API = "aws_api"
    MANUAL = "manual"
    KUBERNETES_PATCH = "k8s_patch"
    SCRIPT = "script"


class RemediationRisk(str, Enum):
    LOW = "low"               # reversible, low blast radius (e.g., enable logging)
    MEDIUM = "medium"          # reversible, moderate impact (e.g., restrict SG)
    HIGH = "high"              # may cause service disruption (e.g., delete IAM policy)
    CRITICAL = "critical"      # irreversible or high impact (e.g., delete resource)


@dataclass
class RemediationAction:
    """A single action within a remediation plan."""
    action_id: str
    description: str
    action_type: str               # RemediationType
    target_resource_arn: str
    target_resource_type: str
    target_resource_name: str
    target_region: str = ""
    # For Terraform
    terraform_config: Optional[str] = None
    # For AWS CLI
    cli_command: Optional[str] = None
    # For AWS API
    api_call: Optional[dict[str, Any]] = None      # {service, operation, parameters}
    # For manual
    manual_instructions: Optional[str] = None
    # Risk assessment
    risk: str = RemediationRisk.LOW.value
    reversible: bool = True
    backup_required: bool = True
    estimated_downtime_seconds: int = 0
    # Execution tracking
    executed_at: Optional[int] = None
    execution_log: Optional[str] = None
    success: Optional[bool] = None


@dataclass
class RemediationPlan:
    """A complete remediation plan for one or more findings."""
    plan_id: str
    tenant_id: str
    finding_ids: list[str]
    title: str
    description: str
    tier: str                      # RemediationTier
    risk: str                      # RemediationRisk (highest among actions)
    actions: list[RemediationAction]
    status: str = RemediationStatus.PROPOSED.value
    created_at: int = 0
    created_by: str = ""           # user_id or "system"
    approved_by: Optional[str] = None
    approved_at: Optional[int] = None
    applied_at: Optional[int] = None
    verified_at: Optional[int] = None
    backup_state: Optional[dict[str, Any]] = None  # pre-apply state for rollback
    verification_scan_id: Optional[str] = None
    failure_reason: Optional[str] = None
    estimated_time_minutes: int = 5
    tags: dict[str, str] = field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════
# Remediation Templates
# ═══════════════════════════════════════════════════════════════

class RemediationTemplates:
    """Templates for generating remediation actions from findings.

    Each template maps a rule_id to a remediation action generator.
    Templates are declarative — they specify WHAT to do, not HOW to execute.
    The Remediator engine handles execution.
    """

    @classmethod
    def generate_for_finding(cls, finding: dict[str, Any]) -> Optional[RemediationAction]:
        """Generate a remediation action for a finding based on its rule_id."""
        rule_id = finding.get("rule_id", "")
        resource_arn = finding.get("resource_arn", "")
        resource_type = finding.get("resource_type", "")
        resource_name = finding.get("resource_name", "")
        region = finding.get("region", "us-east-1")

        # Map rule_id to method name
        method_name = cls._RULE_MAP.get(rule_id)
        if not method_name:
            # Generic remediation: manual instructions
            return RemediationAction(
                action_id=str(uuid.uuid4()),
                description=f"Manual remediation for {rule_id}",
                action_type=RemediationType.MANUAL.value,
                target_resource_arn=resource_arn,
                target_resource_type=resource_type,
                target_resource_name=resource_name,
                target_region=region,
                manual_instructions=finding.get("remediation", "See finding remediation guidance."),
                risk=RemediationRisk.MEDIUM.value,
            )
        # Get the bound classmethod and call it
        generator = getattr(cls, method_name)
        return generator(finding, resource_arn, resource_type, resource_name, region)

    # ─── Template generators ───

    @classmethod
    def _fix_s3_public_acl(cls, finding, arn, rtype, name, region):
        """CIS-AWS-2.4: Remove public ACL from S3 bucket."""
        bucket_name = name or arn.split(":")[-1]
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Remove public ACL from S3 bucket '{bucket_name}'",
            action_type=RemediationType.AWS_CLI.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            cli_command=f"aws s3api put-bucket-acl --bucket {bucket_name} --acl private --region {region}",
            risk=RemediationRisk.LOW.value,
            reversible=True,
            backup_required=True,
            estimated_downtime_seconds=0,
        )

    @classmethod
    def _fix_s3_encryption(cls, finding, arn, rtype, name, region):
        """CIS-AWS-2.2: Enable SSE-S3 encryption on bucket."""
        bucket_name = name or arn.split(":")[-1]
        terraform = f'''resource "aws_s3_bucket_server_side_encryption_configuration" "{name}_encryption" {{
  bucket = aws_s3_bucket.{name}.id

  rule {{
    apply_server_side_encryption_by_default {{
      sse_algorithm = "AES256"
    }}
  }}
}}'''
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Enable SSE-S3 encryption on bucket '{bucket_name}'",
            action_type=RemediationType.AWS_CLI.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            cli_command=f'aws s3api put-bucket-encryption --bucket {bucket_name} --region {region} '
                       f'--server-side-encryption-configuration \'{{"Rules":[{{"ApplyServerSideEncryptionByDefault":{{"SSEAlgorithm":"AES256"}}}}]}}\'',
            terraform_config=terraform,
            risk=RemediationRisk.LOW.value,
            reversible=True,
            backup_required=False,
            estimated_downtime_seconds=0,
        )

    @classmethod
    def _fix_s3_versioning(cls, finding, arn, rtype, name, region):
        """CIS-AWS-2.3: Enable versioning on S3 bucket."""
        bucket_name = name or arn.split(":")[-1]
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Enable versioning on S3 bucket '{bucket_name}'",
            action_type=RemediationType.AWS_CLI.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            cli_command=f'aws s3api put-bucket-versioning --bucket {bucket_name} --region {region} '
                       f'--versioning-configuration Status=Enabled',
            risk=RemediationRisk.LOW.value,
            reversible=True,
            backup_required=False,
        )

    @classmethod
    def _fix_sg_ssh_open(cls, finding, arn, rtype, name, region):
        """CIS-AWS-5.1: Restrict SSH access."""
        sg_id = name or arn.split("/")[-1]
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Revoke SSH (port 22) rule open to 0.0.0.0/0 in '{sg_id}'",
            action_type=RemediationType.AWS_CLI.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            cli_command=f'aws ec2 revoke-security-group-ingress --group-id {sg_id} --region {region} '
                       f'--protocol tcp --port 22 --cidr 0.0.0.0/0',
            risk=RemediationRisk.MEDIUM.value,
            reversible=True,
            backup_required=True,
            estimated_downtime_seconds=0,
        )

    @classmethod
    def _fix_sg_rdp_open(cls, finding, arn, rtype, name, region):
        """CIS-AWS-5.2: Restrict RDP access."""
        sg_id = name or arn.split("/")[-1]
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Revoke RDP (port 3389) rule open to 0.0.0.0/0 in '{sg_id}'",
            action_type=RemediationType.AWS_CLI.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            cli_command=f'aws ec2 revoke-security-group-ingress --group-id {sg_id} --region {region} '
                       f'--protocol tcp --port 3389 --cidr 0.0.0.0/0',
            risk=RemediationRisk.MEDIUM.value,
            reversible=True,
            backup_required=True,
        )

    @classmethod
    def _fix_sg_all_traffic(cls, finding, arn, rtype, name, region):
        """CIS-AWS-5.3: Remove all-traffic rule."""
        sg_id = name or arn.split("/")[-1]
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Revoke all-traffic ingress rule in '{sg_id}'",
            action_type=RemediationType.AWS_CLI.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            cli_command=f'aws ec2 revoke-security-group-ingress --group-id {sg_id} --region {region} '
                       f'--ip-permissions IpProtocol=-1,FromPort=0,ToPort=65535,IpRanges=[{{CidrIp=0.0.0.0/0}}]',
            risk=RemediationRisk.HIGH.value,
            reversible=True,
            backup_required=True,
            estimated_downtime_seconds=5,
        )

    @classmethod
    def _fix_iam_no_mfa(cls, finding, arn, rtype, name, region):
        """CIS-AWS-1.3: Enable MFA for IAM user."""
        user_name = name or arn.split("/")[-1]
        manual = f"""To enable MFA for IAM user '{user_name}':
1. AWS Console → IAM → Users → {user_name} → Security credentials
2. Click "Assign MFA device"
3. Choose Virtual MFA device
4. Scan QR code with Google Authenticator / Authy
5. Enter two consecutive codes

Or via CLI:
  aws iam create-virtual-mfa-device --path / --virtual-mfa-device-name {user_name}-mfa --outfile /tmp/{user_name}.png --bootstrap-method QRCodePNG
  aws iam enable-mfa-device --user-name {user_name} --serial-number arn:aws:iam::ACCOUNT:mfa/{user_name}-mfa --authentication-code-1 CODE1 --authentication-code-2 CODE2
"""
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Enable MFA for IAM user '{user_name}'",
            action_type=RemediationType.MANUAL.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            manual_instructions=manual,
            risk=RemediationRisk.LOW.value,
            reversible=False,
            backup_required=False,
        )

    @classmethod
    def _fix_iam_admin_policy(cls, finding, arn, rtype, name, region):
        """CIS-AWS-1.10: Remove AdministratorAccess."""
        policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess"
        target = name or arn.split("/")[-1]
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Detach AdministratorAccess from '{target}'",
            action_type=RemediationType.AWS_CLI.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            cli_command=f"aws iam detach-role-policy --role-name {target} --policy-arn {policy_arn}"
                       if rtype == "aws_iam_role"
                       else f"aws iam detach-user-policy --user-name {target} --policy-arn {policy_arn}",
            risk=RemediationRisk.HIGH.value,
            reversible=True,
            backup_required=True,
            estimated_downtime_seconds=10,
        )

    @classmethod
    def _fix_rds_public(cls, finding, arn, rtype, name, region):
        """CIS-AWS-6.6: Make RDS private."""
        db_id = name or arn.split(":")[-1]
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Set RDS instance '{db_id}' to non-publicly-accessible",
            action_type=RemediationType.AWS_CLI.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            cli_command=f"aws rds modify-db-instance --db-instance-identifier {db_id} --no-publicly-accessible --apply-immediately --region {region}",
            risk=RemediationRisk.MEDIUM.value,
            reversible=True,
            backup_required=True,
            estimated_downtime_seconds=300,
        )

    @classmethod
    def _fix_rds_encryption(cls, finding, arn, rtype, name, region):
        """CIS-AWS-6.3: Enable RDS encryption (requires snapshot+restore)."""
        db_id = name or arn.split(":")[-1]
        manual = f"""RDS encryption cannot be enabled on an existing instance. You must:

1. Create encrypted snapshot:
   aws rds create-db-snapshot --db-instance-identifier {db_id} --db-snapshot-identifier {db_id}-encrypted-snapshot

2. Copy snapshot with encryption:
   aws rds copy-db-snapshot --source-db-snapshot-identifier {db_id}-encrypted-snapshot --target-db-snapshot-identifier {db_id}-encrypted-copy --kms-key-id alias/aws/rds

3. Restore new encrypted instance:
   aws rds restore-db-instance-from-db-snapshot --db-instance-identifier {db_id}-encrypted --db-snapshot-identifier {db_id}-encrypted-copy

4. Update application to use new instance endpoint
5. Delete old instance:
   aws rds delete-db-instance --db-instance-identifier {db_id}

This process takes 30 minutes to several hours depending on database size.
"""
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Enable RDS encryption for '{db_id}' (requires migration)",
            action_type=RemediationType.MANUAL.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            manual_instructions=manual,
            risk=RemediationRisk.CRITICAL.value,
            reversible=False,
            backup_required=True,
            estimated_downtime_seconds=3600,
        )

    @classmethod
    def _fix_eks_secrets_encryption(cls, finding, arn, rtype, name, region):
        """CIS-AWS-6.9: Enable EKS secrets encryption (requires new cluster)."""
        manual = f"""EKS secrets encryption cannot be enabled on an existing cluster. Options:

Option A: Create new cluster with encryption (recommended):
  eksctl create cluster \\
    --name {name}-encrypted \\
    --encryption-config resources=secrets,kmsKeyID=alias/eks-secrets

Option B: Use AWS CLI to update cluster config (only works if encryption was enabled at creation):
  aws eks update-cluster-config --name {name} --encryption-config 'resources=["secrets"],provider=providers=masterArn=arn:aws:kms:...'

After creating new cluster, migrate workloads via blue/green deployment.
"""
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Enable EKS secrets encryption for '{name}'",
            action_type=RemediationType.MANUAL.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            manual_instructions=manual,
            risk=RemediationRisk.CRITICAL.value,
            reversible=False,
            backup_required=True,
        )

    @classmethod
    def _fix_ebs_encryption(cls, finding, arn, rtype, name, region):
        """CIS-AWS-6.1: Enable account-level EBS encryption by default."""
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description="Enable EBS encryption by default at account level",
            action_type=RemediationType.AWS_CLI.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            cli_command=f"aws ec2 enable-ebs-encryption-by-default --region {region}",
            risk=RemediationRisk.LOW.value,
            reversible=True,
            backup_required=False,
        )

    @classmethod
    def _fix_kms_rotation(cls, finding, arn, rtype, name, region):
        """Enable KMS key rotation."""
        key_id = name or arn.split("/")[-1]
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Enable annual rotation for KMS key '{key_id}'",
            action_type=RemediationType.AWS_CLI.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            cli_command=f"aws kms enable-key-rotation --key-id {key_id} --region {region}",
            risk=RemediationRisk.LOW.value,
            reversible=False,
            backup_required=False,
        )

    @classmethod
    def _fix_lambda_public(cls, finding, arn, rtype, name, region):
        """Make Lambda function private (remove public permission)."""
        func_name = name or arn.split(":")[-1]
        manual = f"""To remove public access from Lambda '{func_name}':

1. List permissions:
   aws lambda get-policy --function-name {func_name} --region {region}

2. Identify the public permission (Principal: '*' or account '*')
3. Remove that statement:
   aws lambda remove-permission --function-name {func_name} --statement-id PUBLIC-ACCESS --region {region}

4. Verify:
   aws lambda get-policy --function-name {func_name} --region {region}
"""
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description=f"Remove public access from Lambda '{func_name}'",
            action_type=RemediationType.MANUAL.value,
            target_resource_arn=arn,
            target_resource_type=rtype,
            target_resource_name=name,
            target_region=region,
            manual_instructions=manual,
            risk=RemediationRisk.MEDIUM.value,
            reversible=True,
            backup_required=True,
        )

    @classmethod
    def _fix_root_no_mfa(cls, finding, arn, rtype, name, region):
        """CIS-AWS-1.2: Enable root MFA (manual, requires root login)."""
        manual = """To enable MFA on the root account:
1. Sign in as root: https://YOUR_ACCOUNT.signin.aws.amazon.com/console
2. Click your account name → Security credentials
3. Click "Assign MFA device"
4. Choose Virtual MFA (recommended) or Hardware MFA
5. Follow the wizard to scan QR code and enter two consecutive codes

This MUST be done as root — no IAM user (even admin) can enable root MFA.
"""
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description="Enable MFA on root account",
            action_type=RemediationType.MANUAL.value,
            target_resource_arn=arn or "arn:aws:iam::ROOT",
            target_resource_type=rtype,
            target_resource_name="root",
            target_region=region,
            manual_instructions=manual,
            risk=RemediationRisk.LOW.value,
            reversible=False,
            backup_required=False,
        )

    @classmethod
    def _fix_root_access_keys(cls, finding, arn, rtype, name, region):
        """CIS-AWS-1.16: Delete root access keys (manual, requires root login)."""
        manual = """To delete root access keys:
1. Sign in as root
2. Go to Security credentials
3. Find "Access keys (access key ID and secret access key)"
4. Click "Delete" next to each access key
5. If services use root keys, replace with IAM role credentials first
"""
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description="Delete root access keys",
            action_type=RemediationType.MANUAL.value,
            target_resource_arn=arn or "arn:aws:iam::ROOT",
            target_resource_type=rtype,
            target_resource_name="root",
            target_region=region,
            manual_instructions=manual,
            risk=RemediationRisk.HIGH.value,
            reversible=False,
            backup_required=True,
        )

    @classmethod
    def _fix_cloudtrail_enable(cls, finding, arn, rtype, name, region):
        """CIS-AWS-3.1: Enable CloudTrail."""
        terraform = '''resource "aws_cloudtrail" "sentinel" {
  name                          = "sentinel-cloudtrail"
  s3_bucket_name                = aws_s3_bucket.cloudtrail_logs.id
  include_global_service_events = true
  is_multi_region_trail         = true
  enable_log_file_validation    = true
  kms_key_id                    = aws_kms_key.cloudtrail.arn

  event_selector {
    read_write_type           = "All"
    include_management_events = true
  }

  depends_on = [aws_s3_bucket_policy.cloudtrail]
}

resource "aws_s3_bucket" "cloudtrail_logs" {
  bucket = "sentinel-cloudtrail-logs-${data.aws_caller_identity.current.account_id}"
}

resource "aws_kms_key" "cloudtrail" {
  description             = "KMS key for CloudTrail encryption"
  enable_key_rotation     = true
  deletion_window_in_days = 30
}'''
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description="Enable multi-region CloudTrail with KMS encryption",
            action_type=RemediationType.TERRAFORM_APPLY.value,
            target_resource_arn=arn or "aws::account",
            target_resource_type=rtype,
            target_resource_name="cloudtrail",
            target_region=region,
            terraform_config=terraform,
            risk=RemediationRisk.LOW.value,
            reversible=True,
            backup_required=False,
        )

    @classmethod
    def _fix_password_policy(cls, finding, arn, rtype, name, region):
        """CIS-AWS-1.5: Set strong IAM password policy."""
        return RemediationAction(
            action_id=str(uuid.uuid4()),
            description="Update IAM password policy (14+ chars, complexity, reuse prevention)",
            action_type=RemediationType.AWS_CLI.value,
            target_resource_arn=arn or "arn:aws:iam::account",
            target_resource_type=rtype,
            target_resource_name="account",
            target_region=region,
            cli_command=(
                "aws iam update-account-password-policy "
                "--minimum-password-length 14 "
                "--require-symbols --require-numbers --require-uppercase-characters --require-lowercase-characters "
                "--allow-users-to-change-password "
                "--max-password-age 90 --password-reuse-prevention 24"
            ),
            risk=RemediationRisk.LOW.value,
            reversible=True,
            backup_required=False,
        )

    # Rule ID → method name map (avoids classmethod binding issues)
    _RULE_MAP = {
        "CIS-AWS-1.2": "_fix_root_no_mfa",
        "CIS-AWS-1.3": "_fix_iam_no_mfa",
        "CIS-AWS-1.5": "_fix_password_policy",
        "CIS-AWS-1.10": "_fix_iam_admin_policy",
        "CIS-AWS-1.16": "_fix_root_access_keys",
        "CIS-AWS-2.2": "_fix_s3_encryption",
        "CIS-AWS-2.3": "_fix_s3_versioning",
        "CIS-AWS-2.4": "_fix_s3_public_acl",
        "CIS-AWS-3.1": "_fix_cloudtrail_enable",
        "CIS-AWS-5.1": "_fix_sg_ssh_open",
        "CIS-AWS-5.2": "_fix_sg_rdp_open",
        "CIS-AWS-5.3": "_fix_sg_all_traffic",
        "CIS-AWS-6.1": "_fix_ebs_encryption",
        "CIS-AWS-6.3": "_fix_rds_encryption",
        "CIS-AWS-6.6": "_fix_rds_public",
        "CIS-AWS-6.9": "_fix_eks_secrets_encryption",
        "CIS-AWS-6.10": "_fix_lambda_public",
    }


# ═══════════════════════════════════════════════════════════════
# Tier Selection Logic
# ═══════════════════════════════════════════════════════════════

class TierSelector:
    """Decides which remediation tier (SUGGEST/APPROVAL/AUTO) to use.

    Decision factors:
      - Risk level: LOW → can auto-apply, CRITICAL → suggest only
      - Reversibility: reversible → can auto-apply, irreversible → suggest only
      - Estimated downtime: 0s → auto, >5min → suggest
      - Finding severity: critical findings → faster tier
      - Tenant policy: tenant can override defaults
    """

    @classmethod
    def select_tier(cls, action: RemediationAction, finding_severity: str = "medium",
                   tenant_policy: Optional[dict] = None) -> RemediationTier:
        tenant_policy = tenant_policy or {}

        # Force manual for critical risk or irreversible
        if action.risk == RemediationRisk.CRITICAL.value or not action.reversible:
            return RemediationTier.SUGGEST

        # Force manual if high downtime
        if action.estimated_downtime_seconds > 300:  # 5 min
            return RemediationTier.SUGGEST

        # HIGH risk → approval required
        if action.risk == RemediationRisk.HIGH.value:
            return RemediationTier.APPROVAL

        # MEDIUM risk → approval (conservative default)
        if action.risk == RemediationRisk.MEDIUM.value:
            # Auto-apply for critical findings if tenant allows
            if finding_severity == "critical" and tenant_policy.get("auto_remediate_critical", False):
                return RemediationTier.AUTO
            return RemediationTier.APPROVAL

        # LOW risk → can auto-apply
        if action.risk == RemediationRisk.LOW.value:
            # Check tenant policy: do they want auto-remediation for low risk?
            if tenant_policy.get("auto_remediate_low", True):
                return RemediationTier.AUTO
            return RemediationTier.APPROVAL

        return RemediationTier.SUGGEST


# ═══════════════════════════════════════════════════════════════
# Remediator Engine
# ═══════════════════════════════════════════════════════════════

class RemediatorEngine:
    """3-tier auto-remediation engine.

    Workflow:
      1. plan_for_findings(): generate RemediationPlan from findings
      2. approve(plan_id): human approves (Tier 2)
      3. apply(plan_id): execute the plan
      4. verify(plan_id): re-scan to confirm
      5. rollback(plan_id): restore state if verification fails
    """

    def __init__(self):
        self._plans: dict[str, RemediationPlan] = {}
        self._lock = threading.RLock()
        self._tenant_policies: dict[str, dict[str, Any]] = {}
        self._stats = {
            "total_plans": 0,
            "total_applied": 0,
            "total_verified": 0,
            "total_failed": 0,
            "total_rolled_back": 0,
        }
        # Rate limits per tenant (per hour)
        self._rate_limits: dict[str, deque] = defaultdict(deque)
        self._max_remediations_per_hour = 50

    def set_tenant_policy(self, tenant_id: str, policy: dict[str, Any]) -> None:
        self._tenant_policies[tenant_id] = policy

    def plan_for_findings(
        self,
        tenant_id: str,
        findings: list[dict[str, Any]],
        created_by: str = "system",
    ) -> RemediationPlan:
        """Generate a remediation plan for a list of findings."""
        actions: list[RemediationAction] = []
        finding_ids: list[str] = []

        for finding in findings:
            action = RemediationTemplates.generate_for_finding(finding)
            if action:
                actions.append(action)
                finding_ids.append(finding.get("id", str(uuid.uuid4())))

        # Determine overall tier (use highest risk action)
        if not actions:
            return RemediationPlan(
                plan_id=str(uuid.uuid4()),
                tenant_id=tenant_id,
                finding_ids=finding_ids,
                title="No remediation needed",
                description="No actions could be generated for the findings.",
                tier=RemediationTier.SUGGEST.value,
                risk=RemediationRisk.LOW.value,
                actions=[],
                created_at=int(time.time() * 1000),
                created_by=created_by,
            )

        # Pick the highest risk action
        risk_order = [RemediationRisk.CRITICAL.value, RemediationRisk.HIGH.value,
                      RemediationRisk.MEDIUM.value, RemediationRisk.LOW.value]
        highest_risk = RemediationRisk.LOW.value
        for action in actions:
            if risk_order.index(action.risk) < risk_order.index(highest_risk):
                highest_risk = action.risk

        # Determine tier based on highest risk and tenant policy
        tenant_policy = self._tenant_policies.get(tenant_id, {})
        # Use the first action's tier for the plan
        tier = TierSelector.select_tier(actions[0], findings[0].get("severity", "medium") if findings else "medium", tenant_policy)

        plan = RemediationPlan(
            plan_id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            finding_ids=finding_ids,
            title=f"Remediation for {len(findings)} finding(s)",
            description=f"Generated {len(actions)} action(s) to remediate findings: "
                       f"{', '.join(f[:30] for f in [fd.get('title', '') for fd in findings[:3]])}",
            tier=tier.value,
            risk=highest_risk,
            actions=actions,
            created_at=int(time.time() * 1000),
            created_by=created_by,
            estimated_time_minutes=max(5, sum(a.estimated_downtime_seconds for a in actions) // 60),
        )

        with self._lock:
            self._plans[plan.plan_id] = plan
            self._stats["total_plans"] += 1

        return plan

    def approve(self, plan_id: str, user_id: str, tenant_id: str) -> RemediationPlan:
        """Approve a remediation plan (Tier 2)."""
        with self._lock:
            plan = self._plans.get(plan_id)
            if not plan or plan.tenant_id != tenant_id:
                raise ValueError("Plan not found")
            if plan.status != RemediationStatus.PROPOSED.value:
                raise ValueError(f"Plan is not in PROPOSED state (current: {plan.status})")
            plan.status = RemediationStatus.APPROVED.value
            plan.approved_by = user_id
            plan.approved_at = int(time.time() * 1000)
            return plan

    def reject(self, plan_id: str, user_id: str, tenant_id: str, reason: str = "") -> RemediationPlan:
        with self._lock:
            plan = self._plans.get(plan_id)
            if not plan or plan.tenant_id != tenant_id:
                raise ValueError("Plan not found")
            plan.status = RemediationStatus.REJECTED.value
            plan.failure_reason = reason
            return plan

    def apply(self, plan_id: str, tenant_id: str, dry_run: bool = False) -> RemediationPlan:
        """Apply a remediation plan.

        For Tier 1 (SUGGEST): returns the plan with manual instructions.
        For Tier 2 (APPROVAL): requires prior approval.
        For Tier 3 (AUTO): executes immediately.
        """
        with self._lock:
            plan = self._plans.get(plan_id)
            if not plan or plan.tenant_id != tenant_id:
                raise ValueError("Plan not found")

            # Rate limit check
            if not self._check_rate_limit(tenant_id):
                raise ValueError("Rate limit exceeded for remediations")

            # State machine checks
            if plan.tier == RemediationTier.APPROVAL.value and plan.status != RemediationStatus.APPROVED.value:
                raise ValueError("Approval-required plan must be approved before applying")

            if plan.status in (RemediationStatus.APPLIED.value, RemediationStatus.VERIFIED.value):
                raise ValueError("Plan already applied")

            plan.status = RemediationStatus.APPLYING.value
            plan.applied_at = int(time.time() * 1000)

        # Create backup state for rollback
        backup = self._create_backup(plan)
        with self._lock:
            plan.backup_state = backup

        # Execute actions
        for action in plan.actions:
            if dry_run:
                action.execution_log = f"[DRY RUN] Would execute: {self._describe_action(action)}"
                action.success = True
                continue
            try:
                result = self._execute_action(action)
                action.success = result["success"]
                action.execution_log = result["log"]
                action.executed_at = int(time.time() * 1000)
                if not result["success"]:
                    plan.status = RemediationStatus.FAILED.value
                    plan.failure_reason = f"Action {action.action_id} failed: {result.get('error', 'unknown')}"
                    # Attempt rollback
                    self._rollback(plan)
                    return plan
            except Exception as e:
                action.success = False
                action.execution_log = str(e)
                action.executed_at = int(time.time() * 1000)
                plan.status = RemediationStatus.FAILED.value
                plan.failure_reason = str(e)
                self._rollback(plan)
                return plan

        # All actions succeeded
        with self._lock:
            plan.status = RemediationStatus.APPLIED.value
            self._stats["total_applied"] += 1
            return plan

    def _execute_action(self, action: RemediationAction) -> dict[str, Any]:
        """Execute a single remediation action."""
        if action.action_type == RemediationType.AWS_CLI.value and action.cli_command:
            # In production, this would shell out to aws CLI
            # For safety, we log the command but don't execute (unless explicitly enabled)
            execute = os.environ.get("REMEDIATOR_EXECUTE", "false").lower() == "true"
            if execute:
                try:
                    result = subprocess.run(
                        action.cli_command, shell=True, capture_output=True,
                        text=True, timeout=300,
                    )
                    return {
                        "success": result.returncode == 0,
                        "log": f"CMD: {action.cli_command}\nSTDOUT: {result.stdout}\nSTDERR: {result.stderr}",
                        "error": result.stderr if result.returncode != 0 else None,
                    }
                except subprocess.TimeoutExpired:
                    return {"success": False, "log": "Command timed out", "error": "timeout"}
            else:
                return {
                    "success": True,
                    "log": f"[SIMULATED] Would execute: {action.cli_command}\n"
                           f"Set REMEDIATOR_EXECUTE=true to apply for real.",
                }

        elif action.action_type == RemediationType.TERRAFORM_APPLY.value and action.terraform_config:
            # In production: write to temp dir, terraform init, plan, apply
            return {
                "success": True,
                "log": f"[SIMULATED] Would apply Terraform config:\n{action.terraform_config[:500]}\n"
                       f"Set REMEDIATOR_EXECUTE=true to apply for real.",
            }

        elif action.action_type == RemediationType.MANUAL.value:
            return {
                "success": True,
                "log": f"[MANUAL] Instructions:\n{action.manual_instructions}",
            }

        return {"success": False, "log": "Unknown action type", "error": "unknown_action_type"}

    def _create_backup(self, plan: RemediationPlan) -> dict[str, Any]:
        """Create a backup of current state before applying remediation.

        In production, this would:
          - For AWS CLI: capture current state via `aws ... describe-*`
          - For Terraform: capture `terraform.tfstate` backup
          - For K8s: capture the resource YAML before patching
        """
        return {
            "plan_id": plan.plan_id,
            "backup_at": int(time.time() * 1000),
            "actions": [
                {
                    "action_id": a.action_id,
                    "target_arn": a.target_resource_arn,
                    "cli_command": a.cli_command,
                }
                for a in plan.actions
            ],
            "note": "Backup state for rollback. In production, this would contain actual resource state.",
        }

    def _rollback(self, plan: RemediationPlan) -> None:
        """Roll back all executed actions in reverse order."""
        if not plan.backup_state:
            plan.status = RemediationStatus.ROLLBACK_FAILED.value
            return

        rollback_success = True
        for action in reversed(plan.actions):
            if action.success:
                # In production, this would run the inverse command
                # e.g., if we ran `revoke-security-group-ingress`, the inverse is `authorize-security-group-ingress`
                # with the same parameters from backup_state
                logger.info(f"Rolling back action {action.action_id}")
                # Mark as rolled back (simulated)
                action.success = None  # reset
                action.execution_log = (action.execution_log or "") + "\n[ROLLED BACK]"

        if rollback_success:
            plan.status = RemediationStatus.ROLLED_BACK.value
            self._stats["total_rolled_back"] += 1
        else:
            plan.status = RemediationStatus.ROLLBACK_FAILED.value

    def _check_rate_limit(self, tenant_id: str) -> bool:
        """Check if tenant has exceeded rate limit."""
        now = int(time.time())
        with self._lock:
            reqs = self._rate_limits[tenant_id]
            # Purge entries older than 1 hour
            while reqs and reqs[0] < now - 3600:
                reqs.popleft()
            if len(reqs) >= self._max_remediations_per_hour:
                return False
            reqs.append(now)
            return True

    def _describe_action(self, action: RemediationAction) -> str:
        if action.cli_command:
            return f"CLI: {action.cli_command[:100]}"
        if action.terraform_config:
            return f"Terraform: {len(action.terraform_config)} chars"
        if action.manual_instructions:
            return f"Manual: {action.manual_instructions[:100]}"
        return f"Unknown action type: {action.action_type}"

    def get_plan(self, plan_id: str, tenant_id: str) -> Optional[RemediationPlan]:
        with self._lock:
            plan = self._plans.get(plan_id)
            return plan if plan and plan.tenant_id == tenant_id else None

    def list_plans(self, tenant_id: str, status: Optional[str] = None,
                  limit: int = 100) -> list[RemediationPlan]:
        with self._lock:
            plans = [p for p in self._plans.values() if p.tenant_id == tenant_id]
        if status:
            plans = [p for p in plans if p.status == status]
        plans.sort(key=lambda p: p.created_at, reverse=True)
        return plans[:limit]

    def get_stats(self) -> dict[str, Any]:
        with self._lock:
            return {
                **self._stats,
                "active_plans": len([p for p in self._plans.values()
                                    if p.status in (RemediationStatus.PROPOSED.value,
                                                   RemediationStatus.APPROVED.value,
                                                   RemediationStatus.APPLYING.value)]),
            }

    def list_templates(self) -> list[dict[str, Any]]:
        """List all remediation templates."""
        return [
            {"rule_id": "CIS-AWS-1.2", "title": "Enable root MFA", "tier": "SUGGEST", "risk": "LOW"},
            {"rule_id": "CIS-AWS-1.3", "title": "Enable IAM user MFA", "tier": "SUGGEST", "risk": "LOW"},
            {"rule_id": "CIS-AWS-1.5", "title": "Set password policy", "tier": "AUTO", "risk": "LOW"},
            {"rule_id": "CIS-AWS-1.10", "title": "Detach AdministratorAccess", "tier": "APPROVAL", "risk": "HIGH"},
            {"rule_id": "CIS-AWS-1.16", "title": "Delete root access keys", "tier": "SUGGEST", "risk": "HIGH"},
            {"rule_id": "CIS-AWS-2.2", "title": "Enable S3 encryption", "tier": "AUTO", "risk": "LOW"},
            {"rule_id": "CIS-AWS-2.3", "title": "Enable S3 versioning", "tier": "AUTO", "risk": "LOW"},
            {"rule_id": "CIS-AWS-2.4", "title": "Remove S3 public ACL", "tier": "AUTO", "risk": "LOW"},
            {"rule_id": "CIS-AWS-3.1", "title": "Enable CloudTrail", "tier": "APPROVAL", "risk": "LOW"},
            {"rule_id": "CIS-AWS-5.1", "title": "Restrict SSH access", "tier": "APPROVAL", "risk": "MEDIUM"},
            {"rule_id": "CIS-AWS-5.2", "title": "Restrict RDP access", "tier": "APPROVAL", "risk": "MEDIUM"},
            {"rule_id": "CIS-AWS-5.3", "title": "Remove all-traffic rule", "tier": "APPROVAL", "risk": "HIGH"},
            {"rule_id": "CIS-AWS-6.1", "title": "Enable EBS encryption", "tier": "AUTO", "risk": "LOW"},
            {"rule_id": "CIS-AWS-6.3", "title": "Enable RDS encryption", "tier": "SUGGEST", "risk": "CRITICAL"},
            {"rule_id": "CIS-AWS-6.6", "title": "Make RDS private", "tier": "APPROVAL", "risk": "MEDIUM"},
            {"rule_id": "CIS-AWS-6.9", "title": "Enable EKS secrets encryption", "tier": "SUGGEST", "risk": "CRITICAL"},
            {"rule_id": "CIS-AWS-6.10", "title": "Make Lambda private", "tier": "APPROVAL", "risk": "MEDIUM"},
        ]


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_engine: Optional[RemediatorEngine] = None
_global_lock = threading.Lock()


def get_remediator_engine() -> RemediatorEngine:
    global _global_engine
    if _global_engine is None:
        with _global_lock:
            if _global_engine is None:
                _global_engine = RemediatorEngine()
    return _global_engine
