"""
Centralized exception hierarchy with error codes.

Every exception has:
- Error code (machine-readable)
- Message (human-readable)
- HTTP status (for API mapping)
- Category (for logging/metrics)
"""
from __future__ import annotations

from typing import Any, Optional


class ErrorCode:
    """Machine-readable error codes for structured error handling."""
    # Authentication
    AUTH_INVALID_CREDENTIALS = "AUTH_001"
    AUTH_TOKEN_EXPIRED = "AUTH_002"
    AUTH_TOKEN_INVALID = "AUTH_003"
    AUTH_MFA_REQUIRED = "AUTH_004"
    AUTH_MFA_INVALID = "AUTH_005"
    AUTH_ACCOUNT_LOCKED = "AUTH_006"
    AUTH_SESSION_EXPIRED = "AUTH_007"
    AUTH_PERMISSION_DENIED = "AUTH_008"

    # Authorization
    AUTHZ_INSUFFICIENT_PERMISSIONS = "AUTHZ_001"
    AUTHZ_TENANT_ACCESS_DENIED = "AUTHZ_002"
    AUTHZ_RESOURCE_ACCESS_DENIED = "AUTHZ_003"

    # Cloud Account
    CLOUD_ACCOUNT_NOT_FOUND = "CLOUD_001"
    CLOUD_ACCOUNT_DISCONNECTED = "CLOUD_002"
    CLOUD_ACCOUNT_LIMIT_EXCEEDED = "CLOUD_003"

    # Credential
    CREDENTIAL_NOT_FOUND = "CRED_001"
    CREDENTIAL_EXPIRED = "CRED_002"
    CREDENTIAL_INVALID = "CRED_003"
    CREDENTIAL_ENCRYPTION_FAILED = "CRED_004"
    CREDENTIAL_DECRYPTION_FAILED = "CRED_005"
    CREDENTIAL_ASSUME_ROLE_FAILED = "CRED_006"
    CREDENTIAL_TRUST_VALIDATION_FAILED = "CRED_007"

    # Scanner
    SCANNER_NOT_FOUND = "SCAN_001"
    SCANNER_FAILED = "SCAN_002"
    SCANNER_TIMEOUT = "SCAN_003"
    SCANNER_RATE_LIMITED = "SCAN_004"
    SCANNER_REGION_UNAVAILABLE = "SCAN_005"
    SCANNER_PLUGIN_ERROR = "SCAN_006"

    # Rule Engine
    RULE_NOT_FOUND = "RULE_001"
    RULE_DSL_PARSE_ERROR = "RULE_002"
    RULE_EXECUTION_ERROR = "RULE_003"
    RULE_VERSION_CONFLICT = "RULE_004"

    # Finding
    FINDING_NOT_FOUND = "FIND_001"
    FINDING_ALREADY_CLOSED = "FIND_002"
    FINDING_FINGERPRINT_CONFLICT = "FIND_003"

    # Compliance
    COMPLIANCE_FRAMEWORK_NOT_FOUND = "COMP_001"
    COMPLIANCE_CONTROL_NOT_FOUND = "COMP_002"

    # Database
    DB_CONNECTION_ERROR = "DB_001"
    DB_QUERY_ERROR = "DB_002"
    DB_TRANSACTION_ERROR = "DB_003"
    DB_MIGRATION_ERROR = "DB_004"

    # Validation
    VALIDATION_ERROR = "VAL_001"
    INVALID_INPUT = "VAL_002"

    # Rate Limiting
    RATE_LIMIT_EXCEEDED = "RATE_001"

    # Internal
    INTERNAL_ERROR = "INT_001"
    SERVICE_UNAVAILABLE = "INT_002"
    CIRCUIT_BREAKER_OPEN = "INT_003"


class CNAPPException(Exception):
    """Base exception for all CNAPP platform errors."""

    def __init__(
        self,
        code: str,
        message: str,
        http_status: int = 500,
        category: str = "internal",
        details: dict[str, Any] | None = None,
    ):
        self.code = code
        self.message = message
        self.http_status = http_status
        self.category = category
        self.details = details or {}
        super().__init__(f"[{code}] {message}")

    def to_dict(self) -> dict[str, Any]:
        return {
            "error": {
                "code": self.code,
                "message": self.message,
                "category": self.category,
                "details": self.details,
            }
        }


class AuthenticationException(CNAPPException):
    def __init__(self, code: str = ErrorCode.AUTH_INVALID_CREDENTIALS, message: str = "Authentication failed", **kwargs):
        super().__init__(code, message, http_status=401, category="authentication", **kwargs)


class AuthorizationException(CNAPPException):
    def __init__(self, code: str = ErrorCode.AUTHZ_INSUFFICIENT_PERMISSIONS, message: str = "Insufficient permissions", **kwargs):
        super().__init__(code, message, http_status=403, category="authorization", **kwargs)


class CredentialException(CNAPPException):
    def __init__(self, code: str = ErrorCode.CREDENTIAL_INVALID, message: str = "Credential error", **kwargs):
        super().__init__(code, message, http_status=400, category="credential", **kwargs)


class ScannerException(CNAPPException):
    def __init__(self, code: str = ErrorCode.SCANNER_FAILED, message: str = "Scanner error", **kwargs):
        super().__init__(code, message, http_status=500, category="scanner", **kwargs)


class RuleException(CNAPPException):
    def __init__(self, code: str = ErrorCode.RULE_EXECUTION_ERROR, message: str = "Rule engine error", **kwargs):
        super().__init__(code, message, http_status=500, category="rule_engine", **kwargs)


class ValidationException(CNAPPException):
    def __init__(self, message: str = "Validation error", details: dict[str, Any] | None = None):
        super().__init__(ErrorCode.VALIDATION_ERROR, message, http_status=400, category="validation", details=details)


class NotFoundException(CNAPPException):
    def __init__(self, resource: str, resource_id: str = ""):
        msg = f"{resource} not found" + (f": {resource_id}" if resource_id else "")
        super().__init__(f"NOT_FOUND_{resource.upper()}", msg, http_status=404, category="not_found")


class RateLimitException(CNAPPException):
    def __init__(self, retry_after: int = 60):
        super().__init__(
            ErrorCode.RATE_LIMIT_EXCEEDED,
            f"Rate limit exceeded. Retry after {retry_after} seconds.",
            http_status=429,
            category="rate_limit",
            details={"retry_after": retry_after},
        )


class CircuitBreakerException(CNAPPException):
    def __init__(self, service: str):
        super().__init__(
            ErrorCode.CIRCUIT_BREAKER_OPEN,
            f"Circuit breaker open for service: {service}",
            http_status=503,
            category="circuit_breaker",
            details={"service": service},
        )
