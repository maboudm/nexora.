"""
Core domain models for the Enterprise CNAPP platform.

Based on Part 9 — Universal Asset Model and Part 7 — DDD Bounded Contexts.

All models are immutable dataclasses with type hints.
No business logic here — only data structures.
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


# ═══════════════════════════════════════════════════════════════
# Enums
# ═══════════════════════════════════════════════════════════════

class CloudProvider(str, Enum):
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
    ORACLE = "oracle"
    ALIBABA = "alibaba"
    DIGITALOCEAN = "digitalocean"
    KUBERNETES = "kubernetes"
    DOCKER = "docker"


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ScanStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PARTIAL = "partial"


class ScanTrigger(str, Enum):
    MANUAL = "manual"
    SCHEDULED = "scheduled"
    EVENT = "event"
    API = "api"
    WEBHOOK = "webhook"


class FindingStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    SUPPRESSED = "suppressed"
    FALSE_POSITIVE = "false_positive"
    RISK_ACCEPTED = "risk_accepted"
    CLOSED = "closed"


class CredentialType(str, Enum):
    ASSUME_ROLE = "assume_role"
    ACCESS_KEY = "access_key"
    SERVICE_PRINCIPAL = "service_principal"
    SERVICE_ACCOUNT = "service_account"
    MANAGED_IDENTITY = "managed_identity"
    WORKLOAD_IDENTITY = "workload_identity"


class CredentialStatus(str, Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    ROTATED = "rotated"
    REVOKED = "revoked"


class AssetState(str, Enum):
    ACTIVE = "active"
    STOPPED = "stopped"
    TERMINATED = "terminated"
    DELETED = "deleted"


class Criticality(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    MINIMAL = "minimal"


class RiskLevel(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


# ═══════════════════════════════════════════════════════════════
# Universal Asset Model (Part 9)
# ═══════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class Asset:
    """Universal Asset Model — provider-agnostic representation of any cloud resource.

    All cloud resources (AWS EC2, Azure VM, GCP Compute, S3, Blob, etc.)
    are normalized into this model so the Rule Engine is provider-independent.
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tenant_id: str = ""
    workspace_id: str = ""
    cloud_account_id: str = ""
    scan_id: str = ""
    provider: str = ""           # aws | azure | gcp
    service: str = ""            # ec2 | s3 | iam | lambda | rds | eks
    resource_type: str = ""      # aws_ec2_instance | aws_s3_bucket (normalized)
    external_id: str = ""        # cloud provider's resource ID
    arn: str = ""
    name: str = ""
    region: str = ""
    tags: dict[str, str] = field(default_factory=dict)
    labels: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    state: str = "active"
    owner: Optional[str] = None
    criticality: str = "medium"
    business_unit: Optional[str] = None
    application: Optional[str] = None
    environment: Optional[str] = None
    cost_center: Optional[str] = None
    compliance: dict[str, str] = field(default_factory=dict)
    risk_score: float = 0.0
    risk_level: str = "low"
    internet_exposed: bool = False
    sensitive_data: bool = False
    first_seen_at: float = field(default_factory=lambda: time.time())
    last_seen_at: float = field(default_factory=lambda: time.time())
    version: int = 1

    def fingerprint(self) -> str:
        """Generate a deterministic fingerprint for deduplication."""
        data = f"{self.provider}:{self.resource_type}:{self.arn}:{json.dumps(self.metadata, sort_keys=True, default=str)}"
        return hashlib.sha256(data.encode()).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AssetRelationship:
    """Directed edge in the asset relationship graph."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    from_asset_arn: str = ""
    to_asset_arn: str = ""
    relationship_type: str = ""  # owns | can_access | connected_to | runs_on | contains | depends_on | trusts | uses | creates | deletes
    properties: dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=lambda: time.time())


# ═══════════════════════════════════════════════════════════════
# Finding Model
# ═══════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class Finding:
    """Security finding generated by the rule engine."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tenant_id: str = ""
    workspace_id: str = ""
    scan_id: str = ""
    asset_id: str = ""
    asset_arn: str = ""
    rule_id: str = ""
    title: str = ""
    description: str = ""
    severity: str = "medium"
    category: str = ""
    compliance: list[str] = field(default_factory=list)
    cvss_score: float = 0.0
    cvss_vector: Optional[str] = None
    epss_score: float = 0.0
    cve_ids: list[str] = field(default_factory=list)
    mitre_attack_ids: list[str] = field(default_factory=list)
    remediation: str = ""
    remediation_steps: list[dict[str, str]] = field(default_factory=list)
    evidence: dict[str, Any] = field(default_factory=dict)
    status: str = "open"
    risk_score: float = 0.0
    risk_level: str = "low"
    risk_factors: dict[str, float] = field(default_factory=dict)
    blast_radius: dict[str, Any] = field(default_factory=dict)
    fingerprint: str = ""
    first_seen_at: float = field(default_factory=lambda: time.time())
    last_seen_at: float = field(default_factory=lambda: time.time())
    sla_deadline: Optional[float] = None
    sla_breached: bool = False

    def compute_fingerprint(self) -> str:
        """Deterministic fingerprint for deduplication across scans."""
        data = f"{self.rule_id}:{self.asset_arn}:{json.dumps(self.evidence, sort_keys=True, default=str)}"
        return hashlib.sha256(data.encode()).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# ═══════════════════════════════════════════════════════════════
# Scan Models
# ═══════════════════════════════════════════════════════════════

@dataclass
class ScanRequest:
    """Request to start a scan."""
    tenant_id: str
    workspace_id: str
    cloud_account_id: str
    scanners: list[str] = field(default_factory=lambda: ["iam", "s3", "sg", "k8s"])
    regions: list[str] = field(default_factory=list)
    trigger: str = "manual"
    trigger_metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ScanResult:
    """Result of a completed scan."""
    scan_id: str
    tenant_id: str
    workspace_id: str
    status: str = "completed"
    scan_mode: str = "real"
    scanners_run: list[str] = field(default_factory=list)
    duration_ms: int = 0
    assets: list[Asset] = field(default_factory=list)
    relationships: list[AssetRelationship] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)
    attack_paths: list[dict[str, Any]] = field(default_factory=list)
    severity_counts: dict[str, int] = field(default_factory=lambda: {"critical": 0, "high": 0, "medium": 0, "low": 0})
    category_counts: dict[str, int] = field(default_factory=dict)
    compliance_counts: dict[str, int] = field(default_factory=dict)
    total_findings: int = 0
    total_assets: int = 0
    total_attack_paths: int = 0
    posture_score: float = 0.0
    regions_scanned: int = 0
    apis_called: int = 0
    error: Optional[str] = None

    def compute_summary(self):
        """Compute summary statistics from findings."""
        self.total_findings = len(self.findings)
        self.total_assets = len(self.assets)
        self.total_attack_paths = len(self.attack_paths)

        self.severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        self.category_counts = {}
        self.compliance_counts = {}

        for f in self.findings:
            self.severity_counts[f.severity] = self.severity_counts.get(f.severity, 0) + 1
            self.category_counts[f.category] = self.category_counts.get(f.category, 0) + 1
            for c in f.compliance:
                self.compliance_counts[c] = self.compliance_counts.get(c, 0) + 1

        # Posture score: 100 × exp(-0.05 × weighted_findings)
        import math
        weighted = (
            self.severity_counts.get("critical", 0) * 4 +
            self.severity_counts.get("high", 0) * 2 +
            self.severity_counts.get("medium", 0) * 1 +
            self.severity_counts.get("low", 0) * 0.3
        )
        self.posture_score = max(0, min(100, 100 * math.exp(-0.05 * weighted)))


# ═══════════════════════════════════════════════════════════════
# Credential Model
# ═══════════════════════════════════════════════════════════════

@dataclass
class CredentialConfig:
    """Configuration for accessing a cloud account."""
    cloud_account_id: str
    provider: str = "aws"
    credential_type: str = "assume_role"
    # AWS AssumeRole
    role_arn: str = ""
    external_id: str = ""
    session_name: str = "sentinel-scanner"
    session_duration: int = 3600  # seconds
    # AWS Direct Credentials
    access_key_id: str = ""
    secret_access_key: str = ""
    session_token: str = ""
    # Azure
    client_id: str = ""
    client_secret: str = ""
    tenant_id: str = ""
    subscription_id: str = ""
    # GCP
    project_id: str = ""
    private_key: str = ""
    # Session tags (ABAC)
    session_tags: dict[str, str] = field(default_factory=dict)
    # MFA
    mfa_serial: str = ""
    mfa_token: str = ""


@dataclass
class SessionCredentials:
    """Active session credentials obtained from STS or direct."""
    access_key_id: str = ""
    secret_access_key: str = ""
    session_token: str = ""
    expiry: float = 0.0  # Unix timestamp
    account_id: str = ""
    region: str = "us-east-1"

    @property
    def is_expired(self) -> bool:
        return time.time() >= (self.expiry - 300)  # 5-min buffer

    @property
    def is_valid(self) -> bool:
        return bool(self.access_key_id and self.secret_access_key and not self.is_expired)


# ═══════════════════════════════════════════════════════════════
# Rule Model
# ═══════════════════════════════════════════════════════════════

@dataclass
class Rule:
    """Security rule definition."""
    rule_id: str = ""
    name: str = ""
    description: str = ""
    version: int = 1
    status: str = "active"
    is_system: bool = False
    is_custom: bool = False
    severity: str = "medium"
    category: str = ""
    provider: str = "aws"
    service: str = ""
    resource_type: str = ""
    dsl: dict[str, Any] = field(default_factory=dict)
    dsl_version: str = "1.0"
    remediation: str = ""
    remediation_steps: list[dict[str, str]] = field(default_factory=list)
    remediation_terraform: Optional[str] = None
    remediation_cli: Optional[str] = None
    cvss_score: float = 0.0
    cvss_vector: Optional[str] = None
    references: list[dict[str, str]] = field(default_factory=list)
    cwe_ids: list[str] = field(default_factory=list)
    mitre_attack_ids: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    default_sla_hours: Optional[int] = None


@dataclass
class RuleExecutionResult:
    """Result of executing a rule against an asset."""
    rule_id: str = ""
    asset_arn: str = ""
    status: str = "pass"  # pass | fail | error | skipped
    finding: Optional[Finding] = None
    execution_time_ms: int = 0
    error: Optional[str] = None


# ═══════════════════════════════════════════════════════════════
# Attack Path Model
# ═══════════════════════════════════════════════════════════════

@dataclass
class AttackPath:
    """A discovered attack path from internet to a sensitive asset."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    path: list[dict[str, str]] = field(default_factory=list)  # [{node: arn, type: type}]
    edges: list[dict[str, str]] = field(default_factory=list)  # [{source, target, label}]
    length: int = 0
    findings: list[str] = field(default_factory=list)  # finding IDs
    risk_score: float = 0.0
    blast_radius: dict[str, Any] = field(default_factory=dict)
    status: str = "active"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# ═══════════════════════════════════════════════════════════════
# Risk Model
# ═══════════════════════════════════════════════════════════════

@dataclass
class RiskScore:
    """Multi-factor risk score for an entity (asset, finding, organization)."""
    entity_type: str = ""  # asset | finding | organization
    entity_id: str = ""
    score: float = 0.0  # 0-100
    level: str = "low"  # critical | high | medium | low
    factors: dict[str, float] = field(default_factory=dict)
    calculation: dict[str, Any] = field(default_factory=dict)
    calculated_at: float = field(default_factory=lambda: time.time())

    @staticmethod
    def compute(
        exposure: float = 0,
        identity: float = 0,
        vulnerability: float = 0,
        compliance: float = 0,
        business: float = 0,
        threat: float = 0,
        weights: dict[str, float] | None = None,
    ) -> "RiskScore":
        """Compute risk score from 6 independent factors.

        Each factor is 0-100. Weights are configurable.
        Default weights: exposure=0.25, identity=0.20, vulnerability=0.15,
                         compliance=0.15, business=0.15, threat=0.10
        """
        w = weights or {
            "exposure": 0.25,
            "identity": 0.20,
            "vulnerability": 0.15,
            "compliance": 0.15,
            "business": 0.15,
            "threat": 0.10,
        }

        factors = {
            "exposure": exposure,
            "identity": identity,
            "vulnerability": vulnerability,
            "compliance": compliance,
            "business": business,
            "threat": threat,
        }

        score = sum(factors[k] * w.get(k, 0) for k in factors)
        score = max(0, min(100, score))

        if score >= 80:
            level = "critical"
        elif score >= 60:
            level = "high"
        elif score >= 30:
            level = "medium"
        else:
            level = "low"

        return RiskScore(
            score=round(score, 2),
            level=level,
            factors={k: round(v, 2) for k, v in factors.items()},
            calculation={"weights": w, "formula": "weighted_sum"},
        )
