"""
Checkov Integration Engine — IaC security scanning with 3,122+ policies.

Checkov is an open-source tool by Prisma Cloud (Bridgecrew) that scans:
  - Terraform (.tf)
  - CloudFormation (.json/.yaml)
  - Kubernetes manifests (.yaml)
  - Serverless Framework
  - ARM templates
  - OpenAPI / Swagger
  - Dockerfiles
  - Secrets in code
  - SCA (software composition analysis)

3,122+ built-in policies across AWS, Azure, GCP, OCI.

This integration:
  1. Provides a catalog browser for the 3,122 policies
  2. Runs real Checkov scans on user-provided IaC code (file content or directory)
  3. Translates Checkov results → Sentinel Finding model
  4. Auto-runs all 6 premium features on Checkov findings (via gateway wiring)

Scientific basis:
  - Checkov uses a graph-based approach (not regex) for Terraform
  - Each check is a Python class with explicit logic
  - Results include severity, guideline URL, code block references
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, asdict, field
from typing import Any
from uuid import uuid4
from collections import defaultdict
import shutil


@dataclass
class CheckovPolicy:
    """One Checkov policy (check) — from --list output."""
    check_id: str               # e.g., "CKV_AWS_1"
    check_name: str
    category: str               # resource | data
    resource_type: str          # e.g., "aws_s3_bucket"
    framework: str              # Terraform | Cloudformation | Kubernetes | etc.
    guideline_url: str
    provider: str = ""          # aws | azure | gcp (derived from check_id)


@dataclass
class CheckovFinding:
    """A finding from running a Checkov scan."""
    finding_id: str
    check_id: str
    check_name: str
    status: str                 # PASS | FAIL | SKIPPED
    resource: str
    resource_type: str
    file_path: str
    file_line_range: list[int]
    severity: str               # high | medium | low | unknown
    guideline: str
    framework: str
    code_block: str
    timestamp: float
    source: str = "checkov"


# Mapping Checkov check_id prefix to cloud provider
PROVIDER_PREFIXES = {
    "CKV_AWS": "aws",
    "CKV_AZURE": "azure",
    "CKV_GCP": "gcp",
    "CKV_OCI": "oci",
    "CKV_K8S": "kubernetes",
    "CKV_SECRET": "secrets",
    "CKV_DOCKER": "docker",
    "CKV_GIT": "git",
    "CKV_OPENAPI": "openapi",
    "CKV_AWS": "aws",
}


def _infer_provider(check_id: str) -> str:
    for prefix, provider in PROVIDER_PREFIXES.items():
        if check_id.startswith(prefix):
            return provider
    return "generic"


def _severity_from_check_id(check_id: str) -> str:
    """Heuristic severity based on Checkov check ID (Checkov doesn't always provide severity)."""
    # These are well-known critical checks
    critical_checks = {
        "CKV_AWS_18",   # S3 bucket logging
        "CKV_AWS_19",   # S3 encrypted
        "CKV_AWS_20",   # S3 not public read
        "CKV_AWS_21",   # S3 versioning
        "CKV_AWS_24",   # No SSH from 0.0.0.0/0
        "CKV_AWS_23",   # SG description
        "CKV_AWS_338",  # KMS rotation
        "CKV_AWS_7",    # KMS rotation
        "CKV_AWS_40",   # IAM policy no admin
        "CKV_AWS_41",   # no secrets in user-data
        "CKV_AWS_45",   # no secrets in lambda env
        "CKV_AWS_126",  # no full S3 access
        "CKV_AWS_107",  # IAM policy no write without constraints
        "CKV_AWS_109",  # IAM policy no resource *
        "CKV_AWS_110",  # IAM policy no action *
        "CKV_AWS_111",  # IAM policy no write *
        "CKV_AWS_135",  # RDS public
        "CKV_AWS_136",  # RDS encrypted
        "CKV_SECRET_1", "CKV_SECRET_2", "CKV_SECRET_3", "CKV_SECRET_4", "CKV_SECRET_5", "CKV_SECRET_6",
    }
    high_checks = {
        "CKV_AWS_2", "CKV_AWS_3", "CKV_AWS_5", "CKV_AWS_6", "CKV_AWS_8", "CKV_AWS_9",
        "CKV_AWS_10", "CKV_AWS_13", "CKV_AWS_14", "CKV_AWS_15", "CKV_AWS_16", "CKV_AWS_17",
        "CKV_AWS_22", "CKV_AWS_25", "CKV_AWS_26", "CKV_AWS_27", "CKV_AWS_28", "CKV_AWS_29",
        "CKV_AWS_30", "CKV_AWS_31", "CKV_AWS_32", "CKV_AWS_33", "CKV_AWS_34", "CKV_AWS_35",
        "CKV_AWS_36", "CKV_AWS_37", "CKV_AWS_38", "CKV_AWS_39",
    }
    if check_id in critical_checks:
        return "critical"
    if check_id in high_checks:
        return "high"
    # Default by topic
    if "encryption" in check_id.lower() or "encrypted" in check_id.lower():
        return "high"
    if "public" in check_id.lower():
        return "high"
    if "secret" in check_id.lower() or "token" in check_id.lower() or "password" in check_id.lower():
        return "critical"
    return "medium"


class CheckovIntegrationEngine:
    """
    Wraps Checkov CLI for IaC scanning.

    Two execution modes:
      1. CATALOG: load all 3,122 policies via `checkov --list`
      2. SCAN: run real Checkov scan on provided Terraform/CFN/K8s code
    """

    def __init__(self) -> None:
        self._policies: dict[str, CheckovPolicy] = {}
        self._loaded = False
        self._checkov_cmd = shutil.which("checkov") or "/home/z/.venv/bin/checkov"

    def _ensure_loaded(self) -> None:
        if not self._loaded:
            self.load_catalog()

    def load_catalog(self) -> dict[str, Any]:
        """Load all Checkov policies via `checkov --list`."""
        if self._loaded:
            return self._stats()

        try:
            result = subprocess.run(
                [self._checkov_cmd, "--list"],
                capture_output=True, text=True, timeout=60,
            )
            if result.returncode != 0:
                return {"error": "checkov --list failed", "stderr": result.stderr[:500]}
            # Parse the table output
            # Format: | index | check_id | category | resource_type | check_name | framework | url |
            lines = result.stdout.split("\n")
            for line in lines:
                if "CKV_" not in line:
                    continue
                parts = [p.strip() for p in line.split("|")]
                if len(parts) < 8:
                    continue
                try:
                    # parts[0] is empty, parts[1] is index, parts[2] is check_id, etc.
                    check_id = parts[2]
                    category = parts[3]
                    resource_type = parts[4]
                    check_name = parts[5]
                    framework = parts[6]
                    url = parts[7] if len(parts) > 7 else ""
                    if not check_id.startswith("CKV_"):
                        continue
                    policy = CheckovPolicy(
                        check_id=check_id,
                        check_name=check_name,
                        category=category,
                        resource_type=resource_type,
                        framework=framework,
                        guideline_url=url,
                        provider=_infer_provider(check_id),
                    )
                    self._policies[check_id] = policy
                except Exception:
                    continue
            self._loaded = True
        except Exception as e:
            return {"error": str(e), "policies_loaded": len(self._policies)}

        return self._stats()

    def list_policies(
        self,
        provider: str | None = None,
        framework: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        self._ensure_loaded()
        results = []
        for p in self._policies.values():
            if provider and p.provider != provider:
                continue
            if framework and p.framework.lower() != framework.lower():
                continue
            results.append(asdict(p))
        return results[offset:offset + limit]

    def search_policies(self, query: str, limit: int = 50) -> list[dict[str, Any]]:
        self._ensure_loaded()
        q = query.lower()
        results = []
        for p in self._policies.values():
            if (q in p.check_id.lower() or q in p.check_name.lower() or
                q in p.resource_type.lower() or q in p.framework.lower()):
                results.append(asdict(p))
                if len(results) >= limit:
                    break
        return results

    def get_policy(self, check_id: str) -> dict[str, Any] | None:
        self._ensure_loaded()
        p = self._policies.get(check_id)
        return asdict(p) if p else None

    def scan_code(
        self,
        code: str,
        filename: str = "main.tf",
        framework: str = "terraform",
    ) -> dict[str, Any]:
        """Scan a single file's content."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = os.path.join(tmpdir, filename)
            with open(file_path, "w") as f:
                f.write(code)
            return self._scan_directory(tmpdir, framework)

    def scan_directory(self, directory: str, framework: str = "terraform") -> dict[str, Any]:
        """Scan a real directory."""
        return self._scan_directory(directory, framework)

    def _scan_directory(self, directory: str, framework: str) -> dict[str, Any]:
        """Run checkov on a directory and parse JSON output."""
        try:
            cmd = [
                self._checkov_cmd,
                "-d", directory,
                "--framework", framework,
                "--output", "json",
                "--quiet",
            ]
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=120,
            )
            # Checkov returns non-zero if findings exist — that's expected
            if not result.stdout:
                return {
                    "status": "error",
                    "error": result.stderr[:1000] or "No output",
                    "command": " ".join(cmd),
                }
            try:
                data = json.loads(result.stdout)
            except json.JSONDecodeError as e:
                return {
                    "status": "parse_error",
                    "error": str(e),
                    "raw_output": result.stdout[:1000],
                }
            return self._parse_checkov_output(data, framework)
        except subprocess.TimeoutExpired:
            return {"status": "timeout", "error": "Checkov scan timed out after 120s"}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    def _parse_checkov_output(self, data: dict, framework: str) -> dict[str, Any]:
        """Parse Checkov JSON output into Sentinel findings."""
        summary = data.get("summary", {})
        results = data.get("results", {})
        failed_checks = results.get("failed_checks", [])
        passed_checks = results.get("passed_checks", [])
        parsing_errors = results.get("parsing_errors", [])

        findings: list[dict[str, Any]] = []
        for chk in failed_checks:
            check_id = chk.get("check_id", "")
            finding = {
                "finding_id": str(uuid4()),
                "check_id": check_id,
                "check_name": chk.get("check_name", ""),
                "status": "FAIL",
                "resource": chk.get("resource", ""),
                "resource_type": chk.get("resource_type", ""),
                "file_path": chk.get("file_path", ""),
                "file_line_range": chk.get("file_line_range", []),
                "severity": chk.get("severity") or _severity_from_check_id(check_id),
                "guideline": chk.get("guideline", ""),
                "framework": framework,
                "code_block": chk.get("code_block", [""])[0] if chk.get("code_block") else "",
                "timestamp": time.time(),
                "source": "checkov",
                "provider": _infer_provider(check_id),
                "categories": self._categories_for_check(check_id),
            }
            findings.append(finding)

        by_severity: dict[str, int] = defaultdict(int)
        by_provider: dict[str, int] = defaultdict(int)
        for f in findings:
            by_severity[f["severity"]] += 1
            by_provider[f["provider"]] += 1

        return {
            "status": "completed",
            "scanner": "checkov",
            "framework": framework,
            "summary": {
                "passed": summary.get("passed", 0),
                "failed": summary.get("failed", 0),
                "skipped": summary.get("skipped", 0),
                "parsing_errors": len(parsing_errors),
            },
            "total_findings": len(findings),
            "by_severity": dict(by_severity),
            "by_provider": dict(by_provider),
            "findings": findings,
            "scanned_at": time.time(),
        }

    def _categories_for_check(self, check_id: str) -> list[str]:
        """Map check_id to compliance categories."""
        cats = set()
        # Parse number from CKV_AWS_NNN
        try:
            num = int(check_id.split("_")[-1])
        except (ValueError, IndexError):
            return []
        # CIS mapping (rough — Checkov has built-in CIS mappings but this is heuristic)
        if 1 <= num <= 50:
            cats.add("CIS-AWS")
        if 100 <= num <= 200:
            cats.add("PCI-DSS")
        if "SECRET" in check_id:
            cats.add("Secrets-Management")
        if "DOCKER" in check_id:
            cats.add("Container-Security")
        return sorted(cats)

    def _stats(self) -> dict[str, Any]:
        by_provider: dict[str, int] = defaultdict(int)
        by_framework: dict[str, int] = defaultdict(int)
        for p in self._policies.values():
            by_provider[p.provider] += 1
            by_framework[p.framework] += 1
        return {
            "total_policies": len(self._policies),
            "by_provider": dict(by_provider),
            "by_framework": dict(by_framework),
            "loaded": self._loaded,
            "checkov_available": shutil.which("checkov") is not None,
        }

    def get_stats(self) -> dict[str, Any]:
        self._ensure_loaded()
        return self._stats()


# Module-level singleton
engine = CheckovIntegrationEngine()
