"""
Subscription Tier Engine — multi-tier billing for mid-market adoption.

Pricing strategy (GitLab/Notion model):
  FREE     $0/mo    — 1 cloud account, 5 scans/mo, community support
                      → acquisition tier (gets users hooked)
  PRO      $29/mo   — 5 cloud accounts, unlimited scans, email alerts
                      → solo power users, indie hackers
  TEAM     $99/mo   — 20 accounts, Slack/Teams alerts, SSO, 3 users
                      → mid-market sweet spot (50-500 employees)
  BUSINESS $299/mo  — 50 accounts, SAML SSO, audit logs export, SLA
                      → larger mid-market
  ENTERPRISE — custom — on-prem, dedicated support, custom rules
                      → enterprise (we don't compete with Wiz here)

Why this works for mid-market:
  - $5/mo signals "toy" — $99/mo signals "professional tool"
  - Free tier removes risk for evaluation
  - Pro tier captures solo devs who upgrade
  - Team tier is the mid-market sweet spot
  - SSO + Slack alerts are the table stakes for mid-market

Enforcement:
  - Resource limits enforced at API gateway (not engine level)
  - Graceful degradation (show upgrade prompt, don't hard-block)
  - Stripe-ready (we don't implement payment, just tier checks)
"""
from __future__ import annotations

import os
import sqlite3
import time
from dataclasses import dataclass, asdict, field
from typing import Any
from uuid import uuid4
from collections import defaultdict


DB_PATH = os.environ.get("SENTINEL_DB_PATH", "/home/z/my-project/db/sentinel.db")


# ─────────────────────────────────────────────────────────────────────────
# Tier definitions
# ─────────────────────────────────────────────────────────────────────────
@dataclass
class Tier:
    tier_id: str
    name: str
    price_monthly: int           # USD cents
    price_3month: int            # USD cents (3-month plan)
    price_6month: int            # USD cents (6-month plan)
    price_yearly: int            # USD cents (annual plan)
    limits: dict[str, int]       # max_accounts, max_scans_per_month, max_users, etc.
    features: list[str]
    description: str


TIERS: dict[str, Tier] = {
    "free": Tier(
        tier_id="free",
        name="Free",
        price_monthly=0,
        price_3month=0,
        price_6month=0,
        price_yearly=0,
        limits={
            "max_cloud_accounts": 1,
            "max_scans_per_month": 5,
            "max_users": 1,
            "max_integrations": 1,
            "max_evidence_records": 100,
            "max_drift_history_days": 7,
            "scheduled_scans": False,
            "slack_alerts": False,
            "sso": False,
            "audit_export": False,
        },
        features=[
            "1 cloud account",
            "5 scans per month",
            "2,064 security checks (Prowler + Checkov)",
            "Attack path visualization",
            "Risk-based prioritization",
            "Evidence vault (7-day history)",
            "Community support",
        ],
        description="For solo developers evaluating cloud security — free forever",
    ),
    "premium": Tier(
        tier_id="premium",
        name="Premium",
        price_monthly=500,          # $5/month
        price_3month=1200,          # $12/3 months (save $3)
        price_6month=2500,          # $25/6 months (save $5)
        price_yearly=6000,          # $60/year (save $12 — 2 months free)
        limits={
            "max_cloud_accounts": 10,
            "max_scans_per_month": -1,  # unlimited
            "max_users": 5,
            "max_integrations": 10,
            "max_evidence_records": 50000,
            "max_drift_history_days": 365,
            "scheduled_scans": True,
            "slack_alerts": True,
            "sso": True,            # Google OAuth
            "audit_export": True,
        },
        features=[
            "10 cloud accounts (AWS + Azure + GCP)",
            "Unlimited scans",
            "Daily scheduled scans + email alerts",
            "Slack/Teams notifications",
            "Google OAuth SSO",
            "365-day drift history",
            "50,000 evidence records",
            "Attack path + MITRE ATT&CK mapping",
            "Risk-based prioritization (Bayesian)",
            "Audit log export (CSV/JSON)",
            "PDF/Excel compliance reports",
            "Email support (24h response)",
        ],
        description="For solo devs, small teams & startups — all features unlocked",
    ),
    "enterprise": Tier(
        tier_id="enterprise",
        name="Enterprise",
        price_monthly=-1,          # custom
        price_3month=-1,
        price_6month=-1,
        price_yearly=-1,
        limits={
            "max_cloud_accounts": -1,
            "max_scans_per_month": -1,
            "max_users": -1,
            "max_integrations": -1,
            "max_evidence_records": -1,
            "max_drift_history_days": -1,
            "scheduled_scans": True,
            "slack_alerts": True,
            "sso": True,
            "audit_export": True,
        },
        features=[
            "Unlimited everything",
            "On-premise deployment",
            "SAML SSO (Okta, Azure AD)",
            "Custom rule development",
            "Dedicated infrastructure",
            "24/7 phone support",
            "Quarterly security reviews",
            "Custom integrations",
            "SOC2 audit assistance",
        ],
        description="For enterprises with custom requirements — contact sales",
    ),
}


# ─────────────────────────────────────────────────────────────────────────
# Usage tracking
# ─────────────────────────────────────────────────────────────────────────
@dataclass
class TenantSubscription:
    tenant_id: str
    tier_id: str
    started_at: float
    renewal_at: float
    status: str                   # active | past_due | canceled | trialing
    scan_count_this_month: int = 0
    scan_count_reset_at: float = 0
    stripe_customer_id: str = ""
    stripe_subscription_id: str = ""
    trial_ends_at: float = 0


def _get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_billing_tables() -> None:
    with _get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS subscriptions (
                tenant_id TEXT PRIMARY KEY,
                tier_id TEXT NOT NULL DEFAULT 'free',
                started_at REAL,
                renewal_at REAL,
                status TEXT DEFAULT 'active',
                scan_count_this_month INTEGER DEFAULT 0,
                scan_count_reset_at REAL DEFAULT 0,
                stripe_customer_id TEXT,
                stripe_subscription_id TEXT,
                trial_ends_at REAL DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS usage_events (
                event_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                event_type TEXT,           -- scan | user_added | integration_added | etc
                timestamp REAL,
                metadata TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_usage_tenant ON usage_events(tenant_id, timestamp DESC)")
        conn.commit()


def get_subscription(tenant_id: str) -> TenantSubscription:
    """Get or create a subscription for a tenant. New tenants start on Free."""
    with _get_db() as conn:
        row = conn.execute(
            "SELECT * FROM subscriptions WHERE tenant_id = ?",
            (tenant_id,),
        ).fetchone()
        if not row:
            # Auto-enroll on Free tier
            now = time.time()
            conn.execute("""
                INSERT INTO subscriptions (tenant_id, tier_id, started_at, renewal_at, status, scan_count_this_month, scan_count_reset_at)
                VALUES (?, 'free', ?, ?, 'active', 0, ?)
            """, (tenant_id, now, now + 30*86400, now))
            conn.commit()
            return TenantSubscription(
                tenant_id=tenant_id,
                tier_id="free",
                started_at=now,
                renewal_at=now + 30*86400,
                status="active",
                scan_count_this_month=0,
                scan_count_reset_at=now,
            )
        return TenantSubscription(
            tenant_id=row["tenant_id"],
            tier_id=row["tier_id"],
            started_at=row["started_at"],
            renewal_at=row["renewal_at"],
            status=row["status"],
            scan_count_this_month=row["scan_count_this_month"],
            scan_count_reset_at=row["scan_count_reset_at"],
            stripe_customer_id=row["stripe_customer_id"] or "",
            stripe_subscription_id=row["stripe_subscription_id"] or "",
            trial_ends_at=row["trial_ends_at"] or 0,
        )


def update_subscription(tenant_id: str, tier_id: str, renewal_at: float | None = None) -> bool:
    """Upgrade/downgrade a tenant's tier."""
    if tier_id not in TIERS:
        return False
    now = time.time()
    new_renewal = renewal_at or (now + 30 * 86400)
    with _get_db() as conn:
        conn.execute("""
            UPDATE subscriptions SET tier_id = ?, renewal_at = ?, status = 'active'
            WHERE tenant_id = ?
        """, (tier_id, new_renewal, tenant_id))
        conn.commit()
    return True


def increment_scan_count(tenant_id: str) -> int:
    """Increment the monthly scan counter. Returns the new count."""
    sub = get_subscription(tenant_id)
    now = time.time()
    # Reset counter monthly
    if now - sub.scan_count_reset_at > 30 * 86400:
        sub.scan_count_this_month = 0
        sub.scan_count_reset_at = now
    new_count = sub.scan_count_this_month + 1
    with _get_db() as conn:
        conn.execute("""
            UPDATE subscriptions SET scan_count_this_month = ?, scan_count_reset_at = ?
            WHERE tenant_id = ?
        """, (new_count, sub.scan_count_reset_at, tenant_id))
        conn.commit()
    return new_count


# ─────────────────────────────────────────────────────────────────────────
# Limit enforcement
# ─────────────────────────────────────────────────────────────────────────
def check_limit(tenant_id: str, limit_name: str, current_value: int = 0) -> dict:
    """Check if a tenant can perform an action given their tier limits.

    Returns:
      {
        "allowed": True/False,
        "tier": "free" | "pro" | ...,
        "limit": int (or -1 for unlimited),
        "current": int,
        "upgrade_url": "/settings/billing",
        "reason": str,
      }
    """
    sub = get_subscription(tenant_id)
    tier = TIERS.get(sub.tier_id, TIERS["free"])
    limit = tier.limits.get(limit_name, 0)

    if limit == -1:
        return {
            "allowed": True,
            "tier": sub.tier_id,
            "limit": -1,
            "current": current_value,
            "upgrade_url": "",
            "reason": "unlimited",
        }
    if current_value < limit:
        return {
            "allowed": True,
            "tier": sub.tier_id,
            "limit": limit,
            "current": current_value,
            "upgrade_url": "",
            "reason": "within limit",
        }
    return {
        "allowed": False,
        "tier": sub.tier_id,
        "limit": limit,
        "current": current_value,
        "upgrade_url": "/settings/billing",
        "reason": f"Plan limit reached ({limit}). Upgrade to continue.",
    }


def check_feature(tenant_id: str, feature_name: str) -> bool:
    """Check if a feature is enabled for the tenant's tier."""
    sub = get_subscription(tenant_id)
    tier = TIERS.get(sub.tier_id, TIERS["free"])
    return bool(tier.limits.get(feature_name, False))


def get_tier_info(tier_id: str) -> dict:
    """Get full tier info for display."""
    tier = TIERS.get(tier_id)
    if not tier:
        return {}
    return asdict(tier)


def list_tiers() -> list[dict]:
    """List all tiers for pricing page display."""
    return [asdict(t) for t in TIERS.values()]


# ─────────────────────────────────────────────────────────────────────────
# Usage analytics
# ─────────────────────────────────────────────────────────────────────────
def record_usage_event(tenant_id: str, event_type: str, metadata: dict | None = None) -> None:
    with _get_db() as conn:
        conn.execute("""
            INSERT INTO usage_events (event_id, tenant_id, event_type, timestamp, metadata)
            VALUES (?, ?, ?, ?, ?)
        """, (
            str(uuid4()),
            tenant_id,
            event_type,
            time.time(),
            str(metadata or {}),
        ))
        conn.commit()


def get_usage_summary(tenant_id: str) -> dict:
    """Get current usage stats for a tenant — for billing dashboard."""
    sub = get_subscription(tenant_id)
    tier = TIERS.get(sub.tier_id, TIERS["free"])
    return {
        "tier": sub.tier_id,
        "tier_name": tier.name,
        "scan_count_this_month": sub.scan_count_this_month,
        "scan_limit": tier.limits.get("max_scans_per_month", -1),
        "renewal_at": sub.renewal_at,
        "status": sub.status,
        "days_until_renewal": int((sub.renewal_at - time.time()) / 86400),
    }
