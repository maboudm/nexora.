"""
Enterprise Asset Inventory Engine — Universal Asset Model + drift detection.

Based on Part 9 — Provider Abstraction Layer and NIST SP 800-137
(Information Security Continuous Monitoring).

Scientific Foundation:
  - Universal Asset Model: provider-agnostic representation of cloud resources
    Every asset has: id, type, name, region, provider, metadata, relationships
    AWS-specific → normalized to UAM (e.g., aws_s3_bucket → storage.bucket)
  - Drift Detection: compare current state to baseline via structural diff.
    Uses JSON canonicalization (RFC 8785) for stable hash comparison.
  - Change Tracking: temporal graph of asset state changes.
    Each change: (asset_id, field, old_value, new_value, timestamp, source)
  - Asset Criticality: multi-factor scoring algorithm
    Factors: internet_exposure, data_sensitivity, business_impact, compliance_scope
  - Topology Graph: bidirectional graph of asset relationships (network, IAM, data)
    Used for blast radius analysis

Capabilities:
  1. Asset Onboarding: normalize provider-specific resources to UAM
  2. Asset Inventory: query/filter/group assets by any attribute
  3. Drift Detection: hourly/daily diff against baseline state
  4. Change Tracking: every change logged with who/what/when
  5. Asset Criticality: scoring 0-100 based on exposure + sensitivity + impact
  6. Topology Graph: build bidirectional relationship graph
  7. Stale Asset Detection: assets not seen in N days (deleted from cloud)
"""
from __future__ import annotations

import hashlib
import json
import logging
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Asset Inventory Domain Model
# ═══════════════════════════════════════════════════════════════

class AssetProvider(str, Enum):
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
    KUBERNETES = "kubernetes"
    DOCKER = "docker"
    ORACLE = "oracle"
    ALIBABA = "alibaba"


class AssetCategory(str, Enum):
    """Universal asset categories (provider-agnostic)."""
    COMPUTE = "compute"            # ec2, vm, container, pod
    STORAGE = "storage"            # s3, blob, persistent_volume
    DATABASE = "database"          # rds, cosmos, dynamodb
    NETWORK = "network"            # vpc, sg, load_balancer, route_table
    IDENTITY = "identity"          # iam_user, iam_role, service_account
    CONTAINER = "container"        # docker_image, k8s_deployment
    SERVERLESS = "serverless"      # lambda, function, cloud_run
    MESSAGING = "messaging"        # sqs, sns, kafka
    CDN = "cdn"                    # cloudfront, akamai
    DNS = "dns"                    # route53, azure_dns
    SECURITY = "security"          # kms, secrets_manager, waf
    MONITORING = "monitoring"      # cloudtrail, cloudwatch
    ANALYTICS = "analytics"        # athena, bigquery, redshift
    OTHER = "other"


class AssetCriticality(str, Enum):
    LOW = "low"            # 0-30
    MEDIUM = "medium"      # 31-60
    HIGH = "high"          # 61-80
    CRITICAL = "critical"  # 81-100


class ChangeType(str, Enum):
    CREATED = "created"
    UPDATED = "updated"
    DELETED = "deleted"
    DRIFTED = "drifted"      # changes detected vs baseline


@dataclass
class AssetRelationship:
    """A relationship between two assets (bidirectional)."""
    source_asset_id: str
    target_asset_id: str
    relationship_type: str   # "attached_to" | "can_assume" | "writes_to" | "reads_from" | "contains"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Asset:
    """Universal Asset Model — provider-agnostic resource representation."""
    asset_id: str             # internal UUID
    tenant_id: str
    cloud_account_id: str
    provider: str             # AssetProvider value
    provider_resource_type: str  # e.g., "aws_s3_bucket"
    universal_type: str       # e.g., "storage.bucket"
    category: str             # AssetCategory value
    name: str
    arn: str                  # provider-specific ARN/URI
    region: str
    metadata: dict[str, Any] = field(default_factory=dict)
    tags: dict[str, str] = field(default_factory=dict)
    # Criticality scoring
    criticality_score: int = 0   # 0-100
    criticality_level: str = AssetCriticality.LOW.value
    # Exposure flags
    internet_exposed: bool = False
    contains_pii: bool = False
    contains_secrets: bool = False
    encrypted: bool = False
    # Tracking
    first_seen: int = 0
    last_seen: int = 0
    state_hash: str = ""    # SHA256 of canonical metadata (for drift detection)
    # Relationships (populated separately)
    relationships: list[AssetRelationship] = field(default_factory=list)


@dataclass
class AssetChange:
    """A change to an asset (created/updated/deleted/drifted)."""
    change_id: str
    tenant_id: str
    asset_id: str
    asset_arn: str
    asset_name: str
    asset_type: str
    change_type: str        # ChangeType value
    field: Optional[str] = None  # which field changed (None for create/delete)
    old_value: Any = None
    new_value: Any = None
    detected_at: int = 0
    source: str = ""        # "scanner" | "manual" | "webhook"
    description: str = ""


@dataclass
class AssetInventory:
    """A snapshot of all assets for a tenant."""
    tenant_id: str
    snapshot_id: str
    assets: list[Asset]
    total_assets: int
    by_provider: dict[str, int]
    by_category: dict[str, int]
    by_region: dict[str, int]
    by_criticality: dict[str, int]
    internet_exposed_count: int
    contains_pii_count: int
    snapshot_at: int
    duration_ms: int


# ═══════════════════════════════════════════════════════════════
# Asset Normalizer (provider → UAM)
# ═══════════════════════════════════════════════════════════════

class AssetNormalizer:
    """Normalizes provider-specific resources to Universal Asset Model.

    Maps:
      aws_s3_bucket         → storage.bucket
      aws_ec2_instance      → compute.instance
      aws_rds_instance      → database.rds
      aws_iam_user          → identity.user
      aws_iam_role          → identity.role
      aws_security_group    → network.security_group
      aws_lambda_function   → serverless.function
      aws_eks_cluster       → container.orchestrator
      ... (extensible per provider)
    """

    # Provider resource type → (universal_type, category)
    TYPE_MAP = {
        # AWS
        "aws_s3_bucket": ("storage.bucket", AssetCategory.STORAGE.value),
        "aws_ec2_instance": ("compute.instance", AssetCategory.COMPUTE.value),
        "aws_rds_instance": ("database.rds", AssetCategory.DATABASE.value),
        "aws_rds_cluster": ("database.cluster", AssetCategory.DATABASE.value),
        "aws_dynamodb_table": ("database.nosql", AssetCategory.DATABASE.value),
        "aws_iam_user": ("identity.user", AssetCategory.IDENTITY.value),
        "aws_iam_role": ("identity.role", AssetCategory.IDENTITY.value),
        "aws_iam_policy": ("identity.policy", AssetCategory.IDENTITY.value),
        "aws_iam_group": ("identity.group", AssetCategory.IDENTITY.value),
        "aws_security_group": ("network.security_group", AssetCategory.NETWORK.value),
        "aws_vpc": ("network.vpc", AssetCategory.NETWORK.value),
        "aws_subnet": ("network.subnet", AssetCategory.NETWORK.value),
        "aws_route_table": ("network.route_table", AssetCategory.NETWORK.value),
        "aws_internet_gateway": ("network.gateway", AssetCategory.NETWORK.value),
        "aws_nat_gateway": ("network.nat_gateway", AssetCategory.NETWORK.value),
        "aws_elb": ("network.load_balancer", AssetCategory.NETWORK.value),
        "aws_alb": ("network.load_balancer", AssetCategory.NETWORK.value),
        "aws_lambda_function": ("serverless.function", AssetCategory.SERVERLESS.value),
        "aws_eks_cluster": ("container.orchestrator", AssetCategory.CONTAINER.value),
        "aws_ecr_repository": ("container.registry", AssetCategory.CONTAINER.value),
        "aws_kms_key": ("security.kms_key", AssetCategory.SECURITY.value),
        "aws_secrets_manager_secret": ("security.secret", AssetCategory.SECURITY.value),
        "aws_sqs_queue": ("messaging.queue", AssetCategory.MESSAGING.value),
        "aws_sns_topic": ("messaging.topic", AssetCategory.MESSAGING.value),
        "aws_cloudfront_distribution": ("cdn.distribution", AssetCategory.CDN.value),
        "aws_route53_record": ("dns.record", AssetCategory.DNS.value),
        "aws_cloudtrail": ("monitoring.audit_trail", AssetCategory.MONITORING.value),
        "aws_cloudwatch_alarm": ("monitoring.alarm", AssetCategory.MONITORING.value),
        "aws_athena_workgroup": ("analytics.workgroup", AssetCategory.ANALYTICS.value),
        # Azure
        "azure_compute_virtual_machine": ("compute.instance", AssetCategory.COMPUTE.value),
        "azure_storage_account": ("storage.account", AssetCategory.STORAGE.value),
        "azure_database_postgresql": ("database.rds", AssetCategory.DATABASE.value),
        # GCP
        "gcp_compute_instance": ("compute.instance", AssetCategory.COMPUTE.value),
        "gcp_storage_bucket": ("storage.bucket", AssetCategory.STORAGE.value),
        "gcp_cloud_function": ("serverless.function", AssetCategory.SERVERLESS.value),
        "gcp_bigquery_dataset": ("analytics.dataset", AssetCategory.ANALYTICS.value),
        # Kubernetes
        "k8s_pod": ("compute.pod", AssetCategory.CONTAINER.value),
        "k8s_deployment": ("compute.deployment", AssetCategory.CONTAINER.value),
        "k8s_service": ("network.service", AssetCategory.NETWORK.value),
        "k8s_secret": ("security.k8s_secret", AssetCategory.SECURITY.value),
        "k8s_config_map": ("config.config_map", AssetCategory.OTHER.value),
        "k8s_persistent_volume": ("storage.persistent_volume", AssetCategory.STORAGE.value),
        "k8s_role": ("identity.role", AssetCategory.IDENTITY.value),
        "k8s_cluster_role": ("identity.cluster_role", AssetCategory.IDENTITY.value),
        # Docker
        "docker_container": ("compute.container", AssetCategory.CONTAINER.value),
        "docker_image": ("container.image", AssetCategory.CONTAINER.value),
        "docker_volume": ("storage.volume", AssetCategory.STORAGE.value),
    }

    @classmethod
    def normalize(
        cls,
        tenant_id: str,
        cloud_account_id: str,
        provider: str,
        provider_resource_type: str,
        name: str,
        arn: str,
        region: str,
        metadata: Optional[dict] = None,
        tags: Optional[dict] = None,
    ) -> Asset:
        """Normalize a provider-specific resource to UAM."""
        universal_type, category = cls.TYPE_MAP.get(
            provider_resource_type,
            (f"unknown.{provider_resource_type}", AssetCategory.OTHER.value),
        )
        now = int(time.time() * 1000)
        asset = Asset(
            asset_id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            cloud_account_id=cloud_account_id,
            provider=provider,
            provider_resource_type=provider_resource_type,
            universal_type=universal_type,
            category=category,
            name=name,
            arn=arn,
            region=region,
            metadata=metadata or {},
            tags=tags or {},
            first_seen=now,
            last_seen=now,
        )
        asset.state_hash = cls._compute_state_hash(asset)
        return asset

    @classmethod
    def _compute_state_hash(cls, asset: Asset) -> str:
        """Compute canonical SHA256 hash of asset state (for drift detection).

        Uses JSON canonicalization (sorted keys) per RFC 8785.
        Excludes timestamps and the hash itself.
        """
        state = {
            "arn": asset.arn,
            "name": asset.name,
            "region": asset.region,
            "metadata": asset.metadata,
            "tags": asset.tags,
        }
        canonical = json.dumps(state, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(canonical.encode()).hexdigest()


# ═══════════════════════════════════════════════════════════════
# Asset Criticality Calculator
# ═══════════════════════════════════════════════════════════════

class AssetCriticalityCalculator:
    """Calculate asset criticality on a 0-100 scale.

    Multi-factor scoring:
      - Internet Exposure (35% max): is the asset reachable from the internet?
      - Data Sensitivity (25% max): does it contain PII/secrets?
      - Business Impact (25% max): from tags (criticality=critical → 25, high → 20, etc.)
      - Compliance Scope (15% max): in scope for PCI/HIPAA/SOC2?

    Categorization:
      0-30: low       — internal-only, no sensitive data, low business impact
      31-60: medium   — some exposure or limited sensitivity
      61-80: high     — public-facing or contains PII
      81-100: critical — public + PII + compliance scope
    """

    @classmethod
    def calculate(cls, asset: Asset) -> tuple[int, str]:
        score = 0

        # Internet exposure (35 points max)
        if asset.internet_exposed:
            score += 35
        elif asset.metadata.get("public_ip"):
            score += 25
        elif asset.metadata.get("public_access"):
            score += 20

        # Data sensitivity (25 points max)
        if asset.contains_secrets:
            score += 25
        elif asset.contains_pii:
            score += 20
        elif asset.metadata.get("classification") in ("confidential", "restricted", "regulated"):
            score += 15

        # Business impact (25 points max) — from tags
        business_tag = asset.tags.get("criticality", asset.tags.get("tier", "")).lower()
        business_scores = {
            "critical": 25, "tier0": 25, "tier_0": 25,
            "high": 20, "tier1": 20, "tier_1": 20,
            "medium": 12, "tier2": 12, "tier_2": 12,
            "low": 5, "tier3": 5, "tier_3": 5,
        }
        score += business_scores.get(business_tag, 10)

        # Compliance scope (15 points max)
        compliance_tags = [v.lower() for v in asset.tags.values()]
        if any("pci" in c for c in compliance_tags):
            score += 15
        elif any("hipaa" in c for c in compliance_tags):
            score += 15
        elif any("soc2" in c for c in compliance_tags):
            score += 10
        elif any("gdpr" in c for c in compliance_tags):
            score += 8

        # Encryption bonus (negative — encryption reduces risk)
        if asset.encrypted:
            score = max(0, score - 5)

        score = min(100, max(0, score))

        if score >= 81:
            level = AssetCriticality.CRITICAL.value
        elif score >= 61:
            level = AssetCriticality.HIGH.value
        elif score >= 31:
            level = AssetCriticality.MEDIUM.value
        else:
            level = AssetCriticality.LOW.value

        return score, level


# ═══════════════════════════════════════════════════════════════
# Asset Inventory Engine
# ═══════════════════════════════════════════════════════════════

class AssetInventoryEngine:
    """Asset inventory management with drift detection.

    Maintains a current snapshot of all assets per tenant. When a new
    scan completes, compares against the previous snapshot to detect
    drift (changes), and records all changes in the change log.
    """

    def __init__(self):
        # tenant_id -> {arn -> Asset} (current state)
        self._inventory: dict[str, dict[str, Asset]] = defaultdict(dict)
        # tenant_id -> list[AssetChange] (change history)
        self._changes: dict[str, list[AssetChange]] = defaultdict(list)
        # tenant_id -> previous state hash (for drift detection)
        self._previous_state: dict[str, dict[str, str]] = defaultdict(dict)
        self._lock = threading.RLock()

    def upsert_asset(self, asset: Asset) -> Optional[AssetChange]:
        """Add or update an asset in the inventory.

        Returns an AssetChange if the asset was updated (drift detected),
        or None if the asset is new.
        """
        with self._lock:
            tenant_inventory = self._inventory[asset.tenant_id]
            existing = tenant_inventory.get(asset.arn)

            # Recalculate criticality
            asset.criticality_score, asset.criticality_level = AssetCriticalityCalculator.calculate(asset)

            if existing is None:
                # New asset
                asset.first_seen = int(time.time() * 1000)
                tenant_inventory[asset.arn] = asset
                change = AssetChange(
                    change_id=str(uuid.uuid4()),
                    tenant_id=asset.tenant_id,
                    asset_id=asset.asset_id,
                    asset_arn=asset.arn,
                    asset_name=asset.name,
                    asset_type=asset.provider_resource_type,
                    change_type=ChangeType.CREATED.value,
                    detected_at=int(time.time() * 1000),
                    source="scanner",
                    description=f"New asset discovered: {asset.name}",
                )
                self._changes[asset.tenant_id].append(change)
                return change

            # Check for drift
            if existing.state_hash != asset.state_hash:
                # Drift detected — find changed fields
                changes = []
                for field in ["name", "region", "metadata", "tags"]:
                    old_val = getattr(existing, field)
                    new_val = getattr(asset, field)
                    if old_val != new_val:
                        changes.append((field, old_val, new_val))

                # Update the asset
                asset.first_seen = existing.first_seen
                tenant_inventory[asset.arn] = asset

                # Record the change
                change = AssetChange(
                    change_id=str(uuid.uuid4()),
                    tenant_id=asset.tenant_id,
                    asset_id=asset.asset_id,
                    asset_arn=asset.arn,
                    asset_name=asset.name,
                    asset_type=asset.provider_resource_type,
                    change_type=ChangeType.DRIFTED.value,
                    detected_at=int(time.time() * 1000),
                    source="scanner",
                    description=f"Asset drifted: {len(changes)} field(s) changed",
                )
                if changes:
                    change.field = changes[0][0]
                    change.old_value = str(changes[0][1])[:200] if changes[0][1] else None
                    change.new_value = str(changes[0][2])[:200] if changes[0][2] else None
                self._changes[asset.tenant_id].append(change)
                return change

            # No change — just update last_seen
            existing.last_seen = int(time.time() * 1000)
            return None

    def bulk_upsert(self, assets: list[Asset]) -> list[AssetChange]:
        """Upsert multiple assets at once. Returns list of changes."""
        changes = []
        for asset in assets:
            change = self.upsert_asset(asset)
            if change:
                changes.append(change)
        return changes

    def delete_asset(self, tenant_id: str, arn: str) -> Optional[AssetChange]:
        """Mark an asset as deleted."""
        with self._lock:
            existing = self._inventory.get(tenant_id, {}).get(arn)
            if not existing:
                return None
            del self._inventory[tenant_id][arn]
            change = AssetChange(
                change_id=str(uuid.uuid4()),
                tenant_id=tenant_id,
                asset_id=existing.asset_id,
                asset_arn=existing.arn,
                asset_name=existing.name,
                asset_type=existing.provider_resource_type,
                change_type=ChangeType.DELETED.value,
                detected_at=int(time.time() * 1000),
                source="scanner",
                description=f"Asset no longer detected: {existing.name}",
            )
            self._changes[tenant_id].append(change)
            return change

    def detect_stale_assets(self, tenant_id: str, stale_after_days: int = 7) -> list[Asset]:
        """Find assets not seen in N days (likely deleted from cloud)."""
        cutoff = int(time.time() * 1000) - (stale_after_days * 86400000)
        with self._lock:
            return [
                asset for asset in self._inventory.get(tenant_id, {}).values()
                if asset.last_seen < cutoff
            ]

    def get_asset(self, tenant_id: str, arn: str) -> Optional[Asset]:
        with self._lock:
            return self._inventory.get(tenant_id, {}).get(arn)

    def list_assets(
        self,
        tenant_id: str,
        provider: Optional[str] = None,
        category: Optional[str] = None,
        region: Optional[str] = None,
        criticality: Optional[str] = None,
        internet_exposed: Optional[bool] = None,
        contains_pii: Optional[bool] = None,
        limit: int = 1000,
        offset: int = 0,
    ) -> list[Asset]:
        """List assets with filters."""
        with self._lock:
            assets = list(self._inventory.get(tenant_id, {}).values())

        if provider:
            assets = [a for a in assets if a.provider == provider]
        if category:
            assets = [a for a in assets if a.category == category]
        if region:
            assets = [a for a in assets if a.region == region]
        if criticality:
            assets = [a for a in assets if a.criticality_level == criticality]
        if internet_exposed is not None:
            assets = [a for a in assets if a.internet_exposed == internet_exposed]
        if contains_pii is not None:
            assets = [a for a in assets if a.contains_pii == contains_pii]

        return assets[offset:offset + limit]

    def get_inventory_snapshot(self, tenant_id: str) -> AssetInventory:
        """Get a complete snapshot of the tenant's asset inventory."""
        start_time = time.time()
        with self._lock:
            assets = list(self._inventory.get(tenant_id, {}).values())

        by_provider = defaultdict(int)
        by_category = defaultdict(int)
        by_region = defaultdict(int)
        by_criticality = defaultdict(int)
        internet_exposed_count = 0
        contains_pii_count = 0

        for asset in assets:
            by_provider[asset.provider] += 1
            by_category[asset.category] += 1
            by_region[asset.region] += 1
            by_criticality[asset.criticality_level] += 1
            if asset.internet_exposed:
                internet_exposed_count += 1
            if asset.contains_pii:
                contains_pii_count += 1

        return AssetInventory(
            tenant_id=tenant_id,
            snapshot_id=str(uuid.uuid4()),
            assets=assets,
            total_assets=len(assets),
            by_provider=dict(by_provider),
            by_category=dict(by_category),
            by_region=dict(by_region),
            by_criticality=dict(by_criticality),
            internet_exposed_count=internet_exposed_count,
            contains_pii_count=contains_pii_count,
            snapshot_at=int(time.time() * 1000),
            duration_ms=int((time.time() - start_time) * 1000),
        )

    def list_changes(
        self,
        tenant_id: str,
        change_type: Optional[str] = None,
        limit: int = 100,
    ) -> list[AssetChange]:
        with self._lock:
            changes = list(self._changes.get(tenant_id, []))
        if change_type:
            changes = [c for c in changes if c.change_type == change_type]
        return list(reversed(changes))[:limit]

    def get_topology(self, tenant_id: str) -> dict[str, Any]:
        """Build a topology graph of asset relationships."""
        with self._lock:
            assets = list(self._inventory.get(tenant_id, {}).values())

        nodes = [
            {
                "id": a.asset_id,
                "arn": a.arn,
                "name": a.name,
                "type": a.universal_type,
                "category": a.category,
                "provider": a.provider,
                "criticality": a.criticality_level,
                "criticality_score": a.criticality_score,
            }
            for a in assets
        ]
        edges = []
        for asset in assets:
            for rel in asset.relationships:
                edges.append({
                    "source": rel.source_asset_id,
                    "target": rel.target_asset_id,
                    "type": rel.relationship_type,
                })

        return {
            "nodes": nodes,
            "edges": edges,
            "summary": {
                "total_nodes": len(nodes),
                "total_edges": len(edges),
                "by_category": dict(defaultdict(int, {
                    cat: sum(1 for n in nodes if n["category"] == cat)
                    for cat in set(n["category"] for n in nodes)
                })),
            },
        }

    def add_relationship(
        self,
        tenant_id: str,
        source_arn: str,
        target_arn: str,
        relationship_type: str,
        metadata: Optional[dict] = None,
    ) -> bool:
        """Add a relationship between two assets."""
        with self._lock:
            source = self._inventory.get(tenant_id, {}).get(source_arn)
            target = self._inventory.get(tenant_id, {}).get(target_arn)
            if not source or not target:
                return False
            rel = AssetRelationship(
                source_asset_id=source.asset_id,
                target_asset_id=target.asset_id,
                relationship_type=relationship_type,
                metadata=metadata or {},
            )
            source.relationships.append(rel)
            return True

    def get_stats(self, tenant_id: str) -> dict[str, Any]:
        """Get asset inventory stats for a tenant."""
        snapshot = self.get_inventory_snapshot(tenant_id)
        with self._lock:
            change_count = len(self._changes.get(tenant_id, []))
        return {
            "total_assets": snapshot.total_assets,
            "by_provider": snapshot.by_provider,
            "by_category": snapshot.by_category,
            "by_criticality": snapshot.by_criticality,
            "internet_exposed": snapshot.internet_exposed_count,
            "contains_pii": snapshot.contains_pii_count,
            "total_changes_tracked": change_count,
            "recent_changes": len([c for c in self._changes.get(tenant_id, [])[-100:]
                                   if c.detected_at > int(time.time() * 1000) - 86400000]),
        }


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_engine: Optional[AssetInventoryEngine] = None
_global_lock = threading.Lock()


def get_asset_inventory_engine() -> AssetInventoryEngine:
    global _global_engine
    if _global_engine is None:
        with _global_lock:
            if _global_engine is None:
                _global_engine = AssetInventoryEngine()
    return _global_engine
