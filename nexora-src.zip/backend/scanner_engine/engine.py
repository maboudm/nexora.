"""
Scanner Engine — Plugin-based cloud resource scanner.

Based on Part 2 — Production Scanner Engine and Part 9 — Provider Abstraction.

Architecture:
  - ScannerPlugin (abstract interface): defines the contract for all providers
  - AWSScannerPlugin: implements the interface for AWS (boto3)
  - ScannerEngine: orchestrates plugins, manages workers, merges results

Features:
  - Plugin-based: new cloud providers added without modifying core
  - Parallel region scanning (ThreadPoolExecutor)
  - Pagination on all AWS APIs (no truncation at 1000+ resources)
  - Exponential backoff with jitter on throttling
  - Multi-region auto-discovery (EC2 describe_regions)
  - Universal Asset Model normalization (provider-agnostic output)
  - Asset relationship graph construction
"""
from __future__ import annotations

import abc
import json
import logging
import os
import time
import random
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Optional

import boto3
from botocore.config import Config as BotoConfig
from botocore.exceptions import ClientError, EndpointConnectionError

from core.models import (
    Asset, AssetRelationship, CloudProvider, CredentialConfig,
    SessionCredentials, ScanResult, ScanRequest,
)
from credential_manager.manager import CredentialManager

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Plugin Interface (Part 9 — Provider Abstraction Layer)
# ═══════════════════════════════════════════════════════════════

class ScannerPlugin(abc.ABC):
    """Abstract interface for cloud provider scanners.

    Each cloud provider (AWS, Azure, GCP) implements this interface.
    The ScannerEngine calls these methods without knowing which provider it's scanning.

    Implementations MUST:
    - Use pagination on all list APIs (no truncation)
    - Implement retry with exponential backoff on throttling
    - Normalize all resources to the Universal Asset Model
    - Discover relationships between resources
    """

    @property
    @abc.abstractmethod
    def provider(self) -> str:
        """Return the cloud provider name (aws, azure, gcp)."""
        pass

    @abc.abstractmethod
    def discover_regions(self, session: SessionCredentials) -> list[str]:
        """Auto-discover all enabled regions for this account."""
        pass

    @abc.abstractmethod
    def scan_region(self, session: SessionCredentials, region: str, scanners: list[str]) -> tuple[list[Asset], list[AssetRelationship]]:
        """Scan a single region and return assets + relationships.

        Args:
            session: Valid session credentials
            region: AWS region to scan (e.g., "us-east-1")
            scanners: Which scanner types to run (e.g., ["iam", "s3", "sg"])

        Returns:
            Tuple of (assets, relationships)
        """
        pass

    @abc.abstractmethod
    def scan_global(self, session: SessionCredentials, scanners: list[str]) -> tuple[list[Asset], list[AssetRelationship]]:
        """Scan global resources (IAM, Organizations, CloudFront, etc.).

        These resources are not region-specific.
        """
        pass

    @abc.abstractmethod
    def validate_credentials(self, session: SessionCredentials) -> dict[str, Any]:
        """Validate that the credentials can access the account.

        Returns:
            {"valid": bool, "account_id": str, "user_arn": str, "error": str | None}
        """
        pass


# ═══════════════════════════════════════════════════════════════
# AWS Scanner Plugin
# ═══════════════════════════════════════════════════════════════

class AWSScannerPlugin(ScannerPlugin):
    """AWS scanner plugin using boto3.

    Supports scanning:
    - IAM (roles, users, policies, groups) — global
    - S3 (buckets, policies, encryption, ACLs) — global + regional
    - EC2 (instances, security groups, NACLs, route tables) — regional
    - EKS (clusters, node groups) — regional
    - Lambda (functions, layers) — regional
    - KMS (keys, policies) — regional
    - Secrets Manager (secrets) — regional
    - RDS (instances, clusters) — regional
    - CloudTrail (trails) — regional
    - CloudWatch (alarms, logs) — regional

    All APIs use paginators to handle 1000+ resources.
    All APIs use exponential backoff with jitter on throttling.
    """

    @property
    def provider(self) -> str:
        return "aws"

    def _make_client(self, service: str, session: SessionCredentials, region: str = "us-east-1") -> boto3.client:
        """Create a boto3 client using session credentials."""
        endpoint_url = os.environ.get("AWS_ENDPOINT_URL") or None
        config = BotoConfig(
            retries={"max_attempts": 5, "mode": "adaptive"},
            max_pool_connections=50,
            connect_timeout=10,
            read_timeout=60,
        )
        return boto3.client(
            service,
            region_name=region,
            aws_access_key_id=session.access_key_id,
            aws_secret_access_key=session.secret_access_key,
            aws_session_token=session.session_token or None,
            endpoint_url=endpoint_url,
            config=config,
        )

    def _retry_api_call(self, func: Callable, **kwargs) -> Any:
        """Execute a boto3 API call with exponential backoff and jitter.

        Retries on:
        - ThrottlingException
        - TooManyRequestsException
        - ServiceUnavailable
        - RequestLimitExceeded
        - Transient connection errors

        Does NOT retry on:
        - AccessDenied (permission issue)
        - ValidationError (bad request)
        - NoSuchResource (resource doesn't exist)
        """
        max_retries = 5
        base_delay = 1.0
        max_delay = 30.0
        retryable_errors = {
            "Throttling", "ThrottlingException", "TooManyRequestsException",
            "RequestLimitExceeded", "ServiceUnavailable", "InternalError",
            "RequestTimeout", "RequestTimeoutException", "SlowDown",
        }

        for attempt in range(max_retries + 1):
            try:
                return func(**kwargs)
            except ClientError as e:
                error_code = e.response.get("Error", {}).get("Code", "")
                if error_code in retryable_errors and attempt < max_retries:
                    delay = min(max_delay, base_delay * (2 ** attempt)) + random.uniform(0, 1)
                    logger.warning(
                        f"API throttled ({error_code}), retrying in {delay:.1f}s",
                        extra={"attempt": attempt + 1, "max_retries": max_retries, "error_code": error_code},
                    )
                    time.sleep(delay)
                    continue
                raise
            except (EndpointConnectionError, ConnectionError) as e:
                if attempt < max_retries:
                    delay = min(max_delay, base_delay * (2 ** attempt)) + random.uniform(0, 1)
                    logger.warning(f"Connection error, retrying in {delay:.1f}s", extra={"attempt": attempt + 1})
                    time.sleep(delay)
                    continue
                raise

    def _paginate(self, client: boto3.client, operation: str, **kwargs) -> list[dict]:
        """Use a paginator to fetch all pages of an API call.

        This prevents truncation when there are 1000+ resources.
        """
        try:
            paginator = client.get_paginator(operation)
            results = []
            for page in self._retry_api_call(lambda: paginator.paginate(**kwargs)):
                # Extract the list from the page (different APIs have different keys)
                for key in page:
                    if isinstance(page[key], list):
                        results.extend(page[key])
            return results
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code in ["AccessDenied", "UnauthorizedOperation"]:
                logger.warning(f"Access denied for {operation}", extra={"error": str(e)})
                return []
            raise

    def validate_credentials(self, session: SessionCredentials) -> dict[str, Any]:
        """Validate credentials by calling STS GetCallerIdentity."""
        try:
            sts = self._make_client("sts", session)
            identity = self._retry_api_call(sts.get_caller_identity)
            return {
                "valid": True,
                "account_id": identity["Account"],
                "user_arn": identity["Arn"],
                "error": None,
            }
        except Exception as e:
            return {"valid": False, "account_id": "", "user_arn": "", "error": str(e)}

    def discover_regions(self, session: SessionCredentials) -> list[str]:
        """Auto-discover all enabled regions using EC2 describe_regions."""
        try:
            ec2 = self._make_client("ec2", session)
            response = self._retry_api_call(
                ec2.describe_regions,
                Filters=[{"Name": "opt-in-status", "Values": ["opt-in-not-needed", "opted-in"]}],
            )
            regions = [r["RegionName"] for r in response.get("Regions", [])]
            logger.info(f"Discovered {len(regions)} regions", extra={"regions": regions[:5]})
            return regions
        except Exception as e:
            logger.warning(f"Failed to discover regions, using defaults: {e}")
            return ["us-east-1", "us-east-2", "us-west-1", "us-west-2",
                    "eu-west-1", "eu-central-1", "ap-south-1", "ap-southeast-1"]

    # ═══════════════════════════════════════════════════════════════
    # Global Resource Scanners (not region-specific)
    # ═══════════════════════════════════════════════════════════════

    def scan_global(self, session: SessionCredentials, scanners: list[str]) -> tuple[list[Asset], list[AssetRelationship]]:
        """Scan global AWS resources: IAM, S3, Organizations."""
        assets: list[Asset] = []
        relationships: list[AssetRelationship] = []

        if "iam" in scanners:
            iam_assets, iam_rels = self._scan_iam(session)
            assets.extend(iam_assets)
            relationships.extend(iam_rels)

        if "s3" in scanners:
            s3_assets, s3_rels = self._scan_s3(session)
            assets.extend(s3_assets)
            relationships.extend(s3_rels)

        if "orgs" in scanners:
            org_assets = self._scan_organizations(session)
            assets.extend(org_assets)

        return assets, relationships

    def _scan_iam(self, session: SessionCredentials) -> tuple[list[Asset], list[AssetRelationship]]:
        """Scan IAM roles, users, groups, policies."""
        iam = self._make_client("iam", session)
        assets: list[Asset] = []
        relationships: list[AssetRelationship] = []
        account_id = session.account_id

        # Scan roles
        try:
            paginator = iam.get_paginator("list_roles")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for role in page.get("Roles", []):
                    role_name = role["RoleName"]
                    arn = role["Arn"]

                    # Get inline policies
                    inline_policies = []
                    try:
                        pol_paginator = iam.get_paginator("list_role_policies")
                        for pol_page in self._retry_api_call(lambda: pol_paginator.paginate(RoleName=role_name)):
                            for pname in pol_page.get("PolicyNames", []):
                                pol = self._retry_api_call(iam.get_role_policy, RoleName=role_name, PolicyName=pname)
                                inline_policies.append({
                                    "PolicyName": pname,
                                    "PolicyDocument": pol["PolicyDocument"],
                                })
                    except ClientError:
                        pass

                    # Get attached managed policies
                    attached = []
                    try:
                        attached = self._retry_api_call(iam.list_attached_role_policies, RoleName=role_name).get("AttachedPolicies", [])
                    except ClientError:
                        pass

                    # Get last used
                    last_used = None
                    try:
                        lu = self._retry_api_call(iam.get_role, RoleName=role_name)
                        rlu = lu["Role"].get("RoleLastUsed", {})
                        if rlu and rlu.get("LastUsedDate"):
                            last_used = {
                                "LastUsedDate": rlu["LastUsedDate"].isoformat(),
                                "Region": rlu.get("Region", "us-east-1"),
                            }
                    except ClientError:
                        pass

                    trust_policy = role.get("AssumeRolePolicyDocument", {})
                    if isinstance(trust_policy, str):
                        try:
                            trust_policy = json.loads(trust_policy)
                        except json.JSONDecodeError:
                            trust_policy = {}

                    asset = Asset(
                        provider="aws",
                        service="iam",
                        resource_type="aws_iam_role",
                        external_id=role["RoleId"],
                        arn=arn,
                        name=role_name,
                        region="global",
                        metadata={
                            "RoleName": role_name,
                            "Arn": arn,
                            "Path": role.get("Path", "/"),
                            "CreateDate": role["CreateDate"].isoformat() if hasattr(role.get("CreateDate"), "isoformat") else str(role.get("CreateDate", "")),
                            "AssumeRolePolicyDocument": trust_policy,
                            "InlinePolicies": inline_policies,
                            "AttachedPolicies": attached,
                            "LastUsed": last_used,
                        },
                    )
                    assets.append(asset)

                    # Build relationships: role → attached policies
                    for pol in attached:
                        rel = AssetRelationship(
                            from_asset_arn=arn,
                            to_asset_arn=pol.get("PolicyArn", ""),
                            relationship_type="has_policy",
                        )
                        relationships.append(rel)

        except ClientError as e:
            logger.error(f"Failed to scan IAM roles: {e}")

        # Scan users (optional — roles are more important for security)
        try:
            paginator = iam.get_paginator("list_users")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for user in page.get("Users", []):
                    asset = Asset(
                        provider="aws",
                        service="iam",
                        resource_type="aws_iam_user",
                        external_id=user["UserId"],
                        arn=user["Arn"],
                        name=user["UserName"],
                        region="global",
                        metadata={"UserName": user["UserName"], "Arn": user["Arn"], "CreateDate": str(user.get("CreateDate", ""))},
                    )
                    assets.append(asset)
        except ClientError as e:
            logger.warning(f"Failed to scan IAM users: {e}")

        logger.info(f"IAM scan complete: {len(assets)} assets, {len(relationships)} relationships")
        return assets, relationships

    def _scan_s3(self, session: SessionCredentials) -> tuple[list[Asset], list[AssetRelationship]]:
        """Scan S3 buckets with full configuration: policy, encryption, versioning, ACL, PAB, logging."""
        s3 = self._make_client("s3", session)
        assets: list[Asset] = []
        relationships: list[AssetRelationship] = []

        try:
            response = self._retry_api_call(s3.list_buckets)
        except ClientError as e:
            logger.error(f"Failed to list S3 buckets: {e}")
            return assets, relationships

        for bucket in response.get("Buckets", []):
            name = bucket["Name"]
            arn = f"arn:aws:s3:::{name}"

            # Determine region
            try:
                loc = self._retry_api_call(s3.get_bucket_location, Bucket=name)
                region = loc.get("LocationConstraint") or "us-east-1"
            except ClientError:
                region = "us-east-1"

            # Use regional client for bucket-specific operations
            regional_s3 = self._make_client("s3", session, region)

            # Fetch all bucket configurations (each is independent and non-fatal)
            bucket_data: dict[str, Any] = {
                "Name": name,
                "CreationDate": bucket["CreationDate"].isoformat() if hasattr(bucket.get("CreationDate"), "isoformat") else "",
                "Region": region,
                "ACL": [],
                "Policy": None,
                "Encryption": None,
                "Versioning": "Suspended",
                "PublicAccessBlock": {"BlockPublicAcls": False, "IgnorePublicAcls": False, "BlockPublicPolicy": False, "RestrictPublicBuckets": False},
                "Logging": None,
                "Tags": {},
            }

            # ACL
            try:
                bucket_data["ACL"] = self._retry_api_call(regional_s3.get_bucket_acl, Bucket=name).get("Grants", [])
            except ClientError:
                pass

            # Bucket Policy
            try:
                policy_str = self._retry_api_call(regional_s3.get_bucket_policy, Bucket=name).get("Policy")
                if policy_str:
                    bucket_data["Policy"] = json.loads(policy_str) if isinstance(policy_str, str) else policy_str
            except ClientError:
                pass

            # Encryption
            try:
                bucket_data["Encryption"] = self._retry_api_call(regional_s3.get_bucket_encryption, Bucket=name).get("ServerSideEncryptionConfiguration")
            except ClientError:
                pass

            # Versioning
            try:
                ver = self._retry_api_call(regional_s3.get_bucket_versioning, Bucket=name)
                bucket_data["Versioning"] = ver.get("Status", "Suspended")
            except ClientError:
                pass

            # Public Access Block
            try:
                bucket_data["PublicAccessBlock"] = self._retry_api_call(regional_s3.get_public_access_block, Bucket=name).get("PublicAccessBlockConfiguration", bucket_data["PublicAccessBlock"])
            except ClientError:
                pass  # PAB not configured = all False (which is a finding)

            # Logging
            try:
                log = self._retry_api_call(regional_s3.get_bucket_logging, Bucket=name)
                if "LoggingEnabled" in log:
                    bucket_data["Logging"] = log["LoggingEnabled"]
            except ClientError:
                pass

            # Tags
            try:
                tags_resp = self._retry_api_call(regional_s3.get_bucket_tagging, Bucket=name)
                bucket_data["Tags"] = {t["Key"]: t["Value"] for t in tags_resp.get("TagSet", [])}
            except ClientError:
                pass

            asset = Asset(
                provider="aws",
                service="s3",
                resource_type="aws_s3_bucket",
                external_id=name,
                arn=arn,
                name=name,
                region=region,
                tags=bucket_data["Tags"],
                metadata=bucket_data,
            )
            assets.append(asset)

        logger.info(f"S3 scan complete: {len(assets)} buckets")
        return assets, relationships

    def _scan_organizations(self, session: SessionCredentials) -> list[Asset]:
        """Scan AWS Organizations for multi-account discovery."""
        org = self._make_client("organizations", session)
        assets: list[Asset] = []

        try:
            paginator = org.get_paginator("list_accounts")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for acct in page.get("Accounts", []):
                    asset = Asset(
                        provider="aws",
                        service="organizations",
                        resource_type="aws_organizations_account",
                        external_id=acct["Id"],
                        arn=acct.get("Arn", f"arn:aws:organizations::{acct['Id']}:account/o-{acct['Id']}/{acct['Id']}"),
                        name=acct.get("Name", acct["Id"]),
                        region="global",
                        metadata={
                            "Id": acct["Id"],
                            "Name": acct.get("Name", ""),
                            "Email": acct.get("Email", ""),
                            "Status": acct.get("Status", ""),
                            "JoinedMethod": acct.get("JoinedMethod", ""),
                            "JoinedDate": str(acct.get("JoinedDate", "")),
                        },
                    )
                    assets.append(asset)
        except ClientError as e:
            logger.warning(f"Organizations scan failed (may not be org master): {e}")

        return assets

    # ═══════════════════════════════════════════════════════════════
    # Regional Resource Scanners
    # ═══════════════════════════════════════════════════════════════

    def scan_region(self, session: SessionCredentials, region: str, scanners: list[str]) -> tuple[list[Asset], list[AssetRelationship]]:
        """Scan a single region for all requested resource types."""
        assets: list[Asset] = []
        relationships: list[AssetRelationship] = []
        account_id = session.account_id

        if "sg" in scanners or "ec2" in scanners:
            sg_assets, sg_rels = self._scan_security_groups(session, region)
            assets.extend(sg_assets)
            relationships.extend(sg_rels)

        if "ec2" in scanners:
            ec2_assets, ec2_rels = self._scan_ec2_instances(session, region)
            assets.extend(ec2_assets)
            relationships.extend(ec2_rels)

        if "eks" in scanners:
            eks_assets = self._scan_eks(session, region)
            assets.extend(eks_assets)

        if "lambda" in scanners:
            lambda_assets = self._scan_lambda(session, region)
            assets.extend(lambda_assets)

        if "kms" in scanners:
            kms_assets = self._scan_kms(session, region)
            assets.extend(kms_assets)

        if "secrets" in scanners:
            secrets_assets = self._scan_secrets(session, region)
            assets.extend(secrets_assets)

        if "rds" in scanners:
            rds_assets = self._scan_rds(session, region)
            assets.extend(rds_assets)

        if "cloudtrail" in scanners:
            trail_assets = self._scan_cloudtrail(session, region)
            assets.extend(trail_assets)

        logger.info(f"Region {region} scan complete: {len(assets)} assets", extra={"region": region})
        return assets, relationships

    def _scan_security_groups(self, session: SessionCredentials, region: str) -> tuple[list[Asset], list[AssetRelationship]]:
        """Scan EC2 security groups with ingress/egress rules."""
        ec2 = self._make_client("ec2", session, region)
        assets: list[Asset] = []

        try:
            paginator = ec2.get_paginator("describe_security_groups")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for sg in page.get("SecurityGroups", []):
                    arn = f"arn:aws:ec2:{region}:{session.account_id}:security-group/{sg['GroupId']}"
                    asset = Asset(
                        provider="aws",
                        service="ec2",
                        resource_type="aws_security_group",
                        external_id=sg["GroupId"],
                        arn=arn,
                        name=f"{sg['GroupName']} ({sg['GroupId']})",
                        region=region,
                        metadata={
                            "GroupId": sg["GroupId"],
                            "GroupName": sg["GroupName"],
                            "Description": sg.get("Description", ""),
                            "VpcId": sg.get("VpcId", ""),
                            "Region": region,
                            "IpPermissions": sg.get("IpPermissions", []),
                            "IpPermissionsEgress": sg.get("IpPermissionsEgress", []),
                        },
                    )
                    assets.append(asset)
        except ClientError as e:
            logger.warning(f"Failed to scan security groups in {region}: {e}")

        return assets, []

    def _scan_ec2_instances(self, session: SessionCredentials, region: str) -> tuple[list[Asset], list[AssetRelationship]]:
        """Scan EC2 instances with IAM profiles, security groups, network config."""
        ec2 = self._make_client("ec2", session, region)
        assets: list[Asset] = []
        relationships: list[AssetRelationship] = []

        try:
            paginator = ec2.get_paginator("describe_instances")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for res in page.get("Reservations", []):
                    for inst in res.get("Instances", []):
                        instance_id = inst["InstanceId"]
                        arn = f"arn:aws:ec2:{region}:{session.account_id}:instance/{instance_id}"

                        # Collect security groups (may be in NetworkInterfaces if launched with NI)
                        sgs = list(inst.get("SecurityGroups", []))
                        if not sgs:
                            for ni in inst.get("NetworkInterfaces", []):
                                for sg in ni.get("Groups", []):
                                    sgs.append({"GroupId": sg["GroupId"], "GroupName": sg.get("GroupName", "")})

                        asset = Asset(
                            provider="aws",
                            service="ec2",
                            resource_type="aws_ec2_instance",
                            external_id=instance_id,
                            arn=arn,
                            name=instance_id,
                            region=region,
                            metadata={
                                "InstanceId": instance_id,
                                "InstanceType": inst.get("InstanceType", ""),
                                "State": inst.get("State", {}).get("Name", ""),
                                "PublicIpAddress": inst.get("PublicIpAddress"),
                                "PrivateIpAddress": inst.get("PrivateIpAddress") or (inst.get("NetworkInterfaces", [{}])[0].get("PrivateIpAddress") if inst.get("NetworkInterfaces") else None),
                                "Region": region,
                                "VpcId": inst.get("VpcId", ""),
                                "SubnetId": inst.get("SubnetId", ""),
                                "SecurityGroups": sgs,
                                "IamInstanceProfile": inst.get("IamInstanceProfile"),
                                "ImageId": inst.get("ImageId", ""),
                            },
                        )
                        assets.append(asset)

                        # Build relationships: SG → EC2
                        for sg in sgs:
                            sg_arn = f"arn:aws:ec2:{region}:{session.account_id}:security-group/{sg['GroupId']}"
                            rel = AssetRelationship(
                                from_asset_arn=sg_arn,
                                to_asset_arn=arn,
                                relationship_type="attached_to",
                            )
                            relationships.append(rel)

                        # Build relationships: EC2 → IAM Role
                        profile = inst.get("IamInstanceProfile", {})
                        if profile and profile.get("Arn"):
                            role_name = profile["Arn"].split("/")[-1]
                            role_arn = f"arn:aws:iam::{session.account_id}:role/{role_name}"
                            rel = AssetRelationship(
                                from_asset_arn=arn,
                                to_asset_arn=role_arn,
                                relationship_type="assumes_role",
                            )
                            relationships.append(rel)

        except ClientError as e:
            logger.warning(f"Failed to scan EC2 instances in {region}: {e}")

        return assets, relationships

    def _scan_eks(self, session: SessionCredentials, region: str) -> list[Asset]:
        """Scan EKS clusters with logging, encryption, endpoint config."""
        eks = self._make_client("eks", session, region)
        assets: list[Asset] = []

        try:
            paginator = eks.get_paginator("list_clusters")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for name in page.get("clusters", []):
                    try:
                        c = self._retry_api_call(eks.describe_cluster, name=name)["cluster"]
                        vpc_config = c.get("resourcesVpcConfig", {})
                        arn = c["arn"]

                        asset = Asset(
                            provider="aws",
                            service="eks",
                            resource_type="aws_eks_cluster",
                            external_id=c["name"],
                            arn=arn,
                            name=c["name"],
                            region=region,
                            metadata={
                                "ClusterName": c["name"],
                                "Arn": arn,
                                "Region": region,
                                "Status": c.get("status", ""),
                                "Version": c.get("version", ""),
                                "Logging": c.get("logging", {"clusterLogging": []}),
                                "EncryptionConfig": c.get("encryptionConfig", []),
                                "PublicAccess": vpc_config.get("endpointPublicAccess", False),
                                "PublicAccessCidrs": vpc_config.get("publicAccessCidrs", []),
                            },
                        )
                        assets.append(asset)
                    except ClientError as e:
                        logger.warning(f"Failed to describe EKS cluster {name}: {e}")
        except ClientError as e:
            logger.warning(f"Failed to list EKS clusters in {region}: {e}")

        return assets

    def _scan_lambda(self, session: SessionCredentials, region: str) -> list[Asset]:
        """Scan Lambda functions with role, runtime, code config."""
        lam = self._make_client("lambda", session, region)
        assets: list[Asset] = []

        try:
            paginator = lam.get_paginator("list_functions")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for f in page.get("Functions", []):
                    arn = f["FunctionArn"]
                    asset = Asset(
                        provider="aws",
                        service="lambda",
                        resource_type="aws_lambda_function",
                        external_id=f["FunctionName"],
                        arn=arn,
                        name=f["FunctionName"],
                        region=region,
                        metadata={
                            "FunctionName": f["FunctionName"],
                            "FunctionArn": arn,
                            "Runtime": f.get("Runtime", ""),
                            "Role": f.get("Role", ""),
                            "Handler": f.get("Handler", ""),
                            "State": f.get("State", "Active"),
                            "Region": region,
                        },
                    )
                    assets.append(asset)
        except ClientError as e:
            logger.warning(f"Failed to scan Lambda in {region}: {e}")

        return assets

    def _scan_kms(self, session: SessionCredentials, region: str) -> list[Asset]:
        """Scan KMS keys with policies."""
        kms = self._make_client("kms", session, region)
        assets: list[Asset] = []

        try:
            paginator = kms.get_paginator("list_keys")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for k in page.get("Keys", []):
                    key_id = k["KeyId"]
                    try:
                        desc = self._retry_api_call(kms.describe_key, KeyId=key_id)["KeyMetadata"]
                        policy = None
                        try:
                            policy_str = self._retry_api_call(kms.get_key_policy, KeyId=key_id, PolicyName="default").get("Policy")
                            if policy_str:
                                policy = json.loads(policy_str) if isinstance(policy_str, str) else policy_str
                        except ClientError:
                            pass

                        arn = desc.get("Arn", f"arn:aws:kms:{region}:{session.account_id}:key/{key_id}")
                        asset = Asset(
                            provider="aws",
                            service="kms",
                            resource_type="aws_kms_key",
                            external_id=key_id,
                            arn=arn,
                            name=key_id,
                            region=region,
                            metadata={
                                "KeyId": key_id,
                                "Arn": arn,
                                "Description": desc.get("Description", ""),
                                "KeyState": desc.get("KeyState", "Enabled"),
                                "KeyUsage": desc.get("KeyUsage", ""),
                                "KeyPolicy": policy,
                                "Region": region,
                            },
                        )
                        assets.append(asset)
                    except ClientError:
                        pass
        except ClientError as e:
            logger.warning(f"Failed to scan KMS in {region}: {e}")

        return assets

    def _scan_secrets(self, session: SessionCredentials, region: str) -> list[Asset]:
        """Scan Secrets Manager secrets."""
        sm = self._make_client("secretsmanager", session, region)
        assets: list[Asset] = []

        try:
            paginator = sm.get_paginator("list_secrets")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for s in page.get("SecretList", []):
                    arn = s["ARN"]
                    asset = Asset(
                        provider="aws",
                        service="secretsmanager",
                        resource_type="aws_secretsmanager_secret",
                        external_id=s["Name"],
                        arn=arn,
                        name=s["Name"],
                        region=region,
                        metadata={
                            "Name": s["Name"],
                            "Arn": arn,
                            "Description": s.get("Description", ""),
                            "KmsKeyId": s.get("KmsKeyId"),
                            "RotationEnabled": s.get("RotationEnabled", False),
                            "Region": region,
                        },
                    )
                    assets.append(asset)
        except ClientError as e:
            logger.warning(f"Failed to scan Secrets Manager in {region}: {e}")

        return assets

    def _scan_rds(self, session: SessionCredentials, region: str) -> list[Asset]:
        """Scan RDS instances and clusters."""
        rds = self._make_client("rds", session, region)
        assets: list[Asset] = []

        try:
            paginator = rds.get_paginator("describe_db_instances")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for db in page.get("DBInstances", []):
                    db_id = db["DBInstanceIdentifier"]
                    arn = db.get("DBInstanceArn", f"arn:aws:rds:{region}:{session.account_id}:db:{db_id}")
                    asset = Asset(
                        provider="aws",
                        service="rds",
                        resource_type="aws_rds_instance",
                        external_id=db_id,
                        arn=arn,
                        name=db_id,
                        region=region,
                        metadata={
                            "DBInstanceIdentifier": db_id,
                            "DBInstanceClass": db.get("DBInstanceClass", ""),
                            "Engine": db.get("Engine", ""),
                            "PubliclyAccessible": db.get("PubliclyAccessible", False),
                            "StorageEncrypted": db.get("StorageEncrypted", False),
                            "KmsKeyId": db.get("KmsKeyId"),
                            "Region": region,
                        },
                    )
                    assets.append(asset)
        except ClientError as e:
            logger.warning(f"Failed to scan RDS in {region}: {e}")

        return assets

    def _scan_cloudtrail(self, session: SessionCredentials, region: str) -> list[Asset]:
        """Scan CloudTrail trails."""
        ct = self._make_client("cloudtrail", session, region)
        assets: list[Asset] = []

        try:
            response = self._retry_api_call(ct.describe_trails)
            for trail in response.get("trailList", []):
                arn = trail.get("TrailARN", f"arn:aws:cloudtrail:{region}:{session.account_id}:trail/{trail.get('Name', '')}")
                asset = Asset(
                    provider="aws",
                    service="cloudtrail",
                    resource_type="aws_cloudtrail_trail",
                    external_id=trail.get("Name", ""),
                    arn=arn,
                    name=trail.get("Name", ""),
                    region=region,
                    metadata={
                        "Name": trail.get("Name", ""),
                        "S3BucketName": trail.get("S3BucketName", ""),
                        "IsLogging": trail.get("IsLogging", False),
                        "IncludeGlobalServiceEvents": trail.get("IncludeGlobalServiceEvents", False),
                        "IsMultiRegionTrail": trail.get("IsMultiRegionTrail", False),
                        "LogFileValidationEnabled": trail.get("LogFileValidationEnabled", False),
                        "KmsKeyId": trail.get("KmsKeyId"),
                        "Region": region,
                    },
                )
                assets.append(asset)
        except ClientError as e:
            logger.warning(f"Failed to scan CloudTrail in {region}: {e}")

        return assets


# ═══════════════════════════════════════════════════════════════
# Scanner Engine — Orchestrator
# ═══════════════════════════════════════════════════════════════

class ScannerEngine:
    """Orchestrates cloud scanning across providers and regions.

    Features:
    - Plugin-based: new providers added by implementing ScannerPlugin
    - Parallel region scanning (ThreadPoolExecutor)
    - Automatic region discovery
    - Progress tracking
    - Error isolation (one region failure doesn't block others)
    - Asset deduplication (by ARN)
    - Relationship merging

    Usage:
        engine = ScannerEngine(credential_manager)
        result = engine.scan(ScanRequest(
            tenant_id="org-123",
            workspace_id="ws-456",
            cloud_account_id="acct-789",
            scanners=["iam", "s3", "sg", "k8s"],
        ))
    """

    def __init__(self, credential_manager: CredentialManager, max_parallel_regions: int = 10):
        self.credential_manager = credential_manager
        self.max_parallel_regions = max_parallel_regions
        self._plugins: dict[str, ScannerPlugin] = {}
        self._register_default_plugins()

    def _register_default_plugins(self):
        """Register built-in plugins."""
        self.register_plugin(AWSScannerPlugin())

    def register_plugin(self, plugin: ScannerPlugin):
        """Register a scanner plugin for a cloud provider."""
        self._plugins[plugin.provider] = plugin
        logger.info(f"Registered scanner plugin: {plugin.provider}")

    def scan(self, request: ScanRequest, cred: CredentialConfig) -> ScanResult:
        """Execute a full scan.

        This is the main entry point for scanning a cloud account.

        Steps (Part 2 — Scan Cycle):
        1. Validate credentials
        2. Create secure session
        3. Discover regions
        4. Scan global resources
        5. Scan regional resources (in parallel)
        6. Merge and deduplicate
        7. Return result
        """
        start_time = time.time()
        scan_id = f"scan-{int(start_time * 1000)}"
        result = ScanResult(
            scan_id=scan_id,
            tenant_id=request.tenant_id,
            workspace_id=request.workspace_id,
            scanners_run=request.scanners,
        )

        # 1. Get plugin for this provider
        plugin = self._plugins.get(cred.provider)
        if not plugin:
            result.status = "failed"
            result.error = f"No scanner plugin registered for provider: {cred.provider}"
            return result

        # 2. Acquire session
        try:
            session = self.credential_manager.get_session(request.cloud_account_id, cred)
        except Exception as e:
            result.status = "failed"
            result.error = f"Credential acquisition failed: {e}"
            return result

        # 3. Validate credentials
        validation = plugin.validate_credentials(session)
        if not validation["valid"]:
            result.status = "failed"
            result.error = f"Credential validation failed: {validation.get('error', 'Unknown')}"
            return result

        logger.info(
            f"Starting scan for account {validation['account_id']}",
            extra={"scan_id": scan_id, "account_id": validation["account_id"], "scanners": request.scanners},
        )

        all_assets: list[Asset] = []
        all_relationships: list[AssetRelationship] = []

        # 4. Scan global resources (IAM, S3, Organizations)
        try:
            global_assets, global_rels = plugin.scan_global(session, request.scanners)
            all_assets.extend(global_assets)
            all_relationships.extend(global_rels)
        except Exception as e:
            logger.error(f"Global scan failed: {e}")

        # 5. Discover regions
        if request.regions:
            regions = request.regions
        else:
            regions = plugin.discover_regions(session)

        result.regions_scanned = len(regions)

        # 6. Scan regions in parallel
        with ThreadPoolExecutor(max_workers=min(len(regions), self.max_parallel_regions)) as executor:
            future_to_region = {}
            for region in regions:
                future = executor.submit(plugin.scan_region, session, region, request.scanners)
                future_to_region[future] = region

            for future in as_completed(future_to_region):
                region = future_to_region[future]
                try:
                    region_assets, region_rels = future.result()
                    all_assets.extend(region_assets)
                    all_relationships.extend(region_rels)
                except Exception as e:
                    logger.error(f"Region {region} scan failed: {e}")

        # 7. Deduplicate assets by ARN
        seen_arns: set[str] = set()
        unique_assets: list[Asset] = []
        for asset in all_assets:
            if asset.arn not in seen_arns:
                seen_arns.add(asset.arn)
                unique_assets.append(asset)

        # 8. Deduplicate relationships
        seen_rels: set[str] = set()
        unique_rels: list[AssetRelationship] = []
        for rel in all_relationships:
            key = f"{rel.from_asset_arn}->{rel.to_asset_arn}:{rel.relationship_type}"
            if key not in seen_rels:
                seen_rels.add(key)
                unique_rels.append(rel)

        # 9. Build result
        result.assets = unique_assets
        result.relationships = unique_rels
        result.scan_mode = "real-aws"
        result.duration_ms = int((time.time() - start_time) * 1000)
        result.total_assets = len(unique_assets)

        logger.info(
            f"Scan completed: {len(unique_assets)} assets, {len(unique_rels)} relationships in {result.duration_ms}ms",
            extra={"scan_id": scan_id, "duration_ms": result.duration_ms},
        )

        return result

    # ═══════════════════════════════════════════════════════════════
    # VPC and EBS Scanners (CIS 3.9, 6.1)
    # ═══════════════════════════════════════════════════════════════

    def _scan_vpcs(self, session, region):
        """Scan VPCs for flow logs (CIS 3.9)."""
        ec2 = self._make_client("ec2", session, region)
        assets = []
        try:
            paginator = ec2.get_paginator("describe_vpcs")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for vpc in page.get("Vpcs", []):
                    vpc_id = vpc["VpcId"]
                    arn = f"arn:aws:ec2:{region}:{session.account_id}:vpc/{vpc_id}"
                    flow_logs_enabled = False
                    try:
                        fl = self._retry_api_call(ec2.describe_flow_logs, Filters=[{"Name": "resource-id", "Values": [vpc_id]}])
                        flow_logs_enabled = len(fl.get("FlowLogs", [])) > 0
                    except ClientError:
                        pass
                    assets.append(Asset(
                        provider="aws", service="ec2", resource_type="aws_vpc",
                        external_id=vpc_id, arn=arn, name=vpc_id, region=region,
                        metadata={"VpcId": vpc_id, "CidrBlock": vpc.get("CidrBlock", ""),
                                  "flow_logs_enabled": flow_logs_enabled},
                    ))
        except ClientError as e:
            logger.warning(f"VPC scan failed in {region}: {e}")
        return assets

    def _scan_ebs_volumes(self, session, region):
        """Scan EBS volumes for encryption (CIS 6.1)."""
        ec2 = self._make_client("ec2", session, region)
        assets = []
        try:
            paginator = ec2.get_paginator("describe_volumes")
            for page in self._retry_api_call(lambda: paginator.paginate()):
                for vol in page.get("Volumes", []):
                    vol_id = vol["VolumeId"]
                    arn = f"arn:aws:ec2:{region}:{session.account_id}:volume/{vol_id}"
                    assets.append(Asset(
                        provider="aws", service="ec2", resource_type="aws_ebs_volume",
                        external_id=vol_id, arn=arn, name=vol_id, region=region,
                        metadata={"VolumeId": vol_id, "Size": vol.get("Size", 0),
                                  "encrypted": vol.get("Encrypted", False)},
                    ))
        except ClientError as e:
            logger.warning(f"EBS scan failed in {region}: {e}")
        return assets
