"""
CIS AWS Foundations Benchmark v3.0 — Rule definitions.

This module registers real CIS AWS security rules into the RuleEngine.
Each rule corresponds to a CIS control and evaluates actual AWS resource
metadata returned by the ScannerEngine.

Scientific Basis:
  - CIS AWS Foundations Benchmark v3.0 (Center for Internet Security)
  - NIST SP 800-53 Rev 5 (security controls mapping)
  - AWS Security Best Practices (AWS documentation)
  - OWASP Cloud Security Top 10

Each rule:
  1. Has a rule_id matching CIS control (e.g., "CIS-AWS-1.3")
  2. Targets a specific resource type (e.g., aws_iam_user)
  3. Evaluates metadata fields from real AWS API responses
  4. Returns a Finding if the condition is met
  5. Includes remediation steps (CLI command or Terraform)
"""
from __future__ import annotations

import logging
from typing import Any

from core.models import Rule, Severity

logger = logging.getLogger(__name__)


def get_cis_aws_rules() -> list[Rule]:
    """Return all CIS AWS Foundations Benchmark v3.0 rules.

    These rules are registered into the RuleEngine and evaluated
    against real AWS resources scanned by the ScannerEngine.

    Each rule uses the DSL (Domain Specific Language) to express
    the condition that triggers a finding.

    DSL syntax (simplified):
      condition: <field> <operator> <value>
      Operators: ==, !=, contains, not_contains, exists, not_exists, in, not_in
      Fields: resource.metadata.<field_name> or resource.tags.<tag_name>
    """
    rules = []

    # ═══════════════════════════════════════════════════════════════
    # 1. IDENTITY AND ACCESS MANAGEMENT (CIS 1.x)
    # ═══════════════════════════════════════════════════════════════

    # CIS 1.3 — MFA enabled for all IAM users with console access
    rules.append(Rule(
        rule_id="CIS-AWS-1.3",
        name="Ensure MFA is enabled for all IAM users with console access",
        description="IAM users with console access must have MFA enabled. "
                    "Without MFA, a compromised password gives full account access.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.HIGH,
        category="iam",
        provider="aws",
        service="iam",
        resource_type="aws_iam_user",
        dsl='condition: metadata.mfa_active == false AND metadata.console_access == true',
        dsl_version="1.0",
        remediation="Enable MFA for the IAM user via AWS Console or CLI: "
                    "aws iam create-virtual-mfa-device --path / --virtual-mfa-device-name <user>-mfa",
        remediation_cli="aws iam enable-mfa-device --user-name <user> --serial-number <arn> "
                        "--authentication-code-1 <code1> --authentication-code-2 <code2>",
        cvss_score=7.5,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
        references=[
            "https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_mfa_enable.html",
            "https://www.cisecurity.org/benchmark/amazon_web_services"
        ],
        cwe_ids=["CWE-308"],
        mitre_attack_ids=["T1078.004"],
        tags=["cis", "iam", "mfa", "console"],
        default_sla_hours=72,
    ))

    # CIS 1.4 — Access keys rotated every 90 days
    rules.append(Rule(
        rule_id="CIS-AWS-1.4",
        name="Ensure access keys are rotated every 90 days",
        description="Access keys older than 90 days should be rotated to reduce "
                    "the risk of credential compromise.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.MEDIUM,
        category="iam",
        provider="aws",
        service="iam",
        resource_type="aws_iam_user",
        dsl='condition: metadata.key_age_days > 90 AND metadata.has_access_keys == true',
        dsl_version="1.0",
        remediation="Create a new access key, update applications, then deactivate the old key: "
                    "aws iam create-access-key --user-name <user>",
        remediation_cli="aws iam update-access-key --access-key-id <old-key> --status Inactive --user-name <user>",
        cvss_score=5.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-269"],
        mitre_attack_ids=["T1078.004"],
        tags=["cis", "iam", "access_keys", "rotation"],
        default_sla_hours=720,
    ))

    # CIS 1.10 — No wildcard permissions (Action: *)
    rules.append(Rule(
        rule_id="CIS-AWS-1.10",
        name="Ensure no IAM policies grant full administrative privileges",
        description="IAM policies with Action: '*' and Resource: '*' grant full "
                    "administrative access. This violates least-privilege principle.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.CRITICAL,
        category="iam",
        provider="aws",
        service="iam",
        resource_type="aws_iam_policy",
        dsl='condition: metadata.has_wildcard_action == true',
        dsl_version="1.0",
        remediation="Replace the wildcard policy with a least-privilege custom policy. "
                    "Use IAM Access Analyzer to identify required permissions.",
        remediation_cli="aws iam create-policy --policy-name LeastPrivilege --policy-document file://policy.json",
        cvss_score=9.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
        cwe_ids=["CWE-269"],
        mitre_attack_ids=["T1078.004", "T1098.001"],
        tags=["cis", "iam", "privilege_escalation", "admin"],
        default_sla_hours=24,
    ))

    # CIS 1.16 — Root account has no access keys
    rules.append(Rule(
        rule_id="CIS-AWS-1.16",
        name="Ensure root account has no access keys",
        description="Root account access keys provide unlimited access. They should be removed.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.CRITICAL,
        category="iam",
        provider="aws",
        service="iam",
        resource_type="aws_iam_user",
        dsl='condition: metadata.is_root == true AND metadata.has_access_keys == true',
        dsl_version="1.0",
        remediation="Delete root access keys immediately: "
                    "aws iam delete-access-key --access-key-id <key> --user-name root",
        cvss_score=10.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H",
        cwe_ids=["CWE-269"],
        mitre_attack_ids=["T1078.004"],
        tags=["cis", "iam", "root", "access_keys"],
        default_sla_hours=24,
    ))

    # ═══════════════════════════════════════════════════════════════
    # 2. STORAGE (CIS 2.x)
    # ═══════════════════════════════════════════════════════════════

    # CIS 2.1 — S3 Block Public Access at account level
    rules.append(Rule(
        rule_id="CIS-AWS-2.1",
        name="Ensure S3 Block Public Access is enabled at account level",
        description="Account-level Block Public Access prevents public bucket creation.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.CRITICAL,
        category="storage",
        provider="aws",
        service="s3",
        resource_type="aws_s3_account_settings",
        dsl='condition: metadata.block_public_access == false',
        dsl_version="1.0",
        remediation="Enable S3 Block Public Access at account level: "
                    "aws s3api put-public-access-block --public-access-block-configuration "
                    '"BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"',
        cvss_score=9.5,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
        cwe_ids=["CWE-732"],
        mitre_attack_ids=["T1530"],
        tags=["cis", "s3", "public_access"],
        default_sla_hours=24,
    ))

    # CIS 2.2 — S3 default encryption
    rules.append(Rule(
        rule_id="CIS-AWS-2.2",
        name="Ensure S3 buckets have default encryption enabled",
        description="S3 buckets without encryption expose data at rest.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.HIGH,
        category="storage",
        provider="aws",
        service="s3",
        resource_type="aws_s3_bucket",
        dsl='condition: metadata.encrypted == false',
        dsl_version="1.0",
        remediation="Enable SSE-S3 encryption: "
                    "aws s3api put-bucket-encryption --bucket <bucket> "
                    "--server-side-encryption-configuration "
                    "'{\"Rules\":[{\"ApplyServerSideEncryptionByDefault\":{\"SSEAlgorithm\":\"AES256\"}}]}'",
        remediation_cli="aws s3api put-bucket-encryption --bucket <bucket> --server-side-encryption-configuration file://encryption.json",
        cvss_score=7.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
        cwe_ids=["CWE-311"],
        mitre_attack_ids=["T1530"],
        tags=["cis", "s3", "encryption"],
        default_sla_hours=72,
    ))

    # CIS 2.3 — S3 versioning enabled
    rules.append(Rule(
        rule_id="CIS-AWS-2.3",
        name="Ensure S3 buckets have versioning enabled",
        description="Versioning protects against accidental deletion and ransomware.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.MEDIUM,
        category="storage",
        provider="aws",
        service="s3",
        resource_type="aws_s3_bucket",
        dsl='condition: metadata.versioning_enabled == false',
        dsl_version="1.0",
        remediation="Enable versioning: aws s3api put-bucket-versioning --bucket <bucket> --versioning-configuration Status=Enabled",
        cvss_score=4.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:L/A:N",
        cwe_ids=["CWE-732"],
        tags=["cis", "s3", "versioning"],
        default_sla_hours=720,
    ))

    # CIS 2.4 — S3 no public read ACL
    rules.append(Rule(
        rule_id="CIS-AWS-2.4",
        name="Ensure S3 buckets are not publicly readable",
        description="S3 buckets with public-read ACL expose data to the internet.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.CRITICAL,
        category="storage",
        provider="aws",
        service="s3",
        resource_type="aws_s3_bucket",
        dsl='condition: metadata.acl in ["public-read", "public-read-write", "website"]',
        dsl_version="1.0",
        remediation="Set ACL to private: aws s3api put-bucket-acl --bucket <bucket> --acl private",
        remediation_cli="aws s3api put-bucket-acl --bucket <bucket> --acl private",
        cvss_score=9.5,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N",
        cwe_ids=["CWE-732"],
        mitre_attack_ids=["T1530", "T1567.002"],
        tags=["cis", "s3", "public_access", "data_exposure"],
        default_sla_hours=24,
    ))

    # ═══════════════════════════════════════════════════════════════
    # 3. LOGGING (CIS 3.x)
    # ═══════════════════════════════════════════════════════════════

    # CIS 3.1 — CloudTrail enabled in all regions
    rules.append(Rule(
        rule_id="CIS-AWS-3.1",
        name="Ensure CloudTrail is enabled in all regions",
        description="CloudTrail logs all API calls. Without it, security incidents cannot be investigated.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.HIGH,
        category="logging",
        provider="aws",
        service="cloudtrail",
        resource_type="aws_cloudtrail",
        dsl='condition: metadata.is_multi_region_trail == false',
        dsl_version="1.0",
        remediation="Create a multi-region trail: "
                    "aws cloudtrail create-trail --name sentinel --s3-bucket-name <bucket> --is-multi-region-trail",
        cvss_score=7.5,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
        cwe_ids=["CWE-778"],
        mitre_attack_ids=["T1562.001"],
        tags=["cis", "cloudtrail", "logging", "audit"],
        default_sla_hours=72,
    ))

    # ═══════════════════════════════════════════════════════════════
    # 5. NETWORKING (CIS 5.x)
    # ═══════════════════════════════════════════════════════════════

    # CIS 5.1 — No SSH open to internet
    rules.append(Rule(
        rule_id="CIS-AWS-5.1",
        name="Ensure no security group allows SSH (port 22) from 0.0.0.0/0",
        description="SSH open to the internet allows brute-force attacks and server compromise.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.CRITICAL,
        category="networking",
        provider="aws",
        service="ec2",
        resource_type="aws_security_group",
        dsl='condition: metadata.ssh_open == true',
        dsl_version="1.0",
        remediation="Revoke the SSH rule: "
                    "aws ec2 revoke-security-group-ingress --group-id <sg> --protocol tcp --port 22 --cidr 0.0.0.0/0",
        remediation_cli="aws ec2 revoke-security-group-ingress --group-id <sg-id> --protocol tcp --port 22 --cidr 0.0.0.0/0",
        cvss_score=9.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
        cwe_ids=["CWE-284"],
        mitre_attack_ids=["T1110.001", "T1021.004"],
        tags=["cis", "security_group", "ssh", "network"],
        default_sla_hours=24,
    ))

    # CIS 5.2 — No RDP open to internet
    rules.append(Rule(
        rule_id="CIS-AWS-5.2",
        name="Ensure no security group allows RDP (port 3389) from 0.0.0.0/0",
        description="RDP open to the internet allows brute-force attacks and ransomware.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.CRITICAL,
        category="networking",
        provider="aws",
        service="ec2",
        resource_type="aws_security_group",
        dsl='condition: metadata.rdp_open == true',
        dsl_version="1.0",
        remediation="Revoke the RDP rule: "
                    "aws ec2 revoke-security-group-ingress --group-id <sg> --protocol tcp --port 3389 --cidr 0.0.0.0/0",
        cvss_score=9.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
        cwe_ids=["CWE-284"],
        mitre_attack_ids=["T1110.001", "T1021.001"],
        tags=["cis", "security_group", "rdp", "network"],
        default_sla_hours=24,
    ))

    # CIS 5.3 — No security group allows all traffic
    rules.append(Rule(
        rule_id="CIS-AWS-5.3",
        name="Ensure no security group allows all traffic",
        description="Security groups with 0.0.0.0/0 on all ports expose all services.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.HIGH,
        category="networking",
        provider="aws",
        service="ec2",
        resource_type="aws_security_group",
        dsl='condition: metadata.all_traffic_open == true',
        dsl_version="1.0",
        remediation="Remove the all-traffic rule and add specific port rules.",
        remediation_cli="aws ec2 revoke-security-group-ingress --group-id <sg-id> --ip-permissions IpProtocol=-1,FromPort=0,ToPort=65535,IpRanges=[{CidrIp=0.0.0.0/0}]",
        cvss_score=8.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
        cwe_ids=["CWE-284"],
        mitre_attack_ids=["T1046", "T1021"],
        tags=["cis", "security_group", "open_ports", "network"],
        default_sla_hours=72,
    ))

    # ═══════════════════════════════════════════════════════════════
    # 6. COMPUTE (CIS 6.x)
    # ═══════════════════════════════════════════════════════════════

    # CIS 6.1 — EBS encryption
    rules.append(Rule(
        rule_id="CIS-AWS-6.1",
        name="Ensure EBS volumes are encrypted",
        description="Unencrypted EBS volumes expose data at rest.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.MEDIUM,
        category="compute",
        provider="aws",
        service="ec2",
        resource_type="aws_ebs_volume",
        dsl='condition: metadata.encrypted == false',
        dsl_version="1.0",
        remediation="Enable EBS encryption by default: aws ec2 enable-ebs-encryption-by-default",
        cvss_score=5.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
        cwe_ids=["CWE-311"],
        tags=["cis", "ebs", "encryption"],
        default_sla_hours=720,
    ))

    # CIS 6.3 — RDS encryption at rest
    rules.append(Rule(
        rule_id="CIS-AWS-6.3",
        name="Ensure RDS instances have encryption at rest enabled",
        description="Unencrypted RDS instances expose database data at rest.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.HIGH,
        category="database",
        provider="aws",
        service="rds",
        resource_type="aws_db_instance",
        dsl='condition: metadata.storage_encrypted == false',
        dsl_version="1.0",
        remediation="Create encrypted snapshot, restore to new encrypted instance, then switch.",
        cvss_score=7.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
        cwe_ids=["CWE-311"],
        tags=["cis", "rds", "encryption"],
        default_sla_hours=720,
    ))

    # CIS 6.6 — RDS not publicly accessible
    rules.append(Rule(
        rule_id="CIS-AWS-6.6",
        name="Ensure RDS instances are not publicly accessible",
        description="Publicly accessible RDS instances can be attacked from the internet.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.CRITICAL,
        category="database",
        provider="aws",
        service="rds",
        resource_type="aws_db_instance",
        dsl='condition: metadata.publicly_accessible == true',
        dsl_version="1.0",
        remediation="Set publicly_accessible to false: "
                    "aws rds modify-db-instance --db-instance-identifier <id> --no-publicly-accessible --apply-immediately",
        remediation_cli="aws rds modify-db-instance --db-instance-identifier <id> --no-publicly-accessible --apply-immediately",
        cvss_score=9.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
        cwe_ids=["CWE-284"],
        mitre_attack_ids=["T1021"],
        tags=["cis", "rds", "public_access"],
        default_sla_hours=24,
    ))

    # CIS 6.9 — EKS secrets encryption
    rules.append(Rule(
        rule_id="CIS-AWS-6.9",
        name="Ensure EKS cluster secrets are encrypted with KMS",
        description="EKS secrets should be encrypted with a customer-managed KMS key.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.HIGH,
        category="container",
        provider="aws",
        service="eks",
        resource_type="aws_eks_cluster",
        dsl='condition: metadata.secrets_encrypted == false',
        dsl_version="1.0",
        remediation="Create a new cluster with encryption config: "
                    "eksctl create cluster --name <name> --encryption-config resources=secrets,kmsKeyID=<key>",
        cvss_score=7.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
        cwe_ids=["CWE-311"],
        tags=["cis", "eks", "encryption", "kubernetes"],
        default_sla_hours=720,
    ))

    # CIS 6.7 — EC2 IMDSv2 required
    rules.append(Rule(
        rule_id="CIS-AWS-6.7",
        name="Ensure EC2 instances require IMDSv2",
        description="IMDSv2 prevents SSRF attacks that could steal instance credentials.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.MEDIUM,
        category="compute",
        provider="aws",
        service="ec2",
        resource_type="aws_ec2_instance",
        dsl='condition: metadata.http_tokens == "optional"',
        dsl_version="1.0",
        remediation="Require IMDSv2: "
                    "aws ec2 modify-instance-metadata-options --instance-id <id> --http-tokens required",
        cvss_score=6.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:N",
        cwe_ids=["CWE-918"],
        mitre_attack_ids=["T1552.005"],
        tags=["cis", "ec2", "imds", "ssrf"],
        default_sla_hours=720,
    ))

    # CIS 1.2 — MFA enabled for root
    rules.append(Rule(
        rule_id="CIS-AWS-1.2",
        name="Ensure MFA is enabled for the root account",
        description="Root account MFA is critical — root has unlimited access.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.CRITICAL,
        category="iam",
        provider="aws",
        service="iam",
        resource_type="aws_iam_user",
        dsl='condition: metadata.is_root == true AND metadata.mfa_active == false',
        dsl_version="1.0",
        remediation="Enable MFA on root account via AWS Console (must be done as root).",
        cvss_score=10.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H",
        cwe_ids=["CWE-308"],
        mitre_attack_ids=["T1078.004"],
        tags=["cis", "iam", "root", "mfa"],
        default_sla_hours=24,
    ))

    # CIS 1.5 — Password policy: minimum length 14
    rules.append(Rule(
        rule_id="CIS-AWS-1.5",
        name="Ensure IAM password policy requires minimum length of 14 or greater",
        description="Weak password policy allows brute-force attacks.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.MEDIUM,
        category="iam",
        provider="aws",
        service="iam",
        resource_type="aws_iam_account_password_policy",
        dsl='condition: metadata.minimum_password_length < 14',
        dsl_version="1.0",
        remediation="Update password policy: "
                    "aws iam update-account-password-policy --minimum-password-length 14 "
                    "--require-symbols --require-numbers --require-uppercase-characters "
                    "--require-lowercase-characters --max-password-age 90 --password-reuse-prevention 24",
        cvss_score=5.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-521"],
        tags=["cis", "iam", "password_policy"],
        default_sla_hours=720,
    ))

    # CIS 3.9 — VPC flow logs enabled
    rules.append(Rule(
        rule_id="CIS-AWS-3.9",
        name="Ensure VPC flow logs are enabled for all VPCs",
        description="VPC flow logs record network traffic for security analysis.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.MEDIUM,
        category="logging",
        provider="aws",
        service="ec2",
        resource_type="aws_vpc",
        dsl='condition: metadata.flow_logs_enabled == false',
        dsl_version="1.0",
        remediation="Enable VPC flow logs: "
                    "aws ec2 create-flow-logs --vpc-id <vpc> --log-destination-type s3 "
                    "--log-destination <arn> --traffic-type ALL",
        cvss_score=4.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
        cwe_ids=["CWE-778"],
        tags=["cis", "vpc", "flow_logs", "network"],
        default_sla_hours=720,
    ))

    # CIS 6.4 — RDS backups enabled
    rules.append(Rule(
        rule_id="CIS-AWS-6.4",
        name="Ensure RDS instances have automated backups enabled",
        description="Automated backups protect against data loss.",
        version="3.0",
        status="active",
        is_system=True,
        severity=Severity.MEDIUM,
        category="database",
        provider="aws",
        service="rds",
        resource_type="aws_db_instance",
        dsl='condition: metadata.backup_retention_period == 0',
        dsl_version="1.0",
        remediation="Enable backups: "
                    "aws rds modify-db-instance --db-instance-identifier <id> --backup-retention-period 7 --apply-immediately",
        cvss_score=4.0,
        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:C",
        cwe_ids=["CWE-732"],
        tags=["cis", "rds", "backup"],
        default_sla_hours=720,
    ))

    logger.info(f"Loaded {len(rules)} CIS AWS rules")
    return rules
