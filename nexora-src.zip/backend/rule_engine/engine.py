"""
Enterprise Rule Engine — DSL-based security rule execution.

Based on Part 2 — Rule Engine and Part 9 — Rule Execution Engine.

Features:
  - JSON-based DSL (no Python code in rules)
  - Versioned rules with enable/disable
  - Parallel execution across assets
  - Provider-independent (rules work on Universal Asset Model)
  - Tenant-specific rules
  - Execution timing and metrics
  - False positive tracking

DSL Format:
  {
    "condition": {
      "operator": "AND",
      "rules": [
        {"field": "metadata.AssumeRolePolicyDocument.Statement[0].Principal", "op": "equals", "value": "*"},
        {"field": "metadata.AssumeRolePolicyDocument.Statement[0].Effect", "op": "equals", "value": "Allow"}
      ]
    },
    "severity": "critical",
    "category": "iam",
    "compliance": ["CIS-AWS-1.3", "NIST-AC-3"]
  }

Supported operators:
  equals, not_equals, contains, not_contains, starts_with, ends_with,
  in, not_in, exists, not_exists, is_empty, is_not_empty,
  greater_than, less_than, regex_match, is_public_cidr, is_wildcard_principal
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
import ipaddress
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Optional

from core.models import Asset, Finding, Rule, RuleExecutionResult

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# DSL Field Resolver — navigate nested JSON paths
# ═══════════════════════════════════════════════════════════════

class FieldResolver:
    """Resolves dotted field paths from asset metadata.

    Supports:
    - Simple paths: "name"
    - Nested paths: "metadata.Policy"
    - Array indexing: "metadata.Statement[0].Effect"
    - Array search: "metadata.Statement[*].Principal"
    """

    @staticmethod
    def resolve(asset: Asset, field_path: str) -> Any:
        """Resolve a field path from an asset.

        Returns None if the path doesn't exist.
        Returns a list if the path includes [*] wildcard.
        """
        # Start with the asset as a dict
        data = asset.to_dict()

        # Split path into segments
        parts = FieldResolver._parse_path(field_path)

        current = data
        for key, index in parts:
            if current is None:
                return None

            if key == "":
                # Array index access
                if isinstance(current, list) and index is not None:
                    if index == "*":
                        return current  # Return all elements
                    try:
                        current = current[int(index)]
                    except (IndexError, ValueError):
                        return None
                else:
                    return None
            else:
                if isinstance(current, dict):
                    current = current.get(key)
                elif isinstance(current, list) and index == "*":
                    # Search across all items in list
                    results = []
                    for item in current:
                        if isinstance(item, dict):
                            val = item.get(key)
                            if val is not None:
                                results.append(val)
                    current = results if results else None
                else:
                    return None

            if index is not None and index != "*" and key != "":
                # Index after a key: e.g., "Statement[0]"
                if isinstance(current, list):
                    try:
                        current = current[int(index)]
                    except (IndexError, ValueError):
                        return None

        return current

    @staticmethod
    def _parse_path(path: str) -> list[tuple[str, Optional[str]]]:
        """Parse a dotted path into (key, index) tuples.

        Examples:
          "name" → [("name", None)]
          "metadata.Policy" → [("metadata", None), ("Policy", None)]
          "metadata.Statement[0].Effect" → [("metadata", None), ("Statement", "0"), ("", None), ("Effect", None)]
          "metadata.Statement[*].Principal" → [("metadata", None), ("Statement", "*"), ("", None), ("Principal", None)]
        """
        parts: list[tuple[str, Optional[str]]] = []
        segments = path.split(".")

        for seg in segments:
            # Check for array index: key[0] or key[*]
            match = re.match(r'^(\w+)\[(\d+|\*)\]$', seg)
            if match:
                key = match.group(1)
                index = match.group(2)
                parts.append((key, index))
            else:
                parts.append((seg, None))

        return parts


# ═══════════════════════════════════════════════════════════════
# Condition Evaluators
# ═══════════════════════════════════════════════════════════════

class ConditionEvaluator:
    """Evaluates DSL conditions against asset fields.

    Each operator is a pure function: (actual_value, expected_value) → bool
    """

    OPERATORS: dict[str, Callable[[Any, Any], bool]] = {}

    @classmethod
    def register(cls, name: str, func: Callable[[Any, Any], bool]):
        """Register a custom operator."""
        cls.OPERATORS[name] = func

    @classmethod
    def evaluate(cls, actual: Any, operator: str, expected: Any) -> bool:
        """Evaluate a single condition: actual OP expected."""
        func = cls.OPERATORS.get(operator)
        if not func:
            logger.warning(f"Unknown operator: {operator}", extra={"operator": operator})
            return False
        return func(actual, expected)

    @classmethod
    def evaluate_condition(cls, condition: dict[str, Any], asset: Asset) -> bool:
        """Evaluate a full condition tree against an asset.

        Condition format:
          {"operator": "AND", "rules": [...]}
          {"field": "...", "op": "...", "value": ...}
        """
        if not condition:
            return True

        # Compound condition (AND/OR/NOT)
        if "operator" in condition and "rules" in condition:
            op = condition["operator"].upper()
            rules = condition["rules"]

            if op == "AND":
                return all(cls.evaluate_condition(r, asset) for r in rules)
            elif op == "OR":
                return any(cls.evaluate_condition(r, asset) for r in rules)
            elif op == "NOT":
                return not cls.evaluate_condition(rules[0] if isinstance(rules, list) else rules, asset)
            else:
                logger.warning(f"Unknown compound operator: {op}")
                return False

        # Simple condition
        field_path = condition.get("field", "")
        operator = condition.get("op", "equals")
        expected = condition.get("value")

        actual = FieldResolver.resolve(asset, field_path)

        # Handle list fields (e.g., Statement[*].Principal returns a list)
        if isinstance(actual, list) and operator not in ["in", "not_in", "exists", "not_exists", "is_empty", "is_not_empty"]:
            # If any element matches, the condition is true
            if not actual:
                return cls.evaluate(None, operator, expected)
            return any(cls.evaluate(item, operator, expected) for item in actual)

        return cls.evaluate(actual, operator, expected)


# ═══════════════════════════════════════════════════════════════
# Built-in Operators
# ═══════════════════════════════════════════════════════════════

def _register_builtin_operators():
    """Register all built-in DSL operators."""

    def equals(actual, expected):
        return actual == expected

    def not_equals(actual, expected):
        return actual != expected

    def contains(actual, expected):
        if actual is None:
            return False
        if isinstance(actual, (list, str, dict)):
            return expected in actual
        return False

    def not_contains(actual, expected):
        if actual is None:
            return True
        if isinstance(actual, (list, str, dict)):
            return expected not in actual
        return True

    def starts_with(actual, expected):
        if isinstance(actual, str):
            return actual.startswith(expected)
        return False

    def ends_with(actual, expected):
        if isinstance(actual, str):
            return actual.endswith(expected)
        return False

    def in_list(actual, expected):
        if not isinstance(expected, list):
            expected = [expected]
        return actual in expected

    def not_in(actual, expected):
        if not isinstance(expected, list):
            expected = [expected]
        return actual not in expected

    def exists(actual, expected):
        return actual is not None

    def not_exists(actual, expected):
        return actual is None

    def is_empty(actual, expected):
        if actual is None:
            return True
        if isinstance(actual, (list, str, dict)):
            return len(actual) == 0
        return False

    def is_not_empty(actual, expected):
        if actual is None:
            return False
        if isinstance(actual, (list, str, dict)):
            return len(actual) > 0
        return True

    def greater_than(actual, expected):
        try:
            return float(actual) > float(expected)
        except (TypeError, ValueError):
            return False

    def less_than(actual, expected):
        try:
            return float(actual) < float(expected)
        except (TypeError, ValueError):
            return False

    def regex_match(actual, expected):
        if not isinstance(actual, str):
            return False
        try:
            return bool(re.search(expected, actual))
        except re.error:
            return False

    def is_public_cidr(actual, expected):
        """Check if a CIDR is public (0.0.0.0/0)."""
        if actual is None:
            return False
        cidrs = actual if isinstance(actual, list) else [actual]
        for cidr in cidrs:
            if isinstance(cidr, dict):
                cidr = cidr.get("CidrIp", "")
            if isinstance(cidr, str) and cidr == "0.0.0.0/0":
                return True
        return False

    def is_wildcard_principal(actual, expected):
        """Check if a Principal is wildcard (* or {AWS: '*'} or {Service: '*'})."""
        if actual is None:
            return False
        if actual == "*":
            return True
        if isinstance(actual, dict):
            for key in ["AWS", "Service", "Federated"]:
                val = actual.get(key)
                if val == "*":
                    return True
                if isinstance(val, list) and "*" in val:
                    return True
        return False

    def has_public_acl(actual, expected):
        """Check if S3 ACL grants public access."""
        if not isinstance(actual, list):
            return False
        for grant in actual:
            grantee = grant.get("Grantee", {})
            uri = grantee.get("URI", "")
            if uri.endswith("AllUsers") or uri.endswith("AuthenticatedUsers"):
                return True
        return False

    def is_none(actual, expected):
        return actual is None

    def is_not_none(actual, expected):
        return actual is not None

    def equals_ignore_case(actual, expected):
        if isinstance(actual, str) and isinstance(expected, str):
            return actual.lower() == expected.lower()
        return actual == expected

    # Register all operators
    ConditionEvaluator.register("equals", equals)
    ConditionEvaluator.register("not_equals", not_equals)
    ConditionEvaluator.register("contains", contains)
    ConditionEvaluator.register("not_contains", not_contains)
    ConditionEvaluator.register("starts_with", starts_with)
    ConditionEvaluator.register("ends_with", ends_with)
    ConditionEvaluator.register("in", in_list)
    ConditionEvaluator.register("not_in", not_in)
    ConditionEvaluator.register("exists", exists)
    ConditionEvaluator.register("not_exists", not_exists)
    ConditionEvaluator.register("is_empty", is_empty)
    ConditionEvaluator.register("is_not_empty", is_not_empty)
    ConditionEvaluator.register("greater_than", greater_than)
    ConditionEvaluator.register("less_than", less_than)
    ConditionEvaluator.register("regex_match", regex_match)
    ConditionEvaluator.register("is_public_cidr", is_public_cidr)
    ConditionEvaluator.register("is_wildcard_principal", is_wildcard_principal)
    ConditionEvaluator.register("has_public_acl", has_public_acl)
    ConditionEvaluator.register("is_none", is_none)
    ConditionEvaluator.register("is_not_none", is_not_none)
    ConditionEvaluator.register("equals_ignore_case", equals_ignore_case)


# Register on import
_register_builtin_operators()


# ═══════════════════════════════════════════════════════════════
# Rule Engine
# ═══════════════════════════════════════════════════════════════

class RuleEngine:
    """Executes security rules against assets and generates findings.

    Features:
    - Parallel execution across assets (ThreadPoolExecutor)
    - Provider-independent (rules use Universal Asset Model)
    - Rule filtering by provider, service, resource_type
    - Execution metrics (time, pass/fail counts)
    - Finding deduplication via fingerprinting
    - SLA computation based on severity
    """

    # SLA hours by severity
    SLA_HOURS = {
        "critical": 24,
        "high": 72,
        "medium": 720,  # 30 days
        "low": 2160,    # 90 days
        "info": 0,
    }

    def __init__(self, max_parallel: int = 20):
        self.max_parallel = max_parallel
        self._rules: list[Rule] = []
        self._execution_count = 0
        self._total_execution_time_ms = 0

    @staticmethod
    def _parse_dsl(dsl_str: str) -> dict[str, Any]:
        """Parse a DSL string into a condition dict.

        Supports: 'condition: field op value AND field2 op value2'
        Operators: ==, !=, >, <, >=, <=, contains, in, not_in, exists
        """
        if not dsl_str:
            return {}

        dsl = dsl_str.strip()
        if dsl.lower().startswith("condition:"):
            dsl = dsl[10:].strip()

        import re
        parts = re.split(r'\s+(AND|OR)\s+', dsl, flags=re.IGNORECASE)

        op_map = {
            '==': 'equals', '!=': 'not_equals', '>': 'greater_than',
            '<': 'less_than', '>=': 'greater_than', '<=': 'less_than',
            'contains': 'contains', 'not_contains': 'not_contains',
            'in': 'in', 'not_in': 'not_in', 'exists': 'exists', 'not_exists': 'not_exists',
        }

        rules = []
        operator = "AND"
        for part in parts:
            part = part.strip()
            if part.upper() in ("AND", "OR"):
                operator = part.upper()
                continue
            match = re.match(
                r'^(\S+)\s+(==|!=|>=|<=|>|<|contains|not_contains|in|not_in|exists|not_exists)\s+(.+)$',
                part
            )
            if match:
                field = match.group(1)
                op = op_map.get(match.group(2), 'equals')
                value_str = match.group(3).strip()

                if value_str.lower() == "true":
                    value = True
                elif value_str.lower() == "false":
                    value = False
                elif value_str.startswith('"') and value_str.endswith('"'):
                    value = value_str[1:-1]
                elif value_str.startswith('[') and value_str.endswith(']'):
                    value = [v.strip().strip('"') for v in value_str[1:-1].split(',')]
                else:
                    try:
                        value = int(value_str)
                    except ValueError:
                        try:
                            value = float(value_str)
                        except ValueError:
                            value = value_str

                rules.append({"field": field, "op": op, "value": value})

        if not rules:
            return {}
        if len(rules) == 1:
            return rules[0]
        return {"operator": operator, "rules": rules}

    def register_rule(self, rule: Rule):
        """Register a security rule."""
        if rule.status != "active":
            return
        self._rules.append(rule)
        logger.debug(f"Registered rule: {rule.rule_id} ({rule.severity})")

    def register_rules(self, rules: list[Rule]):
        """Register multiple rules."""
        for rule in rules:
            self.register_rule(rule)

    def get_rules(self) -> list[Rule]:
        """Get all registered rules."""
        return list(self._rules)

    def execute_all(self, assets: list[Asset], tenant_id: str = "", workspace_id: str = "", scan_id: str = "") -> tuple[list[Finding], list[RuleExecutionResult]]:
        """Execute all registered rules against all assets.

        Returns:
            Tuple of (findings, execution_results)
        """
        all_findings: list[Finding] = []
        all_results: list[RuleExecutionResult] = []

        # Group assets by type for efficient rule matching
        assets_by_type: dict[str, list[Asset]] = {}
        for asset in assets:
            # Use .value if provider is an enum for correct string matching
            provider_str = asset.provider.value if hasattr(asset.provider, 'value') else str(asset.provider)
            key = f"{provider_str}:{asset.resource_type}"
            assets_by_type.setdefault(key, []).append(asset)

        # Execute rules in parallel
        with ThreadPoolExecutor(max_workers=self.max_parallel) as executor:
            future_to_rule = {}

            for rule in self._rules:
                # Determine which assets this rule applies to
                target_key = f"{rule.provider}:{rule.resource_type}" if rule.resource_type else None

                if target_key:
                    target_assets = assets_by_type.get(target_key, [])
                elif rule.service:
                    # Match by service
                    target_assets = [a for a in assets if a.service == rule.service and a.provider == rule.provider]
                else:
                    # Match all assets for this provider
                    target_assets = [a for a in assets if a.provider == rule.provider]

                if not target_assets:
                    continue

                future = executor.submit(self._execute_rule, rule, target_assets, tenant_id, workspace_id, scan_id)
                future_to_rule[future] = rule

            for future in as_completed(future_to_rule):
                rule = future_to_rule[future]
                try:
                    findings, results = future.result()
                    all_findings.extend(findings)
                    all_results.extend(results)
                except Exception as e:
                    logger.error(f"Rule execution failed for {rule.rule_id}: {e}")
                    all_results.append(RuleExecutionResult(
                        rule_id=rule.rule_id,
                        asset_arn="",
                        status="error",
                        error=str(e),
                    ))

        # Deduplicate findings by fingerprint
        seen_fingerprints: set[str] = set()
        unique_findings: list[Finding] = []
        for f in all_findings:
            if not f.fingerprint:
                f = Finding(**{**f.to_dict(), "fingerprint": f.compute_fingerprint()})
            if f.fingerprint not in seen_fingerprints:
                seen_fingerprints.add(f.fingerprint)
                unique_findings.append(f)

        logger.info(
            f"Rule engine: {len(self._rules)} rules, {len(assets)} assets, "
            f"{len(unique_findings)} findings ({len(all_findings)} before dedup)",
        )

        return unique_findings, all_results

    def _execute_rule(
        self,
        rule: Rule,
        assets: list[Asset],
        tenant_id: str,
        workspace_id: str,
        scan_id: str,
    ) -> tuple[list[Finding], list[RuleExecutionResult]]:
        """Execute a single rule against a list of assets."""
        findings: list[Finding] = []
        results: list[RuleExecutionResult] = []

        for asset in assets:
            start = time.time()
            result = RuleExecutionResult(
                rule_id=rule.rule_id,
                asset_arn=asset.arn,
            )

            try:
                # Evaluate the rule's DSL condition
                # DSL can be a string (needs parsing) or a dict (already parsed)
                if isinstance(rule.dsl, str):
                    condition = self._parse_dsl(rule.dsl)
                elif isinstance(rule.dsl, dict):
                    condition = rule.dsl.get("condition", {})
                else:
                    condition = {}
                matched = ConditionEvaluator.evaluate_condition(condition, asset)

                execution_time = int((time.time() - start) * 1000)
                result.execution_time_ms = execution_time

                if matched:
                    # Rule matched — generate finding
                    finding = self._generate_finding(rule, asset, tenant_id, workspace_id, scan_id)
                    findings.append(finding)
                    result.status = "fail"
                    result.finding = finding
                else:
                    result.status = "pass"

            except Exception as e:
                result.status = "error"
                result.error = str(e)
                logger.error(f"Rule {rule.rule_id} failed on {asset.arn}: {e}")

            results.append(result)

        return findings, results

    def _generate_finding(
        self,
        rule: Rule,
        asset: Asset,
        tenant_id: str,
        workspace_id: str,
        scan_id: str,
    ) -> Finding:
        """Generate a Finding from a matched rule and asset."""
        # Extract evidence from the asset based on rule DSL
        evidence = self._extract_evidence(rule, asset)

        # Compute SLA deadline
        sla_hours = rule.default_sla_hours or self.SLA_HOURS.get(rule.severity, 0)
        sla_deadline = time.time() + (sla_hours * 3600) if sla_hours > 0 else None

        finding = Finding(
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            scan_id=scan_id,
            asset_id=asset.id,
            asset_arn=asset.arn,
            rule_id=rule.rule_id,
            title=rule.name,
            description=rule.description,
            severity=rule.severity,
            category=rule.category,
            compliance=rule.compliance if hasattr(rule, "compliance") else [],
            cvss_score=rule.cvss_score,
            cvss_vector=rule.cvss_vector,
            remediation=rule.remediation,
            remediation_steps=rule.remediation_steps,
            evidence=evidence,
            sla_deadline=sla_deadline,
        )

        # Compute fingerprint for deduplication
        finding = Finding(**{**finding.to_dict(), "fingerprint": finding.compute_fingerprint()})

        return finding

    def _extract_evidence(self, rule: Rule, asset: Asset) -> dict[str, Any]:
        """Extract relevant evidence from the asset based on rule DSL fields."""
        evidence: dict[str, Any] = {}
        if isinstance(rule.dsl, str):
            condition = self._parse_dsl(rule.dsl)
        elif isinstance(rule.dsl, dict):
            condition = rule.dsl.get("condition", {})
        else:
            condition = {}

        def extract_fields(cond: dict[str, Any]):
            if "field" in cond:
                field_path = cond["field"]
                value = FieldResolver.resolve(asset, field_path)
                if value is not None:
                    evidence[field_path] = value
            if "rules" in cond:
                for sub in cond["rules"]:
                    extract_fields(sub)

        extract_fields(condition)
        evidence["asset_name"] = asset.name
        evidence["asset_arn"] = asset.arn
        evidence["resource_type"] = asset.resource_type
        evidence["region"] = asset.region

        return evidence

    def get_stats(self) -> dict[str, Any]:
        """Get rule engine statistics."""
        return {
            "total_rules": len(self._rules),
            "active_rules": sum(1 for r in self._rules if r.status == "active"),
            "by_severity": {
                sev: sum(1 for r in self._rules if r.severity == sev)
                for sev in ["critical", "high", "medium", "low"]
            },
            "by_category": {
                cat: sum(1 for r in self._rules if r.category == cat)
                for cat in set(r.category for r in self._rules)
            },
            "execution_count": self._execution_count,
            "avg_execution_time_ms": self._total_execution_time_ms / max(1, self._execution_count),
        }


# ═══════════════════════════════════════════════════════════════
# Built-in CIS AWS Benchmark Rules (14 rules)
# ═══════════════════════════════════════════════════════════════

def get_cis_aws_rules() -> list[Rule]:
    """Get the 14 CIS AWS Benchmark rules in DSL format.

    These rules use the Universal Asset Model and the DSL condition language.
    They are provider-independent — the same conditions work on any asset
    that has the same metadata structure.
    """
    return [
        Rule(
            rule_id="IAM-001",
            name="Overly permissive assume role policy (Principal: *)",
            description="The role trust policy allows any AWS principal to assume it.",
            severity="critical",
            category="iam",
            provider="aws",
            service="iam",
            resource_type="aws_iam_role",
            dsl={
                "condition": {
                    "operator": "AND",
                    "rules": [
                        {
                            "operator": "OR",
                            "rules": [
                                {"field": "metadata.AssumeRolePolicyDocument.Statement[*].Principal", "op": "is_wildcard_principal", "value": True},
                                {"field": "metadata.AssumeRolePolicyDocument.Statement[0].Principal", "op": "is_wildcard_principal", "value": True},
                            ],
                        },
                        {"field": "metadata.AssumeRolePolicyDocument.Statement[0].Effect", "op": "equals", "value": "Allow"},
                    ],
                },
            },
            remediation="Restrict the Principal to specific AWS accounts, services, or roles. Never use Principal: * for production roles.",
            cvss_score=9.8,
            cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
            mitre_attack_ids=["T1078.004"],
            references=[
                {"type": "url", "value": "https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements_principal.html"},
                {"type": "cis", "value": "CIS AWS Foundations Benchmark 1.3"},
            ],
            default_sla_hours=24,
        ),
        Rule(
            rule_id="IAM-002",
            name="AdministratorAccess policy attached (Action:*, Resource:*)",
            description="The role has an inline or attached policy granting Action:* on Resource:*, equivalent to AdministratorAccess.",
            severity="high",
            category="iam",
            provider="aws",
            service="iam",
            resource_type="aws_iam_role",
            dsl={
                "condition": {
                    "operator": "AND",
                    "rules": [
                        {"field": "metadata.InlinePolicies[*].PolicyDocument.Statement[*].Action", "op": "contains", "value": "*"},
                        {"field": "metadata.InlinePolicies[*].PolicyDocument.Statement[*].Resource", "op": "contains", "value": "*"},
                        {"field": "metadata.InlinePolicies[*].PolicyDocument.Statement[*].Effect", "op": "equals", "value": "Allow"},
                    ],
                },
            },
            remediation="Replace AdministratorAccess with a least-privilege custom policy that grants only the specific actions the workload requires.",
            cvss_score=8.5,
            mitre_attack_ids=["T1078.004", "T1098"],
            default_sla_hours=72,
        ),
        Rule(
            rule_id="IAM-003",
            name="Unused IAM role (90+ days since last use)",
            description="The role has not been used in over 90 days. Unused roles expand the attack surface.",
            severity="low",
            category="iam",
            provider="aws",
            service="iam",
            resource_type="aws_iam_role",
            dsl={
                "condition": {
                    "operator": "AND",
                    "rules": [
                        {"field": "metadata.LastUsed", "op": "is_none", "value": True},
                    ],
                },
            },
            remediation="Remove the role if no longer needed. If retained, audit and tighten its policies.",
            cvss_score=3.5,
            default_sla_hours=2160,
        ),
        Rule(
            rule_id="IAM-004",
            name="Compute role with S3 FullAccess (s3:*, Resource:*)",
            description="A compute service role (EC2/Lambda) has a policy granting s3:* on Resource:*. A compromised instance could read/delete all S3 data.",
            severity="high",
            category="iam",
            provider="aws",
            service="iam",
            resource_type="aws_iam_role",
            dsl={
                "condition": {
                    "operator": "AND",
                    "rules": [
                        {"field": "metadata.InlinePolicies[*].PolicyDocument.Statement[*].Action", "op": "contains", "value": "s3:*"},
                        {"field": "metadata.InlinePolicies[*].PolicyDocument.Statement[*].Resource", "op": "contains", "value": "*"},
                        {"field": "metadata.AssumeRolePolicyDocument.Statement[*].Principal.Service", "op": "contains", "value": "ec2.amazonaws.com"},
                    ],
                },
            },
            remediation="Scope S3 permissions to specific bucket ARNs and required actions (s3:GetObject, s3:PutObject).",
            cvss_score=7.7,
            mitre_attack_ids=["T1078.004"],
            default_sla_hours=72,
        ),
        Rule(
            rule_id="S3-001",
            name="S3 bucket is publicly readable",
            description="Bucket ACL or policy grants READ permission to AllUsers group.",
            severity="critical",
            category="s3",
            provider="aws",
            service="s3",
            resource_type="aws_s3_bucket",
            dsl={
                "condition": {
                    "operator": "OR",
                    "rules": [
                        {"field": "metadata.ACL", "op": "has_public_acl", "value": True},
                        {
                            "operator": "AND",
                            "rules": [
                                {"field": "metadata.Policy.Statement[*].Principal", "op": "is_wildcard_principal", "value": True},
                                {"field": "metadata.Policy.Statement[*].Effect", "op": "equals", "value": "Allow"},
                                {"field": "metadata.Policy.Statement[*].Action", "op": "contains", "value": "s3:GetObject"},
                            ],
                        },
                    ],
                },
            },
            remediation="Remove public ACL grants. Enable Block Public Access at the bucket and account level.",
            cvss_score=9.1,
            mitre_attack_ids=["T1530", "T1537"],
            default_sla_hours=24,
        ),
        Rule(
            rule_id="S3-002",
            name="S3 bucket has no server-side encryption",
            description="Bucket does not have default server-side encryption configured.",
            severity="medium",
            category="encryption",
            provider="aws",
            service="s3",
            resource_type="aws_s3_bucket",
            dsl={
                "condition": {"field": "metadata.Encryption", "op": "is_none", "value": True},
            },
            remediation="Enable SSE-S3 (AES256) or SSE-KMS on the bucket.",
            cvss_score=5.3,
            default_sla_hours=720,
        ),
        Rule(
            rule_id="S3-003",
            name="S3 bucket versioning is not enabled",
            description="Without versioning, deleted or overwritten objects cannot be recovered.",
            severity="low",
            category="s3",
            provider="aws",
            service="s3",
            resource_type="aws_s3_bucket",
            dsl={
                "condition": {
                    "operator": "OR",
                    "rules": [
                        {"field": "metadata.Versioning", "op": "not_equals", "value": "Enabled"},
                        {"field": "metadata.Versioning", "op": "is_none", "value": True},
                    ],
                },
            },
            remediation="Enable versioning and MFA delete on critical buckets.",
            cvss_score=3.7,
            default_sla_hours=2160,
        ),
        Rule(
            rule_id="S3-004",
            name="S3 bucket public access block is disabled",
            description="Block Public Access is not enabled. Future ACLs or policies could accidentally expose the bucket.",
            severity="high",
            category="s3",
            provider="aws",
            service="s3",
            resource_type="aws_s3_bucket",
            dsl={
                "condition": {
                    "operator": "OR",
                    "rules": [
                        {"field": "metadata.PublicAccessBlock.BlockPublicAcls", "op": "not_equals", "value": True},
                        {"field": "metadata.PublicAccessBlock.RestrictPublicBuckets", "op": "not_equals", "value": True},
                        {"field": "metadata.PublicAccessBlock", "op": "is_none", "value": True},
                    ],
                },
            },
            remediation="Enable all four Block Public Access settings at both bucket and account levels.",
            cvss_score=7.5,
            default_sla_hours=72,
        ),
        Rule(
            rule_id="S3-005",
            name="S3 bucket access logging is not enabled",
            description="Without access logging, you cannot audit who accessed, modified, or deleted objects.",
            severity="medium",
            category="logging",
            provider="aws",
            service="s3",
            resource_type="aws_s3_bucket",
            dsl={
                "condition": {"field": "metadata.Logging", "op": "is_none", "value": True},
            },
            remediation="Enable server access logging to a dedicated logging bucket in the same region.",
            cvss_score=4.3,
            default_sla_hours=720,
        ),
        Rule(
            rule_id="NET-001",
            name="Security group allows SSH (port 22) from 0.0.0.0/0",
            description="SSH is open to the entire internet.",
            severity="critical",
            category="network",
            provider="aws",
            service="ec2",
            resource_type="aws_security_group",
            dsl={
                "condition": {
                    "operator": "AND",
                    "rules": [
                        {"field": "metadata.IpPermissions[*].FromPort", "op": "equals", "value": 22},
                        {"field": "metadata.IpPermissions[*].IpRanges[*].CidrIp", "op": "is_public_cidr", "value": True},
                    ],
                },
            },
            remediation="Restrict SSH to known corporate CIDR ranges or use AWS Systems Manager Session Manager.",
            cvss_score=9.0,
            mitre_attack_ids=["T1110", "T1021.004"],
            default_sla_hours=24,
        ),
        Rule(
            rule_id="NET-002",
            name="Security group allows RDP (port 3389) from 0.0.0.0/0",
            description="RDP is open to the entire internet.",
            severity="critical",
            category="network",
            provider="aws",
            service="ec2",
            resource_type="aws_security_group",
            dsl={
                "condition": {
                    "operator": "AND",
                    "rules": [
                        {"field": "metadata.IpPermissions[*].FromPort", "op": "equals", "value": 3389},
                        {"field": "metadata.IpPermissions[*].IpRanges[*].CidrIp", "op": "is_public_cidr", "value": True},
                    ],
                },
            },
            remediation="Restrict RDP to specific corporate CIDR ranges via a bastion or VPN.",
            cvss_score=9.5,
            mitre_attack_ids=["T1110", "T1021.001"],
            default_sla_hours=24,
        ),
        Rule(
            rule_id="NET-003",
            name="Security group allows database port from 0.0.0.0/0",
            description="Database ports (MySQL, PostgreSQL, MSSQL, MongoDB, Redis, Elasticsearch) are publicly accessible.",
            severity="critical",
            category="network",
            provider="aws",
            service="ec2",
            resource_type="aws_security_group",
            dsl={
                "condition": {
                    "operator": "AND",
                    "rules": [
                        {
                            "operator": "OR",
                            "rules": [
                                {"field": "metadata.IpPermissions[*].FromPort", "op": "in", "value": [3306, 5432, 1433, 27017, 6379, 9200, 1521]},
                            ],
                        },
                        {"field": "metadata.IpPermissions[*].IpRanges[*].CidrIp", "op": "is_public_cidr", "value": True},
                    ],
                },
            },
            remediation="Database security groups should only allow ingress from application tier security groups.",
            cvss_score=9.4,
            default_sla_hours=24,
        ),
        Rule(
            rule_id="NET-004",
            name="Security group allows all egress traffic to 0.0.0.0/0",
            description="Outbound traffic is unrestricted.",
            severity="medium",
            category="network",
            provider="aws",
            service="ec2",
            resource_type="aws_security_group",
            dsl={
                "condition": {
                    "operator": "AND",
                    "rules": [
                        {"field": "metadata.IpPermissionsEgress[*].IpProtocol", "op": "contains", "value": "-1"},
                        {"field": "metadata.IpPermissionsEgress[*].IpRanges[*].CidrIp", "op": "is_public_cidr", "value": True},
                    ],
                },
            },
            remediation="Restrict egress to required destinations only.",
            cvss_score=5.4,
            default_sla_hours=720,
        ),
        Rule(
            rule_id="K8S-001",
            name="EKS cluster has public API server endpoint with 0.0.0.0/0 cidr",
            description="The Kubernetes API server is reachable from the internet with no IP restriction.",
            severity="critical",
            category="k8s",
            provider="aws",
            service="eks",
            resource_type="aws_eks_cluster",
            dsl={
                "condition": {
                    "operator": "AND",
                    "rules": [
                        {"field": "metadata.PublicAccess", "op": "equals", "value": True},
                        {"field": "metadata.PublicAccessCidrs", "op": "contains", "value": "0.0.0.0/0"},
                    ],
                },
            },
            remediation="Either set the API endpoint to private, or restrict publicAccessCidrs to specific corporate CIDR ranges.",
            cvss_score=8.6,
            default_sla_hours=24,
        ),
    ]
