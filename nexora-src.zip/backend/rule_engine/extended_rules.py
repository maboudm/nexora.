"""
Extended Security Rules — OWASP Top 10 Cloud + AWS Best Practices + NIST.

These rules go beyond CIS Benchmark to cover:
  - OWASP Top 10 for Cloud (2024)
  - AWS Well-Architected Framework Security Pillar
  - NIST SP 800-53 Rev 5 controls
  - AWS Foundational Security Best Practices (FSB)
  - Additional custom rules from real-world incident response

Total: 50+ rules (combined with 21 CIS = 70+ total)

Each rule is grounded in:
  - A documented security framework
  - A real-world attack vector (not theoretical)
  - A specific AWS API response field (not guesswork)
"""
from __future__ import annotations

from core.models import Rule, Severity


def get_extended_rules() -> list[Rule]:
    """Return extended security rules beyond CIS."""
    rules = []

    # ═══════════════════════════════════════════════════════════════
    # OWASP TOP 10 CLOUD (2024)
    # ═══════════════════════════════════════════════════════════════

    # OWASP C1: Broken Access Control — IAM role with overly broad trust policy
    rules.append(Rule(
        rule_id="OWASP-C1",
        name="IAM role trust policy allows all AWS principals",
        description="Role trust policy has Principal: * which allows any AWS account to assume this role.",
        version="1.0", status="active", is_system=True,
        severity=Severity.CRITICAL, category="iam", provider="aws", service="iam",
        resource_type="aws_iam_role",
        dsl='condition: metadata.trust_all_principals == true',
        remediation="Restrict trust policy to specific AWS accounts or services.",
        cvss_score=10.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H",
        cwe_ids=["CWE-269"], mitre_attack_ids=["T1078.004"],
        tags=["owasp", "iam", "trust_policy", "broken_access_control"],
    ))

    # OWASP C2: Cryptographic Failures — S3 bucket without TLS enforcement
    rules.append(Rule(
        rule_id="OWASP-C2",
        name="S3 bucket policy does not enforce TLS/HTTPS",
        description="Bucket allows HTTP requests. Data in transit is unencrypted.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="storage", provider="aws", service="s3",
        resource_type="aws_s3_bucket",
        dsl='condition: metadata.enforce_tls == false',
        remediation="Add bucket policy denying requests with aws:SecureTransport=false.",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
        cwe_ids=["CWE-319"], tags=["owasp", "s3", "tls", "crypto"],
    ))

    # OWASP C3: Injection — Lambda with environment variables containing credentials
    rules.append(Rule(
        rule_id="OWASP-C3",
        name="Lambda function has hardcoded credentials in environment",
        description="Lambda environment variables contain patterns matching passwords, API keys, or tokens.",
        version="1.0", status="active", is_system=True,
        severity=Severity.CRITICAL, category="serverless", provider="aws", service="lambda",
        resource_type="aws_lambda_function",
        dsl='condition: metadata.has_hardcoded_secrets == true',
        remediation="Move secrets to AWS Secrets Manager or SSM Parameter Store.",
        cvss_score=9.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N",
        cwe_ids=["CWE-798"], mitre_attack_ids=["T1552.001"],
        tags=["owasp", "lambda", "secrets", "injection"],
    ))

    # OWASP C4: Insecure Design — RDS without deletion protection
    rules.append(Rule(
        rule_id="OWASP-C4",
        name="RDS instance has no deletion protection",
        description="Database can be deleted accidentally or by an attacker without extra confirmation.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="database", provider="aws", service="rds",
        resource_type="aws_db_instance",
        dsl='condition: metadata.deletion_protection == false',
        remediation="Enable deletion protection: aws rds modify-db-instance --db-instance-identifier <id> --deletion-protection",
        cvss_score=4.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:C",
        cwe_ids=["CWE-1188"], tags=["owasp", "rds", "deletion_protection"],
    ))

    # OWASP C5: Security Misconfiguration — Lambda with public permissions
    rules.append(Rule(
        rule_id="OWASP-C5",
        name="Lambda function has public invoke permission",
        description="Lambda resource policy allows anyone (Principal: *) to invoke the function.",
        version="1.0", status="active", is_system=True,
        severity=Severity.CRITICAL, category="serverless", provider="aws", service="lambda",
        resource_type="aws_lambda_function",
        dsl='condition: metadata.public_invoke == true',
        remediation="Remove Principal: * from the Lambda resource-based policy.",
        cvss_score=9.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N",
        cwe_ids=["CWE-284"], mitre_attack_ids=["T1204.002"],
        tags=["owasp", "lambda", "public_access"],
    ))

    # OWASP C6: Vulnerable Components — Lambda with deprecated runtime
    rules.append(Rule(
        rule_id="OWASP-C6",
        name="Lambda function uses deprecated runtime",
        description="Lambda runtime is deprecated and no longer receives security patches.",
        version="1.0", status="active", is_system=True,
        severity=Severity.HIGH, category="serverless", provider="aws", service="lambda",
        resource_type="aws_lambda_function",
        dsl='condition: metadata.runtime_deprecated == true',
        remediation="Update Lambda function to a supported runtime (e.g., python3.12, nodejs20.x).",
        cvss_score=7.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:L",
        cwe_ids=["CWE-1104"], tags=["owasp", "lambda", "runtime", "deprecated"],
    ))

    # OWASP C7: Auth Failures — API Gateway without rate limiting
    rules.append(Rule(
        rule_id="OWASP-C7",
        name="API Gateway stage has no rate limiting",
        description="API Gateway stage does not have throttling configured.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="network", provider="aws", service="apigateway",
        resource_type="aws_api_gateway_stage",
        dsl='condition: metadata.throttling_enabled == false',
        remediation="Enable throttling on API Gateway stage.",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:C",
        cwe_ids=["CWE-770"], tags=["owasp", "apigateway", "rate_limiting"],
    ))

    # ═══════════════════════════════════════════════════════════════
    # AWS FOUNDATIONAL SECURITY BEST PRACTICES (FSB)
    # ═══════════════════════════════════════════════════════════════

    # FSB EC2.1: EC2 instance profile should not have full access
    rules.append(Rule(
        rule_id="FSB-EC2.1",
        name="EC2 instance profile grants full access",
        description="EC2 instance has an IAM role with AdministratorAccess or wildcard permissions.",
        version="1.0", status="active", is_system=True,
        severity=Severity.CRITICAL, category="compute", provider="aws", service="ec2",
        resource_type="aws_ec2_instance",
        dsl='condition: metadata.instance_profile_has_admin == true',
        remediation="Replace the instance profile role with a least-privilege policy.",
        cvss_score=9.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
        cwe_ids=["CWE-269"], mitre_attack_ids=["T1078.004"],
        tags=["fsb", "ec2", "iam", "privilege_escalation"],
    ))

    # FSB EC2.2: EC2 instance should not have public IP in production
    rules.append(Rule(
        rule_id="FSB-EC2.2",
        name="EC2 instance has a public IP address",
        description="EC2 instance is directly accessible from the internet.",
        version="1.0", status="active", is_system=True,
        severity=Severity.HIGH, category="compute", provider="aws", service="ec2",
        resource_type="aws_ec2_instance",
        dsl='condition: metadata.has_public_ip == true',
        remediation="Remove public IP. Use a load balancer or NAT gateway for internet access.",
        cvss_score=8.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:N",
        cwe_ids=["CWE-284"], mitre_attack_ids=["T1190"],
        tags=["fsb", "ec2", "public_ip", "exposure"],
    ))

    # FSB KMS.1: KMS key should have rotation enabled
    rules.append(Rule(
        rule_id="FSB-KMS.1",
        name="KMS key does not have automatic rotation enabled",
        description="KMS key material is not automatically rotated annually.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="security", provider="aws", service="kms",
        resource_type="aws_kms_key",
        dsl='condition: metadata.key_rotation_enabled == false',
        remediation="Enable key rotation: aws kms enable-key-rotation --key-id <key-id>",
        cvss_score=4.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
        cwe_ids=["CWE-326"], tags=["fsb", "kms", "rotation", "crypto"],
    ))

    # FSB S3.5: S3 bucket should have access logging enabled
    rules.append(Rule(
        rule_id="FSB-S3.5",
        name="S3 bucket does not have access logging enabled",
        description="S3 access logs are not configured. Cannot audit who accessed bucket data.",
        version="1.0", status="active", is_system=True,
        severity=Severity.LOW, category="storage", provider="aws", service="s3",
        resource_type="aws_s3_bucket",
        dsl='condition: metadata.logging_enabled == false',
        remediation="Enable S3 server access logging to a dedicated logging bucket.",
        cvss_score=3.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
        cwe_ids=["CWE-778"], tags=["fsb", "s3", "logging", "audit"],
    ))

    # FSB IAM.7: IAM password policy should require reuse prevention
    rules.append(Rule(
        rule_id="FSB-IAM.7",
        name="IAM password policy does not prevent password reuse",
        description="Password reuse prevention is not configured or is set too low.",
        version="1.0", status="active", is_system=True,
        severity=Severity.LOW, category="iam", provider="aws", service="iam",
        resource_type="aws_iam_account_password_policy",
        dsl='condition: metadata.password_reuse_prevention < 24',
        remediation="Set password reuse prevention to 24: aws iam update-account-password-policy --password-reuse-prevention 24",
        cvss_score=3.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
        cwe_ids=["CWE-521"], tags=["fsb", "iam", "password_policy"],
    ))

    # FSB RDS.5: RDS should have Multi-AZ enabled
    rules.append(Rule(
        rule_id="FSB-RDS.5",
        name="RDS instance does not have Multi-AZ enabled",
        description="Single-AZ RDS has no failover capability. Data loss risk if AZ goes down.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="database", provider="aws", service="rds",
        resource_type="aws_db_instance",
        dsl='condition: metadata.multi_az == false',
        remediation="Enable Multi-AZ: aws rds modify-db-instance --db-instance-identifier <id> --multi-az --apply-immediately",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:C",
        cwe_ids=["CWE-732"], tags=["fsb", "rds", "multi_az", "availability"],
    ))

    # FSB CloudTrail.4: CloudTrail should have log file validation
    rules.append(Rule(
        rule_id="FSB-CT.4",
        name="CloudTrail does not have log file validation enabled",
        description="Without log file validation, logs can be tampered with undetected.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="logging", provider="aws", service="cloudtrail",
        resource_type="aws_cloudtrail",
        dsl='condition: metadata.log_file_validation_enabled == false',
        remediation="Enable log file validation: aws cloudtrail update-trail --name <trail> --enable-log-file-validation",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-345"], tags=["fsb", "cloudtrail", "validation", "integrity"],
    ))

    # FSB CloudTrail.5: CloudTrail should be encrypted with KMS
    rules.append(Rule(
        rule_id="FSB-CT.5",
        name="CloudTrail logs are not encrypted with KMS",
        description="CloudTrail logs contain sensitive API activity data and should be KMS-encrypted.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="logging", provider="aws", service="cloudtrail",
        resource_type="aws_cloudtrail",
        dsl='condition: metadata.kms_key_id == ""',
        remediation="Add KMS encryption: aws cloudtrail update-trail --name <trail> --kms-key-id <key-arn>",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
        cwe_ids=["CWE-311"], tags=["fsb", "cloudtrail", "encryption", "kms"],
    ))

    # ═══════════════════════════════════════════════════════════════
    # NIST SP 800-53 CONTROLS
    # ═══════════════════════════════════════════════════════════════

    # NIST AC-2: Account Management — Unused IAM access keys (>90 days)
    rules.append(Rule(
        rule_id="NIST-AC2",
        name="IAM access key has not been used in 90+ days",
        description="Stale access keys increase the risk of credential compromise.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="iam", provider="aws", service="iam",
        resource_type="aws_iam_user",
        dsl='condition: metadata.key_last_used_days > 90 AND metadata.has_access_keys == true',
        remediation="Deactivate unused access keys: aws iam update-access-key --status Inactive --access-key-id <key>",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-798"], mitre_attack_ids=["T1078.004"],
        tags=["nist", "iam", "access_keys", "stale"],
    ))

    # NIST AU-6: Audit Review — CloudTrail not logging
    rules.append(Rule(
        rule_id="NIST-AU6",
        name="CloudTrail is not actively logging",
        description="CloudTrail trail is stopped or suspended. No API activity is being recorded.",
        version="1.0", status="active", is_system=True,
        severity=Severity.CRITICAL, category="logging", provider="aws", service="cloudtrail",
        resource_type="aws_cloudtrail",
        dsl='condition: metadata.is_logging == false',
        remediation="Restart CloudTrail logging: aws cloudtrail start-logging --name <trail>",
        cvss_score=9.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N",
        cwe_ids=["CWE-778"], mitre_attack_ids=["T1562.001"],
        tags=["nist", "cloudtrail", "logging", "audit"],
    ))

    # NIST SC-7: Boundary Protection — Default security group allows inbound traffic
    rules.append(Rule(
        rule_id="NIST-SC7",
        name="Default security group has inbound rules",
        description="Default security group should have no inbound rules. Custom SGs should be used.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="networking", provider="aws", service="ec2",
        resource_type="aws_security_group",
        dsl='condition: metadata.is_default == true AND metadata.has_ingress_rules == true',
        remediation="Remove all inbound rules from the default security group.",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-284"], tags=["nist", "security_group", "default", "boundary"],
    ))

    # NIST SC-8: Transmission Confidentiality — VPC without flow logs
    # Already covered by CIS-AWS-3.9, adding NIST variant
    rules.append(Rule(
        rule_id="NIST-SC8",
        name="EKS cluster API endpoint is publicly accessible",
        description="EKS API endpoint is open to the internet. Attackers can brute-force Kubernetes API.",
        version="1.0", status="active", is_system=True,
        severity=Severity.HIGH, category="container", provider="aws", service="eks",
        resource_type="aws_eks_cluster",
        dsl='condition: metadata.endpoint_public == true',
        remediation="Set endpointPublicAccess=false and use private endpoint or VPN.",
        cvss_score=7.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:N",
        cwe_ids=["CWE-284"], mitre_attack_ids=["T1190"],
        tags=["nist", "eks", "endpoint", "public_access"],
    ))

    # NIST SI-4: Intrusion Detection — GuardDuty not enabled
    rules.append(Rule(
        rule_id="NIST-SI4",
        name="AWS GuardDuty is not enabled",
        description="No threat detection service is active. Intrusions may go undetected.",
        version="1.0", status="active", is_system=True,
        severity=Severity.HIGH, category="monitoring", provider="aws", service="guardduty",
        resource_type="aws_guardduty_detector",
        dsl='condition: metadata.detector_enabled == false',
        remediation="Enable GuardDuty: aws guardduty create-detector --enable",
        cvss_score=7.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N",
        cwe_ids=["CWE-778"], tags=["nist", "guardduty", "threat_detection"],
    ))

    # ═══════════════════════════════════════════════════════════════
    # AWS WELL-ARCHITECTED SECURITY PILLAR
    # ═══════════════════════════════════════════════════════════════

    # WA-S1: No AWS Config enabled
    rules.append(Rule(
        rule_id="WA-SEC-1",
        name="AWS Config is not enabled",
        description="Without AWS Config, configuration changes are not tracked. Cannot detect drift.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="monitoring", provider="aws", service="config",
        resource_type="aws_config_recorder",
        dsl='condition: metadata.recorder_enabled == false',
        remediation="Enable AWS Config recorder in all regions.",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-778"], tags=["wa", "config", "monitoring", "drift"],
    ))

    # WA-S2: Security Hub not enabled
    rules.append(Rule(
        rule_id="WA-SEC-2",
        name="AWS Security Hub is not enabled",
        description="Security Hub aggregates findings from multiple services. Not enabled.",
        version="1.0", status="active", is_system=True,
        severity=Severity.LOW, category="monitoring", provider="aws", service="securityhub",
        resource_type="aws_securityhub",
        dsl='condition: metadata.securityhub_enabled == false',
        remediation="Enable Security Hub: aws securityhub enable-security-hub",
        cvss_score=3.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
        cwe_ids=["CWE-778"], tags=["wa", "securityhub", "monitoring"],
    ))

    # WA-S3: CloudWatch alarms not configured for critical events
    rules.append(Rule(
        rule_id="WA-SEC-3",
        name="No CloudWatch alarm for root account usage",
        description="Root account usage should trigger an alarm. None is configured.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="monitoring", provider="aws", service="cloudwatch",
        resource_type="aws_cloudwatch_alarm",
        dsl='condition: metadata.root_usage_alarm == false',
        remediation="Create CloudWatch alarm for root account login.",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-778"], tags=["wa", "cloudwatch", "alarm", "root"],
    ))

    # WA-S4: No MFA delete on S3 buckets with versioning
    rules.append(Rule(
        rule_id="WA-SEC-4",
        name="S3 bucket with versioning does not have MFA delete enabled",
        description="Versioning is enabled but MFA delete is not. Protected against accidental deletion only.",
        version="1.0", status="active", is_system=True,
        severity=Severity.LOW, category="storage", provider="aws", service="s3",
        resource_type="aws_s3_bucket",
        dsl='condition: metadata.versioning_enabled == true AND metadata.mfa_delete_enabled == false',
        remediation="Enable MFA delete: aws s3api put-bucket-versioning --bucket <bucket> --versioning-configuration Status=Enabled,MFADelete=Enabled",
        cvss_score=3.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:H/UI:N/S:U/C:N/I:L/A:L",
        cwe_ids=["CWE-284"], tags=["wa", "s3", "mfa_delete", "versioning"],
    ))

    # WA-S5: IAM users should not have inline policies
    rules.append(Rule(
        rule_id="WA-SEC-5",
        name="IAM user has inline policies",
        description="Inline policies bypass governance. Use managed policies instead.",
        version="1.0", status="active", is_system=True,
        severity=Severity.LOW, category="iam", provider="aws", service="iam",
        resource_type="aws_iam_user",
        dsl='condition: metadata.inline_policy_count > 0',
        remediation="Convert inline policies to managed policies and attach them.",
        cvss_score=3.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
        cwe_ids=["CWE-269"], tags=["wa", "iam", "inline_policies"],
    ))

    # ═══════════════════════════════════════════════════════════════
    # REAL-WORLD INCIDENT RESPONSE RULES
    # ═══════════════════════════════════════════════════════════════

    # IR-1: Secrets Manager secret without rotation
    rules.append(Rule(
        rule_id="IR-1",
        name="Secrets Manager secret does not have rotation enabled",
        description="Secret is not being rotated. Long-lived secrets are more likely to be compromised.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="security", provider="aws", service="secretsmanager",
        resource_type="aws_secretsmanager_secret",
        dsl='condition: metadata.rotation_enabled == false',
        remediation="Configure automatic rotation for the secret.",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-798"], tags=["ir", "secrets", "rotation"],
    ))

    # IR-2: EC2 security group allows database ports (3306, 5432, 1433, 27017) to internet
    rules.append(Rule(
        rule_id="IR-2",
        name="Security group allows database port from internet",
        description="Database ports (MySQL, PostgreSQL, MSSQL, MongoDB) are open to 0.0.0.0/0.",
        version="1.0", status="active", is_system=True,
        severity=Severity.CRITICAL, category="networking", provider="aws", service="ec2",
        resource_type="aws_security_group",
        dsl='condition: metadata.db_port_open == true',
        remediation="Restrict database ports to application security groups only.",
        cvss_score=9.5, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N",
        cwe_ids=["CWE-284"], mitre_attack_ids=["T1021"],
        tags=["ir", "security_group", "database", "exposure"],
    ))

    # IR-3: IAM user with both console access AND access keys
    rules.append(Rule(
        rule_id="IR-3",
        name="IAM user has both console access and access keys",
        description="Dual authentication methods increase attack surface. Use one or the other.",
        version="1.0", status="active", is_system=True,
        severity=Severity.LOW, category="iam", provider="aws", service="iam",
        resource_type="aws_iam_user",
        dsl='condition: metadata.console_access == true AND metadata.has_access_keys == true',
        remediation="If programmatic access is needed, remove console access. Use roles for applications.",
        cvss_score=3.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
        cwe_ids=["CWE-269"], tags=["ir", "iam", "dual_auth"],
    ))

    # IR-4: S3 bucket policy allows access from any AWS account
    rules.append(Rule(
        rule_id="IR-4",
        name="S3 bucket policy allows cross-account access",
        description="Bucket policy grants access to principals from other AWS accounts.",
        version="1.0", status="active", is_system=True,
        severity=Severity.HIGH, category="storage", provider="aws", service="s3",
        resource_type="aws_s3_bucket",
        dsl='condition: metadata.cross_account_access == true',
        remediation="Review bucket policy. Remove cross-account access if not explicitly required.",
        cvss_score=7.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:N",
        cwe_ids=["CWE-284"], tags=["ir", "s3", "cross_account", "policy"],
    ))

    # IR-5: EC2 instance with user data containing secrets
    rules.append(Rule(
        rule_id="IR-5",
        name="EC2 user data contains potential secrets",
        description="EC2 user data script contains patterns matching passwords or API keys.",
        version="1.0", status="active", is_system=True,
        severity=Severity.HIGH, category="compute", provider="aws", service="ec2",
        resource_type="aws_ec2_instance",
        dsl='condition: metadata.user_data_has_secrets == true',
        remediation="Move secrets from user data to AWS Secrets Manager or SSM Parameter Store.",
        cvss_score=7.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:L/A:N",
        cwe_ids=["CWE-798"], mitre_attack_ids=["T1552.001"],
        tags=["ir", "ec2", "user_data", "secrets"],
    ))

    # IR-6: CloudFront distribution without AWS WAF
    rules.append(Rule(
        rule_id="IR-6",
        name="CloudFront distribution does not have WAF attached",
        description="CloudFront is not protected by AWS WAF. Vulnerable to web attacks (SQLi, XSS).",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="network", provider="aws", service="cloudfront",
        resource_type="aws_cloudfront_distribution",
        dsl='condition: metadata.waf_attached == false',
        remediation="Create a WAF Web ACL and associate it with the CloudFront distribution.",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-693"], tags=["ir", "cloudfront", "waf", "web_security"],
    ))

    # IR-7: Route53 domain without DNSSEC
    rules.append(Rule(
        rule_id="IR-7",
        name="Route53 domain does not have DNSSEC enabled",
        description="Without DNSSEC, DNS responses can be spoofed (cache poisoning).",
        version="1.0", status="active", is_system=True,
        severity=Severity.LOW, category="network", provider="aws", service="route53",
        resource_type="aws_route53_domain",
        dsl='condition: metadata.dnssec_enabled == false',
        remediation="Enable DNSSEC for the hosted zone.",
        cvss_score=3.0, cvss_vector="CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-345"], tags=["ir", "route53", "dnssec", "dns"],
    ))

    # IR-8: ECR repository with mutable images
    rules.append(Rule(
        rule_id="IR-8",
        name="ECR repository allows image tag overwrite (mutable)",
        description="ECR image tags can be overwritten. Supply chain attack risk.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="container", provider="aws", service="ecr",
        resource_type="aws_ecr_repository",
        dsl='condition: metadata.image_tag_mutable == true',
        remediation="Set image tag immutability: aws ecr put-image-tag-mutability --repository-name <repo> --image-tag-mutability IMMUTABLE",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:L/I:H/A:N",
        cwe_ids=["CWE-284"], tags=["ir", "ecr", "supply_chain", "immutable"],
    ))

    # IR-9: SNS topic with public access
    rules.append(Rule(
        rule_id="IR-9",
        name="SNS topic allows public subscriptions",
        description="SNS topic policy allows anyone to subscribe or publish.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="messaging", provider="aws", service="sns",
        resource_type="aws_sns_topic",
        dsl='condition: metadata.public_access == true',
        remediation="Restrict SNS topic policy to specific AWS accounts or services.",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-284"], tags=["ir", "sns", "public_access"],
    ))

    # IR-10: SQS queue with public access
    rules.append(Rule(
        rule_id="IR-10",
        name="SQS queue allows public access",
        description="SQS queue policy allows anyone to send or receive messages.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="messaging", provider="aws", service="sqs",
        resource_type="aws_sqs_queue",
        dsl='condition: metadata.public_access == true',
        remediation="Restrict SQS queue policy to specific principals.",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:N",
        cwe_ids=["CWE-284"], tags=["ir", "sqs", "public_access"],
    ))

    # IR-11: DynamoDB table without PITR (Point-in-Time Recovery)
    rules.append(Rule(
        rule_id="IR-11",
        name="DynamoDB table does not have Point-in-Time Recovery",
        description="Without PITR, accidental writes or deletes cannot be recovered.",
        version="1.0", status="active", is_system=True,
        severity=Severity.MEDIUM, category="database", provider="aws", service="dynamodb",
        resource_type="aws_dynamodb_table",
        dsl='condition: metadata.pitr_enabled == false',
        remediation="Enable PITR: aws dynamodb update-continuous-backups --table-name <table> --point-in-time-recovery-specification PointInTimeRecoveryEnabled=true",
        cvss_score=5.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:C",
        cwe_ids=["CWE-732"], tags=["ir", "dynamodb", "pitr", "backup"],
    ))

    # IR-12: Athena workgroup without data usage limit
    rules.append(Rule(
        rule_id="IR-12",
        name="Athena workgroup has no data scan limit",
        description="Without a data scan limit, a single query can scan unlimited data (cost + DoS risk).",
        version="1.0", status="active", is_system=True,
        severity=Severity.LOW, category="analytics", provider="aws", service="athena",
        resource_type="aws_athena_workgroup",
        dsl='condition: metadata.bytes_scanned_limit == 0',
        remediation="Set a data scan limit on the Athena workgroup.",
        cvss_score=3.0, cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L",
        cwe_ids=["CWE-770"], tags=["ir", "athena", "cost", "dos"],
    ))

    return rules
