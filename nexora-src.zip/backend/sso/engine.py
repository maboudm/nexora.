"""
SSO Engine — Google OAuth + SAML for mid-market.

Google OAuth (free, mid-market demand):
  - Setup: create OAuth 2.0 credentials in Google Cloud Console (free)
  - User clicks "Sign in with Google"
  - We exchange code for token, verify email, create/login user
  - No password to manage — better security + UX

SAML (for Okta, Azure AD, OneLogin — Team tier feature):
  - We act as SAML Service Provider
  - IdP (Okta/AD) sends assertion, we verify signature
  - Maps IdP users to tenant users

Why this matters for mid-market:
  - 90% of mid-market companies use Google Workspace or Okta/Azure AD
  - "Sign in with Google" is the #1 feature they look for
  - Without SSO, IT teams reject the tool ("we can't manage passwords")
  - With SSO, IT approves it in 1 day vs 2 weeks
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import sqlite3
import time
from dataclasses import dataclass, asdict
from typing import Any
from uuid import uuid4
import urllib.parse
import urllib.request


DB_PATH = os.environ.get("SENTINEL_DB_PATH", "/home/z/my-project/db/sentinel.db")


@dataclass
class SSOConfig:
    tenant_id: str
    provider: str               # google | saml | azure_ad | okta
    client_id: str
    client_secret: str
    redirect_uri: str
    # For SAML:
    idp_metadata_url: str = ""
    idp_entity_id: str = ""
    sp_entity_id: str = ""
    # Domain restriction (only @company.com emails allowed)
    allowed_domains: list[str] = None


@dataclass
class SSOUser:
    email: str
    name: str
    provider: str
    tenant_id: str | None = None  # if None, new user (need to pick/create tenant)
    role: str = "viewer"
    picture_url: str = ""
    raw_attributes: dict = None


# ─────────────────────────────────────────────────────────────────────────
# Database
# ─────────────────────────────────────────────────────────────────────────
def _get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_sso_tables() -> None:
    with _get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sso_configs (
                tenant_id TEXT NOT NULL,
                provider TEXT NOT NULL,
                client_id TEXT,
                client_secret TEXT,
                redirect_uri TEXT,
                idp_metadata_url TEXT,
                idp_entity_id TEXT,
                sp_entity_id TEXT,
                allowed_domains TEXT,
                PRIMARY KEY (tenant_id, provider)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sso_sessions (
                state TEXT PRIMARY KEY,
                tenant_id TEXT,
                provider TEXT,
                redirect_to TEXT,
                created_at REAL,
                expires_at REAL
            )
        """)
        conn.commit()


# ─────────────────────────────────────────────────────────────────────────
# Google OAuth
# ─────────────────────────────────────────────────────────────────────────
GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v3/userinfo"


def get_google_oauth_url(tenant_id: str, state: str, redirect_uri: str) -> str:
    """Generate Google OAuth consent URL.

    Prerequisites (free):
      1. Go to https://console.cloud.google.com/apis/credentials
      2. Create OAuth 2.0 Client ID (Web application)
      3. Add your redirect URI (e.g., https://nexora.yourdomain.com/api/sso/google/callback)
      4. Set env vars: GOOGLE_OAUTH_CLIENT_ID, GOOGLE_OAUTH_CLIENT_SECRET

    Scopes requested:
      - openid: OIDC
      - email: get user email
      - profile: get user name + picture
    """
    client_id = os.environ.get("GOOGLE_OAUTH_CLIENT_ID", "")
    if not client_id:
        raise ValueError("GOOGLE_OAUTH_CLIENT_ID env var not set")

    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": "openid email profile",
        "state": state,
        "access_type": "online",  # no refresh token needed
        "prompt": "select_account",
    }
    return f"{GOOGLE_AUTH_URL}?{urllib.parse.urlencode(params)}"


def exchange_google_code(code: str, redirect_uri: str) -> dict:
    """Exchange OAuth code for access token + ID token."""
    client_id = os.environ.get("GOOGLE_OAUTH_CLIENT_ID", "")
    client_secret = os.environ.get("GOOGLE_OAUTH_CLIENT_SECRET", "")
    if not client_id or not client_secret:
        raise ValueError("GOOGLE_OAUTH_CLIENT_ID or GOOGLE_OAUTH_CLIENT_SECRET not set")

    data = urllib.parse.urlencode({
        "code": code,
        "client_id": client_id,
        "client_secret": client_secret,
        "redirect_uri": redirect_uri,
        "grant_type": "authorization_code",
    }).encode()

    req = urllib.request.Request(
        GOOGLE_TOKEN_URL,
        data=data,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode())


def get_google_userinfo(access_token: str) -> dict:
    """Fetch user info from Google using access token."""
    req = urllib.request.Request(
        GOOGLE_USERINFO_URL,
        headers={"Authorization": f"Bearer {access_token}"},
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode())


def verify_google_email_domain(email: str, allowed_domains: list[str]) -> bool:
    """Check if the user's email domain is in the allowed list."""
    if not allowed_domains:
        return True  # no restriction
    domain = email.split("@")[-1].lower()
    return any(domain == d.lower() for d in allowed_domains)


# ─────────────────────────────────────────────────────────────────────────
# SAML (for Okta, Azure AD, OneLogin — Team tier feature)
# ─────────────────────────────────────────────────────────────────────────
def generate_saml_authn_request(sp_entity_id: str, idp_sso_url: str, acs_url: str) -> str:
    """Generate a SAML AuthnRequest XML (base64-encoded).

    In production, sign this request with the SP's private key.
    For now, we use unsigned requests (works with most IdPs in test mode).
    """
    request_id = str(uuid4())
    issue_instant = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<samlp:AuthnRequest xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol"
                    ID="{request_id}"
                    Version="2.0"
                    IssueInstant="{issue_instant}"
                    Destination="{idp_sso_url}"
                    AssertionConsumerServiceURL="{acs_url}">
  <saml:Issuer xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">{sp_entity_id}</saml:Issuer>
  <samlp:NameIDPolicy Format="urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"
                       AllowCreate="true"/>
</samlp:AuthnRequest>"""
    return base64.b64encode(xml.encode()).decode()


def parse_saml_response(saml_response_b64: str) -> dict:
    """Parse a SAML Response from the IdP.

    Returns a dict with: email, name, attributes, raw_xml
    NOTE: In production, you MUST verify the XML signature using the IdP's
    public key from their metadata. This implementation does NOT verify
    signatures — it's a starting point, not production-ready.
    """
    try:
        xml = base64.b64decode(saml_response_b64).decode()
        # Very basic extraction (production should use xmlsec + lxml)
        # Extract NameID (email)
        import re
        nameid_match = re.search(r'<saml:NameID[^>]*>([^<]+)</saml:NameID>', xml)
        email = nameid_match.group(1) if nameid_match else ""

        # Extract attributes
        attrs = {}
        for attr_match in re.finditer(
            r'<saml:Attribute Name="([^"]+)"[^>]*>\s*<saml:AttributeValue[^>]*>([^<]+)</saml:AttributeValue>',
            xml
        ):
            attrs[attr_match.group(1)] = attr_match.group(2)

        name = attrs.get("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name",
                        attrs.get("name", ""))

        return {
            "email": email,
            "name": name,
            "attributes": attrs,
            "raw_xml": xml[:1000],  # truncated
        }
    except Exception as e:
        return {"error": str(e)}


# ─────────────────────────────────────────────────────────────────────────
# Session state management
# ─────────────────────────────────────────────────────────────────────────
def create_sso_session(tenant_id: str, provider: str, redirect_to: str = "/") -> str:
    """Create a state token for OAuth/OIDC flow to prevent CSRF."""
    state = secrets_token(32)
    with _get_db() as conn:
        conn.execute("""
            INSERT INTO sso_sessions (state, tenant_id, provider, redirect_to, created_at, expires_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            state, tenant_id, provider, redirect_to,
            time.time(), time.time() + 600,  # 10 min expiry
        ))
        conn.commit()
    return state


def validate_sso_session(state: str) -> dict | None:
    """Validate the state token from OAuth callback."""
    with _get_db() as conn:
        row = conn.execute(
            "SELECT * FROM sso_sessions WHERE state = ? AND expires_at > ?",
            (state, time.time()),
        ).fetchone()
        if not row:
            return None
        # Delete used state
        conn.execute("DELETE FROM sso_sessions WHERE state = ?", (state,))
        conn.commit()
        return dict(row)


def secrets_token(length: int = 32) -> str:
    """Generate a cryptographically-secure random token."""
    import secrets
    return secrets.token_urlsafe(length)


# ─────────────────────────────────────────────────────────────────────────
# SSO config persistence
# ─────────────────────────────────────────────────────────────────────────
def save_sso_config(tenant_id: str, config: SSOConfig) -> None:
    with _get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO sso_configs
            (tenant_id, provider, client_id, client_secret, redirect_uri,
             idp_metadata_url, idp_entity_id, sp_entity_id, allowed_domains)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            tenant_id, config.provider, config.client_id, config.client_secret,
            config.redirect_uri, config.idp_metadata_url, config.idp_entity_id,
            config.sp_entity_id,
            json.dumps(config.allowed_domains or []),
        ))
        conn.commit()


def get_sso_config(tenant_id: str, provider: str) -> SSOConfig | None:
    with _get_db() as conn:
        row = conn.execute(
            "SELECT * FROM sso_configs WHERE tenant_id = ? AND provider = ?",
            (tenant_id, provider),
        ).fetchone()
        if not row:
            return None
        return SSOConfig(
            tenant_id=tenant_id,
            provider=row["provider"],
            client_id=row["client_id"] or "",
            client_secret=row["client_secret"] or "",
            redirect_uri=row["redirect_uri"] or "",
            idp_metadata_url=row["idp_metadata_url"] or "",
            idp_entity_id=row["idp_entity_id"] or "",
            sp_entity_id=row["sp_entity_id"] or "",
            allowed_domains=json.loads(row["allowed_domains"] or "[]"),
        )


def is_sso_configured(tenant_id: str) -> bool:
    """Check if any SSO provider is configured for this tenant."""
    with _get_db() as conn:
        row = conn.execute(
            "SELECT COUNT(*) as c FROM sso_configs WHERE tenant_id = ?",
            (tenant_id,),
        ).fetchone()
        return row["c"] > 0
