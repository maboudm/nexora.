"""
Stripe Payment Engine — real payment processing for tier upgrades.

How this works (no theory, all real):
  1. Admin sets STRIPE_SECRET_KEY env var (get from https://dashboard.stripe.com/apikeys)
  2. We create Stripe Products + Prices for each tier (one-time setup)
  3. When user upgrades, we create a Stripe Checkout Session
  4. User pays on Stripe-hosted page (PCI compliant, no card data touches us)
  5. Stripe sends webhook to /v1/billing/stripe/webhook
  6. We verify signature, update tenant tier in DB
  7. User redirected back to app with success message

This is the EXACT flow used by GitLab, Notion, Vercel, etc.
Zero card data on our servers — Stripe handles all PCI compliance.

Cost: Stripe charges 2.9% + 30¢ per transaction. So on $99/mo:
  - We receive: $99 - $3.17 = $95.83
  - Stripe gets: $3.17
  - We pay nothing until customer pays.

Setup (one-time):
  1. Create Stripe account (free, 5 min)
  2. Get API keys from dashboard
  3. Set env vars:
     STRIPE_SECRET_KEY=sk_test_...
     STRIPE_PUBLISHABLE_KEY=pk_test_...
     STRIPE_WEBHOOK_SECRET=whsec_...
  4. Run: python -m backend.payments.setup_stripe_products
     (creates Products + Prices in your Stripe account)
  5. Configure webhook endpoint in Stripe dashboard:
     URL: https://yourdomain.com/api/gateway-proxy/v1/billing/stripe/webhook
     Events: checkout.session.completed, customer.subscription.deleted
"""
from __future__ import annotations

import json
import os
import sqlite3
import time
import hmac
import hashlib
from dataclasses import dataclass, asdict
from typing import Any
from uuid import uuid4


DB_PATH = os.environ.get("SENTINEL_DB_PATH", "/home/z/my-project/db/sentinel.db")


@dataclass
class StripeCheckoutSession:
    session_id: str
    url: str               # Stripe-hosted checkout URL
    tier_id: str
    tenant_id: str
    user_id: str
    created_at: float
    status: str            # pending | paid | expired


# ─────────────────────────────────────────────────────────────────────────
# Database
# ─────────────────────────────────────────────────────────────────────────
def _get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_stripe_tables() -> None:
    with _get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS stripe_checkout_sessions (
                session_id TEXT PRIMARY KEY,
                stripe_session_id TEXT,
                url TEXT,
                tier_id TEXT,
                tenant_id TEXT,
                user_id TEXT,
                created_at REAL,
                status TEXT DEFAULT 'pending',
                stripe_customer_id TEXT,
                stripe_subscription_id TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS stripe_customers (
                tenant_id TEXT PRIMARY KEY,
                stripe_customer_id TEXT,
                email TEXT,
                created_at REAL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS payment_events (
                event_id TEXT PRIMARY KEY,
                tenant_id TEXT,
                event_type TEXT,
                amount INTEGER,
                currency TEXT,
                stripe_event_id TEXT,
                timestamp REAL,
                metadata TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_payments_tenant ON payment_events(tenant_id, timestamp DESC)")
        conn.commit()


# ─────────────────────────────────────────────────────────────────────────
# Stripe API client (uses urllib, no SDK dependency)
# ─────────────────────────────────────────────────────────────────────────
STRIPE_API_BASE = "https://api.stripe.com/v1"


def _stripe_request(method: str, path: str, data: dict | None = None) -> dict:
    """Make a Stripe API call. Returns parsed JSON response.

    Uses urllib (no external SDK needed). This is the same API the official
    stripe-python library wraps.
    """
    import urllib.request
    import urllib.parse

    secret_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if not secret_key:
        raise ValueError(
            "STRIPE_SECRET_KEY not set. Get it from https://dashboard.stripe.com/apikeys"
        )

    url = f"{STRIPE_API_BASE}{path}"
    headers = {
        "Authorization": f"Bearer {secret_key}",
        "Content-Type": "application/x-www-form-urlencoded",
    }

    if data:
        # Stripe uses form-encoded data, not JSON
        form_data = urllib.parse.urlencode(_flatten_for_stripe(data)).encode()
    else:
        form_data = None

    req = urllib.request.Request(url, data=form_data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        try:
            error_data = json.loads(error_body)
            error_msg = error_data.get("error", {}).get("message", error_body)
        except Exception:
            error_msg = error_body
        raise ValueError(f"Stripe API error ({e.code}): {error_msg}")


def _flatten_for_stripe(data: dict, parent_key: str = "") -> list[tuple[str, str]]:
    """Flatten nested dict into Stripe's form-encoded format.

    Stripe expects: price_data[product_data][name]=Pro
    Not: {"price_data": {"product_data": {"name": "Pro"}}}
    """
    items = []
    for k, v in data.items():
        key = f"{parent_key}[{k}]" if parent_key else k
        if isinstance(v, dict):
            items.extend(_flatten_for_stripe(v, key))
        elif isinstance(v, list):
            for i, item in enumerate(v):
                if isinstance(item, dict):
                    items.extend(_flatten_for_stripe(item, f"{key}[{i}]"))
                else:
                    items.append((f"{key}[{i}]", str(item)))
        elif v is None:
            pass
        else:
            items.append((key, str(v)))
    return items


# ─────────────────────────────────────────────────────────────────────────
# Product/Price setup (one-time)
# ─────────────────────────────────────────────────────────────────────────
# In production, you'd run setup_stripe_products() once to create these.
# After that, you store the price IDs in env vars or DB.
# For demo, we use inline price_data in checkout sessions (no pre-created products).

STRIPE_PRICE_IDS: dict[str, dict[str, str]] = {
    # tier_id: {"monthly": "price_...", "yearly": "price_..."}
    # Populated by setup_stripe_products()
}


def setup_stripe_products() -> dict:
    """One-time setup: create Stripe Products + Prices for each tier.

    Run this once when deploying. Stores price IDs in DB for later use.
    """
    from billing.engine import TIERS

    results = {"created": [], "errors": []}
    for tier_id, tier in TIERS.items():
        if tier_id in ("free", "enterprise"):
            continue  # no Stripe product needed
        if tier.price_monthly <= 0:
            continue

        try:
            # Create product
            product = _stripe_request("POST", "/products", {
                "name": f"Sentinel {tier.name}",
                "description": tier.description,
                "metadata": {"tier_id": tier_id},
            })

            # Create monthly price
            monthly_price = _stripe_request("POST", "/prices", {
                "product": product["id"],
                "unit_amount": tier.price_monthly,  # cents
                "currency": "usd",
                "recurring[interval]": "month",
                "metadata": {"tier_id": tier_id, "cycle": "monthly"},
            })

            # Create yearly price
            yearly_price = _stripe_request("POST", "/prices", {
                "product": product["id"],
                "unit_amount": tier.price_yearly,
                "currency": "usd",
                "recurring[interval]": "year",
                "metadata": {"tier_id": tier_id, "cycle": "yearly"},
            })

            STRIPE_PRICE_IDS[tier_id] = {
                "monthly": monthly_price["id"],
                "yearly": yearly_price["id"],
                "product": product["id"],
            }
            results["created"].append({
                "tier_id": tier_id,
                "product_id": product["id"],
                "monthly_price_id": monthly_price["id"],
                "yearly_price_id": yearly_price["id"],
            })
        except Exception as e:
            results["errors"].append({"tier_id": tier_id, "error": str(e)})

    # Persist price IDs to DB
    if STRIPE_PRICE_IDS:
        with _get_db() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS stripe_price_ids (
                    tier_id TEXT PRIMARY KEY,
                    monthly_price_id TEXT,
                    yearly_price_id TEXT,
                    product_id TEXT
                )
            """)
            for tier_id, ids in STRIPE_PRICE_IDS.items():
                conn.execute("""
                    INSERT OR REPLACE INTO stripe_price_ids
                    (tier_id, monthly_price_id, yearly_price_id, product_id)
                    VALUES (?, ?, ?, ?)
                """, (tier_id, ids["monthly"], ids["yearly"], ids["product"]))
            conn.commit()

    return results


def load_stripe_price_ids() -> dict[str, dict[str, str]]:
    """Load persisted Stripe price IDs from DB."""
    try:
        with _get_db() as conn:
            rows = conn.execute("SELECT * FROM stripe_price_ids").fetchall()
            for r in rows:
                STRIPE_PRICE_IDS[r["tier_id"]] = {
                    "monthly": r["monthly_price_id"],
                    "yearly": r["yearly_price_id"],
                    "product": r["product_id"],
                }
    except Exception:
        pass
    return STRIPE_PRICE_IDS


# ─────────────────────────────────────────────────────────────────────────
# Checkout session creation
# ─────────────────────────────────────────────────────────────────────────
def create_checkout_session(
    tenant_id: str,
    user_id: str,
    user_email: str,
    tier_id: str,
    billing_cycle: str = "monthly",
    success_url: str = "",
    cancel_url: str = "",
) -> StripeCheckoutSession:
    """Create a Stripe Checkout Session for upgrading to a tier.

    Returns a StripeCheckoutSession with the URL to redirect the user to.
    The user pays on Stripe's hosted page, then Stripe redirects back to success_url.
    """
    from billing.engine import TIERS

    if tier_id not in TIERS:
        raise ValueError(f"Unknown tier: {tier_id}")
    if tier_id in ("free", "enterprise"):
        raise ValueError(f"Cannot create checkout for {tier_id} tier")
    if billing_cycle not in ("monthly", "yearly"):
        raise ValueError("billing_cycle must be monthly or yearly")

    tier = TIERS[tier_id]
    price_amount = tier.price_monthly if billing_cycle == "monthly" else tier.price_yearly

    # Try to use pre-created price ID, otherwise use inline price_data
    price_ids = load_stripe_price_ids()
    line_items = []

    if tier_id in price_ids:
        line_items.append({
            "price": price_ids[tier_id][billing_cycle],
            "quantity": 1,
        })
    else:
        # Inline price data (works without pre-created products)
        line_items.append({
            "price_data": {
                "currency": "usd",
                "unit_amount": price_amount,
                "recurring[interval]": "month" if billing_cycle == "monthly" else "year",
                "product_data": {
                    "name": f"Sentinel {tier.name} ({billing_cycle})",
                    "description": tier.description,
                    "metadata": {"tier_id": tier_id},
                },
            },
            "quantity": 1,
        })

    # Default URLs
    if not success_url:
        success_url = os.environ.get(
            "STRIPE_SUCCESS_URL",
            "https://nexora.example.com/billing?upgrade=success&session_id={CHECKOUT_SESSION_ID}"
        )
    if not cancel_url:
        cancel_url = os.environ.get(
            "STRIPE_CANCEL_URL",
            "https://nexora.example.com/billing?upgrade=cancelled"
        )

    # Create Stripe Checkout Session
    session_data = {
        "mode": "subscription",
        "line_items": line_items,
        "success_url": success_url,
        "cancel_url": cancel_url,
        "customer_email": user_email,
        "metadata[tenant_id]": tenant_id,
        "metadata[user_id]": user_id,
        "metadata[tier_id]": tier_id,
        "metadata[billing_cycle]": billing_cycle,
        "subscription_data[metadata][tenant_id]": tenant_id,
        "subscription_data[metadata][tier_id]": tier_id,
        "allow_promotion_codes": "true",
        "billing_address_collection": "auto",
        "automatic_tax[enabled]": "true",
    }

    stripe_session = _stripe_request("POST", "/checkout/sessions", session_data)

    # Persist session
    session_id = str(uuid4())
    our_session = StripeCheckoutSession(
        session_id=session_id,
        url=stripe_session["url"],
        tier_id=tier_id,
        tenant_id=tenant_id,
        user_id=user_id,
        created_at=time.time(),
        status="pending",
    )
    with _get_db() as conn:
        conn.execute("""
            INSERT INTO stripe_checkout_sessions
            (session_id, stripe_session_id, url, tier_id, tenant_id, user_id,
             created_at, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            session_id,
            stripe_session["id"],
            stripe_session["url"],
            tier_id,
            tenant_id,
            user_id,
            time.time(),
            "pending",
        ))
        conn.commit()

    return our_session


# ─────────────────────────────────────────────────────────────────────────
# Webhook handler
# ─────────────────────────────────────────────────────────────────────────
def verify_stripe_webhook_signature(payload: bytes, signature: str) -> bool:
    """Verify that a webhook came from Stripe (not an attacker).

    Stripe signs webhooks with HMAC-SHA256 using a shared secret.
    We verify the signature to prevent forged webhook attacks.
    """
    webhook_secret = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
    if not webhook_secret:
        return False  # can't verify without secret

    # Stripe signature format: t=1234567890,v1=abc123...
    try:
        parts = dict(p.split("=") for p in signature.split(","))
        timestamp = int(parts["t"])
        v1_signature = parts["v1"]
    except (KeyError, ValueError):
        return False

    # Prevent replay attacks (5 min tolerance)
    if abs(time.time() - timestamp) > 300:
        return False

    # Compute expected signature
    signed_payload = f"{timestamp}.{payload.decode()}".encode()
    expected = hmac.new(
        webhook_secret.encode(),
        signed_payload,
        hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(expected, v1_signature)


def handle_stripe_webhook(event: dict) -> dict:
    """Process a Stripe webhook event.

    Events we handle:
      - checkout.session.completed: upgrade the tenant's tier
      - customer.subscription.deleted: downgrade to free
      - invoice.payment_failed: mark subscription as past_due
    """
    event_type = event.get("type", "")
    event_data = event.get("data", {}).get("object", {})

    result = {"processed": False, "event_type": event_type, "action": ""}

    if event_type == "checkout.session.completed":
        # Extract metadata
        metadata = event_data.get("metadata", {})
        tenant_id = metadata.get("tenant_id", "")
        tier_id = metadata.get("tier_id", "")
        stripe_customer_id = event_data.get("customer", "")
        stripe_subscription_id = event_data.get("subscription", "")

        if tenant_id and tier_id:
            # Upgrade the tenant
            from billing.engine import update_subscription
            update_subscription(tenant_id, tier_id)

            # Store Stripe customer + subscription IDs
            with _get_db() as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO stripe_customers
                    (tenant_id, stripe_customer_id, email, created_at)
                    VALUES (?, ?, ?, ?)
                """, (
                    tenant_id,
                    stripe_customer_id,
                    event_data.get("customer_email", ""),
                    time.time(),
                ))

                # Update checkout session
                conn.execute("""
                    UPDATE stripe_checkout_sessions
                    SET status = 'paid',
                        stripe_customer_id = ?,
                        stripe_subscription_id = ?
                    WHERE stripe_session_id = ?
                """, (stripe_customer_id, stripe_subscription_id, event_data.get("id", "")))

            # Record payment event
            record_payment_event(
                tenant_id=tenant_id,
                event_type="subscription.created",
                amount=event_data.get("amount_total", 0),
                currency=event_data.get("currency", "usd"),
                stripe_event_id=event.get("id", ""),
                metadata={"tier_id": tier_id, "subscription_id": stripe_subscription_id},
            )

            result["processed"] = True
            result["action"] = f"Upgraded tenant {tenant_id} to {tier_id}"

    elif event_type == "customer.subscription.deleted":
        # Subscription canceled — downgrade to free
        metadata = event_data.get("metadata", {})
        tenant_id = metadata.get("tenant_id", "")

        if tenant_id:
            from billing.engine import update_subscription
            update_subscription(tenant_id, "free")

            record_payment_event(
                tenant_id=tenant_id,
                event_type="subscription.canceled",
                amount=0,
                currency="usd",
                stripe_event_id=event.get("id", ""),
                metadata={"subscription_id": event_data.get("id", "")},
            )

            result["processed"] = True
            result["action"] = f"Downgraded tenant {tenant_id} to free"

    elif event_type == "invoice.payment_failed":
        # Payment failed — mark as past_due
        metadata = event_data.get("subscription_details", {}).get("metadata", {})
        tenant_id = metadata.get("tenant_id", "")

        if tenant_id:
            with _get_db() as conn:
                conn.execute("""
                    UPDATE subscriptions SET status = 'past_due'
                    WHERE tenant_id = ?
                """, (tenant_id,))
                conn.commit()

            record_payment_event(
                tenant_id=tenant_id,
                event_type="payment.failed",
                amount=event_data.get("amount_paid", 0),
                currency=event_data.get("currency", "usd"),
                stripe_event_id=event.get("id", ""),
                metadata={"subscription_id": event_data.get("subscription", "")},
            )

            result["processed"] = True
            result["action"] = f"Marked tenant {tenant_id} as past_due"

    return result


def record_payment_event(
    tenant_id: str,
    event_type: str,
    amount: int,
    currency: str,
    stripe_event_id: str,
    metadata: dict,
) -> None:
    with _get_db() as conn:
        conn.execute("""
            INSERT INTO payment_events
            (event_id, tenant_id, event_type, amount, currency, stripe_event_id, timestamp, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            str(uuid4()),
            tenant_id,
            event_type,
            amount,
            currency,
            stripe_event_id,
            time.time(),
            json.dumps(metadata, default=str),
        ))
        conn.commit()


def list_payment_events(tenant_id: str, limit: int = 50) -> list[dict]:
    with _get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM payment_events WHERE tenant_id = ? ORDER BY timestamp DESC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["metadata"] = json.loads(d.get("metadata", "{}"))
            except Exception:
                d["metadata"] = {}
            out.append(d)
        return out


def get_stripe_publishable_key() -> str:
    """Get the publishable key for frontend (safe to expose)."""
    return os.environ.get("STRIPE_PUBLISHABLE_KEY", "")


def is_stripe_configured() -> bool:
    """Check if Stripe is configured."""
    return bool(os.environ.get("STRIPE_SECRET_KEY"))
