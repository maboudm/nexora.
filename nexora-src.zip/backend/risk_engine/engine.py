"""Risk Engine — Multi-factor risk scoring.

Based on Part 2, 9 — Risk Calculation Pipeline.

Computes risk scores from 6 independent factors:
  1. Exposure Score — internet accessibility
  2. Identity Score — permission breadth, escalation paths
  3. Vulnerability Score — CVE count, CVSS, EPSS
  4. Compliance Score — failed controls
  5. Business Criticality — asset importance
  6. Threat Intelligence — active exploits, CISA KEV

Each factor is 0-100. Weights are configurable per tenant.
Final score: weighted sum → 0-100 → level (critical/high/medium/low)
"""
from __future__ import annotations

import logging
import math
import time
from typing import Any

from core.models import Asset, Finding, RiskScore

logger = logging.getLogger(__name__)


class RiskEngine:
    """Computes multi-factor risk scores for assets, findings, and organizations.

    Usage:
        engine = RiskEngine()
        asset_score = engine.score_asset(asset, findings)
        finding_score = engine.score_finding(finding, asset)
    """

    DEFAULT_WEIGHTS = {
        "exposure": 0.25,
        "identity": 0.20,
        "vulnerability": 0.15,
        "compliance": 0.15,
        "business": 0.15,
        "threat": 0.10,
    }

    def __init__(self, weights: dict[str, float] | None = None):
        self.weights = weights or self.DEFAULT_WEIGHTS.copy()

    def score_asset(self, asset: Asset, findings: list[Finding]) -> RiskScore:
        """Compute risk score for a single asset based on its findings."""
        exposure = self._compute_exposure(asset, findings)
        identity = self._compute_identity(asset, findings)
        vulnerability = self._compute_vulnerability(findings)
        compliance = self._compute_compliance(findings)
        business = self._compute_business(asset)
        threat = self._compute_threat(findings)

        return RiskScore.compute(
            exposure=exposure,
            identity=identity,
            vulnerability=vulnerability,
            compliance=compliance,
            business=business,
            threat=threat,
            weights=self.weights,
        )

    def score_finding(self, finding: Finding, asset: Asset) -> RiskScore:
        """Compute risk score for a single finding."""
        severity_to_base = {
            "critical": 90, "high": 70, "medium": 40, "low": 15, "info": 5,
        }
        base = severity_to_base.get(finding.severity, 30)

        # Adjust based on asset exposure
        exposure_boost = 20 if asset.internet_exposed else 0
        # Adjust based on CVSS
        cvss_boost = (finding.cvss_score / 10) * 20
        # Adjust based on EPSS (exploit probability)
        epss_boost = finding.epss_score * 15
        # Adjust based on CISA KEV
        kev_boost = 15 if any("KEV" in c for c in finding.cve_ids) else 0
        # Business criticality
        crit_boost = {"critical": 15, "high": 10, "medium": 5, "low": 0}.get(asset.criticality, 0)

        score = min(100, base + exposure_boost + cvss_boost + epss_boost + kev_boost + crit_boost)
        level = "critical" if score >= 80 else "high" if score >= 60 else "medium" if score >= 30 else "low"

        return RiskScore(
            score=round(score, 2),
            level=level,
            factors={
                "base_severity": base,
                "exposure_boost": exposure_boost,
                "cvss_boost": round(cvss_boost, 2),
                "epss_boost": round(epss_boost, 2),
                "kev_boost": kev_boost,
                "business_boost": crit_boost,
            },
        )

    def _compute_exposure(self, asset: Asset, findings: list[Finding]) -> float:
        """Exposure: how accessible is this asset from the internet?"""
        score = 0.0
        if asset.internet_exposed:
            score += 50
        # Network findings (open ports) increase exposure
        net_findings = [f for f in findings if f.category == "network" and f.severity in ("critical", "high")]
        score += min(30, len(net_findings) * 10)
        # Public S3 buckets
        if asset.resource_type == "aws_s3_bucket":
            s3_public = [f for f in findings if f.rule_id == "S3-001"]
            if s3_public:
                score += 20
        return min(100, score)

    def _compute_identity(self, asset: Asset, findings: list[Finding]) -> float:
        """Identity: permission breadth and escalation risk."""
        score = 0.0
        iam_findings = [f for f in findings if f.category == "iam"]
        for f in iam_findings:
            if f.rule_id == "IAM-001":  # Principal:*
                score += 40
            elif f.rule_id == "IAM-002":  # AdminAccess
                score += 30
            elif f.rule_id == "IAM-004":  # S3 FullAccess on compute
                score += 20
            else:
                score += 5
        return min(100, score)

    def _compute_vulnerability(self, findings: list[Finding]) -> float:
        """Vulnerability: CVE count and severity."""
        vuln_findings = [f for f in findings if f.category == "vulnerability"]
        if not vuln_findings:
            return 0
        score = min(50, len(vuln_findings) * 5)
        critical_vulns = sum(1 for f in vuln_findings if f.severity == "critical")
        score += min(50, critical_vulns * 15)
        return min(100, score)

    def _compute_compliance(self, findings: list[Finding]) -> float:
        """Compliance: number of failed compliance controls."""
        compliance_findings = [f for f in findings if f.compliance]
        unique_frameworks = set()
        for f in compliance_findings:
            for c in f.compliance:
                unique_frameworks.add(c)
        return min(100, len(compliance_findings) * 5 + len(unique_frameworks) * 10)

    def _compute_business(self, asset: Asset) -> float:
        """Business: asset criticality."""
        return {"critical": 90, "high": 70, "medium": 40, "low": 15, "minimal": 5}.get(asset.criticality, 40)

    def _compute_threat(self, findings: list[Finding]) -> float:
        """Threat: active exploit intelligence."""
        score = 0.0
        for f in findings:
            if f.epss_score > 0.5:
                score += 20
            if f.cve_ids:
                score += 10
            if any("KEV" in c for c in f.cve_ids):
                score += 30
        return min(100, score)
