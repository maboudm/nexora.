"""
Enterprise Posture Score Engine — multi-factor security scoring.

Based on Part 6 — Posture Scoring and Gartner's CSPM Magic Quadrant criteria.

Scientific Foundation:
  The posture score is the headline metric customers show executives.
  It must be:
    1. Defensible: every component traceable to specific findings
    2. Actionable: customer can see "fix these 5 things → score +10"
    3. Benchmarked: comparable to industry peers
    4. Multi-factor: not just "X% compliant"

  This engine implements a weighted multi-factor scoring algorithm:

    Posture Score = (
      Compliance Score × 0.25 +
      Vulnerability Score × 0.20 +
      Exposure Score × 0.20 +
      Identity Score × 0.15 +
      Data Protection Score × 0.10 +
      Detection Coverage × 0.10
    )

  Each factor is normalized to 0-100, where:
    100 = perfect posture (no findings, fully compliant)
    0   = worst posture (all critical findings)

  Weights are derived from:
    - Gartner CSPM Magic Quadrant evaluation criteria
    - Customer survey data on which factors matter most
    - NIST CSF 2.0 function weights (Identify/Protect > Detect/Respond)

Commercial Differentiator:
  Unlike basic CSPM tools that only show "% compliant", this score:
  - Factors in 6 dimensions (not just compliance)
  - Weights by severity (critical findings hurt score more)
  - Tracks trend over time (improving vs degrading)
  - Compares to industry benchmarks
  - Provides actionable breakdown ("+5 if you fix these findings")
"""
from __future__ import annotations

import json
import logging
import math
import threading
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Posture Score Domain Model
# ═══════════════════════════════════════════════════════════════

class PostureGrade(str, Enum):
    A = "A"   # 90-100
    B = "B"   # 80-89
    C = "C"   # 70-79
    D = "D"   # 60-69
    F = "F"   # 0-59


class PostureTrend(str, Enum):
    IMPROVING = "improving"
    STABLE = "stable"
    DEGRADING = "degrading"
    NEW = "new"


@dataclass
class FactorScore:
    """Score for a single posture factor."""
    factor_name: str
    score: float             # 0-100
    weight: float            # 0-1 (contribution to overall)
    weighted_score: float    # score × weight
    findings_count: int = 0
    critical_findings: int = 0
    high_findings: int = 0
    medium_findings: int = 0
    low_findings: int = 0
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class PostureScore:
    """Complete posture score for a tenant."""
    score_id: str
    tenant_id: str
    overall_score: float       # 0-100
    grade: str                 # PostureGrade value
    trend: str                 # PostureTrend value
    previous_score: Optional[float] = None
    score_change: Optional[float] = None
    # Factor breakdown
    factors: list[FactorScore] = field(default_factory=list)
    # Industry benchmark
    industry_benchmark: Optional[float] = None
    percentile: Optional[float] = None  # compared to peers
    # Actionable insights
    top_recommendations: list[dict[str, Any]] = field(default_factory=list)
    quick_wins: list[dict[str, Any]] = field(default_factory=list)
    potential_score_if_fixed: float = 0.0
    # Metadata
    calculated_at: int = 0
    period_start: Optional[int] = None
    period_end: Optional[int] = None


@dataclass
class PostureHistory:
    """Time-series of posture scores for trend analysis."""
    tenant_id: str
    scores: list[dict[str, Any]] = field(default_factory=list)  # list of {timestamp, score, grade}


# ═══════════════════════════════════════════════════════════════
# Factor Weights (Gartner + NIST CSF informed)
# ═══════════════════════════════════════════════════════════════

FACTOR_WEIGHTS = {
    "compliance": 0.25,        # highest weight — most board-visible
    "vulnerability": 0.20,     # CVE management
    "exposure": 0.20,          # internet-facing risk
    "identity": 0.15,          # IAM posture (CIEM)
    "data_protection": 0.10,   # encryption + DSPM
    "detection_coverage": 0.10, # monitoring + alerting
}

# Severity weights — how much each finding type hurts the score
SEVERITY_WEIGHTS = {
    "critical": 10.0,
    "high": 5.0,
    "medium": 2.0,
    "low": 0.5,
    "info": 0.1,
}


# ═══════════════════════════════════════════════════════════════
# Posture Score Calculator
# ═══════════════════════════════════════════════════════════════

class PostureScoreCalculator:
    """Calculates multi-factor posture score.

    Algorithm:
      For each factor:
        1. Gather relevant findings
        2. Apply severity weights to compute penalty
        3. Score = 100 - penalty (clamped to 0-100)
        4. Weighted_score = Score × Factor_Weight

      Overall = sum(Weighted_scores)
      Grade = letter based on overall
      Trend = compare to previous score
    """

    def __init__(self):
        self._history: dict[str, PostureHistory] = {}
        self._lock = threading.RLock()
        # Industry benchmark percentiles (would come from aggregated customer data)
        self._benchmarks: dict[str, float] = {
            "finance": 78.0,
            "healthcare": 75.0,
            "technology": 80.0,
            "government": 72.0,
            "retail": 70.0,
            "manufacturing": 73.0,
            "general": 74.0,
        }

    def calculate(
        self,
        tenant_id: str,
        compliance_data: dict[str, Any],
        vulnerability_data: dict[str, Any],
        exposure_data: dict[str, Any],
        identity_data: dict[str, Any],
        data_protection_data: dict[str, Any],
        detection_data: dict[str, Any],
        industry: str = "general",
    ) -> PostureScore:
        """Calculate posture score from factor data.

        Each data dict should contain:
          - findings_count: total findings in this dimension
          - by_severity: dict of severity → count
          - assets_count: total assets evaluated
          - (factor-specific details)
        """
        start_time = time.time()

        # Calculate each factor
        factors: list[FactorScore] = []
        factors.append(self._calc_compliance(compliance_data))
        factors.append(self._calc_vulnerability(vulnerability_data))
        factors.append(self._calc_exposure(exposure_data))
        factors.append(self._calc_identity(identity_data))
        factors.append(self._calc_data_protection(data_protection_data))
        factors.append(self._calc_detection(detection_data))

        # Overall = sum of weighted scores
        overall = sum(f.weighted_score for f in factors)
        overall = max(0, min(100, overall))

        # Grade
        grade = self._score_to_grade(overall)

        # Trend
        trend, previous_score, score_change = self._compute_trend(tenant_id, overall)

        # Industry benchmark
        benchmark = self._benchmarks.get(industry, self._benchmarks["general"])
        # Percentile: rough calculation (would be from aggregated data)
        if overall >= benchmark + 10:
            percentile = 90
        elif overall >= benchmark:
            percentile = 75
        elif overall >= benchmark - 10:
            percentile = 50
        elif overall >= benchmark - 20:
            percentile = 25
        else:
            percentile = 10

        # Top recommendations (highest-impact fixes)
        recommendations = self._generate_recommendations(factors)

        # Quick wins (low-effort, high-impact)
        quick_wins = self._generate_quick_wins(factors)

        # Potential score if all critical/high fixed
        potential = self._calculate_potential(factors)

        posture = PostureScore(
            score_id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            overall_score=round(overall, 1),
            grade=grade,
            trend=trend,
            previous_score=previous_score,
            score_change=score_change,
            factors=factors,
            industry_benchmark=benchmark,
            percentile=percentile,
            top_recommendations=recommendations,
            quick_wins=quick_wins,
            potential_score_if_fixed=round(potential, 1),
            calculated_at=int(time.time() * 1000),
        )

        # Record in history
        with self._lock:
            if tenant_id not in self._history:
                self._history[tenant_id] = PostureHistory(tenant_id=tenant_id)
            hist = self._history[tenant_id]
            hist.scores.append({
                "timestamp": posture.calculated_at,
                "score": posture.overall_score,
                "grade": posture.grade,
            })
            # Keep last 90 entries
            if len(hist.scores) > 90:
                hist.scores = hist.scores[-90:]

        return posture

    def _calc_compliance(self, data: dict[str, Any]) -> FactorScore:
        """Compliance score from framework assessments."""
        weight = FACTOR_WEIGHTS["compliance"]
        # If we have assessment data, use average score across frameworks
        assessments = data.get("assessments", [])
        if not assessments:
            # No assessments → neutral score (don't penalize for not assessing)
            score = 75.0
            return FactorScore(
                factor_name="Compliance", score=score, weight=weight,
                weighted_score=score * weight,
                details={"note": "No compliance assessments run yet"},
            )

        avg_score = sum(a.get("score", 0) for a in assessments) / len(assessments)
        failed_controls = sum(a.get("failed", 0) for a in assessments)
        critical_failures = sum(
            1 for a in assessments
            for fc in a.get("failed_controls", [])
            if fc.get("highest_severity") in ("critical", "high")
        )

        score = max(0, min(100, avg_score))
        return FactorScore(
            factor_name="Compliance", score=score, weight=weight,
            weighted_score=score * weight,
            findings_count=failed_controls,
            critical_findings=critical_failures,
            details={
                "frameworks_assessed": len(assessments),
                "average_score": round(avg_score, 1),
            },
        )

    def _calc_vulnerability(self, data: dict[str, Any]) -> FactorScore:
        """Vulnerability score from CVE scan results."""
        weight = FACTOR_WEIGHTS["vulnerability"]
        total_vulns = data.get("total_vulnerabilities", 0)
        by_severity = data.get("by_severity", {})
        exploitable = data.get("exploitable_count", 0)

        critical = by_severity.get("critical", 0)
        high = by_severity.get("high", 0)
        medium = by_severity.get("medium", 0)
        low = by_severity.get("low", 0)

        # Penalty: weighted sum of vulnerabilities
        penalty = (
            critical * SEVERITY_WEIGHTS["critical"] +
            high * SEVERITY_WEIGHTS["high"] +
            medium * SEVERITY_WEIGHTS["medium"] +
            low * SEVERITY_WEIGHTS["low"] +
            exploitable * 5  # extra penalty for exploitable
        )
        # Normalize by total assets (more assets = more expected vulns)
        assets_count = data.get("total_packages", data.get("total_assets", 1))
        normalized_penalty = penalty / max(assets_count / 50, 1)  # 50 packages = baseline
        score = max(0, 100 - normalized_penalty)

        return FactorScore(
            factor_name="Vulnerability", score=score, weight=weight,
            weighted_score=score * weight,
            findings_count=total_vulns,
            critical_findings=critical,
            high_findings=high,
            medium_findings=medium,
            low_findings=low,
            details={
                "exploitable": exploitable,
                "total_packages_scanned": assets_count,
            },
        )

    def _calc_exposure(self, data: dict[str, Any]) -> FactorScore:
        """Exposure score from internet-facing asset analysis."""
        weight = FACTOR_WEIGHTS["exposure"]
        total_assets = data.get("total_assets", 1)
        internet_exposed = data.get("internet_exposed_count", 0)
        public_critical = data.get("public_critical_count", 0)
        open_security_groups = data.get("open_security_groups", 0)

        # Penalty
        penalty = (
            internet_exposed * 3 +
            public_critical * 15 +  # critical asset exposed = huge penalty
            open_security_groups * 5
        )
        score = max(0, 100 - penalty)

        return FactorScore(
            factor_name="Exposure", score=score, weight=weight,
            weighted_score=score * weight,
            findings_count=internet_exposed + open_security_groups,
            critical_findings=public_critical,
            details={
                "internet_exposed_assets": internet_exposed,
                "public_critical_assets": public_critical,
                "open_security_groups": open_security_groups,
                "total_assets": total_assets,
            },
        )

    def _calc_identity(self, data: dict[str, Any]) -> FactorScore:
        """Identity score from CIEM assessment."""
        weight = FACTOR_WEIGHTS["identity"]
        total_principals = data.get("total_principals", 1)
        admin_principals = data.get("admin_principals", 0)
        privesc_paths = data.get("privilege_escalation_paths", 0)
        unused_permissions = data.get("unused_permissions", 0)
        mfa_disabled = data.get("mfa_disabled_users", 0)

        penalty = (
            admin_principals * 10 +
            privesc_paths * 5 +
            unused_permissions * 0.5 +
            mfa_disabled * 5
        )
        score = max(0, 100 - penalty)

        return FactorScore(
            factor_name="Identity", score=score, weight=weight,
            weighted_score=score * weight,
            findings_count=admin_principals + privesc_paths + mfa_disabled,
            critical_findings=admin_principals,
            high_findings=privesc_paths,
            details={
                "admin_principals": admin_principals,
                "privesc_paths": privesc_paths,
                "unused_permissions": unused_permissions,
                "mfa_disabled": mfa_disabled,
                "total_principals": total_principals,
            },
        )

    def _calc_data_protection(self, data: dict[str, Any]) -> FactorScore:
        """Data protection score from DSPM + encryption status."""
        weight = FACTOR_WEIGHTS["data_protection"]
        unencrypted_sensitive = data.get("unencrypted_sensitive_assets", 0)
        public_sensitive = data.get("public_sensitive_assets", 0)
        pii_exposed = data.get("pii_exposed_count", 0)
        secrets_in_code = data.get("secrets_in_code", 0)

        penalty = (
            unencrypted_sensitive * 8 +
            public_sensitive * 15 +
            pii_exposed * 10 +
            secrets_in_code * 12
        )
        score = max(0, 100 - penalty)

        return FactorScore(
            factor_name="Data Protection", score=score, weight=weight,
            weighted_score=score * weight,
            findings_count=unencrypted_sensitive + public_sensitive + secrets_in_code,
            critical_findings=public_sensitive,
            high_findings=pii_exposed,
            details={
                "unencrypted_sensitive": unencrypted_sensitive,
                "public_sensitive": public_sensitive,
                "pii_exposed": pii_exposed,
                "secrets_in_code": secrets_in_code,
            },
        )

    def _calc_detection(self, data: dict[str, Any]) -> FactorScore:
        """Detection coverage score from monitoring setup."""
        weight = FACTOR_WEIGHTS["detection_coverage"]
        cloudtrail_enabled = data.get("cloudtrail_enabled", False)
        config_enabled = data.get("config_enabled", False)
        guardduty_enabled = data.get("guardduty_enabled", False)
        securityhub_enabled = data.get("securityhub_enabled", False)
        cw_alarms = data.get("cloudwatch_alarms", 0)
        detection_rules = data.get("detection_rules", 0)

        score = 0
        if cloudtrail_enabled:
            score += 30
        if config_enabled:
            score += 20
        if guardduty_enabled:
            score += 20
        if securityhub_enabled:
            score += 10
        score += min(20, cw_alarms * 2)
        score += min(10, detection_rules * 0.5)

        return FactorScore(
            factor_name="Detection Coverage", score=score, weight=weight,
            weighted_score=score * weight,
            details={
                "cloudtrail_enabled": cloudtrail_enabled,
                "config_enabled": config_enabled,
                "guardduty_enabled": guardduty_enabled,
                "securityhub_enabled": securityhub_enabled,
                "cloudwatch_alarms": cw_alarms,
                "detection_rules": detection_rules,
            },
        )

    def _score_to_grade(self, score: float) -> str:
        if score >= 90:
            return PostureGrade.A.value
        if score >= 80:
            return PostureGrade.B.value
        if score >= 70:
            return PostureGrade.C.value
        if score >= 60:
            return PostureGrade.D.value
        return PostureGrade.F.value

    def _compute_trend(self, tenant_id: str, current_score: float) -> tuple[str, Optional[float], Optional[float]]:
        with self._lock:
            hist = self._history.get(tenant_id)
            if not hist or len(hist.scores) < 2:
                return PostureTrend.NEW.value, None, None
            previous = hist.scores[-1]["score"]
            change = current_score - previous
            if change > 2:
                trend = PostureTrend.IMPROVING.value
            elif change < -2:
                trend = PostureTrend.DEGRADING.value
            else:
                trend = PostureTrend.STABLE.value
            return trend, previous, round(change, 1)

    def _generate_recommendations(self, factors: list[FactorScore]) -> list[dict[str, Any]]:
        """Generate top recommendations sorted by potential score impact."""
        recs: list[dict[str, Any]] = []
        for factor in factors:
            if factor.critical_findings > 0:
                impact = factor.critical_findings * SEVERITY_WEIGHTS["critical"] * factor.weight
                recs.append({
                    "factor": factor.factor_name,
                    "action": f"Fix {factor.critical_findings} critical findings in {factor.factor_name}",
                    "impact": round(impact, 1),
                    "priority": "P1",
                })
            if factor.high_findings > 0:
                impact = factor.high_findings * SEVERITY_WEIGHTS["high"] * factor.weight
                recs.append({
                    "factor": factor.factor_name,
                    "action": f"Address {factor.high_findings} high findings in {factor.factor_name}",
                    "impact": round(impact, 1),
                    "priority": "P2",
                })
        recs.sort(key=lambda r: r["impact"], reverse=True)
        return recs[:10]

    def _generate_quick_wins(self, factors: list[FactorScore]) -> list[dict[str, Any]]:
        """Generate quick wins (low-effort, high-impact actions)."""
        quick_wins: list[dict[str, Any]] = []
        for factor in factors:
            details = factor.details
            if factor.factor_name == "Identity" and details.get("mfa_disabled", 0) > 0:
                quick_wins.append({
                    "factor": "Identity",
                    "action": f"Enable MFA for {details['mfa_disabled']} users",
                    "impact": round(details["mfa_disabled"] * 5 * factor.weight, 1),
                    "effort": "low",
                })
            if factor.factor_name == "Data Protection" and details.get("unencrypted_sensitive", 0) > 0:
                quick_wins.append({
                    "factor": "Data Protection",
                    "action": f"Enable encryption on {details['unencrypted_sensitive']} assets",
                    "impact": round(details["unencrypted_sensitive"] * 8 * factor.weight, 1),
                    "effort": "low",
                })
            if factor.factor_name == "Detection" and not details.get("cloudtrail_enabled"):
                quick_wins.append({
                    "factor": "Detection",
                    "action": "Enable CloudTrail (multi-region with KMS encryption)",
                    "impact": round(30 * factor.weight, 1),
                    "effort": "low",
                })
        quick_wins.sort(key=lambda q: q["impact"], reverse=True)
        return quick_wins[:5]

    def _calculate_potential(self, factors: list[FactorScore]) -> float:
        """Calculate potential score if all critical/high findings are fixed."""
        total = 0
        for factor in factors:
            # If we fix all critical/high, the score goes to ~100 for that factor
            # (assuming medium/low findings have minimal impact)
            fixed_score = min(100, factor.score +
                            factor.critical_findings * SEVERITY_WEIGHTS["critical"] +
                            factor.high_findings * SEVERITY_WEIGHTS["high"])
            total += min(100, fixed_score) * factor.weight
        return min(100, total)

    def get_history(self, tenant_id: str, limit: int = 30) -> list[dict[str, Any]]:
        with self._lock:
            hist = self._history.get(tenant_id)
            if not hist:
                return []
            return hist.scores[-limit:]

    def get_benchmarks(self) -> dict[str, float]:
        return dict(self._benchmarks)


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_engine: Optional[PostureScoreCalculator] = None
_global_lock = threading.Lock()


def get_posture_engine() -> PostureScoreCalculator:
    global _global_engine
    if _global_engine is None:
        with _global_lock:
            if _global_engine is None:
                _global_engine = PostureScoreCalculator()
    return _global_engine
