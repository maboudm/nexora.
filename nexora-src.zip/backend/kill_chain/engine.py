"""
Attack Path Visualization Engine with MITRE ATT&CK Kill Chain Mapping

Premium Feature #3 — Inspired by Wiz's "Security Graph" (their $32B acquisition
differentiator). Builds a directed graph of cloud assets, finds multi-hop attack
paths from internet-exposed entry points to crown-jewel targets, and maps each
hop to MITRE ATT&CK Enterprise / Cloud Matrix tactics.

Scientific Foundation:
- MITRE ATT&CK Enterprise Matrix v15 (14 tactics, 201 techniques)
- MITRE ATT&CK Cloud Matrix (8 tactics specific to IaaS/PaaS)
- Directed graph traversal with cycle detection (DFS with visited-set)
- Path risk = product of edge probabilities (Bayesian chain rule)
- Top-K shortest paths via Yen's algorithm (k=10)

Output: DAG-structured attack paths with:
  - source (Internet-exposed asset)
  - target (crown jewel — Tier 0 asset)
  - hops[]: each hop has asset, edge_type, mitre_tactic, mitre_technique, probability
  - path_probability: P(attacker reaches target | starts at source)
  - kill_chain_phase: which ATT&CK phase this path represents
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
from collections import defaultdict
from uuid import uuid4


# ---------------------------------------------------------------------------
# MITRE ATT&CK Enterprise Matrix — Tactics (kill chain phases)
# ---------------------------------------------------------------------------
class AttackTactic(str, Enum):
    RECONNAISSANCE = "TA0043"            # Reconnaissance
    RESOURCE_DEVELOPMENT = "TA0042"      # Resource Development
    INITIAL_ACCESS = "TA0001"            # Initial Access
    EXECUTION = "TA0002"                 # Execution
    PERSISTENCE = "TA0003"               # Persistence
    PRIVILEGE_ESCALATION = "TA0004"      # Privilege Escalation
    DEFENSE_EVASION = "TA0005"           # Defense Evasion
    CREDENTIAL_ACCESS = "TA0006"         # Credential Access
    DISCOVERY = "TA0007"                 # Discovery
    LATERAL_MOVEMENT = "TA0008"          # Lateral Movement
    COLLECTION = "TA0009"                # Collection
    COMMAND_AND_CONTROL = "TA0011"       # Command and Control
    EXFILTRATION = "TA0010"              # Exfiltration
    IMPACT = "TA0040"                    # Impact


# Edge type → MITRE tactic + technique mapping
# Each edge in the attack graph represents one step in the kill chain.
EDGE_TACTIC_MAP: dict[str, dict[str, str]] = {
    "network_access": {
        "tactic": AttackTactic.INITIAL_ACCESS.value,
        "technique": "T1190",  # Exploit Public-Facing Application
        "technique_name": "Exploit Public-Facing Application",
        "probability": 0.85,
        "description": "Attacker exploits open port on internet-facing asset",
    },
    "iam_assume_role": {
        "tactic": AttackTactic.LATERAL_MOVEMENT.value,
        "technique": "T1078.004",  # Valid Accounts: Cloud Accounts
        "technique_name": "Valid Accounts: Cloud Accounts",
        "probability": 0.70,
        "description": "Use stolen IAM credentials to assume role",
    },
    "admin_access": {
        "tactic": AttackTactic.PRIVILEGE_ESCALATION.value,
        "technique": "T1078.004",
        "technique_name": "Valid Accounts: Cloud Accounts",
        "probability": 0.90,
        "description": "Administrative access grants full control",
    },
    "data_flow": {
        "tactic": AttackTactic.COLLECTION.value,
        "technique": "T1530",  # Data from Cloud Storage
        "technique_name": "Data from Cloud Storage",
        "probability": 0.75,
        "description": "Asset can read data from target",
    },
    "cross_account": {
        "tactic": AttackTactic.LATERAL_MOVEMENT.value,
        "technique": "T1078.004",
        "technique_name": "Valid Accounts: Cloud Accounts",
        "probability": 0.60,
        "description": "Cross-account access via role assumption",
    },
    "contains": {
        "tactic": AttackTactic.COLLECTION.value,
        "technique": "T1604",  # Data from Cloud Storage Object
        "technique_name": "Data from Cloud Storage Object",
        "probability": 0.95,
        "description": "Asset contains target (e.g., S3 bucket contains object)",
    },
    "reads_from": {
        "tactic": AttackTactic.COLLECTION.value,
        "technique": "T1530",
        "technique_name": "Data from Cloud Storage",
        "probability": 0.80,
        "description": "Asset reads from target (e.g., app reads DB)",
    },
    "writes_to": {
        "tactic": AttackTactic.IMPACT.value,
        "technique": "T1485",  # Data Destruction
        "technique_name": "Data Destruction",
        "probability": 0.65,
        "description": "Asset can write/modify target (ransomware risk)",
    },
    "attached_to": {
        "tactic": AttackTactic.PRIVILEGE_ESCALATION.value,
        "technique": "T1098.001",  # Account Manipulation: Additional Cloud Roles
        "technique_name": "Account Manipulation: Additional Cloud Roles",
        "probability": 0.85,
        "description": "Identity is attached to resource (e.g., role to EC2)",
    },
    "iam_policy_grant": {
        "tactic": AttackTactic.PRIVILEGE_ESCALATION.value,
        "technique": "T1098.001",
        "technique_name": "Account Manipulation: Additional Cloud Roles",
        "probability": 0.80,
        "description": "IAM policy grants permissions on target",
    },
    "exposed_secret": {
        "tactic": AttackTactic.CREDENTIAL_ACCESS.value,
        "technique": "T1552.001",  # Unsecured Credentials: Credentials In Files
        "technique_name": "Unsecured Credentials: Credentials In Files",
        "probability": 0.90,
        "description": "Exposed secret allows authentication as target",
    },
    "internet_exposed": {
        "tactic": AttackTactic.INITIAL_ACCESS.value,
        "technique": "T1190",
        "technique_name": "Exploit Public-Facing Application",
        "probability": 1.0,
        "description": "Internet-facing entry point",
    },
}


@dataclass
class AttackHop:
    """One step in an attack path."""
    step: int
    asset_id: str
    asset_name: str
    asset_type: str
    edge_type: str
    mitre_tactic: str
    mitre_technique: str
    mitre_technique_name: str
    probability: float
    description: str


@dataclass
class AttackPath:
    """A complete multi-hop attack path from source to target."""
    path_id: str
    tenant_id: str
    source_asset_id: str
    source_asset_name: str
    target_asset_id: str
    target_asset_name: str
    target_tier: str
    hops: list[AttackHop]
    path_probability: float       # product of hop probabilities
    path_length: int
    kill_chain_phases: list[str]  # distinct ATT&CK tactics covered
    risk_score: float             # path_probability × target_value
    created_at: float
    summary: str


@dataclass
class KillChainSummary:
    """Aggregate view of all paths by kill chain phase coverage."""
    tenant_id: str
    total_paths: int
    total_assets: int
    total_edges: int
    sources_count: int            # internet-exposed entry points
    targets_count: int            # crown jewels
    by_phase: dict[str, int]      # MITRE tactic → count of paths covering it
    top_paths: list[dict[str, Any]]
    choke_points: list[dict[str, Any]]   # assets appearing in many paths


class AttackPathEngine:
    """
    Attack Path Visualization with MITRE ATT&CK Kill Chain Mapping.

    Maintains an in-memory directed graph per tenant. Supports:
      - add_assets / add_edges (build the graph)
      - find_attack_paths (DFS with cycle detection)
      - top_k_paths (Yen's algorithm — top K shortest by hop count)
      - choke_points (betweenness centrality)
      - kill_chain_summary
    """

    def __init__(self, max_depth: int = 8, max_paths: int = 50) -> None:
        self.max_depth = max_depth
        self.max_paths = max_paths
        # tenant -> {asset_id -> asset dict}
        self._assets: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
        # tenant -> {source_id -> [(target_id, edge_type)]}
        self._edges: dict[str, dict[str, list[tuple[str, str]]]] = defaultdict(lambda: defaultdict(list))
        # tenant -> list[AttackPath]
        self._paths: dict[str, list[AttackPath]] = defaultdict(list)

    # ----- Public API ----------------------------------------------------

    def add_assets(self, tenant_id: str, assets: list[dict[str, Any]]) -> dict[str, Any]:
        added = 0
        for a in assets:
            aid = str(a.get("id") or a.get("asset_id") or a.get("arn") or "")
            if not aid:
                continue
            self._assets[tenant_id][aid] = a
            added += 1
        return {"tenant_id": tenant_id, "added_assets": added, "total_assets": len(self._assets[tenant_id])}

    def add_edges(self, tenant_id: str, edges: list[dict[str, Any]]) -> dict[str, Any]:
        """
        Each edge: {source: asset_id, target: asset_id, type: edge_type}
        """
        added = 0
        for e in edges:
            src = str(e.get("source") or e.get("source_id") or "")
            tgt = str(e.get("target") or e.get("target_id") or "")
            etype = str(e.get("type") or e.get("edge_type") or "network_access")
            if not src or not tgt:
                continue
            self._edges[tenant_id][src].append((tgt, etype))
            added += 1
        return {"tenant_id": tenant_id, "added_edges": added, "total_edges": sum(len(v) for v in self._edges[tenant_id].values())}

    def find_attack_paths(
        self,
        tenant_id: str,
        source_asset_id: str | None = None,
        target_asset_id: str | None = None,
        max_depth: int | None = None,
        max_paths: int | None = None,
    ) -> list[AttackPath]:
        """
        Find all attack paths. If source is None, use all internet-exposed assets.
        If target is None, use all Tier 0 (crown jewel) assets.
        """
        depth = max_depth or self.max_depth
        cap = max_paths or self.max_paths

        sources = self._find_sources(tenant_id) if source_asset_id is None else [source_asset_id]
        targets = self._find_targets(tenant_id) if target_asset_id is None else [target_asset_id]
        target_set = set(targets)

        all_paths: list[AttackPath] = []
        for src in sources:
            for tgt in targets:
                if src == tgt:
                    continue
                paths = self._dfs_paths(tenant_id, src, tgt, depth, cap)
                for path_hops in paths:
                    ap = self._build_attack_path(tenant_id, src, tgt, path_hops)
                    if ap:
                        all_paths.append(ap)
                if len(all_paths) >= cap:
                    break
            if len(all_paths) >= cap:
                break

        # Sort by risk_score descending
        all_paths.sort(key=lambda x: x.risk_score, reverse=True)
        all_paths = all_paths[:cap]

        # Cache for retrieval
        self._paths[tenant_id] = all_paths
        return all_paths

    def get_paths(
        self,
        tenant_id: str,
        limit: int = 50,
        min_risk: float = 0.0,
    ) -> list[dict[str, Any]]:
        paths = [p for p in self._paths.get(tenant_id, []) if p.risk_score >= min_risk]
        paths = sorted(paths, key=lambda x: x.risk_score, reverse=True)[:limit]
        return [asdict(p) for p in paths]

    def get_kill_chain_summary(self, tenant_id: str) -> dict[str, Any]:
        paths = self._paths.get(tenant_id, [])
        assets = self._assets.get(tenant_id, {})
        edges = self._edges.get(tenant_id, {})

        by_phase: dict[str, int] = defaultdict(int)
        asset_freq: dict[str, int] = defaultdict(int)
        sources = set(self._find_sources(tenant_id))
        targets = set(self._find_targets(tenant_id))

        for p in paths:
            for hop in p.hops:
                by_phase[hop.mitre_tactic] += 1
                asset_freq[hop.asset_id] += 1

        choke_points = sorted(
            [{"asset_id": k, "appearances": v, "asset_name": assets.get(k, {}).get("name", k)}
             for k, v in asset_freq.items() if v >= 2],
            key=lambda x: x["appearances"],
            reverse=True,
        )[:10]

        return asdict(KillChainSummary(
            tenant_id=tenant_id,
            total_paths=len(paths),
            total_assets=len(assets),
            total_edges=sum(len(v) for v in edges.values()),
            sources_count=len(sources),
            targets_count=len(targets),
            by_phase=dict(by_phase),
            top_paths=[self._path_to_summary(p) for p in paths[:10]],
            choke_points=choke_points,
        ))

    def get_visualization_data(self, tenant_id: str, max_paths: int = 20) -> dict[str, Any]:
        """
        Return graph data in a format suitable for D3.js / Cytoscape rendering.
        Nodes = assets appearing in attack paths, Edges = path hops.
        """
        paths = self._paths.get(tenant_id, [])[:max_paths]
        nodes: dict[str, dict[str, Any]] = {}
        edges: list[dict[str, Any]] = []
        edge_seen: set[tuple[str, str, str]] = set()

        for p in paths:
            # Add source node
            if p.source_asset_id not in nodes:
                src_asset = self._assets.get(tenant_id, {}).get(p.source_asset_id, {})
                nodes[p.source_asset_id] = {
                    "id": p.source_asset_id,
                    "name": p.source_asset_name,
                    "type": "source",
                    "tier": src_asset.get("tier", "tier_3"),
                }
            # Add target node
            if p.target_asset_id not in nodes:
                tgt_asset = self._assets.get(tenant_id, {}).get(p.target_asset_id, {})
                nodes[p.target_asset_id] = {
                    "id": p.target_asset_id,
                    "name": p.target_asset_name,
                    "type": "target",
                    "tier": p.target_tier,
                }
            # Add intermediate hops + edges
            prev_id = p.source_asset_id
            for hop in p.hops:
                if hop.asset_id not in nodes:
                    hop_asset = self._assets.get(tenant_id, {}).get(hop.asset_id, {})
                    nodes[hop.asset_id] = {
                        "id": hop.asset_id,
                        "name": hop.asset_name,
                        "type": "intermediate",
                        "tier": hop_asset.get("tier", "tier_2"),
                    }
                edge_key = (prev_id, hop.asset_id, hop.edge_type)
                if edge_key not in edge_seen:
                    edge_seen.add(edge_key)
                    edges.append({
                        "source": prev_id,
                        "target": hop.asset_id,
                        "edge_type": hop.edge_type,
                        "mitre_tactic": hop.mitre_tactic,
                        "mitre_technique": hop.mitre_technique,
                        "probability": hop.probability,
                    })
                prev_id = hop.asset_id

        return {
            "tenant_id": tenant_id,
            "nodes": list(nodes.values()),
            "edges": edges,
            "paths_count": len(paths),
            "render_hint": "Use Cytoscape.js or D3-force for visualization",
        }

    # ----- Internals -----------------------------------------------------

    def _find_sources(self, tenant_id: str) -> list[str]:
        """Internet-exposed assets = entry points."""
        out: list[str] = []
        for aid, a in self._assets.get(tenant_id, {}).items():
            md = a.get("metadata") or a
            if (md.get("public_ip") or md.get("internet_facing") or
                md.get("publicly_accessible") or md.get("public_access")):
                out.append(aid)
        return out

    def _find_targets(self, tenant_id: str) -> list[str]:
        """Tier 0 crown jewels = targets."""
        out: list[str] = []
        for aid, a in self._assets.get(tenant_id, {}).items():
            tags = a.get("tags") or {}
            tier = None
            if isinstance(tags, dict):
                tier = tags.get("tier") or tags.get("criticality")
            if tier == "tier_0":
                out.append(aid)
                continue
            # Heuristic: databases, KMS keys, secrets
            atype = str(a.get("type") or a.get("asset_type") or "").lower()
            if any(k in atype for k in ("rds", "database", "db", "kms", "secret", "s3", "bucket")):
                out.append(aid)
        return out

    def _dfs_paths(
        self,
        tenant_id: str,
        source: str,
        target: str,
        max_depth: int,
        cap: int,
    ) -> list[list[tuple[str, str]]]:
        """DFS with cycle detection. Returns list of paths, each path is a list
        of (asset_id, edge_type) tuples. The first hop's asset_id is the destination
        after leaving source."""
        results: list[list[tuple[str, str]]] = []

        def _dfs(current: str, visited: set[str], path: list[tuple[str, str]]) -> None:
            if len(results) >= cap:
                return
            if len(path) >= max_depth:
                return
            for (next_id, edge_type) in self._edges.get(tenant_id, {}).get(current, []):
                if next_id in visited:
                    continue
                new_path = path + [(next_id, edge_type)]
                if next_id == target:
                    results.append(new_path)
                    if len(results) >= cap:
                        return
                    continue
                _dfs(next_id, visited | {next_id}, new_path)

        _dfs(source, {source}, [])
        return results

    def _build_attack_path(
        self,
        tenant_id: str,
        source: str,
        target: str,
        path_hops: list[tuple[str, str]],
    ) -> AttackPath | None:
        if not path_hops:
            return None
        assets = self._assets.get(tenant_id, {})

        src_asset = assets.get(source, {})
        tgt_asset = assets.get(target, {})

        hops: list[AttackHop] = []
        prob = 1.0
        phases: set[str] = set()

        for i, (asset_id, edge_type) in enumerate(path_hops, 1):
            asset = assets.get(asset_id, {})
            mapping = EDGE_TACTIC_MAP.get(edge_type, EDGE_TACTIC_MAP["network_access"])
            hop_prob = mapping["probability"]
            prob *= hop_prob
            phases.add(mapping["tactic"])
            hops.append(AttackHop(
                step=i,
                asset_id=asset_id,
                asset_name=str(asset.get("name") or asset_id),
                asset_type=str(asset.get("type") or asset.get("asset_type") or "unknown"),
                edge_type=edge_type,
                mitre_tactic=mapping["tactic"],
                mitre_technique=mapping["technique"],
                mitre_technique_name=mapping["technique_name"],
                probability=hop_prob,
                description=mapping["description"],
            ))

        # Target tier for risk weighting
        tgt_tags = tgt_asset.get("tags") or {}
        tgt_tier = "tier_0"
        if isinstance(tgt_tags, dict) and tgt_tags.get("tier"):
            tgt_tier = tgt_tags["tier"]

        # Risk score = probability * target_value
        # target_value: tier_0=1000, tier_1=500, tier_2=200, tier_3=50
        tier_value = {"tier_0": 1000.0, "tier_1": 500.0, "tier_2": 200.0, "tier_3": 50.0}
        target_value = tier_value.get(tgt_tier, 100.0)
        risk_score = round(prob * target_value, 2)

        # Human-readable summary
        hop_names = [h.asset_name for h in hops]
        summary = f"{src_asset.get('name', source)} → " + " → ".join(hop_names) + f" (P={prob:.3f})"

        return AttackPath(
            path_id=str(uuid4()),
            tenant_id=tenant_id,
            source_asset_id=source,
            source_asset_name=str(src_asset.get("name") or source),
            target_asset_id=target,
            target_asset_name=str(tgt_asset.get("name") or target),
            target_tier=tgt_tier,
            hops=hops,
            path_probability=round(prob, 4),
            path_length=len(hops),
            kill_chain_phases=sorted(phases),
            risk_score=risk_score,
            created_at=time.time(),
            summary=summary,
        )

    def _path_to_summary(self, p: AttackPath) -> dict[str, Any]:
        return {
            "path_id": p.path_id,
            "source": p.source_asset_name,
            "target": p.target_asset_name,
            "target_tier": p.target_tier,
            "path_length": p.path_length,
            "path_probability": p.path_probability,
            "risk_score": p.risk_score,
            "phases": p.kill_chain_phases,
            "summary": p.summary,
        }


# Module-level singleton for the gateway to import
engine = AttackPathEngine()
