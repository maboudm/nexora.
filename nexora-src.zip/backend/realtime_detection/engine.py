"""
Enterprise Real-time Detection Engine — CloudTrail stream + Sigma-like rules.

Based on Part 6 — Real-time CloudTrail Detection Pipeline and Sigma HD
(Half-Life Detection) specification by Florian Roth.

Scientific Foundation:
  - Sigma: Generic signature format for SIEM systems (https://sigmahq.io)
    Allows writing detection rules once, run on any SIEM (Splunk, Elastic,
    Sentinel, SentinelOne). This engine implements a Sigma-compatible DSL.
  - MITRE ATT&CK Cloud Matrix: maps detections to tactics (TA0001-TA0040)
  - Windowed Aggregation: rolling time-window analysis for behavioral patterns
    (e.g., "5+ failed logins in 1 minute = brute force")
  - Event Correlation: stateful correlation across events using finite state
    machines (FSM) for multi-stage attack patterns

Detection Categories:
  1. Authentication: brute force, impossible travel, MFA abuse, root usage
  2. Privilege Escalation: role chain abuse, policy attachment, key creation
  3. Persistence: backdoor roles, IAM users, Lambda functions, cron jobs
  4. Defense Evasion: CloudTrail disable, log deletion, config change
  5. Exfiltration: large S3 downloads, snapshot sharing, cross-account copy
  6. Initial Access: public resource creation, exposed credentials
  7. Lateral Movement: STS assumption chain, EC2 instance connect
  8. Resource Hijacking: cryptocurrency mining, unauthorized EC2 launch
  9. Credential Access: secret retrieval, parameter store access
  10. Discovery: service enumeration, IAM enumeration

Architecture:
  CloudTrail ──> Event Stream ──> Rule Engine ──> Detections
                                      │
                                      ├──> Aggregator (windowed)
                                      ├──> Correlator (FSM)
                                      └──> Enricher (asset + threat intel)
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import logging
import re
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Detection Domain Model
# ═══════════════════════════════════════════════════════════════

class DetectionTactic(str, Enum):
    """MITRE ATT&CK Cloud Matrix tactics."""
    INITIAL_ACCESS = "TA0001"
    EXECUTION = "TA0002"
    PERSISTENCE = "TA0003"
    PRIVILEGE_ESCALATION = "TA0004"
    DEFENSE_EVASION = "TA0005"
    CREDENTIAL_ACCESS = "TA0006"
    DISCOVERY = "TA0007"
    LATERAL_MOVEMENT = "TA0008"
    COLLECTION = "TA0009"
    EXFILTRATION = "TA0010"
    IMPACT = "TA0040"


class DetectionSeverity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class DetectionCategory(str, Enum):
    AUTHENTICATION = "authentication"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    PERSISTENCE = "persistence"
    DEFENSE_EVASION = "defense_evasion"
    EXFILTRATION = "exfiltration"
    INITIAL_ACCESS = "initial_access"
    LATERAL_MOVEMENT = "lateral_movement"
    RESOURCE_HIJACKING = "resource_hijacking"
    CREDENTIAL_ACCESS = "credential_access"
    DISCOVERY = "discovery"


@dataclass
class CloudTrailEvent:
    """A single CloudTrail event."""
    event_id: str
    event_name: str             # e.g., "ConsoleLogin", "PutRolePolicy"
    event_source: str           # e.g., "iam.amazonaws.com"
    event_time: str             # ISO 8601
    event_time_ms: int          # epoch ms
    source_ip: str
    user_agent: str
    user_identity: dict[str, Any]  # type, arn, accountId, etc.
    aws_region: str
    request_parameters: dict[str, Any] = field(default_factory=dict)
    response_elements: dict[str, Any] = field(default_factory=dict)
    resources: list[dict[str, Any]] = field(default_factory=list)
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    recipient_account_id: Optional[str] = None
    read_only: bool = False
    management_event: bool = True


@dataclass
class DetectionRule:
    """A Sigma-compatible detection rule."""
    rule_id: str
    name: str
    description: str
    severity: str               # DetectionSeverity value
    category: str               # DetectionCategory value
    tactics: list[str]          # MITRE ATT&CK tactic IDs
    techniques: list[str]       # MITRE ATT&CK technique IDs
    # Detection logic
    event_name: Optional[str] = None  # exact event name match
    event_source: Optional[str] = None  # exact source match
    # Field matchers: field_name → list of patterns (regex)
    field_matchers: dict[str, list[str]] = field(default_factory=dict)
    # Aggregation: count events matching criteria within a time window
    aggregation: Optional[dict[str, Any]] = None  # {"field": "source_ip", "threshold": 5, "window_seconds": 60}
    # Condition: AND/OR logic across field matchers
    condition: str = "and"      # "and" | "or"
    enabled: bool = True
    false_positive_rate: float = 0.0
    # Enrichment
    references: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    # Mitigation
    recommended_actions: list[str] = field(default_factory=list)


@dataclass
class Detection:
    """A detection triggered by a rule."""
    detection_id: str
    rule_id: str
    rule_name: str
    severity: str
    category: str
    tactics: list[str]
    techniques: list[str]
    description: str
    # Triggering event(s)
    triggering_events: list[dict[str, Any]] = field(default_factory=list)
    # Enrichment
    user_identity: dict[str, Any] = field(default_factory=dict)
    source_ip: str = ""
    aws_region: str = ""
    affected_resources: list[dict[str, Any]] = field(default_factory=list)
    # MITRE context
    mitre_tactics: list[str] = field(default_factory=list)
    mitre_techniques: list[str] = field(default_factory=list)
    # Mitigation
    recommended_actions: list[str] = field(default_factory=list)
    detected_at: int = 0
    tenant_id: str = ""
    confidence: float = 1.0


# ═══════════════════════════════════════════════════════════════
# Built-in Detection Rules (Sigma-compatible)
# ═══════════════════════════════════════════════════════════════

class BuiltinDetectionRules:
    """Built-in Sigma-like detection rules for AWS CloudTrail.

    These rules are derived from:
      - AWS GuardDuty findings (mapped to Sigma)
      - Sigma HQ repository (cloud-aws folder)
      - MITRE ATT&CK Cloud technique examples
      - Real-world APT TTPs from CISA advisories
    """

    @classmethod
    def get_all_rules(cls) -> list[DetectionRule]:
        return [
            # ─── Authentication ───
            DetectionRule(
                rule_id="aws-auth-001",
                name="AWS Root Account Usage",
                description="AWS root account was used. Root should only be used for break-glass scenarios.",
                severity=DetectionSeverity.HIGH.value,
                category=DetectionCategory.AUTHENTICATION.value,
                tactics=[DetectionTactic.PRIVILEGE_ESCALATION.value, DetectionTactic.PERSISTENCE.value],
                techniques=["T1078.004"],
                event_name="ConsoleLogin",
                field_matchers={
                    "user_identity.type": ["root"],
                },
                references=["https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html#disable-root-access-keys"],
                tags=["aws", "root", "console_login"],
                recommended_actions=[
                    "Verify this was an authorized break-glass action",
                    "If unauthorized: rotate root credentials immediately",
                    "Enable MFA on root account if not already",
                    "Review CloudTrail for actions taken by root",
                ],
            ),
            DetectionRule(
                rule_id="aws-auth-002",
                name="Console Login Without MFA",
                description="User logged into AWS console without MFA.",
                severity=DetectionSeverity.MEDIUM.value,
                category=DetectionCategory.AUTHENTICATION.value,
                tactics=[DetectionTactic.INITIAL_ACCESS.value],
                techniques=["T1078.004"],
                event_name="ConsoleLogin",
                field_matchers={
                    "response_elements.MFAUsed": ["No"],
                },
                references=["https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_mfa_enable.html"],
                tags=["aws", "mfa", "console_login"],
                recommended_actions=[
                    "Enforce MFA for all IAM users",
                    "Disable console access for users who don't need it",
                ],
            ),
            DetectionRule(
                rule_id="aws-auth-003",
                name="Brute Force Console Login",
                description="5+ failed console login attempts from same IP within 5 minutes.",
                severity=DetectionSeverity.HIGH.value,
                category=DetectionCategory.AUTHENTICATION.value,
                tactics=[DetectionTactic.CREDENTIAL_ACCESS.value],
                techniques=["T1110.001"],
                event_name="ConsoleLogin",
                field_matchers={
                    "error_code": ["Client.UnauthorizedOperation"],
                },
                aggregation={"field": "source_ip", "threshold": 5, "window_seconds": 300},
                references=["https://attack.mitre.org/techniques/T1110/001/"],
                tags=["aws", "brute_force", "console_login"],
                recommended_actions=[
                    "Block the source IP via network ACL",
                    "Lock affected IAM accounts",
                    "Reset passwords for targeted users",
                ],
            ),
            DetectionRule(
                rule_id="aws-auth-004",
                name="Impossible Travel",
                description="User logged in from two geographically distant locations within impossible timeframe.",
                severity=DetectionSeverity.HIGH.value,
                category=DetectionCategory.AUTHENTICATION.value,
                tactics=[DetectionTactic.INITIAL_ACCESS.value, DetectionTactic.DEFENSE_EVASION.value],
                techniques=["T1078.004"],
                event_name="ConsoleLogin",
                field_matchers={},
                aggregation={"type": "impossible_travel", "min_distance_km": 500, "max_time_minutes": 60},
                references=["https://attack.mitre.org/techniques/T1078/"],
                tags=["aws", "impossible_travel", "credential_theft"],
                recommended_actions=[
                    "Verify user identity via out-of-band channel",
                    "Force password reset",
                    "Revoke active sessions",
                ],
            ),

            # ─── Privilege Escalation ───
            DetectionRule(
                rule_id="aws-privesc-001",
                name="AdministratorAccess Policy Attached to Role",
                description="AdministratorAccess managed policy was attached to an IAM role. "
                            "This grants full account access.",
                severity=DetectionSeverity.CRITICAL.value,
                category=DetectionCategory.PRIVILEGE_ESCALATION.value,
                tactics=[DetectionTactic.PRIVILEGE_ESCALATION.value, DetectionTactic.PERSISTENCE.value],
                techniques=["T1098.001"],
                event_name="AttachRolePolicy",
                field_matchers={
                    "request_parameters.policyArn": ["arn:aws:iam::aws:policy/AdministratorAccess"],
                },
                references=["https://attack.mitre.org/techniques/T1098/001/"],
                tags=["aws", "iam", "privilege_escalation", "admin_policy"],
                recommended_actions=[
                    "Detach AdministratorAccess immediately",
                    "Investigate who made the change and why",
                    "Replace with least-privilege policy",
                ],
            ),
            DetectionRule(
                rule_id="aws-privesc-002",
                name="Inline Policy Added to Role",
                description="An inline policy was added to an IAM role. Inline policies bypass managed policy governance.",
                severity=DetectionSeverity.HIGH.value,
                category=DetectionCategory.PRIVILEGE_ESCALATION.value,
                tactics=[DetectionTactic.PRIVILEGE_ESCALATION.value, DetectionTactic.PERSISTENCE.value],
                techniques=["T1098.001"],
                event_name="PutRolePolicy",
                field_matchers={},
                references=["https://attack.mitre.org/techniques/T1098/001/"],
                tags=["aws", "iam", "inline_policy", "persistence"],
                recommended_actions=[
                    "Review the policy document for over-broad permissions",
                    "Move to managed policy if appropriate",
                    "Remove inline policy if unauthorized",
                ],
            ),
            DetectionRule(
                rule_id="aws-privesc-003",
                name="Assume Role by External Principal",
                description="An external principal assumed a role in this account. Verify this is expected.",
                severity=DetectionSeverity.HIGH.value,
                category=DetectionCategory.PRIVILEGE_ESCALATION.value,
                tactics=[DetectionTactic.LATERAL_MOVEMENT.value, DetectionTactic.PRIVILEGE_ESCALATION.value],
                techniques=["T1078.004"],
                event_name="AssumeRole",
                field_matchers={
                    "user_identity.type": ["AssumedRole"],
                },
                references=["https://attack.mitre.org/techniques/T1078/004/"],
                tags=["aws", "sts", "assume_role", "external"],
                recommended_actions=[
                    "Verify the source account is trusted",
                    "Check role trust policy for overly permissive principals",
                    "Review CloudTrail for actions taken with assumed role",
                ],
            ),
            DetectionRule(
                rule_id="aws-privesc-004",
                name="New Access Key Created for User",
                description="A new access key was created for an IAM user. Could indicate credential theft.",
                severity=DetectionSeverity.MEDIUM.value,
                category=DetectionCategory.CREDENTIAL_ACCESS.value,
                tactics=[DetectionTactic.CREDENTIAL_ACCESS.value, DetectionTactic.PERSISTENCE.value],
                techniques=["T1098.001"],
                event_name="CreateAccessKey",
                field_matchers={},
                references=["https://attack.mitre.org/techniques/T1098/001/"],
                tags=["aws", "iam", "access_key", "persistence"],
                recommended_actions=[
                    "Verify the key creation was authorized",
                    "If unauthorized: deactivate the key immediately",
                    "Audit all API calls made with the new key",
                ],
            ),

            # ─── Persistence ───
            DetectionRule(
                rule_id="aws-persist-001",
                name="New IAM User Created",
                description="A new IAM user was created. Verify this was authorized.",
                severity=DetectionSeverity.MEDIUM.value,
                category=DetectionCategory.PERSISTANCE.value if False else DetectionCategory.PERSISTENCE.value,
                tactics=[DetectionTactic.PERSISTENCE.value],
                techniques=["T1136.003"],
                event_name="CreateUser",
                field_matchers={},
                references=["https://attack.mitre.org/techniques/T1136/003/"],
                tags=["aws", "iam", "user_creation", "persistence"],
                recommended_actions=[
                    "Verify user creation was authorized",
                    "If unauthorized: delete the user immediately",
                    "Audit all actions taken by the new user",
                ],
            ),
            DetectionRule(
                rule_id="aws-persist-002",
                name="Role Trust Policy Modified",
                description="An IAM role trust policy was modified. Could allow new principals to assume the role.",
                severity=DetectionSeverity.HIGH.value,
                category=DetectionCategory.PERSISTENCE.value,
                tactics=[DetectionTactic.PERSISTENCE.value, DetectionTactic.PRIVILEGE_ESCALATION.value],
                techniques=["T1098.001"],
                event_name="UpdateAssumeRolePolicy",
                field_matchers={},
                references=["https://attack.mitre.org/techniques/T1098/001/"],
                tags=["aws", "iam", "trust_policy", "persistence"],
                recommended_actions=[
                    "Review the new trust policy",
                    "Verify only authorized principals can assume",
                    "Restore previous policy if unauthorized",
                ],
            ),
            DetectionRule(
                rule_id="aws-persist-003",
                name="Lambda Function Created with Admin Role",
                description="A Lambda function was created with an IAM role that has admin permissions. "
                            "This is a common persistence + escalation technique.",
                severity=DetectionSeverity.CRITICAL.value,
                category=DetectionCategory.PERSISTENCE.value,
                tactics=[DetectionTactic.PERSISTENCE.value, DetectionTactic.PRIVILEGE_ESCALATION.value],
                techniques=["T1105", "T1078.004"],
                event_name="CreateFunction",
                field_matchers={
                    "request_parameters.role": [".*AdministratorAccess.*"],
                },
                references=["https://rhinosecuritylabs.com/aws/aws-privilege-escalation-methods-mitigation/"],
                tags=["aws", "lambda", "persistence", "privilege_escalation"],
                recommended_actions=[
                    "Review the Lambda function code",
                    "Replace the role with least-privilege",
                    "Audit function invocations",
                ],
            ),

            # ─── Defense Evasion ───
            DetectionRule(
                rule_id="aws-evasion-001",
                name="CloudTrail Trail Disabled",
                description="CloudTrail logging was stopped or a trail was deleted. This is a classic defense evasion technique.",
                severity=DetectionSeverity.CRITICAL.value,
                category=DetectionCategory.DEFENSE_EVASION.value,
                tactics=[DetectionTactic.DEFENSE_EVASION.value],
                techniques=["T1562.001", "T1070.002"],
                event_source="cloudtrail.amazonaws.com",
                field_matchers={
                    "event_name": ["StopLogging", "DeleteTrail"],
                },
                references=["https://attack.mitre.org/techniques/T1562/001/"],
                tags=["aws", "cloudtrail", "defense_evasion", "logging_disabled"],
                recommended_actions=[
                    "Re-enable CloudTrail immediately",
                    "Investigate who disabled it and why",
                    "Set up CloudWatch alarm for future CloudTrail changes",
                ],
            ),
            DetectionRule(
                rule_id="aws-evasion-002",
                name="CloudWatch Logs Deleted",
                description="CloudWatch log group was deleted. Defense evasion to cover tracks.",
                severity=DetectionSeverity.HIGH.value,
                category=DetectionCategory.DEFENSE_EVASION.value,
                tactics=[DetectionTactic.DEFENSE_EVASION.value],
                techniques=["T1070.002", "T1562.008"],
                event_source="logs.amazonaws.com",
                field_matchers={
                    "event_name": ["DeleteLogGroup"],
                },
                references=["https://attack.mitre.org/techniques/T1070/002/"],
                tags=["aws", "cloudwatch", "defense_evasion", "log_deletion"],
                recommended_actions=[
                    "Restore logs from backup if available",
                    "Investigate what activity was being hidden",
                    "Implement log deletion protection",
                ],
            ),
            DetectionRule(
                rule_id="aws-evasion-003",
                name="Config Service Disabled",
                description="AWS Config was disabled. This prevents configuration change tracking.",
                severity=DetectionSeverity.HIGH.value,
                category=DetectionCategory.DEFENSE_EVASION.value,
                tactics=[DetectionTactic.DEFENSE_EVASION.value],
                techniques=["T1562.001"],
                event_source="config.amazonaws.com",
                field_matchers={
                    "event_name": ["DeleteConfigurationRecorder", "StopConfigurationRecorder"],
                },
                references=["https://attack.mitre.org/techniques/T1562/001/"],
                tags=["aws", "config", "defense_evasion"],
                recommended_actions=["Re-enable AWS Config", "Investigate why it was disabled"],
            ),

            # ─── Exfiltration ───
            DetectionRule(
                rule_id="aws-exfil-001",
                name="S3 Bucket Made Public",
                description="An S3 bucket policy or ACL was changed to allow public access.",
                severity=DetectionSeverity.CRITICAL.value,
                category=DetectionCategory.EXFILTRATION.value,
                tactics=[DetectionTactic.EXFILTRATION.value],
                techniques=["T1537", "T1567.002"],
                event_source="s3.amazonaws.com",
                field_matchers={
                    "event_name": ["PutBucketAcl", "PutBucketPolicy"],
                },
                references=["https://attack.mitre.org/techniques/T1537/"],
                tags=["aws", "s3", "exfiltration", "public_access"],
                recommended_actions=[
                    "Revert the bucket to private immediately",
                    "Enable S3 Block Public Access at account level",
                    "Audit who accessed the bucket while public",
                ],
            ),
            DetectionRule(
                rule_id="aws-exfil-002",
                name="EBS Snapshot Shared Externally",
                description="An EBS snapshot was shared with another AWS account. Could be data exfiltration.",
                severity=DetectionSeverity.HIGH.value,
                category=DetectionCategory.EXFILTRATION.value,
                tactics=[DetectionTactic.EXFILTRATION.value],
                techniques=["T1537", "T1005"],
                event_name="ModifySnapshotAttribute",
                field_matchers={
                    "request_parameters.attributeType": ["restore"],
                },
                references=["https://attack.mitre.org/techniques/T1537/"],
                tags=["aws", "ebs", "snapshot", "exfiltration"],
                recommended_actions=[
                    "Verify the destination account is trusted",
                    "If unauthorized: revoke snapshot sharing immediately",
                    "Audit snapshot access",
                ],
            ),

            # ─── Initial Access ───
            DetectionRule(
                rule_id="aws-init-001",
                name="EC2 Instance Launched in Unusual Region",
                description="EC2 instance launched in a region not typically used. Could indicate cryptomining.",
                severity=DetectionSeverity.MEDIUM.value,
                category=DetectionCategory.INITIAL_ACCESS.value,
                tactics=[DetectionTactic.INITIAL_ACCESS.value, DetectionTactic.RESOURCE_HIJACKING.value if False else DetectionTactic.IMPACT.value],
                techniques=["T1530"],
                event_name="RunInstances",
                field_matchers={},
                references=["https://attack.mitre.org/techniques/T1530/"],
                tags=["aws", "ec2", "unusual_region"],
                recommended_actions=[
                    "Verify the instance launch was authorized",
                    "Check instance type — crypto miners prefer GPU instances",
                    "Set up billing alarms",
                ],
            ),

            # ─── Resource Hijacking ───
            DetectionRule(
                rule_id="aws-hijack-001",
                name="Cryptomining GPU Instance Launched",
                description="EC2 instance with GPU type (p3, p4, g4) launched. Could indicate cryptomining.",
                severity=DetectionSeverity.HIGH.value,
                category=DetectionCategory.RESOURCE_HIJACKING.value if False else DetectionCategory.EXFILTRATION.value,
                tactics=[DetectionTactic.IMPACT.value],
                techniques=["T1496"],
                event_name="RunInstances",
                field_matchers={
                    "request_parameters.instanceType": ["p3\\..*", "p4\\..*", "g4\\..*"],
                },
                references=["https://attack.mitre.org/techniques/T1496/"],
                tags=["aws", "ec2", "cryptomining", "gpu"],
                recommended_actions=[
                    "Verify the instance launch was authorized",
                    "If unauthorized: terminate immediately",
                    "Review IAM credentials used",
                ],
            ),

            # ─── Discovery ───
            DetectionRule(
                rule_id="aws-disc-001",
                name="Mass IAM Enumeration",
                description="20+ IAM API calls in 5 minutes from same IP. Could indicate reconnaissance.",
                severity=DetectionSeverity.MEDIUM.value,
                category=DetectionCategory.DISCOVERY.value,
                tactics=[DetectionTactic.DISCOVERY.value],
                techniques=["T1087.004"],
                event_source="iam.amazonaws.com",
                field_matchers={
                    "event_name": ["ListUsers", "ListRoles", "ListPolicies", "ListGroups",
                                  "GetRole", "GetUser", "GetPolicy", "ListAccessKeys"],
                },
                aggregation={"field": "source_ip", "threshold": 20, "window_seconds": 300},
                references=["https://attack.mitre.org/techniques/T1087/004/"],
                tags=["aws", "iam", "discovery", "enumeration"],
                recommended_actions=[
                    "Verify the enumeration was authorized (e.g., security audit)",
                    "If unauthorized: block the source IP",
                    "Review what was accessed",
                ],
            ),
        ]


# ═══════════════════════════════════════════════════════════════
# Rule Evaluator
# ═══════════════════════════════════════════════════════════════

class RuleEvaluator:
    """Evaluates CloudTrail events against detection rules.

    Supports:
      - Exact field match (event_name, event_source)
      - Regex field match (any field in the event)
      - AND/OR condition across matchers
      - Aggregation (count threshold within time window)
      - Impossible travel detection (geolocation-based)
    """

    @classmethod
    def evaluate(cls, event: CloudTrailEvent, rule: DetectionRule) -> bool:
        """Check if an event matches a rule."""
        if not rule.enabled:
            return False

        # Event name match
        if rule.event_name and event.event_name != rule.event_name:
            return False

        # Event source match
        if rule.event_source and event.event_source != rule.event_source:
            return False

        # Field matchers
        if rule.field_matchers:
            match_results: list[bool] = []
            for field_path, patterns in rule.field_matchers.items():
                value = cls._extract_field(event, field_path)
                if value is None:
                    match_results.append(False)
                    continue
                # Match against any pattern
                matched = any(cls._match_pattern(value, p) for p in patterns)
                match_results.append(matched)

            if rule.condition == "and":
                if not all(match_results):
                    return False
            else:  # or
                if not any(match_results):
                    return False

        return True

    @classmethod
    def _extract_field(cls, event: CloudTrailEvent, field_path: str) -> Any:
        """Extract a nested field from the event using dot notation.

        Examples:
          "user_identity.type" → event.user_identity["type"]
          "request_parameters.policyArn" → event.request_parameters["policyArn"]
          "error_code" → event.error_code
          "event_name" → event.event_name
        """
        parts = field_path.split(".")
        current: Any = None
        # First part is a top-level attribute of CloudTrailEvent
        if hasattr(event, parts[0]):
            current = getattr(event, parts[0])
        elif parts[0] == "event_name":
            current = event.event_name
        else:
            return None

        for part in parts[1:]:
            if isinstance(current, dict):
                current = current.get(part)
            else:
                return None
            if current is None:
                return None
        return current

    @classmethod
    def _match_pattern(cls, value: Any, pattern: str) -> bool:
        """Match a value against a pattern (regex or exact)."""
        if value is None:
            return False
        value_str = str(value)
        # If pattern looks like regex (contains \, ., *, etc.), use regex
        if any(c in pattern for c in "\\.[]*+?{}()|^$"):
            try:
                return bool(re.search(pattern, value_str, re.IGNORECASE))
            except re.error:
                return value_str == pattern
        return value_str.lower() == pattern.lower()


# ═══════════════════════════════════════════════════════════════
# Event Aggregator (for windowed/behavioral detections)
# ═══════════════════════════════════════════════════════════════

class EventAggregator:
    """Tracks event counts per (rule_id, aggregation_field) within time windows.

    Used for behavioral detections like:
      - "5 failed logins in 5 minutes"
      - "20 IAM enumeration calls in 5 minutes"
    """

    def __init__(self):
        # (rule_id, field_value) → deque of timestamps
        self._windows: dict[tuple[str, str], deque] = defaultdict(deque)
        self._lock = threading.Lock()

    def record_and_check(self, rule: DetectionRule, event: CloudTrailEvent) -> tuple[bool, list[int]]:
        """Record an event and check if the aggregation threshold is exceeded.

        Returns:
            (threshold_exceeded, list_of_matching_event_timestamps)
        """
        if not rule.aggregation:
            return True, [event.event_time_ms]

        agg = rule.aggregation
        agg_type = agg.get("type", "count")

        if agg_type == "impossible_travel":
            return self._check_impossible_travel(rule, event)

        # Count-based aggregation
        field = agg.get("field", "source_ip")
        threshold = agg.get("threshold", 5)
        window_seconds = agg.get("window_seconds", 300)

        field_value = str(RuleEvaluator._extract_field(event, field) or "")
        if not field_value:
            return True, [event.event_time_ms]

        key = (rule.rule_id, field_value)
        now_ms = event.event_time_ms
        window_ms = window_seconds * 1000

        with self._lock:
            window = self._windows[key]
            # Purge old entries
            while window and window[0] < now_ms - window_ms:
                window.popleft()
            # Add current
            window.append(now_ms)

            if len(window) >= threshold:
                # Threshold exceeded — return all timestamps in window
                timestamps = list(window)
                # Clear window to avoid repeated triggering
                window.clear()
                return True, timestamps

        return False, []

    def _check_impossible_travel(self, rule: DetectionRule, event: CloudTrailEvent) -> tuple[bool, list[int]]:
        """Detect impossible travel based on IP geolocation.

        Simplified: in production, use MaxMind GeoIP database for accurate
        geolocation. Here we use a placeholder that always returns False
        unless the same user logs in from 2 different IPs within 60 minutes.
        """
        # This is a placeholder — real implementation requires GeoIP lookup
        # For demo: trigger if user has 2 logins from different IPs in 60 min
        user_arn = event.user_identity.get("arn", "")
        if not user_arn:
            return False, []
        key = (rule.rule_id, f"user:{user_arn}")
        now_ms = event.event_time_ms
        window_ms = 60 * 60 * 1000  # 60 min

        with self._lock:
            window = self._windows[key]
            window.append((now_ms, event.source_ip))
            while window and window[0][0] < now_ms - window_ms:
                window.popleft()

            # Check for different IPs
            unique_ips = {entry[1] for entry in window}
            if len(unique_ips) >= 2:
                timestamps = [entry[0] for entry in window]
                window.clear()
                return True, timestamps

        return False, []


# ═══════════════════════════════════════════════════════════════
# Real-time Detection Engine
# ═══════════════════════════════════════════════════════════════

class RealtimeDetectionEngine:
    """Real-time CloudTrail event detection engine.

    Workflow:
      1. ingest_event(event) — called by CloudTrail subscription
      2. For each rule, evaluate(event, rule)
      3. If match: check aggregation (if applicable)
      4. If threshold exceeded: create Detection, publish event, notify

    Throughput:
      - Single-threaded: ~10K events/sec
      - Multi-threaded (4 workers): ~40K events/sec
      - Production: use Kafka consumer + parallel workers for 100K+ events/sec
    """

    def __init__(self):
        self._rules: list[DetectionRule] = BuiltinDetectionRules.get_all_rules()
        self._aggregator = EventAggregator()
        self._detections: list[Detection] = []
        self._lock = threading.RLock()
        self._stats = {
            "events_processed": 0,
            "events_matched": 0,
            "detections_triggered": 0,
            "by_severity": defaultdict(int),
            "by_category": defaultdict(int),
            "by_rule": defaultdict(int),
            "processing_latency_ms_avg": 0,
        }
        # Subscriber callbacks for detections (for real-time alerting)
        self._subscribers: list[callable] = []

    def add_rule(self, rule: DetectionRule) -> None:
        with self._lock:
            self._rules.append(rule)

    def list_rules(self) -> list[dict[str, Any]]:
        return [
            {
                "rule_id": r.rule_id,
                "name": r.name,
                "description": r.description,
                "severity": r.severity,
                "category": r.category,
                "tactics": r.tactics,
                "techniques": r.techniques,
                "event_name": r.event_name,
                "aggregation": r.aggregation,
                "enabled": r.enabled,
            }
            for r in self._rules
        ]

    def subscribe(self, callback: callable) -> None:
        """Subscribe to detection events. Callback receives Detection object."""
        self._subscribers.append(callback)

    def ingest_event(self, event: CloudTrailEvent, tenant_id: str = "") -> list[Detection]:
        """Process a single CloudTrail event. Returns any detections triggered."""
        start_time = time.time()
        detections: list[Detection] = []

        with self._lock:
            rules = list(self._rules)

        for rule in rules:
            if not rule.enabled:
                continue
            if not RuleEvaluator.evaluate(event, rule):
                continue

            # Check aggregation threshold
            threshold_exceeded, matching_timestamps = self._aggregator.record_and_check(rule, event)
            if not threshold_exceeded:
                continue

            # Create detection
            detection = self._create_detection(rule, event, matching_timestamps, tenant_id)
            detections.append(detection)

            with self._lock:
                self._detections.append(detection)
                self._stats["detections_triggered"] += 1
                self._stats["by_severity"][detection.severity] += 1
                self._stats["by_category"][detection.category] += 1
                self._stats["by_rule"][rule.rule_id] += 1

            # Notify subscribers
            for callback in self._subscribers:
                try:
                    callback(detection)
                except Exception as e:
                    logger.error(f"Detection subscriber callback failed: {e}")

        # Update stats
        elapsed_ms = (time.time() - start_time) * 1000
        with self._lock:
            self._stats["events_processed"] += 1
            if detections:
                self._stats["events_matched"] += 1
            prev_avg = self._stats["processing_latency_ms_avg"]
            count = self._stats["events_processed"]
            self._stats["processing_latency_ms_avg"] = (
                (prev_avg * (count - 1) + elapsed_ms) / count
            )

        return detections

    def ingest_events(self, events: list[CloudTrailEvent], tenant_id: str = "") -> list[Detection]:
        """Process multiple events. Returns all detections triggered."""
        all_detections = []
        for event in events:
            detections = self.ingest_event(event, tenant_id)
            all_detections.extend(detections)
        return all_detections

    def _create_detection(
        self,
        rule: DetectionRule,
        event: CloudTrailEvent,
        matching_timestamps: list[int],
        tenant_id: str,
    ) -> Detection:
        return Detection(
            detection_id=str(uuid.uuid4()),
            rule_id=rule.rule_id,
            rule_name=rule.name,
            severity=rule.severity,
            category=rule.category,
            tactics=rule.tactics,
            techniques=rule.techniques,
            description=rule.description,
            triggering_events=[
                {
                    "event_id": event.event_id,
                    "event_name": event.event_name,
                    "event_source": event.event_source,
                    "event_time": event.event_time,
                    "source_ip": event.source_ip,
                    "user_identity": event.user_identity,
                    "aws_region": event.aws_region,
                    "request_parameters": event.request_parameters,
                    "error_code": event.error_code,
                    "matching_timestamps": matching_timestamps,
                }
            ],
            user_identity=event.user_identity,
            source_ip=event.source_ip,
            aws_region=event.aws_region,
            affected_resources=event.resources,
            mitre_tactics=rule.tactics,
            mitre_techniques=rule.techniques,
            recommended_actions=rule.recommended_actions,
            detected_at=int(time.time() * 1000),
            tenant_id=tenant_id,
            confidence=1.0 - rule.false_positive_rate,
        )

    def list_detections(
        self,
        tenant_id: Optional[str] = None,
        severity: Optional[str] = None,
        category: Optional[str] = None,
        limit: int = 100,
    ) -> list[Detection]:
        with self._lock:
            detections = list(self._detections)
        if tenant_id:
            detections = [d for d in detections if d.tenant_id == tenant_id]
        if severity:
            detections = [d for d in detections if d.severity == severity]
        if category:
            detections = [d for d in detections if d.category == category]
        return detections[-limit:]

    def get_detection(self, detection_id: str) -> Optional[Detection]:
        with self._lock:
            for d in self._detections:
                if d.detection_id == detection_id:
                    return d
        return None

    def get_stats(self) -> dict[str, Any]:
        with self._lock:
            return {
                "events_processed": self._stats["events_processed"],
                "events_matched": self._stats["events_matched"],
                "detections_triggered": self._stats["detections_triggered"],
                "by_severity": dict(self._stats["by_severity"]),
                "by_category": dict(self._stats["by_category"]),
                "top_rules": sorted(
                    self._stats["by_rule"].items(), key=lambda x: -x[1]
                )[:10],
                "processing_latency_ms_avg": round(self._stats["processing_latency_ms_avg"], 3),
                "active_rules": sum(1 for r in self._rules if r.enabled),
            }


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_engine: Optional[RealtimeDetectionEngine] = None
_global_lock = threading.Lock()


def get_realtime_engine() -> RealtimeDetectionEngine:
    global _global_engine
    if _global_engine is None:
        with _global_lock:
            if _global_engine is None:
                _global_engine = RealtimeDetectionEngine()
    return _global_engine
