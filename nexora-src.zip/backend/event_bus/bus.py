"""
Enterprise Event Bus — Event-Driven Architecture with Outbox Pattern + Saga Orchestrator.

Based on Part 7 — DDD Bounded Contexts (Event-Driven Architecture) and
Part 8 — Outbox Pattern for reliable event delivery.

Design Goals:
  - Decoupled communication between bounded contexts (Scanner, Rule, Risk, etc.)
  - At-least-once delivery with idempotent consumers
  - Outbox pattern: events are persisted in same DB transaction as state change
  - Saga pattern: long-running distributed transactions with compensating actions
  - Multiple subscribers per event (1-to-N fan-out)
  - Backpressure handling (in-memory queue with bounded size)

Architecture:
  Event Producer (e.g., Scanner) ─┐
                                  ├─> EventBus ─> Outbox (DB) ─> Poller ─> Subscriber A (e.g., Notification)
  Event Producer (e.g., Rule)   ─┘                                  ─> Subscriber B (e.g., Risk Engine)
                                                                    ─> Subscriber C (e.g., Audit Log)

Event Types (from Part 7 bounded contexts):
  - scan.started, scan.completed, scan.failed, scan.cancelled
  - finding.created, finding.updated, finding.suppressed, finding.resolved
  - rule.executed, rule.failed
  - risk.scored, risk.threshold_exceeded
  - credential.added, credential.rotated, credential.revoked
  - remediation.suggested, remediation.approved, remediation.applied, remediation.failed
  - user.created, user.invited, user.disabled, user.role_changed
  - alert.triggered, alert.acknowledged, alert.resolved
  - compliance.assessed, compliance.drift_detected
"""
from __future__ import annotations

import json
import logging
import threading
import time
import traceback
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Event Domain Model
# ═══════════════════════════════════════════════════════════════

class EventStatus(str, Enum):
    PENDING = "pending"        # in outbox, waiting for poller
    DELIVERED = "delivered"    # all subscribers acknowledged
    FAILED = "failed"          # delivery failed after retries
    DEAD_LETTER = "dead_letter"  # moved to DLQ after max retries


@dataclass
class Event:
    """A single domain event.

    Events are immutable records of something that happened in the system.
    They carry enough context for subscribers to act without re-querying.
    """
    event_id: str
    event_type: str            # e.g., "scan.completed"
    tenant_id: str             # always present for multi-tenant isolation
    aggregate_type: str        # "scan", "finding", "rule", "credential", etc.
    aggregate_id: str          # ID of the entity that emitted the event
    payload: dict[str, Any]    # event-specific data
    metadata: dict[str, Any] = field(default_factory=dict)
    timestamp: int = 0         # epoch ms
    version: int = 1           # event schema version
    correlation_id: Optional[str] = None  # for tracing
    causation_id: Optional[str] = None    # event that caused this one

    # Outbox fields
    status: str = EventStatus.PENDING.value
    retry_count: int = 0
    next_retry_at: Optional[int] = None
    last_error: Optional[str] = None

    # Delivery tracking
    subscriber_acks: dict[str, int] = field(default_factory=dict)  # subscriber -> timestamp

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = int(time.time() * 1000)
        if not self.event_id:
            self.event_id = str(uuid.uuid4())
        if not self.correlation_id:
            self.correlation_id = str(uuid.uuid4())


@dataclass
class OutboxEntry:
    """Persistent record of an event for the Outbox pattern.

    Stored in the same DB transaction as the state change that produced
    the event. A poller reads these and delivers to subscribers.
    """
    event_id: str
    event_type: str
    tenant_id: str
    payload_json: str
    status: str
    created_at: int
    processed_at: Optional[int] = None
    retry_count: int = 0
    last_error: Optional[str] = None


# ═══════════════════════════════════════════════════════════════
# Event Bus
# ═══════════════════════════════════════════════════════════════

EventHandler = Callable[[Event], None]


class EventBus:
    """In-memory event bus with Outbox pattern support.

    For production, swap InMemoryOutbox with PostgresOutbox to get
    transactional consistency with the application database.

    Features:
      - Pub/Sub with topic-based routing (event_type is the topic)
      - Wildcard subscription: "*" matches all events
      - Synchronous or asynchronous dispatch
      - At-least-once delivery (subscribers must be idempotent)
      - Retry with exponential backoff
      - Dead letter queue for poison messages
    """

    def __init__(self, outbox: Optional["Outbox"] = None, max_retries: int = 5):
        self._subscribers: dict[str, list[tuple[str, EventHandler]]] = defaultdict(list)
        self._outbox = outbox or InMemoryOutbox()
        self._max_retries = max_retries
        self._lock = threading.RLock()
        self._dead_letter_queue: list[Event] = []
        self._poller_thread: Optional[threading.Thread] = None
        self._poller_stop = threading.Event()
        self._stats = {
            "events_published": 0,
            "events_delivered": 0,
            "events_failed": 0,
            "events_dlq": 0,
        }

    def subscribe(self, event_type: str, handler: EventHandler, subscriber_id: Optional[str] = None) -> str:
        """Subscribe to events of a specific type (or "*" for all).

        Args:
            event_type: Event type pattern ("scan.completed" or "*")
            handler: Callable that processes the event
            subscriber_id: Optional ID for tracking; auto-generated if None

        Returns:
            subscriber_id (use for unsubscribe)
        """
        subscriber_id = subscriber_id or f"sub-{uuid.uuid4().hex[:8]}"
        with self._lock:
            self._subscribers[event_type].append((subscriber_id, handler))
        logger.debug(f"Subscriber {subscriber_id} subscribed to {event_type}")
        return subscriber_id

    def unsubscribe(self, subscriber_id: str) -> bool:
        """Remove a subscriber."""
        with self._lock:
            for event_type, subs in self._subscribers.items():
                for i, (sid, _) in enumerate(subs):
                    if sid == subscriber_id:
                        subs.pop(i)
                        return True
        return False

    def publish(self, event: Event) -> str:
        """Publish an event.

        The event is:
        1. Persisted to the outbox (guaranteed durability)
        2. Immediately dispatched to subscribers (low latency)

        If a subscriber is slow or fails, the outbox retries per the
        retry policy. Subscribers MUST be idempotent because the same
        event may be delivered more than once.
        """
        with self._lock:
            self._outbox.append(event)
            self._stats["events_published"] += 1
        # Immediate dispatch (outbox is backup)
        self._dispatch(event)
        return event.event_id

    def publish_simple(
        self,
        event_type: str,
        tenant_id: str,
        aggregate_type: str,
        aggregate_id: str,
        payload: Optional[dict[str, Any]] = None,
        correlation_id: Optional[str] = None,
    ) -> str:
        """Convenience method to publish an event."""
        event = Event(
            event_id=str(uuid.uuid4()),
            event_type=event_type,
            tenant_id=tenant_id,
            aggregate_type=aggregate_type,
            aggregate_id=aggregate_id,
            payload=payload or {},
            correlation_id=correlation_id,
        )
        return self.publish(event)

    def _dispatch(self, event: Event) -> None:
        """Dispatch an event to all matching subscribers."""
        with self._lock:
            # Match exact type and wildcard
            handlers = list(self._subscribers.get(event.event_type, []))
            handlers.extend(self._subscribers.get("*", []))

        if not handlers:
            return

        for subscriber_id, handler in handlers:
            try:
                handler(event)
                with self._lock:
                    event.subscriber_acks[subscriber_id] = int(time.time() * 1000)
                    self._stats["events_delivered"] += 1
            except Exception as e:
                error_msg = f"{type(e).__name__}: {str(e)}\n{traceback.format_exc()}"
                logger.error(f"Subscriber {subscriber_id} failed on event {event.event_id}: {e}")
                with self._lock:
                    event.retry_count += 1
                    event.last_error = error_msg[:2000]
                    self._stats["events_failed"] += 1

                    if event.retry_count >= self._max_retries:
                        self._dead_letter_queue.append(event)
                        self._stats["events_dlq"] += 1
                        logger.error(f"Event {event.event_id} moved to DLQ after {event.retry_count} retries")
                    else:
                        # Schedule retry with exponential backoff
                        backoff = min(2 ** event.retry_count, 60)
                        event.next_retry_at = int(time.time() * 1000) + backoff * 1000

    def start_poller(self, interval_ms: int = 1000) -> None:
        """Start a background thread to retry failed events from the outbox.

        In production with PostgresOutbox, this also picks up events that
        were committed but not yet dispatched (e.g., crash between commit
        and dispatch).
        """
        if self._poller_thread and self._poller_thread.is_alive():
            return

        def _poll():
            while not self._poller_stop.is_set():
                try:
                    pending = self._outbox.get_pending(limit=100)
                    for entry in pending:
                        event = self._outbox.entry_to_event(entry)
                        self._dispatch(event)
                except Exception as e:
                    logger.error(f"Outbox poller error: {e}")
                self._poller_stop.wait(interval_ms / 1000.0)

        self._poller_thread = threading.Thread(target=_poll, daemon=True, name="event-poller")
        self._poller_thread.start()

    def stop_poller(self) -> None:
        self._poller_stop.set()
        if self._poller_thread:
            self._poller_thread.join(timeout=5)

    def get_stats(self) -> dict[str, Any]:
        return {
            **self._stats,
            "outbox_size": len(self._outbox),
            "dlq_size": len(self._dead_letter_queue),
            "subscriber_count": sum(len(subs) for subs in self._subscribers.values()),
        }

    def get_dlq(self, limit: int = 100) -> list[Event]:
        return list(self._dead_letter_queue[-limit:])


# ═══════════════════════════════════════════════════════════════
# Outbox Backends
# ═══════════════════════════════════════════════════════════════

class Outbox:
    """Abstract outbox backend."""

    def append(self, event: Event) -> None:
        raise NotImplementedError

    def get_pending(self, limit: int = 100) -> list[OutboxEntry]:
        raise NotImplementedError

    def mark_delivered(self, event_id: str) -> None:
        raise NotImplementedError

    def entry_to_event(self, entry: OutboxEntry) -> Event:
        raise NotImplementedError

    def __len__(self) -> int:
        raise NotImplementedError


class InMemoryOutbox(Outbox):
    """In-memory outbox for dev/testing."""

    def __init__(self):
        self._entries: list[OutboxEntry] = []
        self._events: dict[str, Event] = {}
        self._lock = threading.Lock()

    def append(self, event: Event) -> None:
        with self._lock:
            entry = OutboxEntry(
                event_id=event.event_id,
                event_type=event.event_type,
                tenant_id=event.tenant_id,
                payload_json=json.dumps(event.payload, default=str),
                status=event.status,
                created_at=event.timestamp,
                retry_count=event.retry_count,
                last_error=event.last_error,
            )
            self._entries.append(entry)
            self._events[event.event_id] = event

    def get_pending(self, limit: int = 100) -> list[OutboxEntry]:
        with self._lock:
            now = int(time.time() * 1000)
            pending = [
                e for e in self._entries
                if e.status == EventStatus.PENDING.value
                or (e.retry_count > 0 and e.processed_at is None)
            ]
            return pending[:limit]

    def mark_delivered(self, event_id: str) -> None:
        with self._lock:
            for entry in self._entries:
                if entry.event_id == event_id:
                    entry.status = EventStatus.DELIVERED.value
                    entry.processed_at = int(time.time() * 1000)
                    break

    def entry_to_event(self, entry: OutboxEntry) -> Event:
        with self._lock:
            return self._events.get(entry.event_id, Event(
                event_id=entry.event_id,
                event_type=entry.event_type,
                tenant_id=entry.tenant_id,
                aggregate_type="unknown",
                aggregate_id="unknown",
                payload=json.loads(entry.payload_json),
            ))

    def __len__(self) -> int:
        return len(self._entries)


# ═══════════════════════════════════════════════════════════════
# Saga Orchestrator
# ═══════════════════════════════════════════════════════════════

class SagaState(str, Enum):
    RUNNING = "running"
    COMPLETED = "completed"
    COMPENSATING = "compensating"  # rolling back
    FAILED = "failed"
    TIMED_OUT = "timed_out"


@dataclass
class SagaStep:
    """A single step in a saga.

    Each step has:
      - execute: action to perform (forward direction)
      - compensate: action to undo if a later step fails
    """
    name: str
    execute: Callable[[dict[str, Any]], dict[str, Any]]
    compensate: Optional[Callable[[dict[str, Any]], None]] = None
    timeout_ms: int = 30000     # 30s default
    retries: int = 3


@dataclass
class SagaExecution:
    saga_id: str
    saga_type: str
    tenant_id: str
    state: str = SagaState.RUNNING.value
    current_step: int = 0
    completed_steps: list[str] = field(default_factory=list)
    context: dict[str, Any] = field(default_factory=dict)
    started_at: int = 0
    completed_at: Optional[int] = None
    last_error: Optional[str] = None


class SagaOrchestrator:
    """Orchestrates long-running distributed transactions.

    Saga Pattern: a sequence of local transactions where each step has
    a compensating action. If any step fails, all previous steps are
    rolled back via their compensate() functions.

    Use cases:
      - Onboarding a new cloud account (validate creds → start scan → create findings → notify)
      - Remediation workflow (suggest → approve → apply → verify → notify)
      - User invitation (create user → assign role → send invite → audit)

    Guarantees:
      - Either all steps succeed, or all are compensated
      - State is persisted, so a crashed saga can resume
      - Timeouts prevent infinite hangs
    """

    def __init__(self, event_bus: EventBus):
        self._event_bus = event_bus
        self._sagas: dict[str, SagaExecution] = {}
        self._definitions: dict[str, list[SagaStep]] = {}
        self._lock = threading.RLock()

    def register_saga(self, saga_type: str, steps: list[SagaStep]) -> None:
        """Register a saga definition."""
        self._definitions[saga_type] = steps

    def execute(self, saga_type: str, tenant_id: str, initial_context: Optional[dict] = None) -> SagaExecution:
        """Execute a saga to completion (or compensation)."""
        if saga_type not in self._definitions:
            raise ValueError(f"Unknown saga type: {saga_type}")

        steps = self._definitions[saga_type]
        execution = SagaExecution(
            saga_id=str(uuid.uuid4()),
            saga_type=saga_type,
            tenant_id=tenant_id,
            context=initial_context or {},
            started_at=int(time.time() * 1000),
        )

        with self._lock:
            self._sagas[execution.saga_id] = execution

        # Publish saga started event
        self._event_bus.publish_simple(
            "saga.started", tenant_id, "saga", execution.saga_id,
            {"saga_type": saga_type, "step_count": len(steps)},
        )

        try:
            for i, step in enumerate(steps):
                execution.current_step = i
                self._execute_step(execution, step)
                execution.completed_steps.append(step.name)

                # Publish step completed
                self._event_bus.publish_simple(
                    f"saga.step_completed", tenant_id, "saga", execution.saga_id,
                    {"step": step.name, "step_index": i},
                )

            execution.state = SagaState.COMPLETED.value
            execution.completed_at = int(time.time() * 1000)
            self._event_bus.publish_simple(
                "saga.completed", tenant_id, "saga", execution.saga_id,
                {"saga_type": saga_type, "duration_ms": execution.completed_at - execution.started_at},
            )

        except Exception as e:
            execution.last_error = f"{type(e).__name__}: {str(e)}"
            execution.state = SagaState.COMPENSATING.value
            logger.error(f"Saga {execution.saga_id} failed at step {execution.current_step}, compensating...")

            # Compensate in reverse order
            for step_name in reversed(execution.completed_steps):
                step = next((s for s in steps if s.name == step_name), None)
                if step and step.compensate:
                    try:
                        step.compensate(execution.context)
                        logger.info(f"Compensated step: {step_name}")
                    except Exception as ce:
                        logger.error(f"Compensation failed for step {step_name}: {ce}")

            execution.state = SagaState.FAILED.value
            execution.completed_at = int(time.time() * 1000)
            self._event_bus.publish_simple(
                "saga.failed", tenant_id, "saga", execution.saga_id,
                {"error": execution.last_error, "saga_type": saga_type},
            )

        return execution

    def _execute_step(self, execution: SagaExecution, step: SagaStep) -> None:
        """Execute a single saga step with retries."""
        last_error = None
        for attempt in range(step.retries + 1):
            try:
                result = step.execute(execution.context)
                if result:
                    execution.context.update(result)
                return
            except Exception as e:
                last_error = e
                logger.warning(f"Saga step {step.name} attempt {attempt+1} failed: {e}")
                if attempt < step.retries:
                    time.sleep(2 ** attempt)  # exponential backoff
        raise last_error

    def get_saga(self, saga_id: str) -> Optional[SagaExecution]:
        return self._sagas.get(saga_id)


# ═══════════════════════════════════════════════════════════════
# Event Type Constants
# ═══════════════════════════════════════════════════════════════

class EventTypes:
    """Canonical event type constants.

    Using constants prevents typos and makes refactoring safer.
    """

    # Scan lifecycle
    SCAN_QUEUED = "scan.queued"
    SCAN_STARTED = "scan.started"
    SCAN_COMPLETED = "scan.completed"
    SCAN_FAILED = "scan.failed"
    SCAN_CANCELLED = "scan.cancelled"
    SCAN_PROGRESS = "scan.progress"

    # Findings
    FINDING_CREATED = "finding.created"
    FINDING_UPDATED = "finding.updated"
    FINDING_SUPPRESSED = "finding.suppressed"
    FINDING_RESOLVED = "finding.resolved"
    FINDING_REOPENED = "finding.reopened"

    # Rules
    RULE_EXECUTED = "rule.executed"
    RULE_FAILED = "rule.failed"
    RULE_CREATED = "rule.created"
    RULE_UPDATED = "rule.updated"

    # Risk
    RISK_SCORED = "risk.scored"
    RISK_THRESHOLD_EXCEEDED = "risk.threshold_exceeded"

    # Credentials
    CREDENTIAL_ADDED = "credential.added"
    CREDENTIAL_ROTATED = "credential.rotated"
    CREDENTIAL_REVOKED = "credential.revoked"
    CREDENTIAL_VALIDATED = "credential.validated"

    # Remediation
    REMEDIATION_SUGGESTED = "remediation.suggested"
    REMEDIATION_APPROVED = "remediation.approved"
    REMEDIATION_REJECTED = "remediation.rejected"
    REMEDIATION_APPLIED = "remediation.applied"
    REMEDIATION_FAILED = "remediation.failed"
    REMEDIATION_ROLLED_BACK = "remediation.rolled_back"

    # Users
    USER_CREATED = "user.created"
    USER_INVITED = "user.invited"
    USER_LOGGED_IN = "user.logged_in"
    USER_LOGGED_OUT = "user.logged_out"
    USER_DISABLED = "user.disabled"
    USER_ROLE_CHANGED = "user.role_changed"

    # Alerts
    ALERT_TRIGGERED = "alert.triggered"
    ALERT_ACKNOWLEDGED = "alert.acknowledged"
    ALERT_RESOLVED = "alert.resolved"

    # Compliance
    COMPLIANCE_ASSESSED = "compliance.assessed"
    COMPLIANCE_DRIFT_DETECTED = "compliance.drift_detected"

    # Cloud Accounts
    CLOUD_ACCOUNT_ADDED = "cloud_account.added"
    CLOUD_ACCOUNT_REMOVED = "cloud_account.removed"
    CLOUD_ACCOUNT_VALIDATED = "cloud_account.validated"

    # System
    SYSTEM_HEALTH = "system.health"
    SYSTEM_ERROR = "system.error"


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_bus: Optional[EventBus] = None
_global_lock = threading.Lock()


def get_event_bus() -> EventBus:
    """Get the global event bus instance."""
    global _global_bus
    if _global_bus is None:
        with _global_lock:
            if _global_bus is None:
                _global_bus = EventBus()
                _global_bus.start_poller()
    return _global_bus
