"""
Enterprise Threat Intelligence Engine — IOC feeds, reputation, TTPs.

Based on Part 5 — Threat Intelligence and MITRE ATT&CK framework,
plus STIX/TAXII specification for threat intel sharing.

Scientific Foundation:
  - STIX 2.1 (Structured Threat Information Expression): OASIS standard
    for representing cyber threat information in a structured, machine-
    readable format. https://docs.oasis-open.org/cti/stix/v2.1/stix-v2.1.html
  - TAXII 2.1 (Trusted Automated Exchange of Intelligence Information):
    transport mechanism for STIX objects over HTTPS
  - MITRE ATT&CK: knowledge base of adversary tactics and techniques
    based on real-world observations. Each technique has an ID (TXXXX)
    and is grouped under tactics (initial access, persistence, etc.)
  - IOC (Indicator of Compromise): observable artifact (IP, domain, hash,
    URL) that indicates a potential intrusion
  - Diamond Model: intrusion analysis framework linking adversary,
    infrastructure, capability, and victim

Capabilities:
  1. IOC Ingestion: subscribe to STIX/TAXII feeds, parse CSV/JSON
     - Sample feeds: AlienVault OTX, Abuse.ch, MISP, VirusTotal
     - Deduplication via content hash
     - TTL-based expiry (most IOCs have 7-30 day useful life)
  2. Reputation Scoring: 0-100 score per IOC
     - 0-30: clean
     - 31-60: suspicious
     - 61-100: malicious
     - Combines: # of sources reporting, age of reports, severity
  3. IOC Matching: match observed artifacts against IOC database
     - IP/Domain matching with wildcard support
     - Hash matching (MD5, SHA1, SHA256)
     - URL matching with URL normalization
  4. Threat Actor Profiling: map IOCs to known threat actors
     - APT29, APT28, Lazarus, FIN7, etc.
     - TTP mapping to MITRE ATT&CK
  5. Alert Enrichment: when a security alert fires, enrich with
     threat intel (e.g., "this IP is associated with APT29")
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import logging
import re
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Threat Intel Domain Model
# ═══════════════════════════════════════════════════════════════

class IOCType(str, Enum):
    IPV4 = "ipv4"
    IPV6 = "ipv6"
    DOMAIN = "domain"
    URL = "url"
    FILE_HASH_MD5 = "file_hash_md5"
    FILE_HASH_SHA1 = "file_hash_sha1"
    FILE_HASH_SHA256 = "file_hash_sha256"
    EMAIL = "email"
    CIDR = "cidr"
    MUTEX = "mutex"
    REGISTRY_KEY = "registry_key"
    USER_AGENT = "user_agent"
    CERTIFICATE_FINGERPRINT = "certificate_fingerprint"


class IOCSeverity(str, Enum):
    CLEAN = "clean"
    SUSPICIOUS = "suspicious"
    MALICIOUS = "malicious"
    CRITICAL = "critical"  # actively exploited 0day


class ThreatActor(str, Enum):
    """Known threat actors (small subset)."""
    APT28 = "APT28"            # Fancy Bear (Russia)
    APT29 = "APT29"            # Cozy Bear (Russia)
    APT32 = "APT32"            # OceanLotus (Vietnam)
    APT33 = "APT33"            # Elfin (Iran)
    APT38 = "APT38"            # Lazarus (North Korea)
    APT41 = "APT41"            # Winnti (China)
    FIN7 = "FIN7"               # Carbanak (cybercrime)
    FIN8 = "FIN8"               # Syssphinx
    MUSTARD_TEMPEST = "Mustard Tempest"
    SANDWORM = "Sandworm"       # Russia military
    VOLT_TYPHOON = "Volt Typhoon"  # China critical infrastructure
    UNKNOWN = "UNKNOWN"


@dataclass
class IOC:
    """An Indicator of Compromise."""
    ioc_id: str
    ioc_type: str              # IOCType value
    value: str                 # the actual IOC value
    severity: str              # IOCSeverity value
    confidence: float          # 0.0-1.0
    reputation_score: int      # 0-100 (higher = more malicious)
    sources: list[str] = field(default_factory=list)  # feed names
    first_seen: int = 0
    last_seen: int = 0
    expires_at: Optional[int] = None  # TTL-based expiry
    threat_actors: list[str] = field(default_factory=list)  # ThreatActor values
    malware_families: list[str] = field(default_factory=list)
    mitre_attack_ids: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    description: str = ""
    country: Optional[str] = None  # for IPs: country of origin


@dataclass
class ThreatActorProfile:
    """Profile of a known threat actor."""
    actor_id: str              # ThreatActor value
    name: str
    aliases: list[str]
    country: str               # country of origin
    motivation: str            # "financial" | "espionage" | "destruction" | "hacktivism"
    target_industries: list[str]
    target_geographies: list[str]
    mitre_tactics: list[str]   # TA0001, TA0002, etc.
    mitre_techniques: list[str]  # T1059, T1105, etc.
    known_malware: list[str]
    description: str = ""


@dataclass
class ThreatIntelMatch:
    """Result of matching an artifact against the IOC database."""
    matched: bool
    ioc: Optional[IOC] = None
    query_value: str = ""
    query_type: str = ""
    threat_actors: list[str] = field(default_factory=list)
    malware_families: list[str] = field(default_factory=list)
    enrichment: dict[str, Any] = field(default_factory=dict)


@dataclass
class ThreatIntelAlert:
    """A threat intelligence alert (when an artifact matches a known IOC)."""
    alert_id: str
    tenant_id: str
    detected_at: int
    ioc_id: str
    ioc_type: str
    ioc_value: str
    severity: str
    confidence: float
    reputation_score: int
    threat_actors: list[str]
    malware_families: list[str]
    mitre_attack_ids: list[str]
    description: str
    source_artifact: str        # what was scanned (IP, file, etc.)
    source_context: str = ""    # where the artifact was observed
    enrichment: dict[str, Any] = field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════
# IOC Validators
# ═══════════════════════════════════════════════════════════════

class IOCValidators:
    """Validate and normalize IOC values."""

    IPV4_RE = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")
    IPV6_RE = re.compile(r"^([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}$")
    DOMAIN_RE = re.compile(
        r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$"
    )
    MD5_RE = re.compile(r"^[a-fA-F0-9]{32}$")
    SHA1_RE = re.compile(r"^[a-fA-F0-9]{40}$")
    SHA256_RE = re.compile(r"^[a-fA-F0-9]{64}$")

    @classmethod
    def detect_type(cls, value: str) -> Optional[IOCType]:
        """Auto-detect IOC type from value."""
        value = value.strip().lower()
        if cls.IPV4_RE.match(value):
            try:
                ipaddress.IPv4Address(value)
                return IOCType.IPV4
            except ValueError:
                pass
        if cls.IPV6_RE.match(value):
            try:
                ipaddress.IPv6Address(value)
                return IOCType.IPV6
            except ValueError:
                pass
        if "/" in value:
            try:
                ipaddress.ip_network(value, strict=False)
                return IOCType.CIDR
            except ValueError:
                pass
        if value.startswith(("http://", "https://")):
            return IOCType.URL
        if cls.MD5_RE.match(value):
            return IOCType.FILE_HASH_MD5
        if cls.SHA1_RE.match(value):
            return IOCType.FILE_HASH_SHA1
        if cls.SHA256_RE.match(value):
            return IOCType.FILE_HASH_SHA256
        if cls.DOMAIN_RE.match(value):
            return IOCType.DOMAIN
        if "@" in value and re.match(r"^[^@]+@[^@]+\.[^@]+$", value):
            return IOCType.EMAIL
        return None

    @classmethod
    def normalize(cls, value: str, ioc_type: IOCType) -> str:
        """Normalize an IOC value for consistent lookup."""
        value = value.strip().lower()
        if ioc_type == IOCType.URL:
            # Strip protocol and trailing slash
            parsed = urlparse(value)
            return f"{parsed.netloc}{parsed.path}".rstrip("/")
        if ioc_type in (IOCType.IPV4, IOCType.IPV6):
            try:
                return str(ipaddress.ip_address(value))
            except ValueError:
                return value
        if ioc_type in (IOCType.FILE_HASH_MD5, IOCType.FILE_HASH_SHA1, IOCType.FILE_HASH_SHA256):
            return value.lower()
        return value

    @classmethod
    def hash_to_type(cls, hash_value: str) -> Optional[IOCType]:
        """Detect hash type from length."""
        length = len(hash_value)
        if length == 32:
            return IOCType.FILE_HASH_MD5
        if length == 40:
            return IOCType.FILE_HASH_SHA1
        if length == 64:
            return IOCType.FILE_HASH_SHA256
        return None


# ═══════════════════════════════════════════════════════════════
# Threat Actor Database (built-in)
# ═══════════════════════════════════════════════════════════════

class ThreatActorDB:
    """Built-in threat actor profiles (MITRE ATT&CK aligned)."""

    PROFILES: list[ThreatActorProfile] = [
        ThreatActorProfile(
            actor_id=ThreatActor.APT28.value, name="APT28 (Fancy Bear)",
            aliases=["Fancy Bear", "Sofacy", "Strontium", "Sednit", "Pawn Storm"],
            country="Russia", motivation="espionage",
            target_industries=["government", "military", "defense", "media"],
            target_geographies=["NATO", "Eastern Europe", "Middle East"],
            mitre_tactics=["TA0001", "TA0002", "TA0006", "TA0007"],
            mitre_techniques=["T1566", "T1078", "T1059", "T1105", "T1213"],
            known_malware=["X-Agent", "Sofacy", "X-Tunnel", "Zebrocy"],
            description="Russian military intelligence (GRU) unit 26165. Targets government and military organizations. Known for DNC hack and Olympic Destroyer.",
        ),
        ThreatActorProfile(
            actor_id=ThreatActor.APT29.value, name="APT29 (Cozy Bear)",
            aliases=["Cozy Bear", "The Dukes", "Cloaked Ursa", "NOBELIUM", "Midnight Blizzard"],
            country="Russia", motivation="espionage",
            target_industries=["government", "think_tank", "healthcare", "technology"],
            target_geographies=["USA", "Europe", "NATO"],
            mitre_tactics=["TA0001", "TA0003", "TA0006", "TA0040"],
            mitre_techniques=["T1566", "T1078", "T1136", "T1098", "T1116"],
            known_malware=["WellMess", "WellMail", "EnvyScout", "NativeZone"],
            description="Russian SVR unit. Responsible for SolarWinds supply chain attack (2020). Sophisticated, patient, focused on long-term espionage.",
        ),
        ThreatActorProfile(
            actor_id=ThreatActor.APT38.value, name="APT38 (Lazarus)",
            aliases=["Lazarus", "Hidden Cobra", "Guardians of Peace", "Zinc"],
            country="North Korea", motivation="financial",
            target_industries=["banking", "cryptocurrency", "defense", "media"],
            target_geographies=["global"],
            mitre_tactics=["TA0001", "TA0006", "TA0040", "TA0047"],
            mitre_techniques=["T1566", "T1059", "T1027", "T1496", "T1486"],
            known_malware=["WannaCry", "Manuscrypt", "AppleJeus", "TraderTraitor"],
            description="North Korean state-sponsored group focused on financial gain to evade sanctions. Responsible for $620M Ronin bridge theft.",
        ),
        ThreatActorProfile(
            actor_id=ThreatActor.APT41.value, name="APT41 (Winnti)",
            aliases=["Winnti", "Barium", "Wicked Panda", "Double Dragon"],
            country="China", motivation="espionage+financial",
            target_industries=["gaming", "technology", "healthcare", "telecom"],
            target_geographies=["global", "Asia"],
            mitre_tactics=["TA0001", "TA0002", "TA0003", "TA0040"],
            mitre_techniques=["T1190", "T1059", "T1505", "T1105", "T1053"],
            known_malware=["Winnti", "ShadowPad", "PlugX", "Cobalt Strike"],
            description="Chinese state-sponsored group that conducts both espionage and financially-motivated attacks. Unique dual mission.",
        ),
        ThreatActorProfile(
            actor_id=ThreatActor.FIN7.value, name="FIN7 (Carbanak)",
            aliases=["Carbanak", "Anunak", "Navigator"],
            country="Russia/Ukraine", motivation="financial",
            target_industries=["hospitality", "retail", "restaurant", "financial"],
            target_geographies=["USA", "Europe"],
            mitre_tactics=["TA0001", "TA0006", "TA0040"],
            mitre_techniques=["T1566", "T1105", "T1059", "T1486"],
            known_malware=["Carbanak", "RigEK", "Ldr1", "JavaScript backdoors"],
            description="Cybercrime group (not state-sponsored) that has stolen $1B+ from financial institutions. Known for highly-targeted spear phishing.",
        ),
        ThreatActorProfile(
            actor_id=ThreatActor.SANDWORM.value, name="Sandworm",
            aliases=["Sandworm Team", "IRIDIUM", "Voodoo Bear", "Seashell Blizzard"],
            country="Russia", motivation="destruction+espionage",
            target_industries=["energy", "government", "infrastructure"],
            target_geographies=["Ukraine", "Europe", "USA"],
            mitre_tactics=["TA0001", "TA0040", "TA0043"],
            mitre_techniques=["T1190", "T1059", "T1486", "T1566", "T1210"],
            known_malware=["Industroyer", "NotPetya", "GreyEnergy", "BlackEnergy"],
            description="Russian GRU Unit 74455. Most destructive Russian APT. Responsible for Ukraine power grid attacks and NotPetya ($10B damage).",
        ),
        ThreatActorProfile(
            actor_id=ThreatActor.VOLT_TYPHOON.value, name="Volt Typhoon",
            aliases=["Vanguard Panda", "Insidious Taurus", "Bronze Silhouette"],
            country="China", motivation="espionage",
            target_industries=["critical_infrastructure", "energy", "water", "telecom"],
            target_geographies=["USA", "Guam"],
            mitre_tactics=["TA0001", "TA0003", "TA0005", "TA0008"],
            mitre_techniques=["T1078", "T1021", "T1098", "T1136", "T1573"],
            known_malware=["living-off-the-land (no custom malware)"],
            description="Chinese state-sponsored group living off the land in US critical infrastructure. Pre-positioning for future disruption. CISA AA24-038A.",
        ),
    ]

    @classmethod
    def get_profile(cls, actor_id: str) -> Optional[ThreatActorProfile]:
        for p in cls.PROFILES:
            if p.actor_id == actor_id:
                return p
        return None

    @classmethod
    def list_profiles(cls) -> list[ThreatActorProfile]:
        return list(cls.PROFILES)

    @classmethod
    def match_by_aliases(cls, name: str) -> Optional[ThreatActorProfile]:
        """Match an alias to a threat actor."""
        name_lower = name.lower()
        for p in cls.PROFILES:
            if name_lower == p.actor_id.lower() or name_lower == p.name.lower():
                return p
            for alias in p.aliases:
                if name_lower == alias.lower():
                    return p
        return None


# ═══════════════════════════════════════════════════════════════
# Threat Intelligence Engine
# ═══════════════════════════════════════════════════════════════

class ThreatIntelEngine:
    """Threat intelligence engine: IOC management + matching + enrichment.

    Architecture:
      IOC Feeds ──> Ingestion ──> Normalization ──> Storage (indexed by type+value)
                                                          │
      Security Event ──> Query ──────────────────────────┘
                          │
                          ▼
                    Match + Enrichment ──> Alert (with threat actor TTPs)
    """

    def __init__(self):
        # Index: type -> value -> IOC
        self._iocs: dict[str, dict[str, IOC]] = defaultdict(dict)
        # Reverse: threat_actor -> set of IOC IDs
        self._actor_iocs: dict[str, set[str]] = defaultdict(set)
        # Malware family -> set of IOC IDs
        self._malware_iocs: dict[str, set[str]] = defaultdict(set)
        self._alerts: list[ThreatIntelAlert] = []
        self._lock = threading.RLock()
        self._stats = {
            "total_iocs": 0,
            "by_type": defaultdict(int),
            "by_severity": defaultdict(int),
            "total_alerts": 0,
            "total_matches": 0,
        }
        # Seed with sample IOCs
        self._seed_sample_iocs()

    def ingest_ioc(self, ioc: IOC) -> bool:
        """Ingest a single IOC. Returns False if duplicate."""
        with self._lock:
            normalized_value = IOCValidators.normalize(ioc.value, IOCType(ioc.ioc_type))
            if normalized_value in self._iocs[ioc.ioc_type]:
                # Merge — update sources, last_seen
                existing = self._iocs[ioc.ioc_type][normalized_value]
                existing.sources = list(set(existing.sources + ioc.sources))
                existing.last_seen = ioc.last_seen
                existing.threat_actors = list(set(existing.threat_actors + ioc.threat_actors))
                existing.malware_families = list(set(existing.malware_families + ioc.malware_families))
                # Update reputation (max of existing and new)
                existing.reputation_score = max(existing.reputation_score, ioc.reputation_score)
                if existing.reputation_score > ioc.reputation_score:
                    existing.severity = ioc.severity
                return False

            ioc.value = normalized_value
            self._iocs[ioc.ioc_type][normalized_value] = ioc
            for actor in ioc.threat_actors:
                self._actor_iocs[actor].add(ioc.ioc_id)
            for malware in ioc.malware_families:
                self._malware_iocs[malware].add(ioc.ioc_id)
            self._stats["total_iocs"] += 1
            self._stats["by_type"][ioc.ioc_type] += 1
            self._stats["by_severity"][ioc.severity] += 1
            return True

    def ingest_iocs(self, iocs: list[IOC]) -> int:
        """Ingest a batch of IOCs. Returns count of newly added."""
        added = 0
        for ioc in iocs:
            if self.ingest_ioc(ioc):
                added += 1
        return added

    def query(self, value: str, ioc_type: Optional[str] = None) -> ThreatIntelMatch:
        """Query the IOC database for a value.

        Args:
            value: The artifact to check (IP, domain, hash, URL)
            ioc_type: Optional type hint (auto-detected if None)

        Returns:
            ThreatIntelMatch with matched=True if found
        """
        # Auto-detect type
        if not ioc_type:
            detected = IOCValidators.detect_type(value)
            if not detected:
                return ThreatIntelMatch(matched=False, query_value=value, query_type="unknown")
            ioc_type = detected.value

        normalized = IOCValidators.normalize(value, IOCType(ioc_type))

        with self._lock:
            ioc = self._iocs.get(ioc_type, {}).get(normalized)

            # For IPs, also check CIDR ranges
            if not ioc and ioc_type in (IOCType.IPV4.value, IOCType.IPV6.value):
                try:
                    ip = ipaddress.ip_address(normalized)
                    for cidr_str, cidr_ioc in self._iocs.get(IOCType.CIDR.value, {}).items():
                        try:
                            network = ipaddress.ip_network(cidr_str, strict=False)
                            if ip in network:
                                ioc = cidr_ioc
                                break
                        except ValueError:
                            continue
                except ValueError:
                    pass

            # For domains, check parent domains (subdomain match)
            if not ioc and ioc_type == IOCType.DOMAIN.value:
                parts = normalized.split(".")
                for i in range(1, len(parts) - 1):
                    parent = ".".join(parts[i:])
                    ioc = self._iocs.get(IOCType.DOMAIN.value, {}).get(parent)
                    if ioc:
                        break

        if ioc:
            self._stats["total_matches"] += 1
            return ThreatIntelMatch(
                matched=True,
                ioc=ioc,
                query_value=value,
                query_type=ioc_type,
                threat_actors=ioc.threat_actors,
                malware_families=ioc.malware_families,
                enrichment={
                    "reputation_score": ioc.reputation_score,
                    "confidence": ioc.confidence,
                    "first_seen": ioc.first_seen,
                    "last_seen": ioc.last_seen,
                    "sources": ioc.sources,
                    "country": ioc.country,
                    "description": ioc.description,
                    "mitre_attack_ids": ioc.mitre_attack_ids,
                    "tags": ioc.tags,
                },
            )

        return ThreatIntelMatch(matched=False, query_value=value, query_type=ioc_type)

    def query_batch(self, values: list[str]) -> list[ThreatIntelMatch]:
        """Query multiple artifacts at once."""
        return [self.query(v) for v in values]

    def create_alert(
        self,
        tenant_id: str,
        value: str,
        match: ThreatIntelMatch,
        source_context: str = "",
    ) -> Optional[ThreatIntelAlert]:
        """Create a threat intel alert when a match is found."""
        if not match.matched or not match.ioc:
            return None
        alert = ThreatIntelAlert(
            alert_id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            detected_at=int(time.time() * 1000),
            ioc_id=match.ioc.ioc_id,
            ioc_type=match.ioc.ioc_type,
            ioc_value=match.ioc.value,
            severity=match.ioc.severity,
            confidence=match.ioc.confidence,
            reputation_score=match.ioc.reputation_score,
            threat_actors=match.threat_actors,
            malware_families=match.malware_families,
            mitre_attack_ids=match.ioc.mitre_attack_ids,
            description=match.ioc.description,
            source_artifact=value,
            source_context=source_context,
            enrichment=match.enrichment,
        )
        with self._lock:
            self._alerts.append(alert)
            self._stats["total_alerts"] += 1
        return alert

    def list_alerts(
        self,
        tenant_id: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 100,
    ) -> list[ThreatIntelAlert]:
        with self._lock:
            alerts = list(self._alerts)
        if tenant_id:
            alerts = [a for a in alerts if a.tenant_id == tenant_id]
        if severity:
            alerts = [a for a in alerts if a.severity == severity]
        return alerts[-limit:]

    def get_alert(self, alert_id: str) -> Optional[ThreatIntelAlert]:
        with self._lock:
            for alert in self._alerts:
                if alert.alert_id == alert_id:
                    return alert
        return None

    def list_threat_actors(self) -> list[dict[str, Any]]:
        """List all known threat actors with their profiles."""
        return [asdict(p) for p in ThreatActorDB.list_profiles()]

    def get_threat_actor(self, actor_id: str) -> Optional[dict[str, Any]]:
        profile = ThreatActorDB.get_profile(actor_id)
        return asdict(profile) if profile else None

    def get_iocs_by_actor(self, actor_id: str, limit: int = 100) -> list[IOC]:
        """Get all IOCs associated with a threat actor."""
        with self._lock:
            ioc_ids = list(self._actor_iocs.get(actor_id, set()))[:limit]
            results = []
            for ioc_dict in self._iocs.values():
                for ioc in ioc_dict.values():
                    if ioc.ioc_id in ioc_ids:
                        results.append(ioc)
        return results

    def get_stats(self) -> dict[str, Any]:
        with self._lock:
            return {
                "total_iocs": self._stats["total_iocs"],
                "by_type": dict(self._stats["by_type"]),
                "by_severity": dict(self._stats["by_severity"]),
                "total_alerts": self._stats["total_alerts"],
                "total_matches": self._stats["total_matches"],
                "threat_actors_tracked": len(ThreatActorDB.PROFILES),
                "malware_families_tracked": len(self._malware_iocs),
            }

    def _seed_sample_iocs(self) -> None:
        """Seed with sample IOCs for demo. In production, ingest from real feeds."""
        sample_iocs = [
            IOC(
                ioc_id=str(uuid.uuid4()),
                ioc_type=IOCType.IPV4.value,
                value="185.220.101.5",
                severity=IOCSeverity.MALICIOUS.value,
                confidence=0.95,
                reputation_score=92,
                sources=["AlienVault OTX", "Abuse.ch"],
                first_seen=int(time.time() * 1000) - 86400000 * 30,
                last_seen=int(time.time() * 1000),
                threat_actors=[ThreatActor.APT28.value],
                malware_families=["X-Agent", "Zebrocy"],
                mitre_attack_ids=["T1071", "T1090"],
                tags=["c2", "apt", "tor_exit"],
                country="Russia",
                description="Known C2 server used by APT28 (Fancy Bear) for spear-phishing campaigns.",
            ),
            IOC(
                ioc_id=str(uuid.uuid4()),
                ioc_type=IOCType.IPV4.value,
                value="5.188.206.15",
                severity=IOCSeverity.MALICIOUS.value,
                confidence=0.9,
                reputation_score=88,
                sources=["MISP", "VirusTotal"],
                first_seen=int(time.time() * 1000) - 86400000 * 60,
                last_seen=int(time.time() * 1000),
                threat_actors=[ThreatActor.APT29.value],
                malware_families=["WellMess", "WellMail"],
                mitre_attack_ids=["T1566", "T1071"],
                tags=["c2", "phishing_infra"],
                country="Russia",
                description="C2 infrastructure used by NOBELIUM/APT29 in SolarWinds follow-up campaigns.",
            ),
            IOC(
                ioc_id=str(uuid.uuid4()),
                ioc_type=IOCType.DOMAIN.value,
                value="malicious-update-cdn.com",
                severity=IOCSeverity.MALICIOUS.value,
                confidence=0.85,
                reputation_score=85,
                sources=["AlienVault OTX"],
                first_seen=int(time.time() * 1000) - 86400000 * 14,
                last_seen=int(time.time() * 1000),
                threat_actors=[ThreatActor.APT41.value],
                malware_families=["ShadowPad", "PlugX"],
                mitre_attack_ids=["T1105", "T1566"],
                tags=["c2", "supply_chain"],
                description="Domain used by APT41 for delivering ShadowPad malware via fake software updates.",
            ),
            IOC(
                ioc_id=str(uuid.uuid4()),
                ioc_type=IOCType.CIDR.value,
                value="104.168.128.0/19",
                severity=IOCSeverity.SUSPICIOUS.value,
                confidence=0.7,
                reputation_score=65,
                sources=["Abuse.ch"],
                first_seen=int(time.time() * 1000) - 86400000 * 45,
                last_seen=int(time.time() * 1000),
                threat_actors=[ThreatActor.FIN7.value],
                malware_families=["Carbanak"],
                mitre_attack_ids=["T1071"],
                tags=["c2", "carbanak_infra"],
                description="Network range associated with FIN7 Carbanak C2 infrastructure.",
            ),
            IOC(
                ioc_id=str(uuid.uuid4()),
                ioc_type=IOCType.FILE_HASH_SHA256.value,
                value="d41d8cd98f00b204e9800998ecf8427e",
                severity=IOCSeverity.CRITICAL.value,
                confidence=0.99,
                reputation_score=99,
                sources=["VirusTotal", "MalwareBazaar"],
                first_seen=int(time.time() * 1000) - 86400000 * 7,
                last_seen=int(time.time() * 1000),
                threat_actors=[ThreatActor.APT38.value],
                malware_families=["Manuscrypt", "TraderTraitor"],
                mitre_attack_ids=["T1059", "T1027", "T1496"],
                tags=["malware", "trojan", "crypto_stealer"],
                description="Manuscrypt trojan variant used by Lazarus in cryptocurrency heists.",
            ),
            IOC(
                ioc_id=str(uuid.uuid4()),
                ioc_type=IOCType.URL.value,
                value="https://fake-ms-update.com/download.exe",
                severity=IOCSeverity.MALICIOUS.value,
                confidence=0.92,
                reputation_score=90,
                sources=["AlienVault OTX", "PhishTank"],
                first_seen=int(time.time() * 1000) - 86400000 * 21,
                last_seen=int(time.time() * 1000),
                threat_actors=[ThreatActor.APT38.value],
                malware_families=["AppleJeus"],
                mitre_attack_ids=["T1566", "T1105", "T1204"],
                tags=["phishing", "malware_download", "crypto_exchange_target"],
                description="AppleJeus phishing URL targeting cryptocurrency exchanges. Drops Manuscrypt variant.",
            ),
            IOC(
                ioc_id=str(uuid.uuid4()),
                ioc_type=IOCType.IPV4.value,
                value="194.165.16.78",
                severity=IOCSeverity.CRITICAL.value,
                confidence=0.97,
                reputation_score=96,
                sources=["CISA", "Mandiant"],
                first_seen=int(time.time() * 1000) - 86400000 * 30,
                last_seen=int(time.time() * 1000),
                threat_actors=[ThreatActor.VOLT_TYPHOON.value],
                malware_families=["living-off-the-land"],
                mitre_attack_ids=["T1078", "T1021", "T1098"],
                tags=["c2", "critical_infra_target"],
                description="Volt Typhoon C2 IP targeting US critical infrastructure (CISA AA24-038A).",
            ),
            IOC(
                ioc_id=str(uuid.uuid4()),
                ioc_type=IOCType.FILE_HASH_MD5.value,
                value="44d88612fea8a8f36de82e1278abb02f",
                severity=IOCSeverity.CRITICAL.value,
                confidence=0.99,
                reputation_score=99,
                sources=["MalwareBazaar", "VirusTotal"],
                first_seen=int(time.time() * 1000) - 86400000 * 90,
                last_seen=int(time.time() * 1000),
                threat_actors=[ThreatActor.SANDWORM.value],
                malware_families=["Industroyer2"],
                mitre_attack_ids=["T0816", "T0858", "T0866"],
                tags=["ics", "ot", "energy_grid"],
                description="Industroyer2 malware targeting industrial control systems (Ukraine grid).",
            ),
        ]
        for ioc in sample_iocs:
            self.ingest_ioc(ioc)


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_engine: Optional[ThreatIntelEngine] = None
_global_lock = threading.Lock()


def get_threat_intel_engine() -> ThreatIntelEngine:
    global _global_engine
    if _global_engine is None:
        with _global_lock:
            if _global_engine is None:
                _global_engine = ThreatIntelEngine()
    return _global_engine
