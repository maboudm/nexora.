"""
Enterprise Policy Engine — Rego-like DSL + OPA-style evaluation.

Based on Part 6 — Policy as Code and Open Policy Agent (OPA) Rego language.

Scientific Foundation:
  - Policy as Code: security policies expressed as version-controlled code,
    enabling CI/CD integration, code review, and automated enforcement
  - Rego (OPA's language): declarative, query-based policy language based on
    Datalog. Policies are queries over JSON data.
    https://www.openpolicyagent.org/docs/latest/policy-language/
  - This engine implements a Python-native subset of Rego, focusing on
    cloud security policy evaluation. It's not a full Rego interpreter,
    but covers the 80% use case for cloud resource policy checks.

Policy DSL Examples:
  # Allow only encrypted S3 buckets
  policy require_s3_encryption {
    resource_type = "aws_s3_bucket"
    deny when not metadata.encrypted
    message "S3 bucket must be encrypted"
    severity HIGH
  }

  # Require tags on all resources
  policy require_tags {
    deny when not has_tag("Environment")
    deny when not has_tag("Owner")
    message "All resources must have Environment and Owner tags"
    severity LOW
  }

  # Prevent public S3 buckets
  policy no_public_s3 {
    resource_type = "aws_s3_bucket"
    deny when metadata.acl in ["public-read", "public-read-write"]
    message "S3 bucket must not be public"
    severity CRITICAL
    remediation "Set ACL to private"
  }

Capabilities:
  1. Policy parsing: custom mini-parser for the DSL above
  2. Policy evaluation: evaluate policy against resource dict
  3. Policy bundles: versioned collections of policies
  4. Decision logging: every policy decision recorded for audit
  5. CI/CD integration: evaluate policies against IaC before deploy
"""
from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Policy Domain Model
# ═══════════════════════════════════════════════════════════════

class PolicySeverity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class PolicyDecision(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    WARN = "warn"


class PolicyEffect(str, Enum):
    DENY_WHEN = "deny_when"
    ALLOW_WHEN = "allow_when"
    WARN_WHEN = "warn_when"


@dataclass
class PolicyCondition:
    """A condition in a policy rule."""
    field: str              # dot-notation path: "metadata.encrypted"
    operator: str           # eq, ne, in, not_in, contains, exists, matches
    value: Any              # value or list of values
    negate: bool = False    # if True, negate the result


@dataclass
class PolicyRule:
    """A single policy rule with conditions and decision."""
    rule_id: str
    name: str
    description: str = ""
    severity: str = PolicySeverity.MEDIUM.value
    # Match criteria — what resources does this rule apply to?
    resource_types: list[str] = field(default_factory=list)
    resource_providers: list[str] = field(default_factory=list)
    # Conditions
    effect: str = PolicyEffect.DENY_WHEN.value
    conditions: list[PolicyCondition] = field(default_factory=list)
    condition_logic: str = "and"  # "and" | "or"
    # Output
    message: str = ""
    remediation: str = ""
    # Metadata
    references: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    enabled: bool = True
    version: str = "1.0"


@dataclass
class PolicyBundle:
    """A versioned collection of policy rules."""
    bundle_id: str
    name: str
    version: str
    description: str
    rules: list[PolicyRule] = field(default_factory=list)
    created_at: int = 0
    created_by: str = ""


@dataclass
class PolicyDecisionResult:
    """Result of evaluating a policy against a resource."""
    decision_id: str
    policy_rule_id: str
    policy_name: str
    decision: str           # PolicyDecision value
    severity: str
    message: str
    remediation: str
    resource_arn: str = ""
    resource_type: str = ""
    resource_name: str = ""
    matched_conditions: list[dict] = field(default_factory=list)
    evaluated_at: int = 0
    tenant_id: str = ""


@dataclass
class PolicyEvaluationResult:
    """Result of evaluating all policies against a resource."""
    resource_arn: str
    resource_type: str
    resource_name: str
    decisions: list[PolicyDecisionResult] = field(default_factory=list)
    overall_decision: str = PolicyDecision.ALLOW.value
    total_deny: int = 0
    total_warn: int = 0
    total_allow: int = 0
    evaluated_at: int = 0
    duration_ms: int = 0


# ═══════════════════════════════════════════════════════════════
# Condition Evaluator
# ═══════════════════════════════════════════════════════════════

class ConditionEvaluator:
    """Evaluates a PolicyCondition against a resource dict.

    Supported operators:
      eq: equal
      ne: not equal
      in: value in list
      not_in: value not in list
      contains: resource field contains value (substring or list element)
      exists: resource field exists
      not_exists: resource field does not exist
      matches: regex match
      gt: greater than (numeric)
      lt: less than (numeric)
      gte: greater than or equal
      lte: less than or equal
    """

    OPERATORS = {"eq", "ne", "in", "not_in", "contains", "exists", "not_exists",
                 "matches", "gt", "lt", "gte", "lte"}

    @classmethod
    def evaluate(cls, condition: PolicyCondition, resource: dict) -> bool:
        field_value = cls._extract_field(resource, condition.field)
        result = cls._apply_operator(condition.operator, field_value, condition.value)
        return (not result) if condition.negate else result

    @classmethod
    def _extract_field(cls, resource: dict, field_path: str) -> Any:
        """Extract nested field using dot notation."""
        parts = field_path.split(".")
        current: Any = resource
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            else:
                return None
            if current is None:
                return None
        return current

    @classmethod
    def _apply_operator(cls, operator: str, field_value: Any, expected: Any) -> bool:
        if operator == "eq":
            return field_value == expected
        if operator == "ne":
            return field_value != expected
        if operator == "in":
            if field_value is None:
                return False
            if isinstance(expected, list):
                return field_value in expected
            return field_value == expected
        if operator == "not_in":
            if field_value is None:
                return True
            if isinstance(expected, list):
                return field_value not in expected
            return field_value != expected
        if operator == "contains":
            if field_value is None:
                return False
            if isinstance(field_value, str):
                return str(expected) in field_value
            if isinstance(field_value, list):
                return expected in field_value
            return False
        if operator == "exists":
            return field_value is not None
        if operator == "not_exists":
            return field_value is None
        if operator == "matches":
            if field_value is None:
                return False
            try:
                return bool(re.search(str(expected), str(field_value), re.IGNORECASE))
            except re.error:
                return False
        if operator in ("gt", "lt", "gte", "lte"):
            if field_value is None or expected is None:
                return False
            try:
                fv = float(field_value)
                ev = float(expected)
                if operator == "gt":
                    return fv > ev
                if operator == "lt":
                    return fv < ev
                if operator == "gte":
                    return fv >= ev
                if operator == "lte":
                    return fv <= ev
            except (ValueError, TypeError):
                return False
        return False


# ═══════════════════════════════════════════════════════════════
# Policy Parser (mini-DSL)
# ═══════════════════════════════════════════════════════════════

class PolicyParser:
    """Parser for the Sentinel policy DSL.

    Grammar (simplified):
      policy <name> {
          resource_type = "<type>"
          resource_provider = "<provider>"
          severity <CRITICAL|HIGH|MEDIUM|LOW|INFO>
          deny_when <field> <operator> <value>
          allow_when <field> <operator> <value>
          warn_when <field> <operator> <value>
          message "<text>"
          remediation "<text>"
          reference "<url>"
          tag "<tag>"
      }
    """

    @classmethod
    def parse(cls, content: str) -> list[PolicyRule]:
        """Parse a policy file and return list of PolicyRules."""
        rules: list[PolicyRule] = []
        # Match each policy block
        policy_pattern = re.compile(
            r"policy\s+(\w+)\s*\{([^}]*(?:\{[^}]*\}[^}]*)*)\}",
            re.DOTALL,
        )
        for match in policy_pattern.finditer(content):
            name = match.group(1)
            body = match.group(2)
            rule = cls._parse_rule(name, body)
            if rule:
                rules.append(rule)
        return rules

    @classmethod
    def _parse_rule(cls, name: str, body: str) -> Optional[PolicyRule]:
        rule_id = f"policy-{name.lower().replace('_', '-')}-{uuid.uuid4().hex[:8]}"
        rule = PolicyRule(
            rule_id=rule_id,
            name=name.replace("_", " ").title(),
        )

        # Parse severity
        severity_match = re.search(r"severity\s+(CRITICAL|HIGH|MEDIUM|LOW|INFO)", body, re.IGNORECASE)
        if severity_match:
            rule.severity = severity_match.group(1).lower()

        # Parse resource_type
        rt_match = re.search(r'resource_type\s*=\s*"([^"]+)"', body)
        if rt_match:
            rule.resource_types = [rt_match.group(1)]

        # Parse resource_provider
        rp_match = re.search(r'resource_provider\s*=\s*"([^"]+)"', body)
        if rp_match:
            rule.resource_providers = [rp_match.group(1)]

        # Parse deny_when / allow_when / warn_when
        for effect_name, effect_val in [
            ("deny_when", PolicyEffect.DENY_WHEN.value),
            ("allow_when", PolicyEffect.ALLOW_WHEN.value),
            ("warn_when", PolicyEffect.WARN_WHEN.value),
        ]:
            for cond_match in re.finditer(
                rf"{effect_name}\s+(\w+(?:\.\w+)*)\s+(\w+)\s+(.+?)(?:\n|$)",
                body, re.IGNORECASE,
            ):
                field_path = cond_match.group(1)
                operator = cond_match.group(2).lower()
                value_str = cond_match.group(3).strip()
                if operator not in ConditionEvaluator.OPERATORS:
                    continue
                value = cls._parse_value(value_str)
                rule.conditions.append(PolicyCondition(
                    field=field_path, operator=operator, value=value,
                ))
                rule.effect = effect_val

        # Parse message
        msg_match = re.search(r'message\s+"([^"]+)"', body)
        if msg_match:
            rule.message = msg_match.group(1)

        # Parse remediation
        rem_match = re.search(r'remediation\s+"([^"]+)"', body)
        if rem_match:
            rule.remediation = rem_match.group(1)

        # Parse references
        for ref_match in re.finditer(r'reference\s+"([^"]+)"', body):
            rule.references.append(ref_match.group(1))

        # Parse tags
        for tag_match in re.finditer(r'tag\s+"([^"]+)"', body):
            rule.tags.append(tag_match.group(1))

        return rule

    @classmethod
    def _parse_value(cls, value_str: str) -> Any:
        """Parse a value string into the appropriate type."""
        value_str = value_str.strip().rstrip(",")
        # List
        if value_str.startswith("[") and value_str.endswith("]"):
            inner = value_str[1:-1]
            return [cls._parse_value(v.strip()) for v in inner.split(",")]
        # String
        if value_str.startswith('"') and value_str.endswith('"'):
            return value_str[1:-1]
        # Boolean
        if value_str.lower() == "true":
            return True
        if value_str.lower() == "false":
            return False
        # Number
        try:
            if "." in value_str:
                return float(value_str)
            return int(value_str)
        except ValueError:
            pass
        # Bare word (string)
        return value_str


# ═══════════════════════════════════════════════════════════════
# Built-in Policy Bundle
# ═══════════════════════════════════════════════════════════════

class BuiltinPolicyBundle:
    """Default policy bundle with common cloud security policies."""

    @classmethod
    def get_rules(cls) -> list[PolicyRule]:
        return [
            PolicyRule(
                rule_id="builtin-s3-encryption",
                name="S3 Buckets Must Be Encrypted",
                description="All S3 buckets must have server-side encryption enabled.",
                severity=PolicySeverity.HIGH.value,
                resource_types=["aws_s3_bucket", "storage.bucket"],
                effect=PolicyEffect.DENY_WHEN.value,
                conditions=[
                    PolicyCondition(field="metadata.encrypted", operator="eq", value=False),
                ],
                message="S3 bucket does not have server-side encryption enabled",
                remediation="Enable SSE-S3 or SSE-KMS on the bucket",
                references=["https://docs.aws.amazon.com/AmazonS3/latest/userguide/serv-side-encryption.html"],
                tags=["s3", "encryption", "cis-aws-2.2"],
            ),
            PolicyRule(
                rule_id="builtin-s3-no-public",
                name="S3 Buckets Must Not Be Public",
                description="S3 buckets must not allow public read or write access.",
                severity=PolicySeverity.CRITICAL.value,
                resource_types=["aws_s3_bucket", "storage.bucket"],
                effect=PolicyEffect.DENY_WHEN.value,
                conditions=[
                    PolicyCondition(field="metadata.acl", operator="in",
                                  value=["public-read", "public-read-write", "website"]),
                ],
                message="S3 bucket has public ACL",
                remediation="Set ACL to private and enable Block Public Access",
                references=["https://docs.aws.amazon.com/AmazonS3/latest/userguide/access-control-block-public-access.html"],
                tags=["s3", "public_access", "cis-aws-2.4"],
            ),
            PolicyRule(
                rule_id="builtin-sg-no-ssh",
                name="No SSH Open to Internet",
                description="Security groups must not allow SSH (port 22) from 0.0.0.0/0.",
                severity=PolicySeverity.CRITICAL.value,
                resource_types=["aws_security_group", "network.security_group"],
                effect=PolicyEffect.DENY_WHEN.value,
                conditions=[
                    PolicyCondition(field="metadata.ssh_open", operator="eq", value=True),
                ],
                message="Security group allows SSH from 0.0.0.0/0",
                remediation="Restrict SSH to corporate VPN CIDR or use SSM Session Manager",
                tags=["sg", "ssh", "cis-aws-5.1"],
            ),
            PolicyRule(
                rule_id="builtin-iam-no-admin",
                name="No AdministratorAccess",
                description="IAM principals must not have AdministratorAccess attached.",
                severity=PolicySeverity.HIGH.value,
                resource_types=["aws_iam_role", "aws_iam_user", "identity.role", "identity.user"],
                effect=PolicyEffect.DENY_WHEN.value,
                conditions=[
                    PolicyCondition(field="metadata.has_admin", operator="eq", value=True),
                ],
                message="IAM principal has AdministratorAccess",
                remediation="Replace with least-privilege custom policy",
                tags=["iam", "admin", "cis-aws-1.10"],
            ),
            PolicyRule(
                rule_id="builtin-rds-encryption",
                name="RDS Must Be Encrypted",
                description="RDS instances must have encryption at rest enabled.",
                severity=PolicySeverity.HIGH.value,
                resource_types=["aws_db_instance", "aws_rds_instance", "database.rds"],
                effect=PolicyEffect.DENY_WHEN.value,
                conditions=[
                    PolicyCondition(field="metadata.storage_encrypted", operator="eq", value=False),
                ],
                message="RDS instance does not have encryption at rest",
                remediation="Enable storage_encrypted = true with a KMS CMK",
                tags=["rds", "encryption", "cis-aws-6.3"],
            ),
            PolicyRule(
                rule_id="builtin-rds-no-public",
                name="RDS Must Not Be Publicly Accessible",
                description="RDS instances must not be publicly accessible.",
                severity=PolicySeverity.CRITICAL.value,
                resource_types=["aws_db_instance", "aws_rds_instance", "database.rds"],
                effect=PolicyEffect.DENY_WHEN.value,
                conditions=[
                    PolicyCondition(field="metadata.publicly_accessible", operator="eq", value=True),
                ],
                message="RDS instance is publicly accessible",
                remediation="Set publicly_accessible = false",
                tags=["rds", "public_access", "cis-aws-6.6"],
            ),
            PolicyRule(
                rule_id="builtin-require-tags",
                name="Resources Must Have Required Tags",
                description="All resources must have Environment, Owner, and Project tags.",
                severity=PolicySeverity.LOW.value,
                effect=PolicyEffect.WARN_WHEN.value,
                conditions=[
                    PolicyCondition(field="tags.Environment", operator="not_exists", value=None),
                ],
                message="Resource missing required 'Environment' tag",
                remediation="Add the 'Environment' tag",
                tags=["tags", "governance"],
            ),
            PolicyRule(
                rule_id="builtin-eks-encryption",
                name="EKS Secrets Must Be Encrypted",
                description="EKS clusters must have secrets encryption enabled with KMS.",
                severity=PolicySeverity.HIGH.value,
                resource_types=["aws_eks_cluster", "container.orchestrator"],
                effect=PolicyEffect.DENY_WHEN.value,
                conditions=[
                    PolicyCondition(field="metadata.secrets_encrypted", operator="eq", value=False),
                ],
                message="EKS cluster secrets are not encrypted with KMS",
                remediation="Enable encryption_config with KMS key",
                tags=["eks", "encryption", "cis-aws-6.9"],
            ),
            PolicyRule(
                rule_id="builtin-cloudtrail-required",
                name="CloudTrail Must Be Enabled",
                description="AWS accounts must have CloudTrail enabled with multi-region and log validation.",
                severity=PolicySeverity.HIGH.value,
                effect=PolicyEffect.WARN_WHEN.value,
                conditions=[
                    PolicyCondition(field="metadata.cloudtrail_enabled", operator="eq", value=False),
                ],
                message="CloudTrail is not enabled or not multi-region",
                remediation="Enable multi-region CloudTrail with log file validation",
                tags=["cloudtrail", "logging", "cis-aws-3.1"],
            ),
            PolicyRule(
                rule_id="builtin-mfa-required",
                name="MFA Required for All Users",
                description="All IAM users with console access must have MFA enabled.",
                severity=PolicySeverity.HIGH.value,
                resource_types=["aws_iam_user", "identity.user"],
                effect=PolicyEffect.DENY_WHEN.value,
                conditions=[
                    PolicyCondition(field="metadata.mfa_active", operator="eq", value=False),
                    PolicyCondition(field="metadata.console_access", operator="eq", value=True),
                ],
                message="IAM user has console access but no MFA",
                remediation="Enable MFA for the user",
                tags=["iam", "mfa", "cis-aws-1.3"],
            ),
        ]


# ═══════════════════════════════════════════════════════════════
# Policy Engine
# ═══════════════════════════════════════════════════════════════

class PolicyEngine:
    """Policy as Code evaluation engine.

    Usage:
        engine = PolicyEngine()
        # Evaluate a single resource
        result = engine.evaluate_resource(tenant_id, resource_dict)
        # Evaluate a batch (e.g., all resources from a scan)
        results = engine.evaluate_resources(tenant_id, [resource1, resource2])
        # Add custom policy
        engine.add_rule(my_rule)
        # Load policies from file
        engine.load_policies_from_file("policies.rego")
    """

    def __init__(self):
        self._rules: list[PolicyRule] = BuiltinPolicyBundle.get_rules()
        self._decisions: list[PolicyDecisionResult] = []
        self._lock = threading.RLock()
        self._stats = {
            "policies_evaluated": 0,
            "resources_evaluated": 0,
            "deny_decisions": 0,
            "warn_decisions": 0,
            "allow_decisions": 0,
        }

    def add_rule(self, rule: PolicyRule) -> None:
        with self._lock:
            self._rules.append(rule)

    def load_policies_from_content(self, content: str) -> int:
        """Load policies from DSL content. Returns count of loaded rules."""
        rules = PolicyParser.parse(content)
        with self._lock:
            self._rules.extend(rules)
        return len(rules)

    def load_policies_from_file(self, file_path: str) -> int:
        """Load policies from a .rego-like file."""
        try:
            with open(file_path, "r") as f:
                content = f.read()
            return self.load_policies_from_content(content)
        except IOError as e:
            logger.error(f"Failed to load policies from {file_path}: {e}")
            return 0

    def list_rules(self) -> list[dict[str, Any]]:
        with self._lock:
            return [
                {
                    "rule_id": r.rule_id,
                    "name": r.name,
                    "description": r.description,
                    "severity": r.severity,
                    "resource_types": r.resource_types,
                    "effect": r.effect,
                    "conditions_count": len(r.conditions),
                    "message": r.message,
                    "remediation": r.remediation,
                    "enabled": r.enabled,
                    "tags": r.tags,
                }
                for r in self._rules
            ]

    def evaluate_resource(self, tenant_id: str, resource: dict) -> PolicyEvaluationResult:
        """Evaluate all policies against a single resource."""
        start_time = time.time()
        resource_arn = resource.get("arn", "")
        resource_type = resource.get("type", resource.get("provider_resource_type", ""))
        resource_name = resource.get("name", "")

        decisions: list[PolicyDecisionResult] = []
        with self._lock:
            rules = list(self._rules)

        for rule in rules:
            if not rule.enabled:
                continue
            # Check resource type match
            if rule.resource_types and resource_type not in rule.resource_types:
                continue
            # Check provider match
            if rule.resource_providers:
                provider = resource.get("provider", "")
                if provider not in rule.resource_providers:
                    continue

            # Evaluate conditions
            condition_results = []
            matched_conditions = []
            for cond in rule.conditions:
                result = ConditionEvaluator.evaluate(cond, resource)
                condition_results.append(result)
                if result:
                    matched_conditions.append({
                        "field": cond.field,
                        "operator": cond.operator,
                        "value": str(cond.value)[:100],
                    })

            # Apply condition logic
            if rule.condition_logic == "and":
                all_match = all(condition_results)
            else:
                all_match = any(condition_results)

            if not all_match:
                continue

            # Determine decision based on effect
            if rule.effect == PolicyEffect.DENY_WHEN.value:
                decision = PolicyDecision.DENY.value
            elif rule.effect == PolicyEffect.WARN_WHEN.value:
                decision = PolicyDecision.WARN.value
            else:
                decision = PolicyDecision.ALLOW.value

            decision_result = PolicyDecisionResult(
                decision_id=str(uuid.uuid4()),
                policy_rule_id=rule.rule_id,
                policy_name=rule.name,
                decision=decision,
                severity=rule.severity,
                message=rule.message,
                remediation=rule.remediation,
                resource_arn=resource_arn,
                resource_type=resource_type,
                resource_name=resource_name,
                matched_conditions=matched_conditions,
                evaluated_at=int(time.time() * 1000),
                tenant_id=tenant_id,
            )
            decisions.append(decision_result)

            with self._lock:
                self._decisions.append(decision_result)
                self._stats["policies_evaluated"] += 1
                if decision == PolicyDecision.DENY.value:
                    self._stats["deny_decisions"] += 1
                elif decision == PolicyDecision.WARN.value:
                    self._stats["warn_decisions"] += 1
                else:
                    self._stats["allow_decisions"] += 1

        # Determine overall decision
        overall = PolicyDecision.ALLOW.value
        if any(d.decision == PolicyDecision.DENY.value for d in decisions):
            overall = PolicyDecision.DENY.value
        elif any(d.decision == PolicyDecision.WARN.value for d in decisions):
            overall = PolicyDecision.WARN.value

        result = PolicyEvaluationResult(
            resource_arn=resource_arn,
            resource_type=resource_type,
            resource_name=resource_name,
            decisions=decisions,
            overall_decision=overall,
            total_deny=sum(1 for d in decisions if d.decision == PolicyDecision.DENY.value),
            total_warn=sum(1 for d in decisions if d.decision == PolicyDecision.WARN.value),
            total_allow=sum(1 for d in decisions if d.decision == PolicyDecision.ALLOW.value),
            evaluated_at=int(time.time() * 1000),
            duration_ms=int((time.time() - start_time) * 1000),
        )

        with self._lock:
            self._stats["resources_evaluated"] += 1

        return result

    def evaluate_resources(self, tenant_id: str, resources: list[dict]) -> list[PolicyEvaluationResult]:
        """Evaluate policies against multiple resources."""
        return [self.evaluate_resource(tenant_id, r) for r in resources]

    def get_decisions(
        self,
        tenant_id: Optional[str] = None,
        decision: Optional[str] = None,
        limit: int = 100,
    ) -> list[PolicyDecisionResult]:
        with self._lock:
            results = list(self._decisions)
        if tenant_id:
            results = [d for d in results if d.tenant_id == tenant_id]
        if decision:
            results = [d for d in results if d.decision == decision]
        return results[-limit:]

    def get_stats(self) -> dict[str, Any]:
        with self._lock:
            return {
                **self._stats,
                "total_rules": len(self._rules),
                "enabled_rules": sum(1 for r in self._rules if r.enabled),
            }

    def create_bundle(self, name: str, version: str, description: str,
                     rule_ids: list[str], created_by: str = "") -> PolicyBundle:
        """Create a versioned policy bundle from selected rules."""
        with self._lock:
            rules = [r for r in self._rules if r.rule_id in rule_ids]
        return PolicyBundle(
            bundle_id=str(uuid.uuid4()),
            name=name,
            version=version,
            description=description,
            rules=rules,
            created_at=int(time.time() * 1000),
            created_by=created_by,
        )


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_engine: Optional[PolicyEngine] = None
_global_lock = threading.Lock()


def get_policy_engine() -> PolicyEngine:
    global _global_engine
    if _global_engine is None:
        with _global_lock:
            if _global_engine is None:
                _global_engine = PolicyEngine()
    return _global_engine
