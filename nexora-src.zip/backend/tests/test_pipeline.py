"""
End-to-end pipeline test: Scanner → Rule Engine → Risk Engine → Attack Graph

This test proves the entire pipeline works together:
1. Credential Manager creates a session
2. Scanner Engine scans AWS resources (via moto)
3. Rule Engine evaluates 14 CIS rules against assets
4. Risk Engine scores each asset and finding
5. Attack Graph Engine builds attack paths
"""
import sys
import os
import json
import time

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# Set up environment for moto
os.environ["AWS_ENDPOINT_URL"] = "http://127.0.0.1:5000"
os.environ["AWS_ACCESS_KEY_ID"] = "test"
os.environ["AWS_SECRET_ACCESS_KEY"] = "test"
os.environ["MASTER_ENCRYPTION_KEY"] = "a" * 64  # 256-bit test key

def test_full_pipeline():
    """Test the full scanning pipeline end-to-end."""
    print("=" * 70)
    print("  ENTERPRISE CNAPP — FULL PIPELINE TEST")
    print("=" * 70)

    # ═══ 1. Credential Manager ═══
    print("\n1. Credential Manager:")
    from credential_manager.manager import CredentialManager
    from core.models import CredentialConfig

    cred_manager = CredentialManager()

    # Test encryption/decryption
    plaintext = "AKIAIOSFODNN7EXAMPLE"
    encrypted = cred_manager.encrypt(plaintext)
    decrypted = cred_manager.decrypt(encrypted)
    print(f"   ✓ AES-256-GCM encryption: {plaintext[:10]}... → {encrypted[:10]}... → {decrypted[:10]}...")
    assert decrypted == plaintext, "Encryption/decryption failed"

    # Test that different encryptions produce different ciphertexts (semantic security)
    encrypted2 = cred_manager.encrypt(plaintext)
    assert encrypted != encrypted2, "Nonce reuse detected!"
    print(f"   ✓ Nonce uniqueness: same plaintext → different ciphertext")

    # Create credential config
    cred = CredentialConfig(
        cloud_account_id="test-acct",
        provider="aws",
        credential_type="access_key",
        access_key_id="test",
        secret_access_key="test",
    )
    print(f"   ✓ Credential config created")

    # ═══ 2. Scanner Engine ═══
    print("\n2. Scanner Engine:")
    from scanner_engine.engine import ScannerEngine
    from core.models import ScanRequest

    engine = ScannerEngine(cred_manager)

    # Scan against moto
    request = ScanRequest(
        tenant_id="org-test",
        workspace_id="ws-test",
        cloud_account_id="test-acct",
        scanners=["iam", "s3", "sg", "ec2", "eks"],
    )

    print(f"   Scanning AWS account via boto3...")
    result = engine.scan(request, cred)

    print(f"   ✓ Status: {result.status}")
    print(f"   ✓ Duration: {result.duration_ms}ms")
    print(f"   ✓ Assets: {result.total_assets}")

    # Count by type
    from collections import Counter
    type_counts = Counter(a.resource_type for a in result.assets)
    for rtype, count in sorted(type_counts.items()):
        print(f"     - {rtype}: {count}")

    print(f"   ✓ Relationships: {len(result.relationships)}")

    # ═══ 3. Rule Engine ═══
    print("\n3. Rule Engine (14 CIS Rules):")
    from rule_engine.engine import RuleEngine, get_cis_aws_rules

    rule_engine = RuleEngine()
    rules = get_cis_aws_rules()
    rule_engine.register_rules(rules)
    print(f"   ✓ Registered {len(rules)} rules")

    # Execute rules
    findings, exec_results = rule_engine.execute_all(
        result.assets,
        tenant_id="org-test",
        workspace_id="ws-test",
        scan_id=result.scan_id,
    )

    print(f"   ✓ Findings: {len(findings)}")
    sev_counts = Counter(f.severity for f in findings)
    for sev in ["critical", "high", "medium", "low"]:
        print(f"     - {sev}: {sev_counts.get(sev, 0)}")

    # Show rule execution results
    pass_count = sum(1 for r in exec_results if r.status == "pass")
    fail_count = sum(1 for r in exec_results if r.status == "fail")
    error_count = sum(1 for r in exec_results if r.status == "error")
    print(f"   ✓ Rule executions: {pass_count} pass, {fail_count} fail, {error_count} error")

    # ═══ 4. Risk Engine ═══
    print("\n4. Risk Engine:")
    from risk_engine.engine import RiskEngine

    risk_engine = RiskEngine()

    # Score each asset
    findings_by_arn = {}
    for f in findings:
        findings_by_arn.setdefault(f.asset_arn, []).append(f)

    asset_scores = []
    for asset in result.assets:
        asset_findings = findings_by_arn.get(asset.arn, [])
        score = risk_engine.score_asset(asset, asset_findings)
        asset_scores.append((asset.name, score.score, score.level))

    # Sort by score (highest risk first)
    asset_scores.sort(key=lambda x: x[1], reverse=True)

    print(f"   ✓ Scored {len(asset_scores)} assets")
    print(f"   Top 5 highest-risk assets:")
    for name, score, level in asset_scores[:5]:
        print(f"     - {name[:40]:40s} score={score:5.1f} level={level}")

    # ═══ 5. Attack Graph Engine ═══
    print("\n5. Attack Graph Engine:")
    from attack_graph.engine import AttackGraphEngine

    graph_engine = AttackGraphEngine(max_depth=6)
    attack_paths = graph_engine.build_attack_paths(
        result.assets,
        result.relationships,
        findings,
    )

    print(f"   ✓ Attack paths found: {len(attack_paths)}")
    summary = graph_engine.build_graph_summary(attack_paths)
    print(f"   ✓ Critical paths: {summary['critical_paths']}")
    print(f"   ✓ Max risk score: {summary['max_risk_score']}")
    print(f"   ✓ Affected assets: {len(summary['affected_assets'])}")

    # Show top attack paths
    if attack_paths:
        print(f"\n   Top 3 Attack Paths:")
        for i, path in enumerate(attack_paths[:3]):
            print(f"   Path {i+1}: risk={path.risk_score:.0f}, length={path.length}, findings={path.findings}")
            for node in path.path:
                print(f"     → {node['node'][:60]} ({node['type']})")

    # ═══ Summary ═══
    print("\n" + "=" * 70)
    print("  PIPELINE SUMMARY")
    print("=" * 70)
    print(f"  Credentials: ✓ Encrypted with AES-256-GCM")
    print(f"  Scanner:     ✓ {result.total_assets} assets in {result.duration_ms}ms")
    print(f"  Rules:       ✓ {len(findings)} findings from {len(rules)} rules")
    print(f"  Risk:        ✓ {len(asset_scores)} assets scored")
    print(f"  Attack Graph: ✓ {len(attack_paths)} paths ({summary['critical_paths']} critical)")
    print(f"  Severity:    ✓ {dict(sev_counts)}")
    print("=" * 70)

    return True


if __name__ == "__main__":
    # Check if moto is running
    import urllib.request
    try:
        urllib.request.urlopen("http://127.0.0.1:5000/moto-api/", timeout=3)
    except Exception:
        print("⚠️  Moto not running on port 5000. Starting it...")
        import subprocess
        subprocess.Popen(["python3", "-m", "moto.server", "-p", "5000", "-H", "127.0.0.1"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(8)

        # Provision resources
        import subprocess
        scanner_dir = os.path.join(os.path.dirname(__file__), "..", "..", "mini-services", "scanner")
        subprocess.run(["python3", "provision.py"], cwd=scanner_dir, env={**os.environ, "AWS_ENDPOINT_URL": "http://127.0.0.1:5000"},
                       capture_output=True)
        subprocess.run(["python3", "provision_v2.py"], cwd=scanner_dir, env={**os.environ, "AWS_ENDPOINT_URL": "http://127.0.0.1:5000"},
                       capture_output=True)

    try:
        success = test_full_pipeline()
        if success:
            print("\n✅ ALL TESTS PASSED")
        else:
            print("\n❌ TESTS FAILED")
            sys.exit(1)
    except Exception as e:
        import traceback
        print(f"\n❌ ERROR: {e}")
        traceback.print_exc()
        sys.exit(1)
