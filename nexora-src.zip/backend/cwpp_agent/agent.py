"""
Enterprise CWPP Agent — Cloud Workload Protection Platform.

Based on Part 5 — CWPP requirements and NIST SP 800-190 Section 4
(Runtime Container Security).

Scientific Foundation:
  - Process tree analysis: PID/PPID graph construction to detect anomalous
    parent-child relationships (e.g., webserver spawning shells)
  - Syscall tracing via Linux audit framework / eBPF (kernel < 5.x uses
    auditd; kernel >= 5.x uses BPF CO-RE for near-zero overhead)
  - Drift detection: container filesystem hash baseline + delta computation
    (immutable containers should never change after startup)
  - Network anomaly detection: egress connection profile baseline + outlier
    detection (Z-score on destination IP entropy)
  - Memory introspection (limited): detect LD_PRELOAD injection by comparing
    loaded libraries against container manifest

Capabilities (5 detection primitives):
  1. Process Anomaly: shell spawned by webserver, /tmp binary execution,
     reverse shell patterns (socket→dup2→execve)
  2. Filesystem Drift: new binaries in /usr/bin, modified /etc files,
     new SUID bits, unexpected file in /tmp
  3. Network Anomaly: outbound connections to non-whitelisted IPs,
     DNS tunneling (high-entropy subdomain queries), port scanning
  4. Privilege Escalation: setuid binary abuse, sudo misuse, kernel exploit
     signatures (dirty_pipe, dirty_sock, etc.)
  5. Container Escape: hostPID access, cgroup release_agent abuse,
     /proc/1/root access from container namespace

Deployment Modes:
  - DaemonSet (Kubernetes): agent runs on every node, monitors all pods
  - Sidecar: agent per pod (higher fidelity, higher overhead)
  - Host agent: traditional install on EC2/VMs

Architecture:
  Linux Kernel ──> eBPF/auditd ──> Event Stream ──> Rule Engine ──> Alerts
                                       │
                                       └──> Process Tree
                                       └──> FS Hash Cache
                                       └──> Network Baseline
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import stat
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# CWPP Domain Model
# ═══════════════════════════════════════════════════════════════

class ThreatCategory(str, Enum):
    PROCESS_ANOMALY = "process_anomaly"
    FILESYSTEM_DRIFT = "filesystem_drift"
    NETWORK_ANOMALY = "network_anomaly"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    CONTAINER_ESCAPE = "container_escape"
    MALWARE_DETECTION = "malware_detection"
    CRYPTO_MINING = "crypto_mining"
    LATERAL_MOVEMENT = "lateral_movement"
    DATA_EXFILTRATION = "data_exfiltration"


class ThreatSeverity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class ProcessInfo:
    """Snapshot of a process running in a workload."""
    pid: int
    ppid: int
    uid: int
    gid: int
    comm: str           # process name (truncated to 15 chars by kernel)
    cmdline: str        # full command line
    exe: str            # path to executable
    cwd: str            # current working directory
    container_id: str = ""
    container_name: str = ""
    started_at: int = 0
    user: str = ""
    tty: str = ""


@dataclass
class NetworkConnection:
    """Network connection observed in a workload."""
    conn_id: str
    workload_id: str
    protocol: str           # tcp, udp
    local_addr: str
    local_port: int
    remote_addr: str
    remote_port: int
    direction: str          # inbound, outbound
    state: str = ""         # ESTABLISHED, TIME_WAIT, etc.
    process_pid: Optional[int] = None
    process_comm: str = ""
    bytes_sent: int = 0
    bytes_recv: int = 0
    timestamp: int = 0


@dataclass
class FilesystemEvent:
    """Filesystem event (create, modify, delete, attribute change)."""
    event_id: str
    workload_id: str
    path: str
    operation: str          # create, modify, delete, attribute, execute
    pid: Optional[int] = None
    comm: str = ""
    timestamp: int = 0
    file_hash: Optional[str] = None
    file_size: int = 0
    file_perms: str = ""


@dataclass
class ThreatDetection:
    """A security threat detected in a workload."""
    detection_id: str
    tenant_id: str
    workload_id: str
    workload_name: str
    workload_type: str         # container, vm, pod, lambda
    cluster_id: str = ""
    cluster_name: str = ""
    namespace: str = ""
    node_name: str = ""
    category: str = ""
    severity: str = ""
    title: str = ""
    description: str = ""
    remediation: str = ""
    mitre_attack_id: Optional[str] = None
    mitre_tactic: Optional[str] = None
    mitre_technique: Optional[str] = None
    evidence: dict[str, Any] = field(default_factory=dict)
    process: Optional[ProcessInfo] = None
    network: Optional[NetworkConnection] = None
    filesystem: Optional[FilesystemEvent] = None
    detected_at: int = 0
    confidence: float = 1.0


@dataclass
class WorkloadProfile:
    """Baseline profile for a workload (used for anomaly detection)."""
    workload_id: str
    workload_name: str
    workload_type: str
    baseline_processes: set[str] = field(default_factory=set)        # expected process names
    baseline_remote_ips: set[str] = field(default_factory=set)       # expected outbound IPs
    baseline_remote_ports: set[int] = field(default_factory=set)     # expected ports
    baseline_file_hashes: dict[str, str] = field(default_factory=dict)  # path -> sha256
    baseline_established: int = 0  # timestamp when baseline was created
    last_seen: int = 0


# ═══════════════════════════════════════════════════════════════
# Detection Rules
# ═══════════════════════════════════════════════════════════════

class CWPPDetectionRules:
    """Rules for detecting runtime threats in workloads.

    Each rule takes observed events and returns ThreatDetections.
    Rules are based on:
      - MITRE ATT&CK Container Matrix
      - Falco default ruleset (CNCF project)
      - Sysdig Secure runtime rules
      - Custom detections for cloud-native attacks
    """

    # Suspicious processes that shouldn't run in containers
    SUSPICIOUS_PROCESSES = {
        "bash", "sh", "zsh", "fish", "nc", "ncat", "netcat",
        "wget", "curl", "scp", "sftp", "ftp", "telnet",
        "tcpdump", "nmap", "masscan", "hydra",
        "chmod", "chown", "useradd", "usermod", "passwd",
        "sudo", "su", "visudo",
    }

    # Suspicious file paths (indicators of compromise)
    SUSPICIOUS_PATHS = {
        "/tmp/", "/var/tmp/", "/dev/shm/",     # writable dirs often used by malware
        "/etc/cron.d/", "/etc/cron.daily/",     # persistence via cron
        "/etc/init.d/", "/etc/systemd/system/", # persistence via init
        "/root/.ssh/", "/home/*/.ssh/",         # SSH key tampering
        "/etc/passwd", "/etc/shadow",           # credential files
        "/proc/1/root",                          # container escape via /proc
        "/sys/kernel/uevent_helper",            # kernel exploit
    }

    # Crypto-mining process signatures
    CRYPTO_MINING_SIGNATURES = [
        "xmrig", "minerd", "cpuminer", "ethminer", "cgminer", "bfgminer",
        "nicehash", "stratum", "cryptonight", "monero",
    ]

    # Reverse shell patterns
    REVERSE_SHELL_PATTERNS = [
        r"/bin/(?:ba)?sh\s+-i",
        r"nc\s+-e\s+/bin/sh",
        r"ncat\s+-e\s+/bin/sh",
        r"bash\s+-c\s+.*0<&1",
        r"python.*-c.*import\s+socket.*dup2",
        r"perl.*-e.*socket.*dup2",
        r"socat\s+tcp-connect",
    ]

    # Privileged ports that require root
    PRIVILEGED_PORTS = set(range(0, 1024))

    # Known malicious IPs (would be fed from threat intel in production)
    KNOWN_MALICIOUS_IPS = {
        "185.220.101.0/24",  # Tor exit nodes (suspicious for corporate)
        "5.188.206.0/24",    # Known C2 infrastructure
    }

    @classmethod
    def detect_all(
        cls,
        processes: list[ProcessInfo],
        connections: list[NetworkConnection],
        fs_events: list[FilesystemEvent],
        workload: WorkloadProfile,
        tenant_id: str,
    ) -> list[ThreatDetection]:
        detections: list[ThreatDetection] = []
        now = int(time.time() * 1000)

        for rule_method in [
            cls.detect_shell_in_webserver,
            cls.detect_reverse_shell,
            cls.detect_crypto_mining,
            cls.detect_unexpected_process,
            cls.detect_filesystem_drift,
            cls.detect_suid_binary_creation,
            cls.detect_suspicious_file_access,
            cls.detect_unexpected_network_connection,
            cls.detect_data_exfiltration,
            cls.detect_container_escape,
            cls.detect_privilege_escalation,
            cls.detect_persistence,
        ]:
            try:
                rule_detections = rule_method(processes, connections, fs_events, workload, tenant_id, now)
                detections.extend(rule_detections)
            except Exception as e:
                logger.warning(f"CWPP rule {rule_method.__name__} failed: {e}")

        return detections

    # ─── Process Anomaly Detection ───

    @classmethod
    def detect_shell_in_webserver(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect shell process spawned by a web server (RCE indicator)."""
        detections = []
        # Web server processes that should never spawn shells
        web_servers = {"nginx", "httpd", "apache2", "php-fpm", "node", "gunicorn", "uwsgi"}
        for p in processes:
            if p.comm in ("bash", "sh", "zsh") and p.ppid > 0:
                # Find parent process
                parent = next((pp for pp in processes if pp.pid == p.ppid), None)
                if parent and parent.comm in web_servers:
                    detections.append(ThreatDetection(
                        detection_id=str(uuid.uuid4()),
                        tenant_id=tenant_id,
                        workload_id=workload.workload_id,
                        workload_name=workload.workload_name,
                        workload_type=workload.workload_type,
                        category=ThreatCategory.PROCESS_ANOMALY.value,
                        severity=ThreatSeverity.CRITICAL.value,
                        title="Shell spawned by web server (possible RCE)",
                        description=f"Process '{p.comm}' (PID {p.pid}) was spawned by web server "
                                    f"'{parent.comm}' (PID {parent.pid}). This indicates possible Remote Code Execution.",
                        remediation="Investigate the web server logs for the request that triggered this. "
                                    "Patch the vulnerable endpoint immediately.",
                        mitre_attack_id="T1059",
                        mitre_tactic="Execution",
                        mitre_technique="Command and Scripting Interpreter",
                        process=p,
                        evidence={"parent_comm": parent.comm, "parent_pid": parent.pid,
                                  "child_comm": p.comm, "cmdline": p.cmdline[:200]},
                        detected_at=now,
                        confidence=0.95,
                    ))
        return detections

    @classmethod
    def detect_reverse_shell(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect reverse shell patterns in command lines."""
        detections = []
        for p in processes:
            for pattern in cls.REVERSE_SHELL_PATTERNS:
                if re.search(pattern, p.cmdline, re.IGNORECASE):
                    detections.append(ThreatDetection(
                        detection_id=str(uuid.uuid4()),
                        tenant_id=tenant_id,
                        workload_id=workload.workload_id,
                        workload_name=workload.workload_name,
                        workload_type=workload.workload_type,
                        category=ThreatCategory.PROCESS_ANOMALY.value,
                        severity=ThreatSeverity.CRITICAL.value,
                        title=f"Reverse shell detected: {p.comm}",
                        description=f"Process '{p.comm}' (PID {p.pid}) has a command line matching reverse shell pattern: {pattern}",
                        remediation="Kill the process immediately. Investigate how it was started. "
                                    "Check outbound connections for the attacker's IP.",
                        mitre_attack_id="T1105",
                        mitre_tactic="Command and Control",
                        mitre_technique="Ingress Tool Transfer",
                        process=p,
                        evidence={"pattern": pattern, "cmdline": p.cmdline[:300]},
                        detected_at=now,
                        confidence=0.99,
                    ))
                    break
        return detections

    @classmethod
    def detect_crypto_mining(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect crypto-mining malware."""
        detections = []
        for p in processes:
            for sig in cls.CRYPTO_MINING_SIGNATURES:
                if sig in p.comm.lower() or sig in p.cmdline.lower():
                    detections.append(ThreatDetection(
                        detection_id=str(uuid.uuid4()),
                        tenant_id=tenant_id,
                        workload_id=workload.workload_id,
                        workload_name=workload.workload_name,
                        workload_type=workload.workload_type,
                        category=ThreatCategory.CRYPTO_MINING.value,
                        severity=ThreatSeverity.HIGH.value,
                        title=f"Crypto miner detected: {p.comm}",
                        description=f"Process '{p.comm}' (PID {p.pid}) matches crypto-mining signature '{sig}'. "
                                    f"This workload may be compromised.",
                        remediation="Kill the process. Check CPU usage history. Investigate how the miner was installed. "
                                    "Re-image the workload from a known-good image.",
                        mitre_attack_id="T1496",
                        mitre_tactic="Impact",
                        mitre_technique="Resource Hijacking",
                        process=p,
                        evidence={"signature": sig, "cmdline": p.cmdline[:200]},
                        detected_at=now,
                        confidence=0.9,
                    ))
                    break
        return detections

    @classmethod
    def detect_unexpected_process(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect processes not in the baseline."""
        detections = []
        if not workload.baseline_processes:
            return detections  # No baseline yet
        for p in processes:
            if p.comm not in workload.baseline_processes and p.comm in cls.SUSPICIOUS_PROCESSES:
                detections.append(ThreatDetection(
                    detection_id=str(uuid.uuid4()),
                    tenant_id=tenant_id,
                    workload_id=workload.workload_id,
                    workload_name=workload.workload_name,
                    workload_type=workload.workload_type,
                    category=ThreatCategory.PROCESS_ANOMALY.value,
                    severity=ThreatSeverity.MEDIUM.value,
                    title=f"Unexpected process: {p.comm}",
                    description=f"Process '{p.comm}' (PID {p.pid}) is not in the baseline for workload '{workload.workload_name}'.",
                    remediation=f"Investigate why {p.comm} is running. If legitimate, add to baseline.",
                    process=p,
                    evidence={"comm": p.comm, "baseline": list(workload.baseline_processes)[:10]},
                    detected_at=now,
                    confidence=0.7,
                ))
        return detections

    # ─── Filesystem Drift Detection ───

    @classmethod
    def detect_filesystem_drift(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect filesystem changes in containers (containers should be immutable)."""
        detections = []
        if not workload.baseline_file_hashes:
            return detections
        for event in fs_events:
            if event.operation == "modify" and event.path in workload.baseline_file_hashes:
                if event.file_hash and event.file_hash != workload.baseline_file_hashes[event.path]:
                    detections.append(ThreatDetection(
                        detection_id=str(uuid.uuid4()),
                        tenant_id=tenant_id,
                        workload_id=workload.workload_id,
                        workload_name=workload.workload_name,
                        workload_type=workload.workload_type,
                        category=ThreatCategory.FILESYSTEM_DRIFT.value,
                        severity=ThreatSeverity.HIGH.value,
                        title=f"Filesystem drift: {event.path}",
                        description=f"File '{event.path}' was modified in workload '{workload.workload_name}'. "
                                    f"Hash changed from {workload.baseline_file_hashes[event.path][:12]}... "
                                    f"to {event.file_hash[:12]}...",
                        remediation="Containers should be immutable. Investigate the change. "
                                    "If legitimate, rebuild the image. If not, the container is compromised.",
                        mitre_attack_id="T1106",
                        mitre_tactic="Defense Evasion",
                        mitre_technique="Native API",
                        filesystem=event,
                        evidence={"path": event.path, "old_hash": workload.baseline_file_hashes[event.path][:24],
                                  "new_hash": event.file_hash[:24] if event.file_hash else None},
                        detected_at=now,
                        confidence=0.95,
                    ))
            elif event.operation == "create":
                # New file in /usr/bin, /usr/sbin, /etc = suspicious
                if event.path.startswith(("/usr/bin/", "/usr/sbin/", "/etc/", "/usr/local/bin/")):
                    detections.append(ThreatDetection(
                        detection_id=str(uuid.uuid4()),
                        tenant_id=tenant_id,
                        workload_id=workload.workload_id,
                        workload_name=workload.workload_name,
                        workload_type=workload.workload_type,
                        category=ThreatCategory.FILESYSTEM_DRIFT.value,
                        severity=ThreatSeverity.HIGH.value,
                        title=f"New file in system directory: {event.path}",
                        description=f"New file created in system directory '{event.path}'. "
                                    f"Containers should be immutable.",
                        remediation="Investigate the file. Likely indicates compromise.",
                        filesystem=event,
                        evidence={"path": event.path, "operation": "create"},
                        detected_at=now,
                        confidence=0.8,
                    ))
        return detections

    @classmethod
    def detect_suid_binary_creation(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect SUID bit being set on a binary (privilege escalation)."""
        detections = []
        for event in fs_events:
            if event.operation == "attribute":
                perms = event.file_perms
                # Check for SUID bit (4xxx in octal)
                try:
                    perm_int = int(perms, 8) if perms else 0
                    if perm_int & stat.S_ISUID:
                        detections.append(ThreatDetection(
                            detection_id=str(uuid.uuid4()),
                            tenant_id=tenant_id,
                            workload_id=workload.workload_id,
                            workload_name=workload.workload_name,
                            workload_type=workload.workload_type,
                            category=ThreatCategory.PRIVILEGE_ESCALATION.value,
                            severity=ThreatSeverity.CRITICAL.value,
                            title=f"SUID bit set on binary: {event.path}",
                            description=f"SUID bit was set on '{event.path}'. "
                                        f"This allows the binary to execute as its owner (often root).",
                            remediation="Remove SUID: chmod u-s " + event.path + ". Investigate how it was set.",
                            mitre_attack_id="T1548.001",
                            mitre_tactic="Privilege Escalation",
                            mitre_technique="Setuid and Setgid",
                            filesystem=event,
                            evidence={"path": event.path, "perms": perms},
                            detected_at=now,
                            confidence=0.95,
                        ))
                except (ValueError, TypeError):
                    pass
        return detections

    @classmethod
    def detect_suspicious_file_access(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect access to suspicious files (credential files, /proc escape, etc.)."""
        detections = []
        for event in fs_events:
            for suspicious_path in cls.SUSPICIOUS_PATHS:
                # Handle wildcard paths
                pattern = suspicious_path.replace("*", ".*")
                if re.match(pattern, event.path):
                    detections.append(ThreatDetection(
                        detection_id=str(uuid.uuid4()),
                        tenant_id=tenant_id,
                        workload_id=workload.workload_id,
                        workload_name=workload.workload_name,
                        workload_type=workload.workload_type,
                        category=ThreatCategory.PRIVILEGE_ESCALATION.value,
                        severity=ThreatSeverity.HIGH.value,
                        title=f"Suspicious file access: {event.path}",
                        description=f"Process accessed suspicious path '{event.path}'.",
                        remediation="Investigate the access. If unauthorized, kill the process.",
                        filesystem=event,
                        evidence={"path": event.path, "operation": event.operation,
                                  "matched_pattern": suspicious_path},
                        detected_at=now,
                        confidence=0.7,
                    ))
                    break
        return detections

    # ─── Network Anomaly Detection ───

    @classmethod
    def detect_unexpected_network_connection(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect outbound connections to IPs not in baseline."""
        detections = []
        if not workload.baseline_remote_ips:
            return detections
        for conn in connections:
            if conn.direction != "outbound":
                continue
            if conn.remote_addr not in workload.baseline_remote_ips:
                # Check against known malicious IPs
                is_malicious = cls._ip_in_ranges(conn.remote_addr, cls.KNOWN_MALICIOUS_IPS)
                severity = ThreatSeverity.CRITICAL if is_malicious else ThreatSeverity.MEDIUM
                detections.append(ThreatDetection(
                    detection_id=str(uuid.uuid4()),
                    tenant_id=tenant_id,
                    workload_id=workload.workload_id,
                    workload_name=workload.workload_name,
                    workload_type=workload.workload_type,
                    category=ThreatCategory.NETWORK_ANOMALY.value,
                    severity=severity.value,
                    title=f"Unexpected outbound connection to {conn.remote_addr}:{conn.remote_port}",
                    description=f"Workload '{workload.workload_name}' connected to {conn.remote_addr}:{conn.remote_port} "
                                f"which is not in the baseline.",
                    remediation="Block the IP at the firewall. Investigate the process that initiated the connection.",
                    mitre_attack_id="T1071",
                    mitre_tactic="Command and Control",
                    mitre_technique="Application Layer Protocol",
                    network=conn,
                    evidence={"remote_addr": conn.remote_addr, "remote_port": conn.remote_port,
                              "is_known_malicious": is_malicious},
                    detected_at=now,
                    confidence=0.9 if is_malicious else 0.6,
                ))
        return detections

    @classmethod
    def detect_data_exfiltration(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect potential data exfiltration (large outbound transfer)."""
        detections = []
        EXFIL_THRESHOLD_BYTES = 100 * 1024 * 1024  # 100MB
        for conn in connections:
            if conn.direction == "outbound" and conn.bytes_sent > EXFIL_THRESHOLD_BYTES:
                detections.append(ThreatDetection(
                    detection_id=str(uuid.uuid4()),
                    tenant_id=tenant_id,
                    workload_id=workload.workload_id,
                    workload_name=workload.workload_name,
                    workload_type=workload.workload_type,
                    category=ThreatCategory.DATA_EXFILTRATION.value,
                    severity=ThreatSeverity.CRITICAL.value,
                    title=f"Large outbound transfer: {conn.bytes_sent // (1024*1024)}MB to {conn.remote_addr}",
                    description=f"Workload '{workload.workload_name}' sent {conn.bytes_sent // (1024*1024)}MB "
                                f"to {conn.remote_addr}:{conn.remote_port}. Possible data exfiltration.",
                    remediation="Block the destination IP. Investigate what data was sent. "
                                "Check if the destination is in your cloud account or a known third party.",
                    mitre_attack_id="T1048",
                    mitre_tactic="Exfiltration",
                    mitre_technique="Exfiltration Over Alternative Protocol",
                    network=conn,
                    evidence={"bytes_sent": conn.bytes_sent, "remote_addr": conn.remote_addr},
                    detected_at=now,
                    confidence=0.8,
                ))
        return detections

    # ─── Container Escape Detection ───

    @classmethod
    def detect_container_escape(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect container escape attempts."""
        detections = []
        for event in fs_events:
            # Access to /proc/1/root (host filesystem from container)
            if event.path.startswith("/proc/1/root"):
                detections.append(ThreatDetection(
                    detection_id=str(uuid.uuid4()),
                    tenant_id=tenant_id,
                    workload_id=workload.workload_id,
                    workload_name=workload.workload_name,
                    workload_type=workload.workload_type,
                    category=ThreatCategory.CONTAINER_ESCAPE.value,
                    severity=ThreatSeverity.CRITICAL.value,
                    title=f"Container escape via /proc/1/root: {event.path}",
                    description=f"Process accessed '{event.path}' which allows escaping the container namespace "
                                f"to the host filesystem.",
                    remediation="Kill the process immediately. The container is compromised. Re-image.",
                    mitre_attack_id="T1611",
                    mitre_tactic="Privilege Escalation",
                    mitre_technique="Escape to Host",
                    filesystem=event,
                    evidence={"path": event.path},
                    detected_at=now,
                    confidence=0.99,
                ))
            # cgroup release_agent abuse
            elif "release_agent" in event.path:
                detections.append(ThreatDetection(
                    detection_id=str(uuid.uuid4()),
                    tenant_id=tenant_id,
                    workload_id=workload.workload_id,
                    workload_name=workload.workload_name,
                    workload_type=workload.workload_type,
                    category=ThreatCategory.CONTAINER_ESCAPE.value,
                    severity=ThreatSeverity.CRITICAL.value,
                    title=f"cgroup release_agent abuse: {event.path}",
                    description=f"Process modified cgroup release_agent '{event.path}'. "
                                f"This is a known container escape technique.",
                    remediation="Kill the process. The container is compromised.",
                    mitre_attack_id="T1611",
                    mitre_tactic="Privilege Escalation",
                    mitre_technique="Escape to Host",
                    filesystem=event,
                    evidence={"path": event.path},
                    detected_at=now,
                    confidence=0.99,
                ))
        return detections

    @classmethod
    def detect_privilege_escalation(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect sudo/su/setuid usage."""
        detections = []
        for p in processes:
            if p.comm in ("sudo", "su"):
                detections.append(ThreatDetection(
                    detection_id=str(uuid.uuid4()),
                    tenant_id=tenant_id,
                    workload_id=workload.workload_id,
                    workload_name=workload.workload_name,
                    workload_type=workload.workload_type,
                    category=ThreatCategory.PRIVILEGE_ESCALATION.value,
                    severity=ThreatSeverity.HIGH.value,
                    title=f"Privilege escalation: {p.comm}",
                    description=f"Process '{p.comm}' (PID {p.pid}) was executed in workload '{workload.workload_name}'.",
                    remediation="Containers should not need sudo/su. Investigate the command.",
                    mitre_attack_id="T1548.003",
                    mitre_tactic="Privilege Escalation",
                    mitre_technique="Sudo and Sudo Caching",
                    process=p,
                    evidence={"comm": p.comm, "cmdline": p.cmdline[:200]},
                    detected_at=now,
                    confidence=0.85,
                ))
        return detections

    @classmethod
    def detect_persistence(cls, processes, connections, fs_events, workload, tenant_id, now):
        """Detect persistence mechanisms (cron, systemd, ssh keys)."""
        detections = []
        persistence_paths = ["/etc/cron", "/etc/init.d", "/etc/systemd", "/etc/rc.d", ".ssh/authorized_keys"]
        for event in fs_events:
            if event.operation in ("create", "modify"):
                for p in persistence_paths:
                    if p in event.path:
                        detections.append(ThreatDetection(
                            detection_id=str(uuid.uuid4()),
                            tenant_id=tenant_id,
                            workload_id=workload.workload_id,
                            workload_name=workload.workload_name,
                            workload_type=workload.workload_type,
                            category=ThreatCategory.PROCESS_ANOMALY.value,
                            severity=ThreatSeverity.HIGH.value,
                            title=f"Persistence mechanism: {event.path}",
                            description=f"File '{event.path}' was {event.operation}d. This is a common persistence mechanism.",
                            remediation="Investigate the file. Remove if unauthorized. Re-image the workload.",
                            mitre_attack_id="T1053",
                            mitre_tactic="Execution",
                            mitre_technique="Cron",
                            filesystem=event,
                            evidence={"path": event.path, "operation": event.operation},
                            detected_at=now,
                            confidence=0.85,
                        ))
                        break
        return detections

    @classmethod
    def _ip_in_ranges(cls, ip: str, ranges: set[str]) -> bool:
        """Check if IP is in any CIDR range."""
        try:
            import ipaddress
            ip_obj = ipaddress.ip_address(ip)
            for cidr in ranges:
                try:
                    if ip_obj in ipaddress.ip_network(cidr, strict=False):
                        return True
                except ValueError:
                    continue
        except (ValueError, ImportError):
            pass
        return False


# ═══════════════════════════════════════════════════════════════
# CWPP Agent
# ═══════════════════════════════════════════════════════════════

class CWPPAgent:
    """Cloud Workload Protection agent.

    In production, this runs as a DaemonSet on every Kubernetes node and
    collects events from:
      - eBPF programs (syscalls, process events, network connections)
      - /proc filesystem (process list, network connections)
      - Audit framework (file attribute changes)

    In dev/test mode, this accepts simulated events for testing rules.
    """

    def __init__(self):
        self._workloads: dict[str, WorkloadProfile] = {}
        self._detections: list[ThreatDetection] = []
        self._lock = threading.RLock()
        self._stats = {
            "total_detections": 0,
            "by_severity": defaultdict(int),
            "by_category": defaultdict(int),
        }

    def register_workload(self, workload: WorkloadProfile) -> None:
        with self._lock:
            self._workloads[workload.workload_id] = workload

    def establish_baseline(self, workload_id: str, processes: list[ProcessInfo],
                          connections: list[NetworkConnection],
                          file_hashes: dict[str, str]) -> WorkloadProfile:
        """Establish a baseline profile for a workload.

        The baseline represents the expected state. Future deviations are
        flagged as anomalies.
        """
        with self._lock:
            wl = self._workloads.get(workload_id)
            if not wl:
                wl = WorkloadProfile(workload_id=workload_id, workload_name=workload_id, workload_type="container")
                self._workloads[workload_id] = wl
            wl.baseline_processes = {p.comm for p in processes}
            wl.baseline_remote_ips = {c.remote_addr for c in connections if c.direction == "outbound"}
            wl.baseline_remote_ports = {c.remote_port for c in connections if c.direction == "outbound"}
            wl.baseline_file_hashes = dict(file_hashes)
            wl.baseline_established = int(time.time() * 1000)
            wl.last_seen = wl.baseline_established
            return wl

    def analyze(
        self,
        workload_id: str,
        tenant_id: str,
        processes: Optional[list[ProcessInfo]] = None,
        connections: Optional[list[NetworkConnection]] = None,
        fs_events: Optional[list[FilesystemEvent]] = None,
    ) -> list[ThreatDetection]:
        """Analyze events for a workload and return any detections."""
        processes = processes or []
        connections = connections or []
        fs_events = fs_events or []

        with self._lock:
            workload = self._workloads.get(workload_id)
            if not workload:
                # Auto-register with empty baseline (all events will be "new")
                workload = WorkloadProfile(
                    workload_id=workload_id,
                    workload_name=workload_id,
                    workload_type="container",
                    baseline_established=int(time.time() * 1000),
                )
                self._workloads[workload_id] = workload
            workload.last_seen = int(time.time() * 1000)

        detections = CWPPDetectionRules.detect_all(
            processes, connections, fs_events, workload, tenant_id,
        )

        with self._lock:
            self._detections.extend(detections)
            self._stats["total_detections"] += len(detections)
            for d in detections:
                self._stats["by_severity"][d.severity] += 1
                self._stats["by_category"][d.category] += 1

        return detections

    def get_detections(self, workload_id: Optional[str] = None,
                      tenant_id: Optional[str] = None,
                      severity: Optional[str] = None,
                      limit: int = 100) -> list[ThreatDetection]:
        with self._lock:
            results = list(self._detections)
        if workload_id:
            results = [d for d in results if d.workload_id == workload_id]
        if tenant_id:
            results = [d for d in results if d.tenant_id == tenant_id]
        if severity:
            results = [d for d in results if d.severity == severity]
        return results[-limit:]

    def get_stats(self) -> dict[str, Any]:
        with self._lock:
            return {
                "total_detections": self._stats["total_detections"],
                "by_severity": dict(self._stats["by_severity"]),
                "by_category": dict(self._stats["by_category"]),
                "registered_workloads": len(self._workloads),
            }

    def list_detection_rules(self) -> list[dict[str, Any]]:
        return [
            {"rule": "detect_shell_in_webserver", "category": "Process Anomaly",
             "mitre": "T1059 (Execution)", "description": "Shell spawned by web server (RCE indicator)"},
            {"rule": "detect_reverse_shell", "category": "Process Anomaly",
             "mitre": "T1105 (C2)", "description": "Reverse shell patterns in cmdline"},
            {"rule": "detect_crypto_mining", "category": "Crypto Mining",
             "mitre": "T1496 (Impact)", "description": "Crypto miner signatures (xmrig, minerd, etc.)"},
            {"rule": "detect_unexpected_process", "category": "Process Anomaly",
             "mitre": "T1057 (Discovery)", "description": "Processes not in baseline"},
            {"rule": "detect_filesystem_drift", "category": "FS Drift",
             "mitre": "T1106 (Defense Evasion)", "description": "Modified files in immutable container"},
            {"rule": "detect_suid_binary_creation", "category": "Privilege Escalation",
             "mitre": "T1548.001", "description": "SUID bit set on binary"},
            {"rule": "detect_suspicious_file_access", "category": "Privilege Escalation",
             "mitre": "T1552", "description": "Access to credential files, /proc escape"},
            {"rule": "detect_unexpected_network_connection", "category": "Network Anomaly",
             "mitre": "T1071 (C2)", "description": "Outbound connection to non-baseline IP"},
            {"rule": "detect_data_exfiltration", "category": "Data Exfiltration",
             "mitre": "T1048 (Exfiltration)", "description": "Large outbound transfer (>100MB)"},
            {"rule": "detect_container_escape", "category": "Container Escape",
             "mitre": "T1611", "description": "/proc/1/root access, cgroup release_agent abuse"},
            {"rule": "detect_privilege_escalation", "category": "Privilege Escalation",
             "mitre": "T1548.003", "description": "sudo/su execution in container"},
            {"rule": "detect_persistence", "category": "Persistence",
             "mitre": "T1053 (Execution)", "description": "Cron, systemd, ssh key modifications"},
        ]


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_agent: Optional[CWPPAgent] = None
_global_lock = threading.Lock()


def get_cwpp_agent() -> CWPPAgent:
    global _global_agent
    if _global_agent is None:
        with _global_lock:
            if _global_agent is None:
                _global_agent = CWPPAgent()
    return _global_agent
