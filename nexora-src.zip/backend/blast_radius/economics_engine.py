"""
Exploit Economics Engine — calculates ROI of exploitation vs remediation.

THIS IS THE SECOND KILLER DIFFERENTIATOR. Nobody in CNAPP does this.

Problem:
  Security teams are overwhelmed with 1000s of findings. Which to fix first?
  CVSS doesn't help — 50% of CRITICAL CVEs are never exploited.
  EPSS helps but doesn't account for business impact.

  What if we told you: "This finding costs $200 to exploit, $50 to fix,
  and if exploited, costs you $500K. Fix it NOW."
  vs "This finding costs $50K to exploit, $200 to fix, and if exploited
  costs $1K. Defer it."

Our approach:
  For each finding, calculate:
    1. Exploit Cost (EC): how much would it cost an attacker to exploit?
       - Based on CVSS Attack Complexity, Privileges Required, User Interaction
       - Adjusted for exploit availability (public exploit = cheap)
       - Market rate for exploit kits / 0-day brokers

    2. Exploit Revenue (ER): how much would attacker gain?
       - Data theft value (PII on dark web: $1-50/record)
       - Ransomware potential
       - Cryptomining potential
       - Credential theft value

    3. Remediation Cost (RC): how much does it cost to fix?
       - Engineering hours × hourly rate
       - Testing + deployment
       - Downtime risk
       - Rollback risk

    4. Expected Loss (EL): P(exploit) × Impact

    5. ROI of Remediation: (EL - RC) / RC
       If ROI > 1: fix immediately (saves more than it costs)
       If ROI < 0: defer (fixing costs more than expected loss)

This is grounded in:
  - Gordon-Loeb Model (economics of information security investment)
  - IBM Cost of Data Breach Report
  - Dark web price index (Sophos, Trustwave)
  - NIST SP 800-30 risk quantification
"""
from __future__ import annotations

import logging
import math
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Economics Domain Model
# ═══════════════════════════════════════════════════════════════

class RemediationPriority(str, Enum):
    FIX_NOW = "fix_now"           # ROI > 10 — fixing saves 10x+ the cost
    FIX_SOON = "fix_soon"         # ROI > 1 — fixing saves more than it costs
    DEFER = "defer"               # ROI < 1 but > 0 — fixing is net positive
    IGNORE = "ignore"            # ROI < 0 — fixing costs more than expected loss
    MONITOR = "monitor"          # can't calculate ROI — monitor for changes


@dataclass
class FindingEconomics:
    """Economic analysis of a single security finding."""
    finding_id: str
    finding_title: str
    severity: str
    # Exploit economics
    exploit_cost: float          # USD — cost to attacker
    exploit_revenue: float       # USD — gain to attacker
    exploit_roi: float           # (revenue - cost) / cost — attacker's ROI
    attacker_motivated: bool     # is exploit profitable for attacker?
    # Remediation economics
    remediation_cost: float      # USD — cost to fix
    remediation_hours: float     # engineering hours
    remediation_risk: str        # low, medium, high (risk of breaking something)
    # Risk economics
    exploit_probability: float   # P(exploit) from EPSS or CVSS
    expected_loss: float         # P(exploit) × impact
    # Decision
    remediation_roi: float       # (expected_loss - remediation_cost) / remediation_cost
    priority: str                # RemediationPriority value
    priority_reason: str         # why this priority?
    # Comparison
    cost_ratio: float            # remediation_cost / exploit_cost
    # Metadata
    resource_name: str = ""
    resource_type: str = ""
    cvss_score: float = 0.0
    epss_score: float = 0.0
    industry: str = "general"
    assessed_at: int = 0


@dataclass
class EconomicsAssessment:
    """Complete economics assessment for a set of findings."""
    assessment_id: str
    tenant_id: str
    total_findings: int
    # Summary
    total_expected_loss: float       # sum of all EL
    total_remediation_cost: float    # cost to fix everything
    total_remediation_savings: float # expected_loss - remediation_cost
    overall_roi: float               # total ROI of fixing everything
    # By priority
    fix_now_count: int
    fix_soon_count: int
    defer_count: int
    ignore_count: int
    monitor_count: int
    # Top findings by ROI
    top_fix_now: list[FindingEconomics]
    top_defer: list[FindingEconomics]
    # Budget optimization
    optimal_fix_set: list[FindingEconomics]  # best ROI within budget
    optimal_budget: float                    # the budget used
    optimal_savings: float                   # expected savings from optimal set
    # Metadata
    assessed_at: int = 0
    duration_ms: int = 0


# ═══════════════════════════════════════════════════════════════
# Exploit Cost Model (attacker's perspective)
# ═══════════════════════════════════════════════════════════════

class ExploitCostModel:
    """Calculates the cost for an attacker to exploit a finding.

    Based on:
      - CVSS Attack Vector (AV): network = cheap, physical = expensive
      - CVSS Attack Complexity (AC): low = cheap, high = expensive
      - CVSS Privileges Required (PR): none = cheap, high = expensive
      - CVSS User Interaction (UI): none = cheap, required = expensive
      - Exploit availability: public exploit = very cheap
      - Dark web exploit prices (Trustwave Cybersecurity Economics Report)

    Market data (dark web prices, 2024):
      - RCE exploit for popular CMS: $500-$5,000
      - 0-day for major software: $50,000-$500,000
      - Credential stuffing tool: $50/month
      - Ransomware kit (RaaS): $500 + 30% of ransom
      - Cryptomining malware: free (open source)
    """

    # Base cost by CVSS Attack Vector
    AV_COST = {
        "N": 500,      # Network — cheapest (remote, no special access)
        "A": 2000,     # Adjacent — need to be on same network
        "L": 5000,     # Local — need local access
        "P": 20000,    # Physical — need physical access
    }

    # Complexity multiplier
    AC_MULTIPLIER = {
        "L": 1.0,      # Low complexity — automated, cheap
        "H": 5.0,      # High complexity — manual, expensive
    }

    # Privilege multiplier
    PR_MULTIPLIER = {
        "N": 1.0,      # No privileges needed
        "L": 2.0,      # Low privileges
        "H": 5.0,      # High privileges
    }

    # User interaction multiplier
    UI_MULTIPLIER = {
        "N": 1.0,      # No interaction needed
        "R": 3.0,      # Requires user interaction (phishing, etc.)
    }

    @classmethod
    def calculate_exploit_cost(
        cls,
        cvss_vector: str = "",
        cvss_score: float = 0.0,
        has_public_exploit: bool = False,
        exploit_type: str = "vulnerability",
    ) -> float:
        """Calculate cost for attacker to exploit.

        Returns: estimated cost in USD
        """
        # If public exploit exists, cost drops dramatically
        if has_public_exploit:
            # Public exploit = just need to run a script
            base_cost = 100  # $100 — script kiddie level
            # Adjust by CVSS (higher CVSS = easier to find target)
            if cvss_score >= 9.0:
                base_cost = 50   # trivial
            elif cvss_score >= 7.0:
                base_cost = 200
            elif cvss_score >= 4.0:
                base_cost = 500
            else:
                base_cost = 1000
            return base_cost

        # Parse CVSS vector for attack metrics
        av = "N"  # default: network
        ac = "L"  # default: low complexity
        pr = "N"  # default: no privileges
        ui = "N"  # default: no user interaction

        if cvss_vector:
            parts = cvss_vector.split("/")
            for part in parts:
                if part.startswith("AV:"):
                    av = part.split(":")[1]
                elif part.startswith("AC:"):
                    ac = part.split(":")[1]
                elif part.startswith("PR:"):
                    pr = part.split(":")[1]
                elif part.startswith("UI:"):
                    ui = part.split(":")[1]

        # Calculate cost using multipliers
        base = cls.AV_COST.get(av, 500)
        cost = base * cls.AC_MULTIPLIER.get(ac, 1.0) * cls.PR_MULTIPLIER.get(pr, 1.0) * cls.UI_MULTIPLIER.get(ui, 1.0)

        # Adjust by exploit type
        if exploit_type == "misconfiguration":
            cost *= 0.5  # misconfigurations are easier to exploit
        elif exploit_type == "privilege_escalation":
            cost *= 2.0  # privesc is harder
        elif exploit_type == "container_escape":
            cost *= 5.0  # container escapes are very hard

        return round(cost, 2)


# ═══════════════════════════════════════════════════════════════
# Exploit Revenue Model (attacker's gain)
# ═══════════════════════════════════════════════════════════════

class ExploitRevenueModel:
    """Calculates revenue an attacker can gain from exploiting a finding.

    Based on:
      - Dark web data prices (Sophos State of Ransomware 2024)
      - IBM Cost of Data Breach Report 2024
      - Verizon DBIR 2024
      - Trustwave Cybersecurity Economics Report

    Dark web prices (per record):
      - Credit card: $5-$110
      - SSN: $0.50-$1.50
      - Email + password: $1-$10
      - Medical record: $50-$250
      - Banking login: $30-$500
      - AWS access key: $10-$100 (on dark web markets)
    """

    # Revenue by finding category
    CATEGORY_REVENUE = {
        "storage": 50000,          # S3 bucket = data exfiltration
        "database": 200000,        # RDS = PII/PHI records
        "identity": 30000,         # IAM = credential theft
        "network": 10000,          # SG = lateral movement
        "compute": 20000,          # EC2 = cryptomining/ransomware
        "container": 15000,        # Container = resource hijacking
        "vulnerability": 100000,   # CVE = depends on CVE
        "secrets": 50000,          # Secret exposure = account takeover
        "iam": 40000,              # IAM misconfig = privilege escalation
    }

    # Multiplier for PII exposure
    PII_MULTIPLIER = 5.0
    # Multiplier for secrets exposure
    SECRETS_MULTIPLIER = 3.0
    # Multiplier for internet-facing
    INTERNET_MULTIPLIER = 2.0

    @classmethod
    def calculate_exploit_revenue(
        cls,
        finding_category: str = "",
        contains_pii: bool = False,
        contains_secrets: bool = False,
        internet_exposed: bool = False,
        cvss_score: float = 0.0,
        resource_criticality: str = "medium",
    ) -> float:
        """Calculate revenue for attacker from exploiting this finding.

        Returns: estimated revenue in USD
        """
        # Base revenue from category
        base = cls.CATEGORY_REVENUE.get(finding_category, 10000)

        # Adjust for PII
        if contains_pii:
            base *= cls.PII_MULTIPLIER

        # Adjust for secrets
        if contains_secrets:
            base *= cls.SECRETS_MULTIPLIER

        # Adjust for internet exposure
        if internet_exposed:
            base *= cls.INTERNET_MULTIPLIER

        # Adjust for CVSS (higher = more damage)
        if cvss_score > 0:
            base *= (cvss_score / 10.0)

        # Adjust for resource criticality
        criticality_mult = {
            "critical": 3.0,
            "high": 2.0,
            "medium": 1.0,
            "low": 0.5,
        }
        base *= criticality_mult.get(resource_criticality, 1.0)

        return round(base, 2)


# ═══════════════════════════════════════════════════════════════
# Remediation Cost Model (defender's perspective)
# ═══════════════════════════════════════════════════════════════

class RemediationCostModel:
    """Calculates cost for defender to fix a finding.

    Based on:
      - Engineering hourly rate: $100/hr (US average for DevOps)
      - Complexity by rule type (from our remediation templates)
      - Testing + deployment overhead
      - Downtime risk

    Cost factors:
      - Simple config change (e.g., enable encryption): 1 hour = $100
      - Policy change (e.g., restrict SG): 2 hours = $200
      - IAM policy rewrite: 4 hours = $400
      - RDS encryption (requires migration): 40 hours = $4000
      - EKS secrets encryption (requires new cluster): 80 hours = $8000
    """

    # Cost by remediation type (USD)
    REMEDIATION_COSTS = {
        "enable_encryption": 100,         # 1 hour
        "restrict_security_group": 200,   # 2 hours
        "remove_public_access": 150,      # 1.5 hours
        "enable_mfa": 300,               # 3 hours (per user)
        "detach_admin_policy": 500,      # 5 hours (need to design replacement)
        "enable_logging": 200,           # 2 hours
        "patch_vulnerability": 300,      # 3 hours (test + deploy)
        "rotate_secrets": 200,           # 2 hours
        "rds_encryption_migration": 4000, # 40 hours (snapshot + restore)
        "eks_recreate_cluster": 8000,    # 80 hours (blue/green deploy)
        "iam_policy_rewrite": 800,       # 8 hours (analyze + design + implement)
        "container_image_update": 500,   # 5 hours (build + test + deploy)
        "k8s_manifest_fix": 200,         # 2 hours
        "iac_template_fix": 200,         # 2 hours
        "default": 500,                  # default: 5 hours
    }

    # Risk of breaking something during remediation
    REMEDIATION_RISK = {
        "enable_encryption": "low",
        "restrict_security_group": "high",  # may break app connectivity
        "remove_public_access": "medium",   # may break integrations
        "enable_mfa": "low",
        "detach_admin_policy": "high",      # may break automation
        "enable_logging": "low",
        "patch_vulnerability": "medium",
        "rotate_secrets": "medium",
        "rds_encryption_migration": "critical",  # requires downtime
        "eks_recreate_cluster": "critical",
        "iam_policy_rewrite": "medium",
        "container_image_update": "medium",
        "k8s_manifest_fix": "low",
        "iac_template_fix": "low",
        "default": "medium",
    }

    @classmethod
    def calculate_remediation_cost(
        cls,
        remediation_type: str = "default",
        resource_type: str = "",
        rule_id: str = "",
    ) -> tuple[float, float, str]:
        """Calculate remediation cost.

        Returns: (cost_usd, hours, risk_level)
        """
        # Determine remediation type from rule_id if not specified
        if remediation_type == "default" and rule_id:
            remediation_type = cls._infer_type_from_rule(rule_id, resource_type)

        cost = cls.REMEDIATION_COSTS.get(remediation_type, cls.REMEDIATION_COSTS["default"])
        hours = cost / 100  # $100/hr
        risk = cls.REMEDIATION_RISK.get(remediation_type, cls.REMEDIATION_RISK["default"])

        return cost, hours, risk

    @classmethod
    def _infer_type_from_rule(cls, rule_id: str, resource_type: str) -> str:
        """Infer remediation type from rule ID and resource type."""
        rule_lower = rule_id.lower()
        if "encryption" in rule_lower or "encrypted" in rule_lower:
            if "rds" in resource_type or "db" in resource_type:
                return "rds_encryption_migration"
            if "eks" in resource_type:
                return "eks_recreate_cluster"
            return "enable_encryption"
        if "sg" in rule_lower or "security_group" in rule_lower or "ssh" in rule_lower or "rdp" in rule_lower:
            return "restrict_security_group"
        if "public" in rule_lower:
            return "remove_public_access"
        if "mfa" in rule_lower:
            return "enable_mfa"
        if "admin" in rule_lower or "iam" in rule_lower:
            return "detach_admin_policy"
        if "log" in rule_lower or "cloudtrail" in rule_lower:
            return "enable_logging"
        if "patch" in rule_lower or "cve" in rule_lower or "vuln" in rule_lower:
            return "patch_vulnerability"
        if "secret" in rule_lower or "key" in rule_lower:
            return "rotate_secrets"
        return "default"


# ═══════════════════════════════════════════════════════════════
# Exploit Economics Engine
# ═══════════════════════════════════════════════════════════════

class ExploitEconomicsEngine:
    """Calculates economics of exploitation vs remediation for findings.

    This is the decision-support engine that tells security teams:
    "Fix THIS finding first because it has the highest ROI."

    Usage:
        engine = ExploitEconomicsEngine()
        assessment = engine.assess_findings(
            tenant_id="...",
            findings=[...],  # list of finding dicts
            industry="technology",
            budget=10000,  # max budget for remediation
        )
    """

    def assess_findings(
        self,
        tenant_id: str,
        findings: list[dict[str, Any]],
        industry: str = "general",
        budget: float = 10000,
    ) -> EconomicsAssessment:
        """Assess economics for a list of findings.

        Args:
            findings: list of finding dicts with:
                - id, title, severity, category
                - cvss_score, cvss_vector, epss_score
                - resource_type, resource_name
                - exploit_available
                - contains_pii, contains_secrets, internet_exposed
            industry: for impact calculation
            budget: max budget for optimal fix set calculation

        Returns: EconomicsAssessment with per-finding analysis + budget optimization
        """
        start_time = time.time()
        now = int(time.time() * 1000)

        # Analyze each finding
        economics: list[FindingEconomics] = []
        for f in findings:
            econ = self._analyze_finding(f, industry, now)
            economics.append(econ)

        # Summary
        total_expected_loss = sum(e.expected_loss for e in economics)
        total_remediation_cost = sum(e.remediation_cost for e in economics)
        total_savings = total_expected_loss - total_remediation_cost
        overall_roi = (total_savings / total_remediation_cost) if total_remediation_cost > 0 else 0

        # Count by priority
        fix_now = [e for e in economics if e.priority == RemediationPriority.FIX_NOW.value]
        fix_soon = [e for e in economics if e.priority == RemediationPriority.FIX_SOON.value]
        defer = [e for e in economics if e.priority == RemediationPriority.DEFER.value]
        ignore = [e for e in economics if e.priority == RemediationPriority.IGNORE.value]
        monitor = [e for e in economics if e.priority == RemediationPriority.MONITOR.value]

        # Budget optimization: knapsack problem
        # Given budget B, which findings to fix to maximize savings?
        optimal_set = self._optimize_budget(economics, budget)

        return EconomicsAssessment(
            assessment_id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            total_findings=len(findings),
            total_expected_loss=round(total_expected_loss, 2),
            total_remediation_cost=round(total_remediation_cost, 2),
            total_remediation_savings=round(total_savings, 2),
            overall_roi=round(overall_roi, 2),
            fix_now_count=len(fix_now),
            fix_soon_count=len(fix_soon),
            defer_count=len(defer),
            ignore_count=len(ignore),
            monitor_count=len(monitor),
            top_fix_now=sorted(fix_now, key=lambda e: e.remediation_roi, reverse=True)[:10],
            top_defer=sorted(defer, key=lambda e: e.remediation_roi)[:10],
            optimal_fix_set=optimal_set,
            optimal_budget=budget,
            optimal_savings=round(sum(e.expected_loss - e.remediation_cost for e in optimal_set), 2),
            assessed_at=now,
            duration_ms=int((time.time() - start_time) * 1000),
        )

    def _analyze_finding(
        self,
        finding: dict[str, Any],
        industry: str,
        now: int,
    ) -> FindingEconomics:
        """Analyze economics for a single finding."""
        finding_id = finding.get("id", str(uuid.uuid4()))
        title = finding.get("title", "Untitled")
        severity = finding.get("severity", "medium")
        category = finding.get("category", "")
        cvss_score = finding.get("cvss_score", finding.get("cvss_v3_score", 0))
        cvss_vector = finding.get("cvss_vector", finding.get("cvss_v3_vector", ""))
        epss = finding.get("epss_score", 0)
        has_exploit = finding.get("exploit_available", False)
        resource_type = finding.get("resource_type", "")
        resource_name = finding.get("resource_name", "")
        contains_pii = finding.get("contains_pii", False)
        contains_secrets = finding.get("contains_secrets", False)
        internet_exposed = finding.get("internet_exposed", False)
        resource_criticality = finding.get("resource_criticality", "medium")
        rule_id = finding.get("rule_id", "")

        # 1. Exploit cost (attacker's cost)
        exploit_cost = ExploitCostModel.calculate_exploit_cost(
            cvss_vector=cvss_vector,
            cvss_score=cvss_score,
            has_public_exploit=has_exploit,
            exploit_type=category,
        )

        # 2. Exploit revenue (attacker's gain)
        exploit_revenue = ExploitRevenueModel.calculate_exploit_revenue(
            finding_category=category,
            contains_pii=contains_pii,
            contains_secrets=contains_secrets,
            internet_exposed=internet_exposed,
            cvss_score=cvss_score,
            resource_criticality=resource_criticality,
        )

        # Attacker ROI
        if exploit_cost > 0:
            attacker_roi = (exploit_revenue - exploit_cost) / exploit_cost
        else:
            attacker_roi = float('inf') if exploit_revenue > 0 else 0

        attacker_motivated = attacker_roi > 1.0  # profitable for attacker

        # 3. Remediation cost (defender's cost)
        rem_cost, rem_hours, rem_risk = RemediationCostModel.calculate_remediation_cost(
            remediation_type="default",
            resource_type=resource_type,
            rule_id=rule_id,
        )

        # 4. Exploit probability
        if epss > 0:
            exploit_prob = epss
        elif cvss_score > 0:
            exploit_prob = 1.0 / (1.0 + math.exp(-(cvss_score - 5.0) / 2.0))
        else:
            exploit_prob = 0.1  # default for misconfigurations

        # Adjust probability by attacker motivation
        if not attacker_motivated:
            exploit_prob *= 0.3  # less likely if not profitable

        # 5. Expected loss
        expected_loss = exploit_prob * exploit_revenue

        # 6. Remediation ROI
        if rem_cost > 0:
            rem_roi = (expected_loss - rem_cost) / rem_cost
        else:
            rem_roi = float('inf') if expected_loss > 0 else 0

        # 7. Priority decision
        if rem_roi > 10:
            priority = RemediationPriority.FIX_NOW.value
            reason = f"ROI={rem_roi:.1f}x — fixing saves ${expected_loss:.0f} vs ${rem_cost:.0f} cost"
        elif rem_roi > 1:
            priority = RemediationPriority.FIX_SOON.value
            reason = f"ROI={rem_roi:.1f}x — fixing is net positive"
        elif rem_roi > 0:
            priority = RemediationPriority.DEFER.value
            reason = f"ROI={rem_roi:.1f}x — fix later, low priority"
        elif rem_roi > -0.5:
            priority = RemediationPriority.MONITOR.value
            reason = f"ROI={rem_roi:.1f}x — monitor for changes"
        else:
            priority = RemediationPriority.IGNORE.value
            reason = f"ROI={rem_roi:.1f}x — fixing costs more than expected loss"

        # Cost ratio
        cost_ratio = rem_cost / exploit_cost if exploit_cost > 0 else float('inf')

        return FindingEconomics(
            finding_id=finding_id,
            finding_title=title,
            severity=severity,
            exploit_cost=exploit_cost,
            exploit_revenue=exploit_revenue,
            exploit_roi=round(attacker_roi, 2),
            attacker_motivated=attacker_motivated,
            remediation_cost=rem_cost,
            remediation_hours=rem_hours,
            remediation_risk=rem_risk,
            exploit_probability=round(exploit_prob, 4),
            expected_loss=round(expected_loss, 2),
            remediation_roi=round(rem_roi, 2),
            priority=priority,
            priority_reason=reason,
            cost_ratio=round(cost_ratio, 2),
            resource_name=resource_name,
            resource_type=resource_type,
            cvss_score=cvss_score,
            epss_score=epss,
            industry=industry,
            assessed_at=now,
        )

    def _optimize_budget(
        self,
        economics: list[FindingEconomics],
        budget: float,
    ) -> list[FindingEconomics]:
        """Optimize which findings to fix within budget.

        Uses a greedy knapsack approximation: sort by ROI descending,
        then pick findings until budget is exhausted.

        This is O(n log n) — optimal for real-time use.
        """
        # Only consider findings with positive ROI (saves money)
        positive_roi = [e for e in economics if e.remediation_roi > 0]
        # Sort by ROI (savings per dollar spent)
        positive_roi.sort(key=lambda e: e.remediation_roi, reverse=True)

        selected = []
        remaining_budget = budget
        for econ in positive_roi:
            if econ.remediation_cost <= remaining_budget:
                selected.append(econ)
                remaining_budget -= econ.remediation_cost

        return selected


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_engine: Optional[ExploitEconomicsEngine] = None
_global_lock = threading.Lock()


def get_economics_engine() -> ExploitEconomicsEngine:
    global _global_engine
    if _global_engine is None:
        with _global_lock:
            if _global_engine is None:
                _global_engine = ExploitEconomicsEngine()
    return _global_engine
