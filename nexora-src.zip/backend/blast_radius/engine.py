"""
Enterprise Blast Radius Calculator — graph-based impact analysis.

Based on Part 8 — Attack Graph Engine and NIST SP 800-30 (Risk Assessment).

Scientific Foundation:
  - Graph Theory: models cloud infrastructure as a directed graph where
    nodes are assets (S3, EC2, IAM, RDS) and edges are relationships
    (network, IAM trust, data flow, admin access)
  - Blast Radius: given a compromised asset, compute the set of all
    reachable assets via the relationship graph
  - NetworkX: Python library for complex network analysis
    (https://networkx.org/) — provides BFS/DFS, centrality, path finding
  - Centrality Analysis: identifies "choke points" in the infrastructure
    — assets whose compromise would have the largest blast radius
  - Reachability: BFS-based traversal from a starting node, counting
    reachable nodes within N hops

Capabilities:
  1. Blast Radius: given a starting asset, compute all assets reachable
     within N hops (default: unlimited)
  2. Critical Path Analysis: identify the shortest path from internet-
     exposed asset to critical asset (e.g., database with PII)
  3. Centrality: compute betweenness centrality to identify choke points
  4. Asset Impact: for each asset, compute "if compromised, how many
     other assets are at risk?"
  5. Remediation Prioritization: rank assets by blast radius × criticality
  6. Simulation: simulate "what if asset X is compromised?" scenarios

Graph Construction:
  Edges represent:
    - network_access: SG→EC2, LB→EC2 (network reachability)
    - iam_assume_role: User→Role, Role→Role (STS chain)
    - data_flow: EC2→RDS, Lambda→S3 (data plane)
    - admin_access: IAM→ALL (admin role can access everything)
    - cross_account: External→Role (cross-account trust)
"""
from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional

import networkx as nx

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Blast Radius Domain Model
# ═══════════════════════════════════════════════════════════════

class RelationshipType(str, Enum):
    NETWORK_ACCESS = "network_access"
    IAM_ASSUME_ROLE = "iam_assume_role"
    DATA_FLOW = "data_flow"
    ADMIN_ACCESS = "admin_access"
    CROSS_ACCOUNT = "cross_account"
    CONTAINS = "contains"
    READS_FROM = "reads_from"
    WRITES_TO = "writes_to"
    ATTACHED_TO = "attached_to"
    CAN_ACCESS = "can_access"


class BlastRadiusSeverity(str, Enum):
    CRITICAL = "critical"   # >50 assets reachable, or critical asset reachable
    HIGH = "high"           # 10-50 assets reachable
    MEDIUM = "medium"       # 3-10 assets reachable
    LOW = "low"             # 1-2 assets reachable
    NONE = "none"           # 0 assets reachable


@dataclass
class AssetNode:
    """A node in the blast radius graph."""
    asset_id: str
    arn: str
    name: str
    asset_type: str
    category: str            # compute, storage, identity, network, database, etc.
    criticality: str = "low"
    criticality_score: int = 0
    internet_exposed: bool = False
    contains_pii: bool = False
    contains_secrets: bool = False
    encrypted: bool = False
    region: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class RelationshipEdge:
    """An edge in the blast radius graph."""
    source_id: str
    target_id: str
    relationship_type: str   # RelationshipType value
    bidirectional: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class BlastRadiusResult:
    """Result of a blast radius calculation for a starting asset."""
    calculation_id: str
    tenant_id: str
    starting_asset_id: str
    starting_asset_arn: str
    starting_asset_name: str
    # Reachability
    reachable_assets: list[dict[str, Any]] = field(default_factory=list)
    reachable_count: int = 0
    reachable_critical_count: int = 0
    reachable_pii_count: int = 0
    reachable_secrets_count: int = 0
    # Path analysis
    paths: list[dict[str, Any]] = field(default_factory=list)
    max_depth: int = 0
    # Severity
    severity: str = BlastRadiusSeverity.NONE.value
    risk_score: float = 0.0
    # Recommendations
    recommended_actions: list[str] = field(default_factory=dict) if False else field(default_factory=list)
    # Metadata
    calculated_at: int = 0
    duration_ms: int = 0


@dataclass
class CriticalPath:
    """A path from an internet-exposed asset to a critical asset."""
    path_id: str
    source_asset_id: str
    source_asset_name: str
    target_asset_id: str
    target_asset_name: str
    path: list[str]          # list of asset IDs
    path_names: list[str]
    length: int
    risk_score: float
    relationships: list[str]  # relationship types along the path


# ═══════════════════════════════════════════════════════════════
# Blast Radius Calculator
# ═══════════════════════════════════════════════════════════════

class BlastRadiusCalculator:
    """Graph-based blast radius analysis using NetworkX.

    Architecture:
      Asset Inventory ──> Graph Builder ──> NetworkX DiGraph
                                          │
      Query: blast_radius(asset_id) ──────┤
                                          ├──> BFS traversal
                                          ├──> Path analysis
                                          └──> Centrality
    """

    def __init__(self):
        self._graphs: dict[str, nx.DiGraph] = {}  # tenant_id -> graph
        self._assets: dict[str, dict[str, AssetNode]] = defaultdict(dict)  # tenant_id -> asset_id -> node
        self._lock = threading.RLock()

    def add_asset(self, tenant_id: str, asset: AssetNode) -> None:
        """Add an asset to the graph."""
        with self._lock:
            self._assets[tenant_id][asset.asset_id] = asset
            graph = self._get_or_create_graph(tenant_id)
            graph.add_node(
                asset.asset_id,
                arn=asset.arn,
                name=asset.name,
                asset_type=asset.asset_type,
                category=asset.category,
                criticality=asset.criticality,
                criticality_score=asset.criticality_score,
                internet_exposed=asset.internet_exposed,
                contains_pii=asset.contains_pii,
                contains_secrets=asset.contains_secrets,
                encrypted=asset.encrypted,
                region=asset.region,
            )

    def add_relationship(self, tenant_id: str, edge: RelationshipEdge) -> None:
        """Add a relationship edge to the graph."""
        with self._lock:
            graph = self._get_or_create_graph(tenant_id)
            graph.add_edge(
                edge.source_id, edge.target_id,
                relationship_type=edge.relationship_type,
                bidirectional=edge.bidirectional,
                **edge.metadata,
            )
            if edge.bidirectional:
                graph.add_edge(
                    edge.target_id, edge.source_id,
                    relationship_type=edge.relationship_type,
                    bidirectional=True,
                    **edge.metadata,
                )

    def bulk_load(
        self,
        tenant_id: str,
        assets: list[AssetNode],
        relationships: list[RelationshipEdge],
    ) -> None:
        """Bulk load assets and relationships into the graph."""
        for asset in assets:
            self.add_asset(tenant_id, asset)
        for edge in relationships:
            self.add_relationship(tenant_id, edge)

    def _get_or_create_graph(self, tenant_id: str) -> nx.DiGraph:
        if tenant_id not in self._graphs:
            self._graphs[tenant_id] = nx.DiGraph()
        return self._graphs[tenant_id]

    def calculate_blast_radius(
        self,
        tenant_id: str,
        starting_asset_id: str,
        max_depth: int = 10,
    ) -> BlastRadiusResult:
        """Calculate the blast radius of a starting asset.

        Uses BFS to find all assets reachable from the starting asset.

        Args:
            starting_asset_id: The asset to start from (simulated compromise)
            max_depth: Maximum number of hops to traverse

        Returns:
            BlastRadiusResult with reachable assets, paths, and severity
        """
        start_time = time.time()
        with self._lock:
            graph = self._graphs.get(tenant_id)
            assets = self._assets.get(tenant_id, {})

        if not graph or starting_asset_id not in graph:
            return BlastRadiusResult(
                calculation_id=str(uuid.uuid4()),
                tenant_id=tenant_id,
                starting_asset_id=starting_asset_id,
                starting_asset_arn="",
                starting_asset_name="",
                calculated_at=int(time.time() * 1000),
                duration_ms=0,
            )

        starting_asset = assets.get(starting_asset_id)

        # BFS to find reachable nodes
        reachable: set[str] = set()
        paths_to: dict[str, list[str]] = {starting_asset_id: [starting_asset_id]}
        queue: deque[tuple[str, int]] = deque([(starting_asset_id, 0)])
        reachable.add(starting_asset_id)

        while queue:
            current, depth = queue.popleft()
            if depth >= max_depth:
                continue
            for neighbor in graph.successors(current):
                if neighbor not in reachable:
                    reachable.add(neighbor)
                    paths_to[neighbor] = paths_to[current] + [neighbor]
                    queue.append((neighbor, depth + 1))

        # Build result
        reachable_assets: list[dict[str, Any]] = []
        reachable_critical = 0
        reachable_pii = 0
        reachable_secrets = 0
        for asset_id in reachable:
            if asset_id == starting_asset_id:
                continue  # exclude the starting asset from count
            asset = assets.get(asset_id)
            if not asset:
                continue
            reachable_assets.append({
                "asset_id": asset.asset_id,
                "arn": asset.arn,
                "name": asset.name,
                "type": asset.asset_type,
                "category": asset.category,
                "criticality": asset.criticality,
                "criticality_score": asset.criticality_score,
                "contains_pii": asset.contains_pii,
                "contains_secrets": asset.contains_secrets,
                "internet_exposed": asset.internet_exposed,
                "path": paths_to.get(asset_id, []),
                "depth": len(paths_to.get(asset_id, [])) - 1,
            })
            if asset.criticality in ("critical", "high"):
                reachable_critical += 1
            if asset.contains_pii:
                reachable_pii += 1
            if asset.contains_secrets:
                reachable_secrets += 1

        # Compute severity
        reachable_count = len(reachable_assets)
        if reachable_count > 50 or reachable_critical > 5 or reachable_pii > 0:
            severity = BlastRadiusSeverity.CRITICAL.value
        elif reachable_count > 10 or reachable_critical > 0:
            severity = BlastRadiusSeverity.HIGH.value
        elif reachable_count > 2:
            severity = BlastRadiusSeverity.MEDIUM.value
        elif reachable_count > 0:
            severity = BlastRadiusSeverity.LOW.value
        else:
            severity = BlastRadiusSeverity.NONE.value

        # Compute risk score (0-100)
        risk_score = min(100, (
            reachable_count * 2 +
            reachable_critical * 10 +
            reachable_pii * 15 +
            reachable_secrets * 20
        ))

        # Build top paths (most critical reachable assets)
        sorted_reachable = sorted(
            reachable_assets,
            key=lambda a: (a["criticality_score"], -a["depth"]),
            reverse=True,
        )
        top_paths = []
        for asset in sorted_reachable[:5]:
            path_names = []
            for aid in asset["path"]:
                a = assets.get(aid)
                if a:
                    path_names.append(a.name)
            top_paths.append({
                "target_asset_id": asset["asset_id"],
                "target_asset_name": asset["name"],
                "target_criticality": asset["criticality"],
                "path": asset["path"],
                "path_names": path_names,
                "depth": asset["depth"],
                "contains_pii": asset["contains_pii"],
                "contains_secrets": asset["contains_secrets"],
            })

        # Recommended actions
        recommended: list[str] = []
        if reachable_pii > 0:
            recommended.append(f"Isolate the starting asset — {reachable_pii} PII-containing assets are reachable")
        if reachable_secrets > 0:
            recommended.append(f"Rotate all secrets — {reachable_secrets} secret-containing assets are reachable")
        if reachable_critical > 0:
            recommended.append(f"Apply network segmentation — {reachable_critical} critical assets are reachable")
        if not recommended:
            recommended.append("Blast radius is contained — no critical assets reachable")

        return BlastRadiusResult(
            calculation_id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            starting_asset_id=starting_asset_id,
            starting_asset_arn=starting_asset.arn if starting_asset else "",
            starting_asset_name=starting_asset.name if starting_asset else "",
            reachable_assets=reachable_assets,
            reachable_count=reachable_count,
            reachable_critical_count=reachable_critical,
            reachable_pii_count=reachable_pii,
            reachable_secrets_count=reachable_secrets,
            paths=top_paths,
            max_depth=max([a["depth"] for a in reachable_assets], default=0),
            severity=severity,
            risk_score=round(risk_score, 1),
            recommended_actions=recommended,
            calculated_at=int(time.time() * 1000),
            duration_ms=int((time.time() - start_time) * 1000),
        )

    def find_critical_paths(
        self,
        tenant_id: str,
        max_paths: int = 10,
    ) -> list[CriticalPath]:
        """Find paths from internet-exposed assets to critical assets.

        These are the most dangerous paths in the infrastructure —
        an attacker who compromises an internet-facing asset can
        traverse the path to reach a critical asset.
        """
        with self._lock:
            graph = self._graphs.get(tenant_id)
            assets = self._assets.get(tenant_id, {})

        if not graph:
            return []

        # Find internet-exposed assets
        internet_exposed = [
            aid for aid, attrs in graph.nodes(data=True)
            if attrs.get("internet_exposed")
        ]
        # Find critical assets
        critical_assets = [
            aid for aid, attrs in graph.nodes(data=True)
            if attrs.get("criticality") in ("critical", "high")
        ]

        paths: list[CriticalPath] = []
        for source_id in internet_exposed:
            for target_id in critical_assets:
                if source_id == target_id:
                    continue
                try:
                    path = nx.shortest_path(graph, source_id, target_id)
                    if len(path) < 2:
                        continue
                    # Get relationship types along the path
                    rel_types = []
                    for i in range(len(path) - 1):
                        edge_data = graph.get_edge_data(path[i], path[i + 1], {})
                        rel_types.append(edge_data.get("relationship_type", "unknown"))

                    # Compute risk score
                    source_attrs = graph.nodes[source_id]
                    target_attrs = graph.nodes[target_id]
                    risk_score = (
                        (len(path) - 1) * 5 +  # longer path = lower risk
                        target_attrs.get("criticality_score", 0) * 0.5 +
                        (20 if target_attrs.get("contains_pii") else 0) +
                        (15 if target_attrs.get("contains_secrets") else 0)
                    )

                    path_names = [assets.get(aid).name if assets.get(aid) else aid for aid in path]
                    paths.append(CriticalPath(
                        path_id=str(uuid.uuid4()),
                        source_asset_id=source_id,
                        source_asset_name=assets.get(source_id).name if assets.get(source_id) else source_id,
                        target_asset_id=target_id,
                        target_asset_name=assets.get(target_id).name if assets.get(target_id) else target_id,
                        path=path,
                        path_names=path_names,
                        length=len(path) - 1,
                        risk_score=round(risk_score, 1),
                        relationships=rel_types,
                    ))
                except (nx.NetworkXNoPath, nx.NodeNotFound):
                    continue

        # Sort by risk score descending
        paths.sort(key=lambda p: p.risk_score, reverse=True)
        return paths[:max_paths]

    def compute_centrality(self, tenant_id: str) -> dict[str, Any]:
        """Compute betweenness centrality to identify choke points.

        Assets with high betweenness centrality are "bridges" — their
        compromise would impact many paths. These should be hardened.
        """
        with self._lock:
            graph = self._graphs.get(tenant_id)
            assets = self._assets.get(tenant_id, {})

        if not graph or graph.number_of_nodes() == 0:
            return {"nodes": [], "total_nodes": 0, "total_edges": 0}

        # Compute centrality
        try:
            betweenness = nx.betweenness_centrality(graph)
            degree_centrality = nx.degree_centrality(graph)
        except Exception as e:
            logger.warning(f"Centrality computation failed: {e}")
            return {"nodes": [], "total_nodes": graph.number_of_nodes(),
                    "total_edges": graph.number_of_edges()}

        nodes = []
        for asset_id, attrs in graph.nodes(data=True):
            nodes.append({
                "asset_id": asset_id,
                "name": attrs.get("name", asset_id),
                "arn": attrs.get("arn", ""),
                "type": attrs.get("asset_type", ""),
                "criticality": attrs.get("criticality", "low"),
                "betweenness_centrality": round(betweenness.get(asset_id, 0), 4),
                "degree_centrality": round(degree_centrality.get(asset_id, 0), 4),
                "in_degree": graph.in_degree(asset_id),
                "out_degree": graph.out_degree(asset_id),
            })

        nodes.sort(key=lambda n: n["betweenness_centrality"], reverse=True)
        return {
            "nodes": nodes[:20],
            "total_nodes": graph.number_of_nodes(),
            "total_edges": graph.number_of_edges(),
            "top_choke_point": nodes[0]["name"] if nodes else None,
        }

    def simulate_compromise(
        self,
        tenant_id: str,
        asset_ids: list[str],
        max_depth: int = 10,
    ) -> dict[str, Any]:
        """Simulate compromise of multiple assets simultaneously.

        Useful for "what if" analysis: "What if these 3 assets are compromised?"
        """
        combined_reachable: set[str] = set()
        all_results: list[BlastRadiusResult] = []

        for asset_id in asset_ids:
            result = self.calculate_blast_radius(tenant_id, asset_id, max_depth)
            all_results.append(result)
            for r in result.reachable_assets:
                combined_reachable.add(r["asset_id"])

        # Count critical/PII/secrets in combined reachability
        with self._lock:
            assets = self._assets.get(tenant_id, {})
        critical_count = sum(1 for aid in combined_reachable
                            if assets.get(aid) and assets[aid].criticality in ("critical", "high"))
        pii_count = sum(1 for aid in combined_reachable
                       if assets.get(aid) and assets[aid].contains_pii)
        secrets_count = sum(1 for aid in combined_reachable
                           if assets.get(aid) and assets[aid].contains_secrets)

        return {
            "simulation_id": str(uuid.uuid4()),
            "tenant_id": tenant_id,
            "compromised_assets": asset_ids,
            "compromised_count": len(asset_ids),
            "combined_reachable_count": len(combined_reachable),
            "combined_critical_reachable": critical_count,
            "combined_pii_reachable": pii_count,
            "combined_secrets_reachable": secrets_count,
            "per_asset_results": [
                {
                    "asset_id": r.starting_asset_id,
                    "asset_name": r.starting_asset_name,
                    "reachable_count": r.reachable_count,
                    "severity": r.severity,
                    "risk_score": r.risk_score,
                }
                for r in all_results
            ],
            "simulated_at": int(time.time() * 1000),
        }

    def get_graph_stats(self, tenant_id: str) -> dict[str, Any]:
        with self._lock:
            graph = self._graphs.get(tenant_id)
            assets = self._assets.get(tenant_id, {})

        if not graph:
            return {"total_nodes": 0, "total_edges": 0, "density": 0}

        return {
            "total_nodes": graph.number_of_nodes(),
            "total_edges": graph.number_of_edges(),
            "density": round(nx.density(graph), 4),
            "internet_exposed_count": sum(
                1 for _, attrs in graph.nodes(data=True) if attrs.get("internet_exposed")
            ),
            "critical_assets_count": sum(
                1 for _, attrs in graph.nodes(data=True) if attrs.get("criticality") in ("critical", "high")
            ),
            "average_degree": round(
                sum(dict(graph.degree()).values()) / max(graph.number_of_nodes(), 1), 2
            ),
        }


# ═══════════════════════════════════════════════════════════════
# Module-level singleton
# ═══════════════════════════════════════════════════════════════

_global_engine: Optional[BlastRadiusCalculator] = None
_global_lock = threading.Lock()


def get_blast_radius_engine() -> BlastRadiusCalculator:
    global _global_engine
    if _global_engine is None:
        with _global_lock:
            if _global_engine is None:
                _global_engine = BlastRadiusCalculator()
    return _global_engine
