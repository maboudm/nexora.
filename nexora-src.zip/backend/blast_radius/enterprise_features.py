"""
Enterprise Features — Risk Acceptance, Finding Lifecycle, Posture Trend, Custom Rules.

These are features that ALL paid CNAPP platforms (Wiz, Prisma, Orca, Lacework) have
but no free tool offers. We implement them for free.

1. Risk Acceptance Workflow:
   - Accept a finding's risk with justification
   - Set expiry date (auto-reopen after expiry)
   - Track approver
   - Audit trail

2. Finding Lifecycle Management:
   - Open → Investigating → Remediated → Verified → Closed
   - SLA tracking per severity (CIS: critical=24h, high=72h, medium=30d, low=90d)
   - Breach alerts when SLA exceeded
   - Assignment to team members

3. Posture Trend Tracking:
   - Store posture score after each scan
   - Show trend over time (30/60/90 days)
   - Compare to industry benchmark
   - Alert on significant degradation

4. Custom Rules Builder:
   - Users create rules via simple DSL without coding
   - Rules are tenant-specific
   - Auto-validated before activation
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)

DB_PATH = os.environ.get("DATABASE_URL", "file:/home/z/my-project/db/custom.db").replace("file:", "")
if not DB_PATH.endswith(".db"):
    DB_PATH = "/home/z/my-project/db/custom.db"


# ═══════════════════════════════════════════════════════════════
# 1. RISK ACCEPTANCE WORKFLOW
# ═══════════════════════════════════════════════════════════════

class RiskAcceptanceStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    REVOKED = "revoked"


@dataclass
class RiskAcceptance:
    """A formal risk acceptance for a finding."""
    acceptance_id: str
    tenant_id: str
    finding_id: str
    finding_title: str
    justifier_id: str        # who is accepting the risk
    justifier_name: str
    justification: str       # why the risk is acceptable
    compensating_controls: str  # what mitigates the risk
    expiry_date: str         # ISO date — auto-reopen after this
    approver_id: Optional[str] = None
    approver_name: Optional[str] = None
    status: str = RiskAcceptanceStatus.PENDING.value
    created_at: int = 0
    approved_at: Optional[int] = None
    revoked_at: Optional[int] = None
    revoke_reason: Optional[str] = None


class RiskAcceptanceEngine:
    """Manage risk acceptance lifecycle.

    Workflow:
      1. User requests risk acceptance for a finding
      2. Approver reviews and approves/rejects
      3. If approved, finding is marked "risk_accepted"
      4. On expiry date, finding auto-reopens
      5. Any revocation reopens the finding immediately
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._init_table()

    def _init_table(self):
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS risk_acceptances (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    finding_id TEXT NOT NULL,
                    finding_title TEXT,
                    justifier_id TEXT NOT NULL,
                    justifier_name TEXT,
                    justification TEXT NOT NULL,
                    compensating_controls TEXT,
                    expiry_date TEXT NOT NULL,
                    approver_id TEXT,
                    approver_name TEXT,
                    status TEXT DEFAULT 'pending',
                    created_at INTEGER,
                    approved_at INTEGER,
                    revoked_at INTEGER,
                    revoke_reason TEXT
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_ra_tenant ON risk_acceptances(tenant_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_ra_finding ON risk_acceptances(finding_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_ra_status ON risk_acceptances(status)")

    def create_acceptance(self, tenant_id: str, finding_id: str, finding_title: str,
                          justifier_id: str, justifier_name: str,
                          justification: str, compensating_controls: str = "",
                          expiry_days: int = 90) -> RiskAcceptance:
        """Create a new risk acceptance request."""
        now = int(time.time() * 1000)
        expiry = (datetime.now(timezone.utc) + timedelta(days=expiry_days)).strftime("%Y-%m-%dT%H:%M:%SZ")
        acceptance = RiskAcceptance(
            acceptance_id=str(uuid.uuid4()),
            tenant_id=tenant_id, finding_id=finding_id, finding_title=finding_title,
            justifier_id=justifier_id, justifier_name=justifier_name,
            justification=justification, compensating_controls=compensating_controls,
            expiry_date=expiry, created_at=now,
        )
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute(
                """INSERT INTO risk_acceptances
                   (id, tenant_id, finding_id, finding_title, justifier_id, justifier_name,
                    justification, compensating_controls, expiry_date, status, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)""",
                (acceptance.acceptance_id, tenant_id, finding_id, finding_title,
                 justifier_id, justifier_name, justification, compensating_controls,
                 expiry, now)
            )
        return acceptance

    def approve(self, acceptance_id: str, approver_id: str, approver_name: str,
                tenant_id: str) -> Optional[RiskAcceptance]:
        """Approve a risk acceptance."""
        now = int(time.time() * 1000)
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            conn.execute(
                """UPDATE risk_acceptances SET status='approved', approver_id=?, approver_name=?, approved_at=?
                   WHERE id=? AND tenant_id=? AND status='pending'""",
                (approver_id, approver_name, now, acceptance_id, tenant_id)
            )
            row = conn.execute(
                "SELECT * FROM risk_acceptances WHERE id=? AND tenant_id=?",
                (acceptance_id, tenant_id)
            ).fetchone()
            return RiskAcceptance(
                acceptance_id=row["id"], tenant_id=row["tenant_id"],
                finding_id=row["finding_id"], finding_title=row["finding_title"],
                justifier_id=row["justifier_id"], justifier_name=row["justifier_name"],
                justification=row["justification"], compensating_controls=row["compensating_controls"],
                expiry_date=row["expiry_date"], approver_id=row["approver_id"],
                approver_name=row["approver_name"], status=row["status"],
                created_at=row["created_at"], approved_at=row["approved_at"],
            ) if row else None

    def revoke(self, acceptance_id: str, tenant_id: str, reason: str) -> bool:
        """Revoke a risk acceptance (reopens the finding)."""
        now = int(time.time() * 1000)
        with sqlite3.connect(DB_PATH) as conn:
            cur = conn.execute(
                """UPDATE risk_acceptances SET status='revoked', revoked_at=?, revoke_reason=?
                   WHERE id=? AND tenant_id=? AND status='approved'""",
                (now, reason, acceptance_id, tenant_id)
            )
            return cur.rowcount > 0

    def list_acceptances(self, tenant_id: str, status: Optional[str] = None) -> list[dict]:
        """List risk acceptances for a tenant."""
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            if status:
                rows = conn.execute(
                    "SELECT * FROM risk_acceptances WHERE tenant_id=? AND status=? ORDER BY created_at DESC",
                    (tenant_id, status)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM risk_acceptances WHERE tenant_id=? ORDER BY created_at DESC",
                    (tenant_id,)
                ).fetchall()
            return [dict(r) for r in rows]

    def check_expired(self, tenant_id: str) -> list[str]:
        """Check for expired risk acceptances and return finding IDs to reopen."""
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """UPDATE risk_acceptances SET status='expired'
                   WHERE tenant_id=? AND status='approved' AND expiry_date < ?
                   RETURNING finding_id""",
                (tenant_id, now_str)
            ).fetchall()
            return [r["finding_id"] for r in rows]


# ═══════════════════════════════════════════════════════════════
# 2. FINDING LIFECYCLE MANAGEMENT
# ═══════════════════════════════════════════════════════════════

class FindingStatus(str, Enum):
    OPEN = "open"
    INVESTIGATING = "investigating"
    REMEDIATED = "remediated"
    VERIFIED = "verified"
    CLOSED = "closed"
    RISK_ACCEPTED = "risk_accepted"
    FALSE_POSITIVE = "false_positive"


# SLA hours by severity (CIS recommended)
SLA_HOURS = {
    "critical": 24,      # 1 day
    "high": 72,          # 3 days
    "medium": 720,       # 30 days
    "low": 2160,         # 90 days
    "info": 0,           # no SLA
}


class FindingLifecycleEngine:
    """Manage finding lifecycle with SLA tracking.

    States:
      OPEN → INVESTIGATING → REMEDIATED → VERIFIED → CLOSED
                                    ↘ RISK_ACCEPTED (via RiskAcceptance)
                                    ↘ FALSE_POSITIVE

    SLA:
      - Each finding has an SLA based on severity
      - If SLA is breached, alert is generated
      - SLA clock pauses when INVESTIGATING or RISK_ACCEPTED
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._init_table()

    def _init_table(self):
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS finding_lifecycle (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    finding_id TEXT NOT NULL,
                    status TEXT DEFAULT 'open',
                    assigned_to_id TEXT,
                    assigned_to_name TEXT,
                    sla_deadline TEXT,
                    sla_breached INTEGER DEFAULT 0,
                    first_seen_at INTEGER,
                    last_state_change_at INTEGER,
                    notes TEXT DEFAULT '[]',
                    UNIQUE(finding_id)
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_fl_tenant ON finding_lifecycle(tenant_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_fl_status ON finding_lifecycle(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_fl_sla ON finding_lifecycle(sla_breached)")

    def register_finding(self, tenant_id: str, finding_id: str, severity: str) -> dict:
        """Register a new finding in the lifecycle."""
        now = int(time.time() * 1000)
        sla_hours = SLA_HOURS.get(severity, 720)
        sla_deadline = (datetime.now(timezone.utc) + timedelta(hours=sla_hours)).strftime("%Y-%m-%dT%H:%M:%SZ") if sla_hours else ""

        lifecycle_id = str(uuid.uuid4())
        with sqlite3.connect(DB_PATH) as conn:
            try:
                conn.execute(
                    """INSERT INTO finding_lifecycle
                       (id, tenant_id, finding_id, status, sla_deadline, first_seen_at, last_state_change_at)
                       VALUES (?, ?, ?, 'open', ?, ?, ?)""",
                    (lifecycle_id, tenant_id, finding_id, sla_deadline, now, now)
                )
            except sqlite3.IntegrityError:
                pass  # already registered

        return {"lifecycle_id": lifecycle_id, "finding_id": finding_id, "status": "open", "sla_deadline": sla_deadline}

    def update_status(self, finding_id: str, tenant_id: str, new_status: str,
                      assigned_to_id: str = "", assigned_to_name: str = "",
                      note: str = "") -> bool:
        """Update finding status."""
        now = int(time.time() * 1000)
        with sqlite3.connect(DB_PATH) as conn:
            # Get current notes
            row = conn.execute(
                "SELECT notes FROM finding_lifecycle WHERE finding_id=? AND tenant_id=?",
                (finding_id, tenant_id)
            ).fetchone()
            notes = json.loads(row[0]) if row and row[0] else []
            if note:
                notes.append({"timestamp": now, "note": note, "status": new_status})

            cur = conn.execute(
                """UPDATE finding_lifecycle SET status=?, assigned_to_id=?, assigned_to_name=?,
                   last_state_change_at=?, notes=?
                   WHERE finding_id=? AND tenant_id=?""",
                (new_status, assigned_to_id, assigned_to_name, now,
                 json.dumps(notes), finding_id, tenant_id)
            )
            return cur.rowcount > 0

    def check_sla_breaches(self, tenant_id: str) -> list[dict]:
        """Find findings with breached SLA."""
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            conn.execute(
                """UPDATE finding_lifecycle SET sla_breached=1
                   WHERE tenant_id=? AND status='open' AND sla_deadline != '' AND sla_deadline < ?
                   AND sla_breached=0""",
                (tenant_id, now_str)
            )
            rows = conn.execute(
                """SELECT * FROM finding_lifecycle
                   WHERE tenant_id=? AND sla_breached=1 AND status='open'""",
                (tenant_id,)
            ).fetchall()
            return [dict(r) for r in rows]

    def get_lifecycle(self, finding_id: str, tenant_id: str) -> Optional[dict]:
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT * FROM finding_lifecycle WHERE finding_id=? AND tenant_id=?",
                (finding_id, tenant_id)
            ).fetchone()
            return dict(row) if row else None

    def list_by_status(self, tenant_id: str, status: Optional[str] = None) -> list[dict]:
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            if status:
                rows = conn.execute(
                    "SELECT * FROM finding_lifecycle WHERE tenant_id=? AND status=?",
                    (tenant_id, status)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM finding_lifecycle WHERE tenant_id=?",
                    (tenant_id,)
                ).fetchall()
            return [dict(r) for r in rows]


# ═══════════════════════════════════════════════════════════════
# 3. POSTURE TREND TRACKING
# ═══════════════════════════════════════════════════════════════

class PostureTrendEngine:
    """Track posture score over time and detect trends.

    All paid platforms show "Your security improved 15% this month."
    We store posture scores in the database and compute trends.
    """

    def __init__(self):
        self._init_table()

    def _init_table(self):
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS posture_history (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    score REAL NOT NULL,
                    grade TEXT,
                    scan_id TEXT,
                    factors TEXT,
                    critical_findings INTEGER DEFAULT 0,
                    high_findings INTEGER DEFAULT 0,
                    medium_findings INTEGER DEFAULT 0,
                    low_findings INTEGER DEFAULT 0,
                    total_findings INTEGER DEFAULT 0,
                    created_at INTEGER
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_ph_tenant ON posture_history(tenant_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_ph_created ON posture_history(created_at)")

    def record(self, tenant_id: str, score: float, grade: str, scan_id: str = "",
               factors: dict = None, findings_by_severity: dict = None) -> str:
        """Record a posture score."""
        record_id = str(uuid.uuid4())
        now = int(time.time() * 1000)
        findings_by_severity = findings_by_severity or {}
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute(
                """INSERT INTO posture_history
                   (id, tenant_id, score, grade, scan_id, factors,
                    critical_findings, high_findings, medium_findings, low_findings,
                    total_findings, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (record_id, tenant_id, score, grade, scan_id,
                 json.dumps(factors or {}),
                 findings_by_severity.get("critical", 0),
                 findings_by_severity.get("high", 0),
                 findings_by_severity.get("medium", 0),
                 findings_by_severity.get("low", 0),
                 sum(findings_by_severity.values()),
                 now)
            )
        return record_id

    def get_trend(self, tenant_id: str, days: int = 30) -> dict:
        """Get posture trend over last N days."""
        cutoff = int((time.time() - days * 86400) * 1000)
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """SELECT * FROM posture_history
                   WHERE tenant_id=? AND created_at >= ?
                   ORDER BY created_at ASC""",
                (tenant_id, cutoff)
            ).fetchall()

        if not rows:
            return {"trend": "no_data", "records": [], "change": 0}

        scores = [r["score"] for r in rows]
        first = scores[0]
        last = scores[-1]
        change = last - first

        if change > 2:
            trend = "improving"
        elif change < -2:
            trend = "degrading"
        else:
            trend = "stable"

        return {
            "trend": trend,
            "change": round(change, 1),
            "first_score": first,
            "last_score": last,
            "highest_score": max(scores),
            "lowest_score": min(scores),
            "average_score": round(sum(scores) / len(scores), 1),
            "records": [
                {
                    "score": r["score"],
                    "grade": r["grade"],
                    "timestamp": r["created_at"],
                    "critical": r["critical_findings"],
                    "high": r["high_findings"],
                    "medium": r["medium_findings"],
                    "low": r["low_findings"],
                    "total": r["total_findings"],
                }
                for r in rows
            ],
        }


# ═══════════════════════════════════════════════════════════════
# 4. CUSTOM RULES BUILDER
# ═══════════════════════════════════════════════════════════════

@dataclass
class CustomRule:
    """A user-created custom rule."""
    rule_id: str
    tenant_id: str
    name: str
    description: str
    severity: str
    resource_type: str
    dsl: str              # condition: field op value AND ...
    remediation: str
    enabled: bool = True
    created_by: str = ""
    created_at: int = 0


class CustomRulesEngine:
    """Let users create custom security rules without coding.

    Users specify:
      - Resource type (e.g., aws_s3_bucket)
      - Condition (e.g., metadata.acl == "public-read")
      - Severity (critical/high/medium/low)
      - Remediation text

    The rule is validated and stored. On next scan, it's evaluated
    alongside the built-in CIS/OWASP/NIST rules.
    """

    def __init__(self):
        self._init_table()

    def _init_table(self):
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS custom_rules (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    description TEXT,
                    severity TEXT DEFAULT 'medium',
                    resource_type TEXT NOT NULL,
                    dsl TEXT NOT NULL,
                    remediation TEXT,
                    enabled INTEGER DEFAULT 1,
                    created_by TEXT,
                    created_at INTEGER
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_cr_tenant ON custom_rules(tenant_id)")

    def create_rule(self, tenant_id: str, name: str, description: str,
                    severity: str, resource_type: str, dsl: str,
                    remediation: str, created_by: str = "") -> CustomRule:
        """Create a custom rule."""
        rule_id = f"CUSTOM-{str(uuid.uuid4())[:8]}"
        now = int(time.time() * 1000)
        rule = CustomRule(
            rule_id=rule_id, tenant_id=tenant_id, name=name, description=description,
            severity=severity, resource_type=resource_type, dsl=dsl,
            remediation=remediation, created_by=created_by, created_at=now,
        )
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute(
                """INSERT INTO custom_rules
                   (id, tenant_id, name, description, severity, resource_type, dsl,
                    remediation, enabled, created_by, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)""",
                (rule_id, tenant_id, name, description, severity, resource_type, dsl,
                 remediation, created_by, now)
            )
        return rule

    def list_rules(self, tenant_id: str) -> list[dict]:
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM custom_rules WHERE tenant_id=? ORDER BY created_at DESC",
                (tenant_id,)
            ).fetchall()
            return [dict(r) for r in rows]

    def toggle_rule(self, rule_id: str, tenant_id: str, enabled: bool) -> bool:
        with sqlite3.connect(DB_PATH) as conn:
            cur = conn.execute(
                "UPDATE custom_rules SET enabled=? WHERE id=? AND tenant_id=?",
                (1 if enabled else 0, rule_id, tenant_id)
            )
            return cur.rowcount > 0

    def delete_rule(self, rule_id: str, tenant_id: str) -> bool:
        with sqlite3.connect(DB_PATH) as conn:
            cur = conn.execute(
                "DELETE FROM custom_rules WHERE id=? AND tenant_id=?",
                (rule_id, tenant_id)
            )
            return cur.rowcount > 0

    def validate_dsl(self, dsl: str) -> tuple[bool, str]:
        """Validate a DSL string before saving."""
        if not dsl or not dsl.strip():
            return False, "DSL is empty"
        if not dsl.lower().startswith("condition:"):
            return False, "DSL must start with 'condition:'"
        # Basic syntax check
        import re
        condition = dsl[10:].strip()
        parts = re.split(r'\s+(AND|OR)\s+', condition, flags=re.IGNORECASE)
        for part in parts:
            if part.upper() in ("AND", "OR"):
                continue
            match = re.match(r'^(\S+)\s+(==|!=|>=|<=|>|<|contains|in|not_in|exists)\s+(.+)$', part)
            if not match:
                return False, f"Invalid condition: '{part[:50]}'"
        return True, "Valid"


# ═══════════════════════════════════════════════════════════════
# Singletons
# ═══════════════════════════════════════════════════════════════

_risk_engine: Optional[RiskAcceptanceEngine] = None
_lifecycle_engine: Optional[FindingLifecycleEngine] = None
_trend_engine: Optional[PostureTrendEngine] = None
_custom_rules: Optional[CustomRulesEngine] = None
_lock = threading.Lock()


def get_risk_engine() -> RiskAcceptanceEngine:
    global _risk_engine
    if _risk_engine is None:
        with _lock:
            if _risk_engine is None:
                _risk_engine = RiskAcceptanceEngine()
    return _risk_engine


def get_lifecycle_engine() -> FindingLifecycleEngine:
    global _lifecycle_engine
    if _lifecycle_engine is None:
        with _lock:
            if _lifecycle_engine is None:
                _lifecycle_engine = FindingLifecycleEngine()
    return _lifecycle_engine


def get_trend_engine() -> PostureTrendEngine:
    global _trend_engine
    if _trend_engine is None:
        with _lock:
            if _trend_engine is None:
                _trend_engine = PostureTrendEngine()
    return _trend_engine


def get_custom_rules_engine() -> CustomRulesEngine:
    global _custom_rules
    if _custom_rules is None:
        with _lock:
            if _custom_rules is None:
                _custom_rules = CustomRulesEngine()
    return _custom_rules
