"""
Risk-Based Finding Prioritization Engine with Fix-Order Optimizer

Premium Feature #2 — Inspired by Wiz's "Wiz Risk Score" and Tenable's
"Vulnerability Priority Rating". Solves the "500 findings, which to fix first?" problem.

Scientific Foundation:
- FIRST.org EPSS (Exploit Prediction Scoring System) — probability of exploitation in 30 days
- Microsoft TVM (Threat & Vulnerability Management) risk weighting model
- Knapsack-based fix-order optimization (maximize risk reduction per engineer-hour)
- Bayesian combination of independent evidence sources (CVSS, EPSS, exposure, asset value)

Risk Formula (multiplicative Bayesian):
    R = CVSS_normalized × EPSS × Exposure_factor × Asset_criticality × Threat_intel_boost
    Where:
      CVSS_normalized = CVSS / 10
      EPSS = exploit prediction (0-1)
      Exposure_factor = {internet: 1.0, internal: 0.6, isolated: 0.2}
      Asset_criticality = tier_0: 1.0, tier_1: 0.7, tier_2: 0.4, tier_3: 0.15
      Threat_intel_boost = 1.5 if active exploitation observed, else 1.0

Fix-Order Optimizer:
    Greedy 0/1 knapsack — maximize risk reduction given fixed engineer hours budget
    Risk reduction per finding = R_finding × P(successful_fix)
    Cost per finding = estimated_engineer_hours
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
from collections import defaultdict
from uuid import uuid4


# ---------------------------------------------------------------------------
# Asset tier definitions (Wiz-style crown jewel classification)
# ---------------------------------------------------------------------------
class AssetTier(str, Enum):
    TIER_0 = "tier_0"   # Crown jewels — production DBs, customer data, root accounts
    TIER_1 = "tier_1"   # Critical infrastructure — prod app servers, KMS keys
    TIER_2 = "tier_2"   # Important — staging, internal services
    TIER_3 = "tier_3"   # Low impact — dev/test, sandbox


TIER_WEIGHTS: dict[AssetTier, float] = {
    AssetTier.TIER_0: 1.00,
    AssetTier.TIER_1: 0.70,
    AssetTier.TIER_2: 0.40,
    AssetTier.TIER_3: 0.15,
}


class ExposureLevel(str, Enum):
    INTERNET = "internet"     # public IP, public S3, etc.
    INTERNAL = "internal"     # VPC-internal
    ISOLATED = "isolated"     # no network access


EXPOSURE_WEIGHTS: dict[ExposureLevel, float] = {
    ExposureLevel.INTERNET: 1.00,
    ExposureLevel.INTERNAL: 0.60,
    ExposureLevel.ISOLATED: 0.20,
}


class FindingCategory(str, Enum):
    MISCONFIGURATION = "misconfiguration"
    VULNERABILITY = "vulnerability"
    IDENTITY_RISK = "identity_risk"
    DATA_EXPOSURE = "data_exposure"
    NETWORK_EXPOSURE = "network_exposure"
    SECRET_EXPOSURE = "secret_exposure"
    COMPLIANCE_VIOLATION = "compliance_violation"


# Effort estimates (engineer-hours) per category + severity — calibrated against
# industry benchmarks (Cloud Security Alliance remediation time studies)
EFFORT_MATRIX: dict[tuple[FindingCategory, str], float] = {
    # (category, severity) -> engineer-hours
    (FindingCategory.MISCONFIGURATION, "critical"): 2.0,
    (FindingCategory.MISCONFIGURATION, "high"):     1.5,
    (FindingCategory.MISCONFIGURATION, "medium"):   1.0,
    (FindingCategory.MISCONFIGURATION, "low"):      0.5,
    (FindingCategory.VULNERABILITY, "critical"):    4.0,   # need patch testing
    (FindingCategory.VULNERABILITY, "high"):        3.0,
    (FindingCategory.VULNERABILITY, "medium"):      2.0,
    (FindingCategory.VULNERABILITY, "low"):         1.0,
    (FindingCategory.IDENTITY_RISK, "critical"):    3.0,   # IAM policy rewrite
    (FindingCategory.IDENTITY_RISK, "high"):        2.0,
    (FindingCategory.IDENTITY_RISK, "medium"):      1.5,
    (FindingCategory.IDENTITY_RISK, "low"):         0.5,
    (FindingCategory.DATA_EXPOSURE, "critical"):    6.0,   # data classification + access review
    (FindingCategory.DATA_EXPOSURE, "high"):        4.0,
    (FindingCategory.DATA_EXPOSURE, "medium"):      2.5,
    (FindingCategory.DATA_EXPOSURE, "low"):         1.0,
    (FindingCategory.NETWORK_EXPOSURE, "critical"): 1.5,   # SG rule change
    (FindingCategory.NETWORK_EXPOSURE, "high"):     1.0,
    (FindingCategory.NETWORK_EXPOSURE, "medium"):   0.75,
    (FindingCategory.NETWORK_EXPOSURE, "low"):      0.5,
    (FindingCategory.SECRET_EXPOSURE, "critical"):  2.0,   # rotate + redeploy
    (FindingCategory.SECRET_EXPOSURE, "high"):      1.5,
    (FindingCategory.SECRET_EXPOSURE, "medium"):    1.0,
    (FindingCategory.SECRET_EXPOSURE, "low"):       0.5,
    (FindingCategory.COMPLIANCE_VIOLATION, "critical"): 8.0,
    (FindingCategory.COMPLIANCE_VIOLATION, "high"):     5.0,
    (FindingCategory.COMPLIANCE_VIOLATION, "medium"):   3.0,
    (FindingCategory.COMPLIANCE_VIOLATION, "low"):      1.0,
}


@dataclass
class PrioritizedFinding:
    finding_id: str
    rule_id: str
    title: str
    severity: str               # original CVSS severity label
    category: FindingCategory
    asset_id: str
    asset_name: str
    asset_tier: AssetTier
    exposure: ExposureLevel

    # Inputs to risk score
    cvss_score: float           # 0-10
    epss_score: float           # 0-1 (exploit prediction)
    threat_intel_match: bool    # is there active exploitation?

    # Computed
    risk_score: float           # 0-1000 (composite)
    risk_band: str              # CRITICAL / HIGH / MEDIUM / LOW
    business_impact: float      # 0-1
    exposure_factor: float      # 0-1
    asset_factor: float         # 0-1
    threat_boost: float         # 1.0 or 1.5
    fix_effort_hours: float
    risk_reduction_per_hour: float  # risk_score / effort — for knapsack
    remediation_id: str | None = None
    remediation_summary: str = ""
    reason: str = ""            # human-readable explanation


@dataclass
class FixPlan:
    plan_id: str
    tenant_id: str
    budget_hours: float
    used_hours: float
    remaining_hours: float
    total_risk_reduction: float
    selected_findings: list[PrioritizedFinding]
    skipped_findings: list[PrioritizedFinding]   # didn't fit in budget
    quick_wins: list[PrioritizedFinding]         # high RROI, low effort
    created_at: float


@dataclass
class PrioritizationStats:
    tenant_id: str
    total_findings: int
    by_risk_band: dict[str, int]
    by_category: dict[str, int]
    by_asset_tier: dict[str, int]
    total_risk_score: float
    mean_risk_score: float
    total_fix_effort_hours: float
    top_risk_findings: list[dict[str, Any]]
    top_quick_wins: list[dict[str, Any]]


def _infer_asset_tier(asset: dict[str, Any]) -> AssetTier:
    """Infer asset tier from tags, name, type."""
    tags = asset.get("tags") or {}
    if isinstance(tags, dict):
        tier_str = tags.get("tier") or tags.get("criticality") or tags.get("Tier")
        if tier_str:
            try:
                return AssetTier(tier_str.lower())
            except ValueError:
                pass
    # Heuristic by asset type
    atype = str(asset.get("type") or asset.get("asset_type") or "").lower()
    if any(k in atype for k in ("rds", "database", "db", "kms", "secret", "s3", "bucket")):
        return AssetTier.TIER_0
    if any(k in atype for k in ("ec2", "vm", "eks", "lambda", "function")):
        return AssetTier.TIER_1
    if any(k in atype for k in ("sg", "security_group", "vpc", "subnet")):
        return AssetTier.TIER_2
    return AssetTier.TIER_3


def _infer_exposure(asset: dict[str, Any]) -> ExposureLevel:
    """Infer exposure level from asset metadata."""
    md = asset.get("metadata") or asset
    if md.get("public_ip") or md.get("internet_facing") or md.get("publicly_accessible"):
        return ExposureLevel.INTERNET
    if md.get("public_access") or md.get("acl") == "public-read":
        return ExposureLevel.INTERNET
    atype = str(asset.get("type") or asset.get("asset_type") or "").lower()
    if any(k in atype for k in ("s3", "bucket", "lambda", "cloudfront", "ec2")):
        # default to internal unless confirmed public
        return ExposureLevel.INTERNAL
    return ExposureLevel.INTERNAL


def _risk_band(score: float) -> str:
    # Score range is ~0-1500 (10 * 1 * 1 * 1 * 1 * 1.5 * 100)
    if score >= 800:
        return "CRITICAL"
    if score >= 400:
        return "HIGH"
    if score >= 150:
        return "MEDIUM"
    return "LOW"


def _category_from_finding(finding: dict[str, Any]) -> FindingCategory:
    cat = finding.get("category") or finding.get("type") or ""
    cat_lower = str(cat).lower()
    if "vuln" in cat_lower:
        return FindingCategory.VULNERABILITY
    if "identity" in cat_lower or "iam" in cat_lower or "priv" in cat_lower:
        return FindingCategory.IDENTITY_RISK
    if "data" in cat_lower or "pii" in cat_lower or "phi" in cat_lower:
        return FindingCategory.DATA_EXPOSURE
    if "secret" in cat_lower or "key" in cat_lower:
        return FindingCategory.SECRET_EXPOSURE
    if "network" in cat_lower or "sg" in cat_lower or "security_group" in cat_lower:
        return FindingCategory.NETWORK_EXPOSURE
    if "compliance" in cat_lower or "compliant" in cat_lower:
        return FindingCategory.COMPLIANCE_VIOLATION
    return FindingCategory.MISCONFIGURATION


class FindingPrioritizationEngine:
    """
    Risk-Based Finding Prioritization with Fix-Order Optimizer.

    Combines CVSS + EPSS + asset criticality + exposure + threat intel into
    a single risk score, then runs a greedy knapsack to produce a fix plan
    that maximizes risk reduction within an engineer-hours budget.
    """

    def __init__(self) -> None:
        self._plans: dict[str, dict[str, FixPlan]] = defaultdict(dict)  # tenant -> plan_id -> FixPlan

    # ----- Public API ----------------------------------------------------

    def prioritize(
        self,
        tenant_id: str,
        findings: list[dict[str, Any]],
        assets: list[dict[str, Any]] | None = None,
    ) -> list[PrioritizedFinding]:
        """
        Score and rank all findings by composite risk score.
        assets: optional list of asset dicts (to lookup tier + exposure).
                If not provided, tier/exposure inferred from finding fields.
        """
        asset_index: dict[str, dict[str, Any]] = {}
        if assets:
            for a in assets:
                aid = str(a.get("id") or a.get("asset_id") or a.get("arn") or "")
                if aid:
                    asset_index[aid] = a

        results: list[PrioritizedFinding] = []
        for f in findings:
            pf = self._score_finding(f, asset_index)
            results.append(pf)

        # Sort by risk_score descending
        results.sort(key=lambda x: x.risk_score, reverse=True)
        return results

    def build_fix_plan(
        self,
        tenant_id: str,
        prioritized: list[PrioritizedFinding],
        budget_hours: float = 40.0,
    ) -> FixPlan:
        """
        Greedy 0/1 knapsack: maximize total risk reduction given budget_hours.
        Sort by risk_reduction_per_hour descending, pack until budget exhausted.
        """
        # Sort by RROI (risk reduction per hour)
        sorted_by_rroi = sorted(
            prioritized,
            key=lambda x: x.risk_reduction_per_hour,
            reverse=True,
        )

        selected: list[PrioritizedFinding] = []
        skipped: list[PrioritizedFinding] = []
        used = 0.0
        total_reduction = 0.0

        for pf in sorted_by_rroi:
            if used + pf.fix_effort_hours <= budget_hours:
                selected.append(pf)
                used += pf.fix_effort_hours
                total_reduction += pf.risk_score
            else:
                skipped.append(pf)

        # Quick wins: high RROI + low effort (≤2h)
        quick_wins = [
            pf for pf in selected
            if pf.fix_effort_hours <= 2.0 and pf.risk_reduction_per_hour >= 100.0
        ]

        plan = FixPlan(
            plan_id=str(uuid4()),
            tenant_id=tenant_id,
            budget_hours=budget_hours,
            used_hours=round(used, 2),
            remaining_hours=round(budget_hours - used, 2),
            total_risk_reduction=round(total_reduction, 2),
            selected_findings=selected,
            skipped_findings=skipped,
            quick_wins=quick_wins,
            created_at=time.time(),
        )
        self._plans[tenant_id][plan.plan_id] = plan
        return plan

    def get_plan(self, tenant_id: str, plan_id: str) -> FixPlan | None:
        return self._plans.get(tenant_id, {}).get(plan_id)

    def list_plans(self, tenant_id: str) -> list[dict[str, Any]]:
        return [
            {
                "plan_id": p.plan_id,
                "budget_hours": p.budget_hours,
                "used_hours": p.used_hours,
                "total_risk_reduction": p.total_risk_reduction,
                "selected_count": len(p.selected_findings),
                "quick_wins_count": len(p.quick_wins),
                "created_at": p.created_at,
            }
            for p in sorted(
                self._plans.get(tenant_id, {}).values(),
                key=lambda x: x.created_at,
                reverse=True,
            )
        ]

    def get_stats(
        self,
        tenant_id: str,
        prioritized: list[PrioritizedFinding] | None = None,
    ) -> dict[str, Any]:
        if prioritized is None:
            return {
                "tenant_id": tenant_id,
                "total_findings": 0,
                "by_risk_band": {},
                "by_category": {},
                "by_asset_tier": {},
                "total_risk_score": 0,
                "mean_risk_score": 0,
                "total_fix_effort_hours": 0,
                "top_risk_findings": [],
                "top_quick_wins": [],
            }

        by_band: dict[str, int] = defaultdict(int)
        by_cat: dict[str, int] = defaultdict(int)
        by_tier: dict[str, int] = defaultdict(int)
        total_risk = 0.0
        total_effort = 0.0

        for pf in prioritized:
            by_band[pf.risk_band] += 1
            by_cat[pf.category.value] += 1
            by_tier[pf.asset_tier.value] += 1
            total_risk += pf.risk_score
            total_effort += pf.fix_effort_hours

        top_risk = sorted(prioritized, key=lambda x: x.risk_score, reverse=True)[:10]
        top_quick = sorted(
            prioritized,
            key=lambda x: x.risk_reduction_per_hour,
            reverse=True,
        )[:10]

        return asdict(PrioritizationStats(
            tenant_id=tenant_id,
            total_findings=len(prioritized),
            by_risk_band=dict(by_band),
            by_category=dict(by_cat),
            by_asset_tier=dict(by_tier),
            total_risk_score=round(total_risk, 2),
            mean_risk_score=round(total_risk / max(len(prioritized), 1), 2),
            total_fix_effort_hours=round(total_effort, 2),
            top_risk_findings=[self._pf_to_dict(p) for p in top_risk],
            top_quick_wins=[self._pf_to_dict(p) for p in top_quick],
        ))

    # ----- Internals -----------------------------------------------------

    def _score_finding(
        self,
        finding: dict[str, Any],
        asset_index: dict[str, dict[str, Any]],
    ) -> PrioritizedFinding:
        # Pull fields with sensible defaults
        finding_id = str(finding.get("id") or finding.get("finding_id") or uuid4())
        rule_id = str(finding.get("rule_id") or "")
        title = str(finding.get("title") or finding.get("description") or "")
        severity = str(finding.get("severity") or "medium").lower()
        asset_id = str(finding.get("asset_id") or finding.get("resource_id") or finding.get("arn") or "")
        asset_name = str(finding.get("asset_name") or finding.get("resource_name") or asset_id)
        cvss = float(finding.get("cvss_score") or finding.get("cvss") or 5.0)
        epss = float(finding.get("epss_score") or finding.get("epss") or 0.1)
        threat_match = bool(finding.get("threat_intel_match") or finding.get("active_exploit") or False)
        remediation_id = finding.get("remediation_id")
        remediation_summary = str(finding.get("remediation_summary") or "")

        # Lookup asset
        asset = asset_index.get(asset_id, {})
        tier = _infer_asset_tier(asset or finding)
        exposure = _infer_exposure(asset or finding)
        category = _category_from_finding(finding)

        # Compute factors
        cvss_norm = max(0.0, min(10.0, cvss)) / 10.0
        epss_norm = max(0.0, min(1.0, epss))
        exposure_factor = EXPOSURE_WEIGHTS[exposure]
        asset_factor = TIER_WEIGHTS[tier]
        threat_boost = 1.5 if threat_match else 1.0

        # Composite risk score (0-1500)
        risk_score = cvss_norm * epss_norm * exposure_factor * asset_factor * threat_boost * 1000.0
        risk_score = round(risk_score, 2)
        risk_band = _risk_band(risk_score)

        # Effort estimate
        effort = EFFORT_MATRIX.get((category, severity), 2.0)
        risk_reduction_per_hour = round(risk_score / max(effort, 0.1), 2)

        # Human-readable reason
        reason_parts = []
        reason_parts.append(f"CVSS={cvss:.1f}")
        reason_parts.append(f"EPSS={epss:.2f}")
        reason_parts.append(f"exposure={exposure.value}")
        reason_parts.append(f"tier={tier.value}")
        if threat_match:
            reason_parts.append("ACTIVE_EXPLOIT")
        reason = " | ".join(reason_parts)

        return PrioritizedFinding(
            finding_id=finding_id,
            rule_id=rule_id,
            title=title,
            severity=severity,
            category=category,
            asset_id=asset_id,
            asset_name=asset_name,
            asset_tier=tier,
            exposure=exposure,
            cvss_score=cvss,
            epss_score=epss,
            threat_intel_match=threat_match,
            risk_score=risk_score,
            risk_band=risk_band,
            business_impact=asset_factor,
            exposure_factor=exposure_factor,
            asset_factor=asset_factor,
            threat_boost=threat_boost,
            fix_effort_hours=effort,
            risk_reduction_per_hour=risk_reduction_per_hour,
            remediation_id=remediation_id,
            remediation_summary=remediation_summary,
            reason=reason,
        )

    def _pf_to_dict(self, pf: PrioritizedFinding) -> dict[str, Any]:
        d = asdict(pf)
        return d


# Module-level singleton for the gateway to import
engine = FindingPrioritizationEngine()
