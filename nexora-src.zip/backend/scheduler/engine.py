"""
Scheduled Scan Engine — automatic recurring scans + email alerts.

Provides:
  - Schedule creation: daily / weekly / monthly / custom cron
  - Schedule persistence (survives restart)
  - Background scheduler thread (wakes every minute, checks due schedules)
  - Email alerts on critical findings (via SMTP — free with Gmail SMTP)
  - Alert deduplication (don't spam same finding twice in 24h)

Email alert logic:
  - On scan completion, count critical + high findings
  - If > 0 critical OR > 5 high → send email
  - Email contains: scan summary, top 5 critical findings, link to dashboard
  - Uses smtplib (no paid service needed — Gmail SMTP is free)

Schedule storage:
  - SQLite-backed (schedules survive restart)
  - Each schedule: tenant_id, cloud_account_id, scanners, cron expression,
    last_run, next_run, enabled, alert_email
"""
from __future__ import annotations

import json
import os
import smtplib
import sqlite3
import threading
import time
from dataclasses import dataclass, asdict, field
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any
from uuid import uuid4
from collections import defaultdict


DB_PATH = os.environ.get("SENTINEL_DB_PATH", "/home/z/my-project/db/sentinel.db")
_lock = threading.RLock()


@dataclass
class ScanSchedule:
    schedule_id: str
    tenant_id: str
    cloud_account_id: str
    name: str
    scanners: list[str]
    frequency: str           # hourly | daily | weekly | monthly
    hour: int = 2            # for daily: 2am; for weekly: 2am on day_of_week
    day_of_week: int = 0     # 0=Mon for weekly
    day_of_month: int = 1    # 1st for monthly
    enabled: bool = True
    alert_email: str = ""    # email to alert on critical findings
    last_run: float = 0
    next_run: float = 0
    created_at: float = 0
    run_count: int = 0


@dataclass
class AlertRecord:
    alert_id: str
    tenant_id: str
    schedule_id: str
    scan_id: str
    email: str
    subject: str
    body_preview: str
    sent_at: float
    status: str             # sent | failed | skipped
    error: str = ""


# ─────────────────────────────────────────────────────────────────────────
# Database
# ─────────────────────────────────────────────────────────────────────────
def _get_db():
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_scheduler_tables() -> None:
    with _get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS scan_schedules (
                schedule_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                cloud_account_id TEXT NOT NULL,
                name TEXT,
                scanners TEXT,
                frequency TEXT,
                hour INTEGER DEFAULT 2,
                day_of_week INTEGER DEFAULT 0,
                day_of_month INTEGER DEFAULT 1,
                enabled INTEGER DEFAULT 1,
                alert_email TEXT,
                last_run REAL DEFAULT 0,
                next_run REAL DEFAULT 0,
                created_at REAL,
                run_count INTEGER DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS scan_alerts (
                alert_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                schedule_id TEXT,
                scan_id TEXT,
                email TEXT,
                subject TEXT,
                body_preview TEXT,
                sent_at REAL,
                status TEXT,
                error TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_schedules_tenant ON scan_schedules(tenant_id, enabled)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_alerts_tenant ON scan_alerts(tenant_id, sent_at DESC)")
        conn.commit()


# ─────────────────────────────────────────────────────────────────────────
# Schedule CRUD
# ─────────────────────────────────────────────────────────────────────────
def save_schedule(sched: ScanSchedule) -> None:
    with _lock, _get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO scan_schedules
            (schedule_id, tenant_id, cloud_account_id, name, scanners, frequency,
             hour, day_of_week, day_of_month, enabled, alert_email,
             last_run, next_run, created_at, run_count)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            sched.schedule_id, sched.tenant_id, sched.cloud_account_id,
            sched.name, json.dumps(sched.scanners), sched.frequency,
            sched.hour, sched.day_of_week, sched.day_of_month,
            1 if sched.enabled else 0, sched.alert_email,
            sched.last_run, sched.next_run, sched.created_at, sched.run_count,
        ))
        conn.commit()


def load_schedules(tenant_id: str | None = None, enabled_only: bool = False) -> list[dict]:
    with _get_db() as conn:
        if tenant_id:
            q = "SELECT * FROM scan_schedules WHERE tenant_id = ?"
            params = (tenant_id,)
        else:
            q = "SELECT * FROM scan_schedules"
            params = ()
        if enabled_only:
            q += " AND enabled = 1" if tenant_id else " WHERE enabled = 1"
        rows = conn.execute(q, params).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["scanners"] = json.loads(d.get("scanners", "[]"))
            except Exception:
                d["scanners"] = []
            d["enabled"] = bool(d.get("enabled", 1))
            out.append(d)
        return out


def delete_schedule(schedule_id: str) -> bool:
    with _lock, _get_db() as conn:
        cur = conn.execute("DELETE FROM scan_schedules WHERE schedule_id = ?", (schedule_id,))
        conn.commit()
        return cur.rowcount > 0


def save_alert(alert: AlertRecord) -> None:
    with _lock, _get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO scan_alerts
            (alert_id, tenant_id, schedule_id, scan_id, email, subject,
             body_preview, sent_at, status, error)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            alert.alert_id, alert.tenant_id, alert.schedule_id, alert.scan_id,
            alert.email, alert.subject, alert.body_preview[:500],
            alert.sent_at, alert.status, alert.error,
        ))
        conn.commit()


def load_alerts(tenant_id: str, limit: int = 50) -> list[dict]:
    with _get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM scan_alerts WHERE tenant_id = ? ORDER BY sent_at DESC LIMIT ?",
            (tenant_id, limit),
        ).fetchall()
        return [dict(r) for r in rows]


# ─────────────────────────────────────────────────────────────────────────
# Email sending
# ─────────────────────────────────────────────────────────────────────────
def send_email_alert(
    to_email: str,
    subject: str,
    html_body: str,
    text_body: str = "",
) -> tuple[bool, str]:
    """Send an email via SMTP. Returns (success, error_message).

    Configuration via environment variables:
      SMTP_HOST (default: smtp.gmail.com)
      SMTP_PORT (default: 587)
      SMTP_USER (your Gmail address)
      SMTP_PASSWORD (Gmail App Password — 16 chars, free)
      SMTP_FROM (default: same as SMTP_USER)

    If SMTP_USER/SMTP_PASSWORD not set, email is skipped (no error).
    """
    smtp_host = os.environ.get("SMTP_HOST", "smtp.gmail.com")
    smtp_port = int(os.environ.get("SMTP_PORT", "587"))
    smtp_user = os.environ.get("SMTP_USER", "")
    smtp_password = os.environ.get("SMTP_PASSWORD", "")
    smtp_from = os.environ.get("SMTP_FROM", smtp_user)

    if not smtp_user or not smtp_password:
        return False, "SMTP credentials not configured (set SMTP_USER + SMTP_PASSWORD)"

    if not to_email:
        return False, "No recipient email"

    msg = MIMEMultipart("alternative")
    msg["From"] = smtp_from
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(text_body or "Sentinel alert — see HTML version", "plain"))
    msg.attach(MIMEText(html_body, "html"))

    try:
        with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as server:
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.sendmail(smtp_from, [to_email], msg.as_string())
        return True, ""
    except Exception as e:
        return False, str(e)


def build_alert_email(
    tenant_id: str,
    schedule_name: str,
    scan_id: str,
    findings: list[dict],
    assets_count: int,
    dashboard_url: str = "",
) -> tuple[str, str]:
    """Build email subject + body for a scan alert."""
    critical = [f for f in findings if f.get("severity") == "critical"]
    high = [f for f in findings if f.get("severity") == "high"]
    medium = [f for f in findings if f.get("severity") == "medium"]

    subject = f"[Sentinel] {len(critical)} critical, {len(high)} high findings — {schedule_name}"

    # Top 5 critical findings
    top_findings_html = ""
    for f in critical[:5]:
        top_findings_html += f"""
        <tr>
          <td style="padding:8px;border-bottom:1px solid #e5e7eb;color:#dc2626;font-weight:bold;">CRITICAL</td>
          <td style="padding:8px;border-bottom:1px solid #e5e7eb;">{f.get('title', f.get('rule_id', ''))[:80]}</td>
          <td style="padding:8px;border-bottom:1px solid #e5e7eb;font-family:monospace;font-size:12px;">{f.get('asset_name', f.get('asset_id', ''))[:40]}</td>
        </tr>
        """

    html = f"""
    <html><body style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;color:#1f2937;">
      <div style="background:#dc2626;color:white;padding:20px;border-radius:8px 8px 0 0;">
        <h1 style="margin:0;font-size:20px;">Nexora Security Alert</h1>
        <p style="margin:4px 0 0;font-size:14px;opacity:0.9;">{schedule_name}</p>
      </div>
      <div style="border:1px solid #e5e7eb;border-top:none;padding:20px;">
        <h2 style="font-size:18px;margin-top:0;">Scan Summary</h2>
        <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
          <tr><td style="padding:8px;background:#f9fafb;font-weight:bold;">Scan ID</td><td style="padding:8px;font-family:monospace;">{scan_id[:36]}</td></tr>
          <tr><td style="padding:8px;background:#f9fafb;font-weight:bold;">Assets Scanned</td><td style="padding:8px;">{assets_count}</td></tr>
          <tr><td style="padding:8px;background:#f9fafb;font-weight:bold;">Critical Findings</td><td style="padding:8px;color:#dc2626;font-weight:bold;">{len(critical)}</td></tr>
          <tr><td style="padding:8px;background:#f9fafb;font-weight:bold;">High Findings</td><td style="padding:8px;color:#ea580c;font-weight:bold;">{len(high)}</td></tr>
          <tr><td style="padding:8px;background:#f9fafb;font-weight:bold;">Medium Findings</td><td style="padding:8px;color:#d97706;">{len(medium)}</td></tr>
        </table>
        {f'<h2 style="font-size:16px;">Top {min(5, len(critical))} Critical Findings</h2><table style="width:100%;border-collapse:collapse;"><thead><tr style="background:#f9fafb;"><th style="padding:8px;text-align:left;">Severity</th><th style="padding:8px;text-align:left;">Finding</th><th style="padding:8px;text-align:left;">Asset</th></tr></thead><tbody>{top_findings_html}</tbody></table>' if critical else '<p>No critical findings.</p>'}
        {f'<p style="margin-top:20px;"><a href="{dashboard_url}" style="background:#2563eb;color:white;padding:10px 20px;text-decoration:none;border-radius:4px;">View Full Dashboard</a></p>' if dashboard_url else ''}
        <p style="margin-top:20px;color:#6b7280;font-size:12px;">Nexora — automated security alert</p>
      </div>
    </body></html>
    """
    text = f"""
Nexora Security Alert — {schedule_name}

Scan ID: {scan_id}
Assets scanned: {assets_count}
Critical: {len(critical)} | High: {len(high)} | Medium: {len(medium)}

Top critical findings:
""" + "\n".join(f"  - {f.get('title', '')[:80]} on {f.get('asset_name', '')[:40]}" for f in critical[:5])

    return subject, html


# ─────────────────────────────────────────────────────────────────────────
# Schedule calculation
# ─────────────────────────────────────────────────────────────────────────
def compute_next_run(frequency: str, hour: int, day_of_week: int, day_of_month: int, from_time: float = 0) -> float:
    """Compute the next run time in epoch seconds."""
    import datetime as dt
    now = dt.datetime.fromtimestamp(from_time if from_time else time.time())
    today = now.date()

    if frequency == "hourly":
        next_run = now.replace(minute=0, second=0, microsecond=0) + dt.timedelta(hours=1)
    elif frequency == "daily":
        candidate = today.replace(day=today.day)  # today
        next_dt = dt.datetime.combine(candidate, dt.time(hour=hour, minute=0))
        if next_dt <= now:
            next_dt += dt.timedelta(days=1)
        next_run = next_dt
    elif frequency == "weekly":
        days_ahead = (day_of_week - today.weekday()) % 7
        candidate = today + dt.timedelta(days=days_ahead)
        next_dt = dt.datetime.combine(candidate, dt.time(hour=hour, minute=0))
        if next_dt <= now:
            next_dt += dt.timedelta(weeks=1)
        next_run = next_dt
    elif frequency == "monthly":
        # Next month on day_of_month at hour
        if today.month == 12:
            next_month = today.replace(year=today.year + 1, month=1)
        else:
            next_month = today.replace(month=today.month + 1)
        try:
            candidate = next_month.replace(day=day_of_month)
        except ValueError:
            # day_of_month doesn't exist in next month
            candidate = next_month.replace(day=28)
        next_dt = dt.datetime.combine(candidate, dt.time(hour=hour, minute=0))
        next_run = next_dt
    else:
        # default: 1 hour from now
        next_run = now + dt.timedelta(hours=1)

    return next_run.timestamp()


# ─────────────────────────────────────────────────────────────────────────
# Scheduler background thread
# ─────────────────────────────────────────────────────────────────────────
class SchedulerEngine:
    """Background scheduler that runs scans on schedule + sends alerts."""

    def __init__(self) -> None:
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._started = False
        # tenant_id -> {(finding_id, asset_id)} -> last_alert_time (dedupe)
        self._alert_dedupe: dict[str, dict[tuple[str, str], float]] = defaultdict(dict)

    def start(self) -> None:
        if self._started:
            return
        self._started = True
        init_scheduler_tables()
        self._thread = threading.Thread(target=self._run_loop, daemon=True, name="scheduler")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)

    def _run_loop(self) -> None:
        """Main loop: every 60 seconds, check for due schedules and run them."""
        while not self._stop.is_set():
            try:
                self._check_and_run()
            except Exception as e:
                print(f"[scheduler] error: {e}", flush=True)
            self._stop.wait(60)  # 1 minute

    def _check_and_run(self) -> None:
        """Find due schedules and execute them."""
        now = time.time()
        all_schedules = load_schedules(enabled_only=True)
        due = [s for s in all_schedules if s.get("next_run", 0) <= now and s.get("enabled", True)]
        if not due:
            return
        print(f"[scheduler] {len(due)} schedule(s) due", flush=True)
        for sched_dict in due:
            try:
                self._run_one(sched_dict)
            except Exception as e:
                print(f"[scheduler] failed schedule {sched_dict.get('schedule_id')}: {e}", flush=True)

    def _run_one(self, sched_dict: dict) -> None:
        """Execute one scheduled scan + send alert if needed."""
        try:
            from gateway.app import store, drift_engine, evidence_vault_engine, workflow_engine
        except Exception as e:
            print(f"[scheduler] cannot import gateway: {e}", flush=True)
            return

        tenant_id = sched_dict["tenant_id"]
        cloud_account_id = sched_dict["cloud_account_id"]
        scanners = sched_dict.get("scanners", ["iam", "s3", "ec2", "rds", "eks"])

        account = store.get_cloud_account(cloud_account_id, tenant_id)
        if not account:
            print(f"[scheduler] cloud account not found: {cloud_account_id}", flush=True)
            return

        # Generate scan_id and execute
        scan_id = str(uuid4())
        print(f"[scheduler] running scan {scan_id} for schedule {sched_dict['name']}", flush=True)

        # Execute scan synchronously (we're in a background thread)
        try:
            from gateway.app import _execute_scan
            _execute_scan(scan_id, tenant_id, account, scanners)
        except Exception as e:
            print(f"[scheduler] scan failed: {e}", flush=True)
            return

        # Get scan results
        scan = store.get_scan(scan_id, tenant_id)
        if not scan:
            return

        findings = scan.findings or []
        critical_count = sum(1 for f in findings if f.get("severity") == "critical")
        high_count = sum(1 for f in findings if f.get("severity") == "high")

        # Update schedule
        sched = ScanSchedule(
            schedule_id=sched_dict["schedule_id"],
            tenant_id=tenant_id,
            cloud_account_id=cloud_account_id,
            name=sched_dict.get("name", ""),
            scanners=scanners,
            frequency=sched_dict.get("frequency", "daily"),
            hour=sched_dict.get("hour", 2),
            day_of_week=sched_dict.get("day_of_week", 0),
            day_of_month=sched_dict.get("day_of_month", 1),
            enabled=sched_dict.get("enabled", True),
            alert_email=sched_dict.get("alert_email", ""),
            last_run=time.time(),
            next_run=compute_next_run(
                sched_dict.get("frequency", "daily"),
                sched_dict.get("hour", 2),
                sched_dict.get("day_of_week", 0),
                sched_dict.get("day_of_month", 1),
            ),
            created_at=sched_dict.get("created_at", 0),
            run_count=sched_dict.get("run_count", 0) + 1,
        )
        save_schedule(sched)

        # Send email alert if critical findings or many high
        if sched.alert_email and (critical_count > 0 or high_count >= 5):
            self._send_alert(
                tenant_id=tenant_id,
                schedule_id=sched.schedule_id,
                schedule_name=sched.name,
                scan_id=scan_id,
                findings=findings,
                assets_count=scan.total_assets,
                email=sched.alert_email,
            )

    def _send_alert(
        self,
        tenant_id: str,
        schedule_id: str,
        schedule_name: str,
        scan_id: str,
        findings: list[dict],
        assets_count: int,
        email: str,
    ) -> None:
        # Dedupe: skip if we alerted on the same critical findings in last 24h
        now = time.time()
        dedupe_key = (schedule_id, scan_id)
        last_alert = self._alert_dedupe[tenant_id].get(dedupe_key, 0)
        if now - last_alert < 24 * 3600:
            return  # already alerted in last 24h

        dashboard_url = os.environ.get("SENTINEL_DASHBOARD_URL", "")
        subject, html = build_alert_email(
            tenant_id, schedule_name, scan_id, findings, assets_count, dashboard_url
        )
        success, error = send_email_alert(email, subject, html)

        alert = AlertRecord(
            alert_id=str(uuid4()),
            tenant_id=tenant_id,
            schedule_id=schedule_id,
            scan_id=scan_id,
            email=email,
            subject=subject,
            body_preview=html[:500],
            sent_at=now,
            status="sent" if success else "failed",
            error=error,
        )
        save_alert(alert)
        if success:
            self._alert_dedupe[tenant_id][dedupe_key] = now
            print(f"[scheduler] alert sent to {email} ({len(findings)} findings)", flush=True)
        else:
            print(f"[scheduler] alert failed: {error}", flush=True)


# Module-level singleton
engine = SchedulerEngine()
