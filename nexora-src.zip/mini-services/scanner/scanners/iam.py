"""IAM scanner - detects overly permissive roles, admin access, unused roles.

Works against real boto3 IAM data returned by collectors.collect_iam_roles().
Detects:
  IAM-001: Principal:* in trust policy
  IAM-002: AdministratorAccess (action:*, resource:*) via inline or attached policy
  IAM-003: Role unused for 90+ days
  IAM-004: Compute role (EC2/Lambda) with S3 full access (s3:*, resource:*)
"""
import json
from datetime import datetime, timezone
from typing import Any

from rules import get_rule


def _is_admin_policy(policy_doc: dict) -> bool:
    """Check if a policy document grants Action:*, Resource:* (AdministratorAccess-equivalent)."""
    if not isinstance(policy_doc, dict):
        return False
    for stmt in policy_doc.get("Statement", []):
        if isinstance(stmt, list):
            for s in stmt:
                if _stmt_is_admin(s):
                    return True
        else:
            if _stmt_is_admin(stmt):
                return True
    return False


def _stmt_is_admin(stmt: dict) -> bool:
    action = stmt.get("Action")
    resource = stmt.get("Resource")
    action_match = action == "*" or (isinstance(action, list) and "*" in action)
    resource_match = resource == "*" or (isinstance(resource, list) and "*" in resource)
    return stmt.get("Effect") == "Allow" and action_match and resource_match


def _is_s3_full_access(policy_doc: dict) -> bool:
    """Check if a policy grants s3:* on resource:* (S3FullAccess-equivalent)."""
    if not isinstance(policy_doc, dict):
        return False
    for stmt in policy_doc.get("Statement", []):
        if isinstance(stmt, list):
            stmts = stmt
        else:
            stmts = [stmt]
        for s in stmts:
            if s.get("Effect") != "Allow":
                continue
            action = s.get("Action")
            resource = s.get("Resource")
            action_match = action == "s3:*" or (isinstance(action, list) and "s3:*" in action) or action == "*"
            resource_match = resource == "*" or (isinstance(resource, list) and "*" in resource)
            if action_match and resource_match:
                return True
    return False


def _is_compute_role(name: str, trust_policy: dict) -> bool:
    """A role is a 'compute role' if its trust policy allows EC2 or Lambda to assume it."""
    if "EC2" in name or "Lambda" in name:
        return True
    for stmt in trust_policy.get("Statement", []):
        principal = stmt.get("Principal", {})
        if isinstance(principal, dict):
            service = principal.get("Service", "")
            if isinstance(service, str) and ("ec2" in service or "lambda" in service):
                return True
            if isinstance(service, list) and any("ec2" in s or "lambda" in s for s in service):
                return True
    return False


def scan(iam_roles: list[dict[str, Any]]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []

    for role in iam_roles:
        arn = role["Arn"]
        name = role["RoleName"]
        trust_policy = role.get("AssumeRolePolicyDocument", {}) or {}
        attached = role.get("AttachedPolicies", []) or []
        inline = role.get("InlinePolicies", []) or []
        last_used = role.get("LastUsed")

        # Rule IAM-001: Principal: * in trust policy
        for stmt in trust_policy.get("Statement", []):
            if isinstance(stmt, list):
                stmts = stmt
            else:
                stmts = [stmt]
            for s in stmts:
                principal = s.get("Principal", {})
                if principal == "*" or (isinstance(principal, dict) and principal.get("AWS") == "*"):
                    rule = get_rule("IAM-001")
                    findings.append({
                        "rule_id": rule.rule_id,
                        "resource_type": "aws_iam_role",
                        "resource_arn": arn,
                        "resource_name": name,
                        "region": "global",
                        "evidence": {
                            "trust_policy_statement": s,
                            "principal": principal,
                        },
                    })

        # Rule IAM-002: AdministratorAccess-equivalent (Action:*, Resource:*)
        # Check both attached and inline policies
        admin_evidence = None
        for policy in attached:
            if policy.get("PolicyName") == "AdministratorAccess":
                admin_evidence = {
                    "source": "attached_managed",
                    "policy_name": policy["PolicyName"],
                    "policy_arn": policy.get("PolicyArn"),
                }
                break
        if not admin_evidence:
            for ipolicy in inline:
                if _is_admin_policy(ipolicy.get("PolicyDocument")):
                    admin_evidence = {
                        "source": "inline",
                        "policy_name": ipolicy.get("PolicyName"),
                        "policy_document": ipolicy.get("PolicyDocument"),
                    }
                    break
        if admin_evidence:
            rule = get_rule("IAM-002")
            findings.append({
                "rule_id": rule.rule_id,
                "resource_type": "aws_iam_role",
                "resource_arn": arn,
                "resource_name": name,
                "region": "global",
                "evidence": admin_evidence,
            })

        # Rule IAM-004: Compute role with S3 full access
        if _is_compute_role(name, trust_policy):
            s3_evidence = None
            # Check attached first
            for policy in attached:
                if policy.get("PolicyName") in ("AmazonS3FullAccess", "AmazonS3ReadOnlyAccess"):
                    s3_evidence = {
                        "source": "attached_managed",
                        "policy_name": policy["PolicyName"],
                        "policy_arn": policy.get("PolicyArn"),
                    }
                    break
            if not s3_evidence:
                for ipolicy in inline:
                    if _is_s3_full_access(ipolicy.get("PolicyDocument")):
                        s3_evidence = {
                            "source": "inline",
                            "policy_name": ipolicy.get("PolicyName"),
                            "policy_document": ipolicy.get("PolicyDocument"),
                        }
                        break
            if s3_evidence:
                rule = get_rule("IAM-004")
                findings.append({
                    "rule_id": rule.rule_id,
                    "resource_type": "aws_iam_role",
                    "resource_arn": arn,
                    "resource_name": name,
                    "region": "global",
                    "evidence": {
                        "compute_role": True,
                        **s3_evidence,
                    },
                })

        # Rule IAM-003: unused role (90+ days since last use, OR created 90+ days ago and never used)
        if last_used is None:
            created_str = role.get("CreateDate", "")
            try:
                created = _parse_datetime(created_str)
                if created:
                    age_days = (datetime.now(timezone.utc) - created).days
                    if age_days > 90:
                        rule = get_rule("IAM-003")
                        findings.append({
                            "rule_id": rule.rule_id,
                            "resource_type": "aws_iam_role",
                            "resource_arn": arn,
                            "resource_name": name,
                            "region": "global",
                            "evidence": {
                                "last_used": None,
                                "age_days": age_days,
                                "create_date": created_str,
                            },
                        })
            except (ValueError, TypeError):
                pass
        else:
            last_used_str = last_used.get("LastUsedDate", "")
            try:
                last = _parse_datetime(last_used_str)
                if last:
                    days_since = (datetime.now(timezone.utc) - last).days
                    if days_since > 90:
                        rule = get_rule("IAM-003")
                        findings.append({
                            "rule_id": rule.rule_id,
                            "resource_type": "aws_iam_role",
                            "resource_arn": arn,
                            "resource_name": name,
                            "region": "global",
                            "evidence": {
                                "last_used": last_used_str,
                                "days_since_used": days_since,
                            },
                        })
            except (ValueError, TypeError):
                pass

    return findings


def _parse_datetime(s: str) -> datetime | None:
    """Parse ISO 8601 datetime, handling both Z and +00:00 suffixes."""
    if not s:
        return None
    s = s.replace("Z", "+00:00")
    return datetime.fromisoformat(s)
