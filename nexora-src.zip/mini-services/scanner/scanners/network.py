"""Security Group scanner - detects 0.0.0.0/0 ingress on sensitive ports."""
from typing import Any

from rules import get_rule

SENSITIVE_PORTS = {
    22: "NET-001",      # SSH
    3389: "NET-002",    # RDP
    3306: "NET-003",    # MySQL
    5432: "NET-003",    # PostgreSQL
    1433: "NET-003",    # MSSQL
    27017: "NET-003",   # MongoDB
    6379: "NET-003",    # Redis
    9200: "NET-003",    # Elasticsearch
}


def scan(security_groups: list[dict[str, Any]]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []

    for sg in security_groups:
        group_id = sg["GroupId"]
        name = sg["GroupName"]
        region = sg.get("Region", "us-east-1")
        arn = f"arn:aws:ec2:{region}:123456789012:security-group/{group_id}"

        # Ingress checks
        for perm in sg.get("IpPermissions", []):
            port = perm.get("FromPort")
            if port is None:
                continue
            for ip_range in perm.get("IpRanges", []):
                cidr = ip_range.get("CidrIp", "")
                if cidr == "0.0.0.0/0":
                    rule_id = SENSITIVE_PORTS.get(port)
                    if rule_id:
                        rule = get_rule(rule_id)
                        findings.append({
                            "rule_id": rule.rule_id,
                            "resource_type": "aws_security_group",
                            "resource_arn": arn,
                            "resource_name": f"{name} ({group_id})",
                            "region": region,
                            "evidence": {
                                "port": port,
                                "protocol": perm.get("IpProtocol"),
                                "cidr": cidr,
                                "description": ip_range.get("Description"),
                            },
                        })

        # Egress check - all traffic to 0.0.0.0/0
        for perm in sg.get("IpPermissionsEgress", []):
            proto = perm.get("IpProtocol", "-1")
            if proto == "-1":
                for ip_range in perm.get("IpRanges", []):
                    if ip_range.get("CidrIp") == "0.0.0.0/0":
                        rule = get_rule("NET-004")
                        findings.append({
                            "rule_id": rule.rule_id,
                            "resource_type": "aws_security_group",
                            "resource_arn": arn,
                            "resource_name": f"{name} ({group_id})",
                            "region": region,
                            "evidence": {
                                "egress_protocol": proto,
                                "cidr": "0.0.0.0/0",
                            },
                        })

    return findings
