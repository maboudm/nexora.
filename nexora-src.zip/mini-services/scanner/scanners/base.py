"""Scanner interface contract."""
from typing import Any, Protocol


class Scanner(Protocol):
    name: str

    def scan(self, resources: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Return a list of finding dicts. Each finding must include:
        rule_id, resource_type, resource_arn, resource_name, region, evidence (dict).
        """
        ...
