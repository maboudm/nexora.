"""EKS / Kubernetes scanner - detects public API endpoints, missing logging, missing encryption."""
from typing import Any

from rules import get_rule


def scan(clusters: list[dict[str, Any]]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []

    for cluster in clusters:
        name = cluster["ClusterName"]
        arn = cluster["Arn"]
        region = cluster.get("Region", "us-east-1")
        logging_config = cluster.get("Logging", {})
        encryption_config = cluster.get("EncryptionConfig", [])
        public_access = cluster.get("PublicAccess", False)
        public_cidrs = cluster.get("PublicAccessCidrs", [])

        # Rule K8S-001: Public API endpoint with 0.0.0.0/0
        if public_access and "0.0.0.0/0" in public_cidrs:
            rule = get_rule("K8S-001")
            findings.append({
                "rule_id": rule.rule_id,
                "resource_type": "aws_eks_cluster",
                "resource_arn": arn,
                "resource_name": name,
                "region": region,
                "evidence": {
                    "public_access": public_access,
                    "public_access_cidrs": public_cidrs,
                },
            })

        # Rule K8S-002: Control plane logging disabled
        enabled_types = set()
        for entry in logging_config.get("clusterLogging", []):
            if entry.get("enabled"):
                enabled_types.update(entry.get("types", []))
        required = {"api", "audit", "authenticator"}
        if not required.issubset(enabled_types):
            rule = get_rule("K8S-002")
            findings.append({
                "rule_id": rule.rule_id,
                "resource_type": "aws_eks_cluster",
                "resource_arn": arn,
                "resource_name": name,
                "region": region,
                "evidence": {
                    "enabled_log_types": list(enabled_types),
                    "required_log_types": list(required),
                },
            })

        # Rule K8S-003: No secrets encryption
        if not encryption_config:
            rule = get_rule("K8S-003")
            findings.append({
                "rule_id": rule.rule_id,
                "resource_type": "aws_eks_cluster",
                "resource_arn": arn,
                "resource_name": name,
                "region": region,
                "evidence": {"encryption_config": encryption_config},
            })

    return findings
