"""S3 scanner - detects public buckets, missing encryption, missing versioning/logging."""
from typing import Any

from rules import get_rule


def scan(buckets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []

    for bucket in buckets:
        name = bucket["Name"]
        region = bucket.get("Region", "us-east-1")
        arn = f"arn:aws:s3:::{name}"
        acl = bucket.get("ACL", [])
        policy = bucket.get("Policy")
        encryption = bucket.get("Encryption")
        versioning = bucket.get("Versioning")
        pab = bucket.get("PublicAccessBlock", {})
        logging = bucket.get("Logging")

        # Rule S3-001: Public readable
        is_public_acl = any(
            grant.get("Grantee", {}).get("URI", "").endswith("AllUsers")
            and grant.get("Permission") in ("READ", "FULL_CONTROL", "READ_ACP", "WRITE")
            for grant in acl
        )
        is_public_policy = False
        if policy:
            for stmt in policy.get("Statement", []):
                if stmt.get("Principal") == "*":
                    action_str = str(stmt.get("Action", ""))
                    if "s3:GetObject" in action_str or "s3:*" in action_str:
                        is_public_policy = True
        if is_public_acl or is_public_policy:
            rule = get_rule("S3-001")
            findings.append({
                "rule_id": rule.rule_id,
                "resource_type": "aws_s3_bucket",
                "resource_arn": arn,
                "resource_name": name,
                "region": region,
                "evidence": {
                    "public_acl": is_public_acl,
                    "public_policy": is_public_policy,
                    "acl": acl,
                },
            })

        # Rule S3-002: No encryption
        if encryption is None:
            rule = get_rule("S3-002")
            findings.append({
                "rule_id": rule.rule_id,
                "resource_type": "aws_s3_bucket",
                "resource_arn": arn,
                "resource_name": name,
                "region": region,
                "evidence": {"encryption": None},
            })

        # Rule S3-003: No versioning
        if versioning != "Enabled":
            rule = get_rule("S3-003")
            findings.append({
                "rule_id": rule.rule_id,
                "resource_type": "aws_s3_bucket",
                "resource_arn": arn,
                "resource_name": name,
                "region": region,
                "evidence": {"versioning": versioning},
            })

        # Rule S3-004: Public access block disabled (any of the four)
        if not (pab.get("BlockPublicAcls") and pab.get("IgnorePublicAcls")
                and pab.get("BlockPublicPolicy") and pab.get("RestrictPublicBuckets")):
            rule = get_rule("S3-004")
            findings.append({
                "rule_id": rule.rule_id,
                "resource_type": "aws_s3_bucket",
                "resource_arn": arn,
                "resource_name": name,
                "region": region,
                "evidence": {"public_access_block": pab},
            })

        # Rule S3-005: No logging
        if logging is None:
            rule = get_rule("S3-005")
            findings.append({
                "rule_id": rule.rule_id,
                "resource_type": "aws_s3_bucket",
                "resource_arn": arn,
                "resource_name": name,
                "region": region,
                "evidence": {"logging": None},
            })

    return findings
