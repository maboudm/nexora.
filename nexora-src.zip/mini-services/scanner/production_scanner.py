"""
Production AWS Scanner with cross-account access, pagination, retry, multi-region,
and AWS Organizations support.

This module replaces the basic collectors.py when scanning real AWS accounts.
It handles:
  - STS AssumeRole for cross-account access
  - External ID support
  - Session rotation
  - Trust policy validation
  - Pagination on all list APIs
  - Exponential backoff with jitter
  - Retry on throttling and transient failures
  - Multi-region auto-discovery via describe_regions
  - AWS Organizations enumeration (root, OUs, accounts)
  - Parallel region scanning
"""
import json
import os
import time
import random
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Optional
from dataclasses import dataclass

import boto3
from botocore.config import Config
from botocore.exceptions import (
    ClientError, EndpointConnectionError, ConnectionError as BotoConnectionError,
)


# ─── Retry Configuration ───

MAX_RETRIES = 5
BASE_BACKOFF = 1.0  # seconds
MAX_BACKOFF = 60.0  # seconds
RETRYABLE_ERRORS = [
    "Throttling",
    "ThrottlingException",
    "TooManyRequestsException",
    "RequestLimitExceeded",
    "ServiceUnavailable",
    "InternalError",
    "RequestTimeout",
    "RequestTimeoutException",
]


def retry_with_backoff(func, *args, max_retries=MAX_RETRIES, **kwargs):
    """Execute a function with exponential backoff and jitter.

    Retries on:
      - Throttling errors (HTTP 429)
      - Service unavailable (HTTP 503)
      - Transient network failures
      - Internal errors (HTTP 500)

    Does NOT retry on:
      - Access denied (HTTP 403)
      - Not found (HTTP 404)
      - Validation errors (HTTP 400)
    """
    last_exception = None

    for attempt in range(max_retries + 1):
        try:
            return func(*args, **kwargs)
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            # Check for retryable errors
            if error_code in RETRYABLE_ERRORS and attempt < max_retries:
                last_exception = e
                wait = _compute_backoff(attempt)
                time.sleep(wait)
                continue
            raise  # Non-retryable ClientError
        except (EndpointConnectionError, BotoConnectionError) as e:
            last_exception = e
            if attempt < max_retries:
                wait = _compute_backoff(attempt)
                time.sleep(wait)
                continue
            raise
        except Exception as e:
            raise  # Non-retryable exception

    raise last_exception


def _compute_backoff(attempt: int) -> float:
    """Compute exponential backoff with jitter.

    Formula: min(MAX_BACKOFF, BASE_BACKOFF * 2^attempt) + random(0, 1)
    """
    backoff = min(MAX_BACKOFF, BASE_BACKOFF * (2 ** attempt))
    jitter = random.uniform(0, 1)
    return backoff + jitter


# ─── Cross-Account Access ───

@dataclass
class CrossAccountConfig:
    """Configuration for cross-account scanning."""
    role_arn: str           # ARN of the role to assume in the target account
    external_id: str        # External ID for trust policy validation
    session_name: str = "sentinel-scanner"
    session_duration: int = 3600  # seconds (1 hour)
    session_tags: dict = None


class CrossAccountScanner:
    """Scanner that assumes a role in a target AWS account.

    Usage:
        config = CrossAccountConfig(
            role_arn="arn:aws:iam::123456789012:role/SentinelScannerRole",
            external_id="unique-external-id",
        )
        scanner = CrossAccountScanner(config)
        resources = scanner.scan_account()
    """

    def __init__(self, config: CrossAccountConfig):
        self.config = config
        self._cached_credentials = None
        self._credentials_expiry = 0
        self._lock = threading.Lock()

    def _get_session_credentials(self):
        """Get STS session credentials, with automatic rotation."""
        with self._lock:
            # Check if cached credentials are still valid (with 5-min buffer)
            if self._cached_credentials and time.time() < (self._credentials_expiry - 300):
                return self._cached_credentials

            # Assume role via STS
            sts = boto3.client(
                "sts",
                region_name="us-east-1",
                endpoint_url=os.environ.get("AWS_ENDPOINT_URL"),
            )
            assume_kwargs = {
                "RoleArn": self.config.role_arn,
                "RoleSessionName": self.config.session_name,
                "DurationSeconds": self.config.session_duration,
            }
            if self.config.external_id:
                assume_kwargs["ExternalId"] = self.config.external_id
            if self.config.session_tags:
                assume_kwargs["Tags"] = [
                    {"Key": k, "Value": v} for k, v in self.config.session_tags.items()
                ]

            response = retry_with_backoff(sts.assume_role, **assume_kwargs)
            self._cached_credentials = response["Credentials"]
            self._credentials_expiry = self._cached_credentials["Expiration"].timestamp()
            return self._cached_credentials

    def _make_client(self, service: str, region: str = "us-east-1") -> boto3.client:
        """Create a boto3 client using assumed role credentials."""
        creds = self._get_session_credentials()

        # For moto testing, use endpoint_url from env
        endpoint_url = os.environ.get("AWS_ENDPOINT_URL")

        config = Config(
            retries={"max_attempts": MAX_RETRIES, "mode": "adaptive"},
            max_pool_connections=50,
        )

        return boto3.client(
            service,
            region_name=region,
            aws_access_key_id=creds["AccessKeyId"],
            aws_secret_access_key=creds["SecretAccessKey"],
            aws_session_token=creds["SessionToken"],
            endpoint_url=endpoint_url,
            config=config,
        )

    def validate_trust_policy(self) -> dict:
        """Validate that the target role's trust policy allows our assumption.

        Returns:
            {"valid": bool, "details": str, "trust_policy": dict}
        """
        try:
            # Extract account ID from role ARN
            parts = self.config.role_arn.split(":")
            target_account = parts[4]
            role_name = parts[5].split("/")[1]

            # Get our own account ID
            sts = boto3.client("sts", region_name="us-east-1", endpoint_url=os.environ.get("AWS_ENDPOINT_URL"))
            identity = retry_with_backoff(sts.get_caller_identity)
            our_account = identity["Account"]

            # Get the target role's trust policy
            iam = self._make_client("iam")
            role = retry_with_backoff(iam.get_role, RoleName=role_name)
            trust_policy = role["Role"]["AssumeRolePolicyDocument"]

            if isinstance(trust_policy, str):
                trust_policy = json.loads(trust_policy)

            # Check if our account is allowed
            allowed = False
            for stmt in trust_policy.get("Statement", []):
                if stmt.get("Effect") != "Allow":
                    continue
                principal = stmt.get("Principal", {})
                if isinstance(principal, dict) and "AWS" in principal:
                    aws_principals = principal["AWS"]
                    if isinstance(aws_principals, str):
                        aws_principals = [aws_principals]
                    for p in aws_principals:
                        if p == "*":
                            allowed = True
                        elif p == f"arn:aws:iam::{our_account}:root":
                            allowed = True
                        elif p == f"arn:aws:iam::{our_account}:role/SentinelScannerRole":
                            allowed = True

                # Check ExternalId condition
                if allowed and self.config.external_id:
                    conditions = stmt.get("Condition", {})
                    if "StringEquals" in conditions:
                        expected_ext_id = conditions["StringEquals"].get("sts:ExternalId")
                        if expected_ext_id and expected_ext_id != self.config.external_id:
                            allowed = False

            return {
                "valid": allowed,
                "details": f"Trust policy {'allows' if allowed else 'denies'} our account {our_account}",
                "trust_policy": trust_policy,
            }
        except Exception as e:
            return {"valid": False, "details": f"Validation failed: {e}", "trust_policy": {}}

    def discover_regions(self) -> list[str]:
        """Auto-discover all enabled regions using EC2 describe_regions."""
        ec2 = self._make_client("ec2")
        try:
            response = retry_with_backoff(
                ec2.describe_regions,
                Filters=[{"Name": "opt-in-status", "Values": ["opt-in-not-needed", "opted-in"]}],
            )
            return [r["RegionName"] for r in response.get("Regions", [])]
        except Exception:
            # Fallback to common regions
            return ["us-east-1", "us-east-2", "us-west-1", "us-west-2",
                    "eu-west-1", "eu-central-1", "ap-south-1", "ap-southeast-1"]

    def scan_account(self, regions: list[str] = None, scanners: list[str] = None) -> dict:
        """Scan the target account across all regions.

        Args:
            regions: List of regions to scan. If None, auto-discover.
            scanners: List of scanner types. If None, run all.

        Returns:
            Dict of resources keyed by type.
        """
        if regions is None:
            regions = self.discover_regions()
        if scanners is None:
            scanners = ["iam", "s3", "sg", "ec2", "eks", "lambda", "secrets", "kms", "codebuild"]

        # Validate trust policy first
        trust_check = self.validate_trust_policy()
        if not trust_check["valid"]:
            raise PermissionError(f"Trust policy validation failed: {trust_check['details']}")

        # Global services (IAM, Organizations) — only scan in us-east-1
        results = {}
        if "iam" in scanners:
            results["iam_roles"] = self._scan_iam()
        if "orgs" in scanners:
            results["organizations"] = self._scan_organizations()

        # Regional services — scan in parallel
        regional_results = {}
        with ThreadPoolExecutor(max_workers=min(len(regions), 10)) as executor:
            future_to_region = {}
            for region in regions:
                future = executor.submit(self._scan_region, region, scanners)
                future_to_region[future] = region

            for future in as_completed(future_to_region):
                region = future_to_region[future]
                try:
                    region_data = future.result()
                    for k, v in region_data.items():
                        if k not in regional_results:
                            regional_results[k] = []
                        regional_results[k].extend(v)
                except Exception as e:
                    # Log but continue — one region failure shouldn't block the scan
                    regional_results.setdefault("errors", []).append({
                        "region": region,
                        "error": str(e),
                    })

        results.update(regional_results)
        return results

    def _scan_region(self, region: str, scanners: list[str]) -> dict:
        """Scan a single region."""
        results = {}

        if "s3" in scanners:
            results["s3_buckets"] = self._scan_s3(region)
        if "sg" in scanners:
            results["security_groups"] = self._scan_security_groups(region)
        if "ec2" in scanners:
            results["ec2_instances"] = self._scan_ec2(region)
        if "eks" in scanners:
            results["eks_clusters"] = self._scan_eks(region)
        if "lambda" in scanners:
            results["lambda_functions"] = self._scan_lambda(region)
        if "secrets" in scanners:
            results["secrets"] = self._scan_secrets(region)
        if "kms" in scanners:
            results["kms_keys"] = self._scan_kms(region)
        if "codebuild" in scanners:
            results["codebuild_projects"] = self._scan_codebuild(region)

        return results

    # ─── Paginated Scanners ───

    def _scan_iam(self) -> list[dict]:
        """Scan IAM roles with pagination."""
        iam = self._make_client("iam")
        roles = []
        paginator = iam.get_paginator("list_roles")
        for page in retry_with_backoff(lambda: paginator.paginate()):
            for role in page.get("Roles", []):
                role_name = role["RoleName"]
                # Get inline policies
                inline_policies = []
                try:
                    policy_paginator = iam.get_paginator("list_role_policies")
                    for pol_page in retry_with_backoff(
                        lambda: policy_paginator.paginate(RoleName=role_name)
                    ):
                        for pname in pol_page.get("PolicyNames", []):
                            pol = retry_with_backoff(
                                iam.get_role_policy, RoleName=role_name, PolicyName=pname
                            )
                            inline_policies.append({
                                "PolicyName": pname,
                                "PolicyDocument": pol["PolicyDocument"],
                            })
                except ClientError:
                    pass

                # Get attached managed policies
                attached = []
                try:
                    attached = retry_with_backoff(
                        iam.list_attached_role_policies, RoleName=role_name
                    ).get("AttachedPolicies", [])
                except ClientError:
                    pass

                # Get last used
                last_used = None
                try:
                    lu = retry_with_backoff(iam.get_role, RoleName=role_name)
                    rlu = lu["Role"].get("RoleLastUsed", {})
                    if rlu and rlu.get("LastUsedDate"):
                        last_used = {
                            "LastUsedDate": rlu["LastUsedDate"].isoformat(),
                            "Region": rlu.get("Region", "us-east-1"),
                        }
                except ClientError:
                    pass

                roles.append({
                    "RoleName": role_name,
                    "Arn": role["Arn"],
                    "Path": role.get("Path", "/"),
                    "CreateDate": role["CreateDate"].isoformat() if hasattr(role.get("CreateDate"), "isoformat") else str(role.get("CreateDate", "")),
                    "AssumeRolePolicyDocument": role.get("AssumeRolePolicyDocument", {}) if isinstance(role.get("AssumeRolePolicyDocument"), dict) else _safe_json_parse(role.get("AssumeRolePolicyDocument")),
                    "InlinePolicies": inline_policies,
                    "AttachedPolicies": attached,
                    "LastUsed": last_used,
                })
        return roles

    def _scan_s3(self, region: str) -> list[dict]:
        """Scan S3 buckets with pagination and per-bucket config."""
        s3 = self._make_client("s3", region)
        buckets = []
        try:
            response = retry_with_backoff(s3.list_buckets)
        except ClientError:
            return buckets

        for b in response.get("Buckets", []):
            name = b["Name"]
            bucket = {
                "Name": name,
                "CreationDate": b["CreationDate"].isoformat() if hasattr(b.get("CreationDate"), "isoformat") else "",
                "Region": region,
                "ACL": [],
                "Policy": None,
                "Encryption": None,
                "Versioning": "Suspended",
                "PublicAccessBlock": {"BlockPublicAcls": False, "IgnorePublicAcls": False, "BlockPublicPolicy": False, "RestrictPublicBuckets": False},
                "Logging": None,
            }
            # Each config fetch is independent and non-fatal
            for attr, func_name, kwargs in [
                ("ACL", "get_bucket_acl", {"Bucket": name}),
                ("Policy", "get_bucket_policy", {"Bucket": name}),
                ("Encryption", "get_bucket_encryption", {"Bucket": name}),
                ("Versioning", "get_bucket_versioning", {"Bucket": name}),
                ("PublicAccessBlock", "get_public_access_block", {"Bucket": name}),
                ("Logging", "get_bucket_logging", {"Bucket": name}),
            ]:
                try:
                    resp = retry_with_backoff(getattr(s3, func_name), **kwargs)
                    if attr == "Policy":
                        policy_str = resp.get("Policy")
                        bucket["Policy"] = _safe_json_parse(policy_str) if policy_str else None
                    elif attr == "Versioning":
                        bucket["Versioning"] = resp.get("Status", "Suspended")
                    elif attr == "PublicAccessBlock":
                        bucket["PublicAccessBlock"] = resp.get("PublicAccessBlockConfiguration", bucket["PublicAccessBlock"])
                    elif attr == "Logging":
                        bucket["Logging"] = resp.get("LoggingEnabled")
                    else:
                        bucket[attr] = resp.get(attr if attr != "ACL" else "Grants", bucket[attr])
                except ClientError:
                    pass
            buckets.append(bucket)
        return buckets

    def _scan_security_groups(self, region: str) -> list[dict]:
        """Scan security groups with pagination."""
        ec2 = self._make_client("ec2", region)
        sgs = []
        paginator = ec2.get_paginator("describe_security_groups")
        for page in retry_with_backoff(lambda: paginator.paginate()):
            for sg in page.get("SecurityGroups", []):
                sgs.append({
                    "GroupId": sg["GroupId"],
                    "GroupName": sg["GroupName"],
                    "Description": sg.get("Description", ""),
                    "VpcId": sg.get("VpcId", ""),
                    "Region": region,
                    "IpPermissions": sg.get("IpPermissions", []),
                    "IpPermissionsEgress": sg.get("IpPermissionsEgress", []),
                })
        return sgs

    def _scan_ec2(self, region: str) -> list[dict]:
        """Scan EC2 instances with pagination."""
        ec2 = self._make_client("ec2", region)
        instances = []
        paginator = ec2.get_paginator("describe_instances")
        for page in retry_with_backoff(lambda: paginator.paginate()):
            for res in page.get("Reservations", []):
                for inst in res.get("Instances", []):
                    sgs = list(inst.get("SecurityGroups", []))
                    if not sgs:
                        for ni in inst.get("NetworkInterfaces", []):
                            for sg in ni.get("Groups", []):
                                sgs.append({"GroupId": sg["GroupId"], "GroupName": sg.get("GroupName", "")})
                    instances.append({
                        "InstanceId": inst["InstanceId"],
                        "InstanceType": inst.get("InstanceType", ""),
                        "State": inst.get("State", {}).get("Name", ""),
                        "PublicIpAddress": inst.get("PublicIpAddress"),
                        "PrivateIpAddress": inst.get("PrivateIpAddress"),
                        "Region": region,
                        "VpcId": inst.get("VpcId", ""),
                        "SubnetId": inst.get("SubnetId", ""),
                        "SecurityGroups": sgs,
                        "IamInstanceProfile": inst.get("IamInstanceProfile"),
                        "ImageId": inst.get("ImageId", ""),
                    })
        return instances

    def _scan_eks(self, region: str) -> list[dict]:
        """Scan EKS clusters."""
        eks = self._make_client("eks", region)
        clusters = []
        try:
            paginator = eks.get_paginator("list_clusters")
            for page in retry_with_backoff(lambda: paginator.paginate()):
                for name in page.get("clusters", []):
                    try:
                        c = retry_with_backoff(eks.describe_cluster, name=name)["cluster"]
                        vpc_config = c.get("resourcesVpcConfig", {})
                        clusters.append({
                            "ClusterName": c["name"],
                            "Arn": c["arn"],
                            "Region": region,
                            "Status": c.get("status", ""),
                            "Version": c.get("version", ""),
                            "Logging": c.get("logging", {"clusterLogging": []}),
                            "EncryptionConfig": c.get("encryptionConfig", []),
                            "PublicAccess": vpc_config.get("endpointPublicAccess", False),
                            "PublicAccessCidrs": vpc_config.get("publicAccessCidrs", []),
                        })
                    except ClientError:
                        pass
        except ClientError:
            pass
        return clusters

    def _scan_lambda(self, region: str) -> list[dict]:
        """Scan Lambda functions with pagination."""
        lam = self._make_client("lambda", region)
        functions = []
        paginator = lam.get_paginator("list_functions")
        for page in retry_with_backoff(lambda: paginator.paginate()):
            for f in page.get("Functions", []):
                functions.append({
                    "FunctionName": f["FunctionName"],
                    "FunctionArn": f["FunctionArn"],
                    "Runtime": f.get("Runtime", ""),
                    "Role": f.get("Role", ""),
                    "Handler": f.get("Handler", ""),
                    "State": f.get("State", "Active"),
                    "Region": region,
                })
        return functions

    def _scan_secrets(self, region: str) -> list[dict]:
        """Scan Secrets Manager secrets with pagination."""
        sm = self._make_client("secretsmanager", region)
        secrets = []
        try:
            paginator = sm.get_paginator("list_secrets")
            for page in retry_with_backoff(lambda: paginator.paginate()):
                for s in page.get("SecretList", []):
                    secrets.append({
                        "Name": s["Name"],
                        "Arn": s["ARN"],
                        "Description": s.get("Description", ""),
                        "KmsKeyId": s.get("KmsKeyId"),
                        "Region": region,
                    })
        except ClientError:
            pass
        return secrets

    def _scan_kms(self, region: str) -> list[dict]:
        """Scan KMS keys with pagination."""
        kms = self._make_client("kms", region)
        keys = []
        try:
            paginator = kms.get_paginator("list_keys")
            for page in retry_with_backoff(lambda: paginator.paginate()):
                for k in page.get("Keys", []):
                    key_id = k["KeyId"]
                    try:
                        desc = retry_with_backoff(kms.describe_key, KeyId=key_id)["KeyMetadata"]
                        policy = None
                        try:
                            policy_str = retry_with_backoff(kms.get_key_policy, KeyId=key_id, PolicyName="default").get("Policy")
                            policy = _safe_json_parse(policy_str) if policy_str else None
                        except ClientError:
                            pass
                        keys.append({
                            "KeyId": key_id,
                            "Arn": desc.get("Arn", ""),
                            "Description": desc.get("Description", ""),
                            "KeyState": desc.get("KeyState", "Enabled"),
                            "KeyUsage": desc.get("KeyUsage", ""),
                            "KeyPolicy": policy,
                            "Region": region,
                        })
                    except ClientError:
                        pass
        except ClientError:
            pass
        return keys

    def _scan_codebuild(self, region: str) -> list[dict]:
        """Scan CodeBuild projects."""
        cb = self._make_client("codebuild", region)
        projects = []
        try:
            for name in retry_with_backoff(cb.list_projects).get("projects", []):
                try:
                    proj = retry_with_backoff(cb.batch_get_projects, names=[name])["projects"][0]
                    projects.append({
                        "Name": proj["name"],
                        "Arn": proj["arn"],
                        "ServiceRole": proj.get("serviceRole", ""),
                        "Region": region,
                    })
                except ClientError:
                    pass
        except ClientError:
            pass
        return projects

    def _scan_organizations(self) -> list[dict]:
        """Scan AWS Organizations for multi-account enumeration."""
        org = self._make_client("organizations")
        accounts = []
        try:
            paginator = org.get_paginator("list_accounts")
            for page in retry_with_backoff(lambda: paginator.paginate()):
                for acct in page.get("Accounts", []):
                    accounts.append({
                        "Id": acct["Id"],
                        "Name": acct.get("Name", ""),
                        "Email": acct.get("Email", ""),
                        "Status": acct.get("Status", ""),
                        "Arn": acct.get("Arn", ""),
                    })
        except ClientError:
            pass
        return accounts


def _safe_json_parse(raw):
    """Safely parse a JSON string, returning None on failure."""
    if raw is None:
        return None
    if isinstance(raw, dict):
        return raw
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None


# ─── Credential Vault ───

class CredentialVault:
    """Securely store and retrieve customer AWS credentials.

    Uses AWS Secrets Manager for encryption at rest.
    Credentials are NEVER stored in plaintext — only encrypted via KMS.

    Usage:
        vault = CredentialVault()
        vault.store("customer-123", {
            "role_arn": "arn:aws:iam::123456789012:role/SentinelScanner",
            "external_id": "unique-id",
        })
        creds = vault.retrieve("customer-123")
    """

    def __init__(self, secret_prefix: str = "sentinel/credentials"):
        self.secret_prefix = secret_prefix
        self._secrets = boto3.client(
            "secretsmanager",
            region_name="us-east-1",
            endpoint_url=os.environ.get("AWS_ENDPOINT_URL"),
            config=Config(retries={"max_attempts": MAX_RETRIES, "mode": "adaptive"}),
        )

    def store(self, customer_id: str, credentials: dict) -> str:
        """Store customer credentials securely.

        Args:
            customer_id: Unique customer identifier
            credentials: {"role_arn": ..., "external_id": ...}

        Returns:
            The ARN of the stored secret
        """
        secret_name = f"{self.secret_prefix}/{customer_id}"
        secret_string = json.dumps(credentials)

        try:
            response = self._secrets.create_secret(
                Name=secret_name,
                Description=f"AWS credentials for customer {customer_id}",
                SecretString=secret_string,
                KmsKeyId="alias/aws/secretsmanager",  # AWS managed KMS key
            )
            return response["ARN"]
        except self._secrets.exceptions.ResourceExistsException:
            # Update existing secret
            response = self._secrets.update_secret(
                SecretId=secret_name,
                SecretString=secret_string,
            )
            return response["ARN"]

    def retrieve(self, customer_id: str) -> Optional[dict]:
        """Retrieve customer credentials.

        Args:
            customer_id: Unique customer identifier

        Returns:
            {"role_arn": ..., "external_id": ...} or None
        """
        secret_name = f"{self.secret_prefix}/{customer_id}"
        try:
            response = self._secrets.get_secret_value(SecretId=secret_name)
            return json.loads(response["SecretString"])
        except self._secrets.exceptions.ResourceNotFoundException:
            return None
        except ClientError:
            return None

    def delete(self, customer_id: str) -> bool:
        """Delete customer credentials (for offboarding)."""
        secret_name = f"{self.secret_prefix}/{customer_id}"
        try:
            self._secrets.delete_secret(
                SecretId=secret_name,
                ForceDeleteWithoutRecovery=True,
            )
            return True
        except ClientError:
            return False

    def list_customers(self) -> list[str]:
        """List all customer IDs with stored credentials."""
        customer_ids = []
        paginator = self._secrets.get_paginator("list_secrets")
        for page in paginator.paginate(
            Filters=[{"Key": "name", "Values": [self.secret_prefix]}]
        ):
            for secret in page.get("SecretList", []):
                name = secret["Name"]
                if name.startswith(self.secret_prefix + "/"):
                    customer_id = name.split("/")[-1]
                    customer_ids.append(customer_id)
        return customer_ids


# ─── Multi-Account Orchestrator ───

class MultiAccountOrchestrator:
    """Orchestrate scanning across multiple AWS accounts.

    Usage:
        vault = CredentialVault()
        orchestrator = MultiAccountOrchestrator(vault)
        results = orchestrator.scan_all_accounts()
    """

    def __init__(self, vault: CredentialVault, max_parallel: int = 5):
        self.vault = vault
        self.max_parallel = max_parallel

    def scan_all_accounts(self) -> dict[str, dict]:
        """Scan all accounts that have credentials stored in the vault.

        Returns:
            {customer_id: scan_results}
        """
        customer_ids = self.vault.list_customers()
        results = {}

        with ThreadPoolExecutor(max_workers=self.max_parallel) as executor:
            future_to_customer = {}
            for customer_id in customer_ids:
                future = executor.submit(self._scan_single_account, customer_id)
                future_to_customer[future] = customer_id

            for future in as_completed(future_to_customer):
                customer_id = future_to_customer[future]
                try:
                    results[customer_id] = future.result()
                except Exception as e:
                    results[customer_id] = {"error": str(e), "status": "failed"}

        return results

    def _scan_single_account(self, customer_id: str) -> dict:
        """Scan a single account using stored credentials."""
        creds = self.vault.retrieve(customer_id)
        if not creds:
            return {"error": "No credentials found", "status": "failed"}

        config = CrossAccountConfig(
            role_arn=creds["role_arn"],
            external_id=creds.get("external_id", ""),
        )
        scanner = CrossAccountScanner(config)
        return scanner.scan_account()

    def scan_organization(self, master_role_arn: str, external_id: str) -> dict[str, dict]:
        """Scan all accounts in an AWS Organization.

        Args:
            master_role_arn: Role ARN in the master/payer account
            external_id: External ID for the master role

        Returns:
            {account_id: scan_results}
        """
        # Scan the master account to get org account list
        config = CrossAccountConfig(role_arn=master_role_arn, external_id=external_id)
        master_scanner = CrossAccountScanner(config)
        org_accounts = master_scanner._scan_organizations()

        # Scan each member account in parallel
        results = {}
        with ThreadPoolExecutor(max_workers=self.max_parallel) as executor:
            future_to_account = {}
            for acct in org_accounts:
                if acct["Status"] != "ACTIVE":
                    continue
                # Assume the same role name in each member account
                role_name = master_role_arn.split("/")[-1]
                member_role_arn = f"arn:aws:iam::{acct['Id']}:role/{role_name}"

                future = executor.submit(self._scan_member_account, member_role_arn, external_id)
                future_to_account[future] = acct["Id"]

            for future in as_completed(future_to_account):
                account_id = future_to_account[future]
                try:
                    results[account_id] = future.result()
                except Exception as e:
                    results[account_id] = {"error": str(e), "status": "failed"}

        return results

    def _scan_member_account(self, role_arn: str, external_id: str) -> dict:
        """Scan a single member account."""
        config = CrossAccountConfig(role_arn=role_arn, external_id=external_id)
        scanner = CrossAccountScanner(config)
        return scanner.scan_account()
