"""
Attack Chain Validator — Formal decision procedure.

Validates that a candidate attack chain is feasible by checking every hop
against 5 feasibility predicates:
  1. Permission feasibility (IAM solver)
  2. Identity feasibility (credentials)
  3. Network feasibility (reachability)
  4. Runtime feasibility (target exists and is in correct state)
  5. Credential feasibility (attacker holds required credentials)

Returns: (Bool, Evidence) — TRUE if chain is valid, FALSE with reason if broken.
"""
from typing import Optional
from dataclasses import dataclass, field
from iam_solver import authorize, evaluate_trust_policy, Verdict


@dataclass
class HopEvidence:
    step: int
    action: str
    resource: str
    permission_ok: bool
    permission_proof: Optional[dict] = None
    identity_ok: bool = True
    identity_reason: str = ""
    network_ok: bool = True
    network_reason: str = ""
    runtime_ok: bool = True
    runtime_reason: str = ""
    credential_ok: bool = True
    credential_reason: str = ""
    new_state_delta: dict = field(default_factory=dict)


@dataclass
class ValidationResult:
    valid: bool
    reason: str
    broken_at_hop: Optional[int] = None
    evidence: list[HopEvidence] = field(default_factory=list)
    witness_path: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "valid": self.valid,
            "reason": self.reason,
            "broken_at_hop": self.broken_at_hop,
            "evidence": [e.__dict__ for e in self.evidence],
            "witness_path": self.witness_path,
        }


def validate_chain(
    chain: list[dict],
    initial_state: dict,
    attacker: dict,
) -> ValidationResult:
    """Validate an attack chain.

    chain: list of hops, each hop is {
        action: str,
        resource_arn: str,
        resource_type: str,
        transition: str (e.g., "AssumeRole", "PassRole", "UpdateLambdaCode"),
        requires_network: bool,
        required_port: Optional[int],
    }

    initial_state: {
        identities: list,
        resources: list,
        scps: list,
        sessions: list,
        network: dict,
        resource_by_arn: dict,
    }

    attacker: {
        principal_arn: str,
        credentials: list,
        network_position: str,
        capabilities: set,
    }

    Returns ValidationResult.
    """
    if not chain:
        return ValidationResult(False, "empty chain")

    state = _deep_copy_state(initial_state)
    evidence = []
    witness_path = []

    for i, hop in enumerate(chain):
        hop_evidence = HopEvidence(step=i, action=hop["action"], resource=hop["resource_arn"])

        # 1. Permission feasibility
        identity = _find_identity(state, attacker["principal_arn"])
        if not identity:
            hop_evidence.permission_ok = False
            hop_evidence.permission_reason = f"attacker identity not found: {attacker['principal_arn']}"
            evidence.append(hop_evidence)
            return ValidationResult(
                False,
                f"hop {i}: identity not found",
                broken_at_hop=i,
                evidence=evidence,
                witness_path=witness_path,
            )

        proof = authorize(identity, hop["action"], hop["resource_arn"], state)
        hop_evidence.permission_ok = (proof.verdict == Verdict.ALLOW)
        hop_evidence.permission_proof = proof.to_dict()

        if not hop_evidence.permission_ok:
            hop_evidence.permission_reason = f"IAM denied: {proof.reason}"
            evidence.append(hop_evidence)
            return ValidationResult(
                False,
                f"hop {i}: permission denied — {proof.reason}",
                broken_at_hop=i,
                evidence=evidence,
                witness_path=witness_path,
            )

        # 2. Identity feasibility
        cred_ok, cred_reason = _check_identity_feasibility(hop, attacker, state)
        hop_evidence.identity_ok = cred_ok
        hop_evidence.identity_reason = cred_reason
        if not cred_ok:
            evidence.append(hop_evidence)
            return ValidationResult(
                False,
                f"hop {i}: identity infeasible — {cred_reason}",
                broken_at_hop=i,
                evidence=evidence,
                witness_path=witness_path,
            )

        # 3. Network feasibility
        if hop.get("requires_network", False):
            net_ok, net_reason = _check_network_feasibility(hop, attacker, state)
            hop_evidence.network_ok = net_ok
            hop_evidence.network_reason = net_reason
            if not net_ok:
                evidence.append(hop_evidence)
                return ValidationResult(
                    False,
                    f"hop {i}: network infeasible — {net_reason}",
                    broken_at_hop=i,
                    evidence=evidence,
                    witness_path=witness_path,
                )

        # 4. Runtime feasibility
        rt_ok, rt_reason = _check_runtime_feasibility(hop, state)
        hop_evidence.runtime_ok = rt_ok
        hop_evidence.runtime_reason = rt_reason
        if not rt_ok:
            evidence.append(hop_evidence)
            return ValidationResult(
                False,
                f"hop {i}: runtime infeasible — {rt_reason}",
                broken_at_hop=i,
                evidence=evidence,
                witness_path=witness_path,
            )

        # 5. Credential feasibility
        cred_ok, cred_reason = _check_credential_feasibility(hop, attacker, state)
        hop_evidence.credential_ok = cred_ok
        hop_evidence.credential_reason = cred_reason
        if not cred_ok:
            evidence.append(hop_evidence)
            return ValidationResult(
                False,
                f"hop {i}: credential infeasible — {cred_reason}",
                broken_at_hop=i,
                evidence=evidence,
                witness_path=witness_path,
            )

        # Apply mutation (update state for next hop)
        delta = _apply_mutation(hop, state, attacker)
        hop_evidence.new_state_delta = delta

        evidence.append(hop_evidence)
        witness_path.append({
            "step": i,
            "action": hop["action"],
            "resource": hop["resource_arn"],
            "transition": hop.get("transition", ""),
            "permission_proof": hop_evidence.permission_proof,
        })

    return ValidationResult(
        valid=True,
        reason="all hops valid",
        evidence=evidence,
        witness_path=witness_path,
    )


def _deep_copy_state(state: dict) -> dict:
    """Deep copy state for mutation during validation."""
    import copy
    return copy.deepcopy(state)


def _find_identity(state: dict, arn: str) -> Optional[dict]:
    """Find identity by ARN."""
    for identity in state.get("identities", []):
        if identity.get("arn") == arn:
            return identity
    return None


def _check_identity_feasibility(hop: dict, attacker: dict, state: dict) -> tuple[bool, str]:
    """Check if attacker identity can hold the credentials required."""
    required = hop.get("required_credential", "session")
    if required == "long_term":
        if not any(c.get("type") == "long_term" for c in attacker.get("credentials", [])):
            return False, "attacker has no long-term keys"
    elif required == "session":
        if not any(c.get("type") == "session" for c in attacker.get("credentials", [])):
            return False, "attacker has no active session"
    elif required == "federated":
        if not any(c.get("type") == "federated" for c in attacker.get("credentials", [])):
            return False, "attacker is not federated"
    return True, "identity feasible"


def _check_network_feasibility(hop: dict, attacker: dict, state: dict) -> tuple[bool, str]:
    """Check network reachability from attacker to target endpoint."""
    # For this implementation, we check if the target resource is network-accessible
    resource_arn = hop["resource_arn"]
    resource = state.get("resource_by_arn", {}).get(resource_arn, {})

    if not resource:
        return False, f"resource not found: {resource_arn}"

    # Check if resource is publicly accessible
    resource_type = resource.get("type", "")
    if resource_type == "aws_s3_bucket":
        # S3 is internet-accessible by default unless VPC endpoint only
        pab = resource.get("public_access_block", {})
        if pab.get("block_public_acls") and pab.get("restrict_public_buckets"):
            # Check if there's a VPC endpoint
            if not state.get("network", {}).get("vpc_endpoints", []):
                return False, "S3 bucket is private (PAB enabled, no VPC endpoint)"
        return True, "S3 endpoint reachable"

    if resource_type == "aws_ec2_instance":
        # EC2 requires network path
        public_ip = resource.get("public_ip")
        if not public_ip:
            return False, "EC2 instance has no public IP"
        # Check security groups
        sgs = resource.get("security_groups", [])
        for sg in sgs:
            sg_obj = _find_sg(state, sg.get("GroupId", ""))
            if sg_obj:
                for ingress in sg_obj.get("ingress", []):
                    if "0.0.0.0/0" in str(ingress.get("cidr_blocks", [])):
                        return True, f"reachable via SG {sg['GroupId']}"
        return False, "no SG allows ingress from attacker"

    if resource_type == "aws_eks_cluster":
        # EKS API is accessible if endpoint_public = true
        if resource.get("endpoint_public"):
            cidrs = resource.get("public_cidrs", [])
            if "0.0.0.0/0" in cidrs:
                return True, "EKS API public and open"
            return False, f"EKS API public but CIDR-restricted: {cidrs}"
        return False, "EKS API endpoint is private"

    # Default: assume reachable
    return True, "default reachable"


def _find_sg(state: dict, sg_id: str) -> Optional[dict]:
    """Find security group by ID."""
    for sg in state.get("security_groups", []):
        if sg.get("GroupId") == sg_id:
            return sg
    return None


def _check_runtime_feasibility(hop: dict, state: dict) -> tuple[bool, str]:
    """Check runtime preconditions."""
    action = hop["action"]
    resource_arn = hop["resource_arn"]
    resource = state.get("resource_by_arn", {}).get(resource_arn, {})

    if action == "lambda:InvokeFunction":
        if resource.get("state") == "Deleted":
            return False, "Lambda function deleted"
        if resource.get("state") != "Active":
            return False, f"Lambda not Active (state={resource.get('state')})"
        return True, "Lambda active"

    if action == "ssm:SendCommand":
        if not resource.get("ssm_agent_running", True):
            return False, "SSM agent not running"
        return True, "SSM agent running"

    if action == "ec2:RunInstances":
        if not hop.get("ami_id"):
            return False, "AMI not specified"
        return True, "AMI available"

    # Default: runtime OK
    return True, "runtime OK"


def _check_credential_feasibility(hop: dict, attacker: dict, state: dict) -> tuple[bool, str]:
    """Check if attacker holds required credentials."""
    required_creds = hop.get("required_credentials", [])
    for cred in required_creds:
        if cred not in attacker.get("credentials", []):
            return False, f"attacker lacks credential: {cred}"
    # Check credential expiry
    for cred in attacker.get("credentials", []):
        expiry = cred.get("expiry")
        if expiry and expiry < state.get("clock", 0):
            return False, f"credential expired: {cred.get('type')}"
    return True, "credentials feasible"


def _apply_mutation(hop: dict, state: dict, attacker: dict) -> dict:
    """Apply the hop's mutation to state. Returns delta."""
    transition = hop.get("transition", "")
    delta = {}

    if transition == "AssumeRole":
        # Add new session
        role_arn = hop["resource_arn"]
        new_session = {
            "principal_arn": role_arn,
            "scoped_policy": None,
            "expiry": state.get("clock", 0) + 3600,
            "source_ip": attacker.get("network_position", "0.0.0.0"),
        }
        state.setdefault("sessions", []).append(new_session)
        attacker.setdefault("credentials", []).append({
            "type": "session",
            "role_arn": role_arn,
            "expiry": new_session["expiry"],
        })
        delta["new_session"] = new_session

    elif transition == "PassRole":
        # No state change — just capability expansion at next invoke
        delta["note"] = "PassRole enables future invoke with target role"

    elif transition == "UpdateLambdaCode":
        # Lambda code is now attacker-controlled
        resource_arn = hop["resource_arn"]
        resource = state.get("resource_by_arn", {}).get(resource_arn)
        if resource:
            resource["code_hash"] = "attacker_controlled"
            delta["code_mutated"] = resource_arn

    elif transition == "AttachRolePolicy":
        # Role's effective policy changes
        resource_arn = hop["resource_arn"]
        delta["policy_attached"] = resource_arn

    elif transition == "CreatePolicyVersion":
        # New policy version is default
        delta["policy_version_created"] = hop.get("policy_arn", "")

    return delta
