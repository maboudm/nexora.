"""
Attack graph builder - constructs an attack path graph from findings.
Nodes are resources, edges are lateral movement / privilege escalation paths.

This is NOT a hardcoded demo. The graph is computed from real findings using
networkx. An attacker path is built when:
  - A public ingress (NET-*) reaches an EC2 instance with an IAM role
  - That IAM role has a trust policy or admin access finding (IAM-*)
  - That role can reach S3 buckets (S3-*) or other resources

The output is a directed graph in a JSON-serializable format the frontend can
render with react-flow or any DAG visualizer.
"""
import json
from collections import defaultdict
from typing import Any

import networkx as nx


SEVERITY_TO_WEIGHT = {"critical": 4, "high": 3, "medium": 2, "low": 1}


def build_attack_graph(findings: list[dict[str, Any]], resources: list[dict[str, Any]]) -> dict[str, Any]:
    """Build a directed attack-path graph from findings and resources."""
    g = nx.DiGraph()

    # Group findings by resource_arn for quick lookup
    findings_by_arn: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for f in findings:
        findings_by_arn[f["resource_arn"]].append(f)

    # Index resources by ARN
    resources_by_arn = {r["arn"]: r for r in resources}

    # 1. Add all resources as nodes (with their findings attached)
    for r in resources:
        arn = r["arn"]
        r_findings = findings_by_arn.get(arn, [])
        severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for f in r_findings:
            severity_counts[f.get("severity", "low")] += 1

        max_severity = "low"
        if severity_counts["critical"] > 0:
            max_severity = "critical"
        elif severity_counts["high"] > 0:
            max_severity = "high"
        elif severity_counts["medium"] > 0:
            max_severity = "medium"

        g.add_node(
            arn,
            id=arn,
            label=r["name"],
            type=r["type"],
            region=r.get("region", "global"),
            findings_count=len(r_findings),
            severity=max_severity,
            severity_counts=severity_counts,
        )

    # 2. Build edges based on relationships in the resource metadata
    #    - EC2 instance -> IAM role (instance profile)
    #    - EC2 instance -> Security Group
    #    - Security Group -> public internet (if 0.0.0.0/0)
    #    - IAM role -> S3 bucket (if S3 policy attached)
    #    - EKS cluster -> IAM role (cluster service role)

    # Add "internet" node as the attacker entry point
    internet_arn = "aws::internet"
    g.add_node(
        internet_arn,
        id=internet_arn,
        label="Internet (Attacker)",
        type="external",
        region="global",
        findings_count=0,
        severity="external",
        severity_counts={"critical": 0, "high": 0, "medium": 0, "low": 0},
    )

    for r in resources:
        rtype = r["type"]
        arn = r["arn"]
        meta = r.get("metadata", {})

        if rtype == "aws_security_group":
            # If this SG has a public ingress finding, edge from internet
            sg_findings = findings_by_arn.get(arn, [])
            has_public = any(f["rule_id"].startswith("NET-00") for f in sg_findings)
            if has_public:
                g.add_edge(internet_arn, arn, relationship="public_ingress")

        elif rtype == "aws_ec2_instance":
            # Edge: SG -> EC2
            for sg in meta.get("SecurityGroups", []):
                sg_arn = f"arn:aws:ec2:{r.get('region','us-east-1')}:123456789012:security-group/{sg['GroupId']}"
                if sg_arn in g:
                    g.add_edge(sg_arn, arn, relationship="attached_sg")
            # Edge: EC2 -> IAM role (instance profile)
            profile = meta.get("IamInstanceProfile", {})
            if profile and "Arn" in profile:
                # Convert instance-profile ARN to role ARN (best-effort)
                profile_arn = profile["Arn"]
                role_name = profile_arn.split("/")[-1].replace("instance-profile/", "")
                role_arn = f"arn:aws:iam::123456789012:role/{role_name}"
                if role_arn in g:
                    g.add_edge(arn, role_arn, relationship="assumes_role")

        elif rtype == "aws_iam_role":
            # Edge: IAM role -> S3 bucket (if S3FullAccess or S3 policy attached)
            meta_findings = findings_by_arn.get(arn, [])
            has_s3_finding = any(f["rule_id"] in ("IAM-004", "IAM-002") for f in meta_findings)
            if has_s3_finding:
                # Connect to all S3 buckets in same account
                for other_arn, other_data in g.nodes(data=True):
                    if other_data.get("type") == "aws_s3_bucket":
                        g.add_edge(arn, other_arn, relationship="can_access_s3")

        elif rtype == "aws_eks_cluster":
            # If API is public, edge from internet
            eks_findings = findings_by_arn.get(arn, [])
            has_public_api = any(f["rule_id"] == "K8S-001" for f in eks_findings)
            if has_public_api:
                g.add_edge(internet_arn, arn, relationship="public_api_endpoint")

    # 3. Layout: tier-based vertical positioning
    #    Tier 0: internet, Tier 1: SGs, Tier 2: EC2/eks, Tier 3: IAM roles, Tier 4: S3
    type_to_tier = {
        "external": 0,
        "aws_security_group": 1,
        "aws_ec2_instance": 2,
        "aws_eks_cluster": 2,
        "aws_iam_role": 3,
        "aws_s3_bucket": 4,
    }

    # Group nodes by tier for layout
    nodes_by_tier = defaultdict(list)
    for node_id, data in g.nodes(data=True):
        tier = type_to_tier.get(data.get("type", ""), 99)
        nodes_by_tier[tier].append((node_id, data))

    # Position nodes in a vertical tier layout
    positions = {}
    x_step = 220
    y_step = 160
    for tier, nodes in sorted(nodes_by_tier.items()):
        for idx, (node_id, _) in enumerate(nodes):
            positions[node_id] = {
                "x": idx * x_step + 100,
                "y": tier * y_step + 80,
            }

    # 4. Serialize
    nodes_out = []
    for node_id, data in g.nodes(data=True):
        node = {
            "id": node_id,
            "label": data.get("label", node_id),
            "type": data.get("type", "unknown"),
            "region": data.get("region", "global"),
            "findings_count": data.get("findings_count", 0),
            "severity": data.get("severity", "low"),
            "severity_counts": data.get("severity_counts", {}),
            "position": positions.get(node_id, {"x": 0, "y": 0}),
        }
        nodes_out.append(node)

    edges_out = []
    for source, target, data in g.edges(data=True):
        # Find a representative finding to show on the edge
        edge_id = f"{source}->{target}"
        edges_out.append({
            "id": edge_id,
            "source": source,
            "target": target,
            "label": data.get("relationship", "related_to"),
        })

    # 5. Critical attack paths (longest paths from internet to S3/data targets)
    attack_paths = []
    s3_arns = [n for n, d in g.nodes(data=True) if d.get("type") == "aws_s3_bucket"]
    for s3_arn in s3_arns:
        try:
            if g.has_node(internet_arn) and g.has_node(s3_arn):
                paths = list(nx.all_simple_paths(g, internet_arn, s3_arn, cutoff=6))
                for path in paths[:2]:  # limit per target
                    path_findings = []
                    for node in path:
                        for f in findings_by_arn.get(node, []):
                            path_findings.append(f["rule_id"])
                    attack_paths.append({
                        "path": path,
                        "findings": path_findings,
                        "length": len(path) - 1,
                    })
        except (nx.NetworkXError, nx.NodeNotFound):
            continue

    # Sort by length (shorter = more critical)
    attack_paths.sort(key=lambda p: p["length"])

    return {
        "nodes": nodes_out,
        "edges": edges_out,
        "attack_paths": attack_paths[:10],
        "summary": {
            "total_nodes": len(nodes_out),
            "total_edges": len(edges_out),
            "critical_paths": len(attack_paths),
            "internet_reachable_resources": len([n for n in g.successors(internet_arn)]) if g.has_node(internet_arn) else 0,
        },
    }
