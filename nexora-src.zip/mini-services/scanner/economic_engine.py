"""
Economic Value Engine — Translates technical findings into dollar-valued expected loss.

Formula:
  ExpectedLoss = P(compromise) × BlastRadius × BusinessImpact × RecoveryCost

Outputs:
  - expected_loss: dollar amount
  - breach_probability: 0-1
  - remediation_roi: ratio
  - risk_reduction: dollar amount
  - priority: Critical | High | Medium | Low
"""
import math
from dataclasses import dataclass


# Industry average breach costs (IBM Cost of a Data Breach Report 2024)
INDUSTRY_LOSS = {
    "finance": 5_900_000,
    "healthcare": 7_100_000,
    "technology": 4_900_000,
    "retail": 3_500_000,
    "manufacturing": 4_200_000,
    "education": 3_700_000,
    "government": 2_600_000,
    "other": 4_000_000,
}

CUSTOMER_SIZE_MULTIPLIER = {
    "micro": 0.3,    # <100 employees
    "small": 0.6,    # 100-1000
    "mid": 1.0,      # 1000-10000
    "large": 1.5,    # 10000-50000
    "enterprise": 2.0, # >50000
}

REGULATORY_MULTIPLIER = {
    "GDPR": 1.4,
    "HIPAA": 1.5,
    "PCI": 1.3,
    "SOC2": 1.1,
    "ISO27001": 1.1,
    "none": 1.0,
}

# Per-record loss (IBM average)
PER_RECORD_LOSS = 200  # USD

# Base adversary likelihood by industry
ADVERSARY_BASE_RATE = {
    "finance": 0.30,
    "healthcare": 0.25,
    "technology": 0.20,
    "retail": 0.15,
    "manufacturing": 0.10,
    "education": 0.08,
    "government": 0.15,
    "other": 0.10,
}

# Confidence tiers from simulation
CONFIDENCE_SCORES = {
    "CONFIRMED": 0.9,
    "LIKELY": 0.5,
    "UNKNOWN": 0.3,
    "NOT_EXPLOITABLE": 0.0,
}

# Remediation cost estimates (engineer-hours × $150/hr)
REMEDIATION_COSTS = {
    "S3-001": 2,    # Enable BlockPublicAccess
    "S3-002": 4,    # Enable SSE
    "S3-003": 2,    # Enable versioning
    "S3-004": 2,    # Enable PAB
    "S3-005": 4,    # Enable logging
    "IAM-001": 8,   # Fix trust policy
    "IAM-002": 8,   # Remove AdminAccess
    "IAM-003": 4,   # Remove unused role
    "IAM-004": 8,   # Scope S3 permissions
    "NET-001": 4,   # Restrict SSH
    "NET-002": 4,   # Restrict RDP
    "NET-003": 4,   # Restrict DB ports
    "NET-004": 8,   # Restrict egress
    "K8S-001": 8,   # Restrict EKS API
    "K8S-002": 4,   # Enable EKS logging
    "K8S-003": 8,   # Enable EKS encryption
}


@dataclass
class EconomicVerdict:
    finding_id: str
    expected_loss: float
    breach_probability: float
    blast_radius_count: int
    per_record_loss: float
    recovery_cost: float
    remediation_cost: float
    remediation_roi: float
    risk_reduction: float
    priority: str
    justification: str

    def to_dict(self) -> dict:
        return {
            "finding_id": self.finding_id,
            "expected_loss": round(self.expected_loss, 2),
            "breach_probability": round(self.breach_probability, 4),
            "blast_radius_count": self.blast_radius_count,
            "per_record_loss": self.per_record_loss,
            "recovery_cost": round(self.recovery_cost, 2),
            "remediation_cost": round(self.remediation_cost, 2),
            "remediation_roi": round(self.remediation_roi, 1),
            "risk_reduction": round(self.risk_reduction, 2),
            "priority": self.priority,
            "justification": self.justification,
        }


def compute_economic_verdict(
    finding: dict,
    confidence_tier: str = "CONFIRMED",
    customer_profile: dict | None = None,
) -> EconomicVerdict:
    """Compute economic verdict for a finding.

    customer_profile = {
        industry: "finance" | "healthcare" | ...
        size: "micro" | "small" | "mid" | "large" | "enterprise"
        regulations: ["GDPR", "HIPAA", ...]
    }
    """
    profile = customer_profile or {"industry": "other", "size": "mid", "regulations": []}
    industry = profile.get("industry", "other")
    size = profile.get("size", "mid")
    regulations = profile.get("regulations", [])

    # 1. Breach probability
    exploitability_confidence = CONFIDENCE_SCORES.get(confidence_tier, 0.5)
    adversary_base = ADVERSARY_BASE_RATE.get(industry, 0.10)

    # Target attractiveness: PII/PHI = 1.5x, production = 1.2x
    resource_type = finding.get("resource_type", "")
    tags = finding.get("tags", [])
    attractiveness = 1.0
    if "PII" in tags or "PHI" in tags or "customer" in str(finding.get("title", "")).lower():
        attractiveness *= 1.5
    if "production" in tags or "prod" in str(finding.get("resource_name", "")).lower():
        attractiveness *= 1.2

    # Exposure window: findings open >30 days are assumed exploited
    days_open = finding.get("days_open", 0)
    exposure_factor = min(1.0, days_open / 30.0) if days_open > 0 else 0.5

    breach_probability = exploitability_confidence * adversary_base * attractiveness * exposure_factor
    breach_probability = min(1.0, breach_probability)

    # 2. Blast radius (estimated records affected)
    blast_radius_count = finding.get("estimated_records", 1000)
    if resource_type == "aws_s3_bucket":
        blast_radius_count = max(blast_radius_count, 10000)  # S3 buckets typically have many objects
    elif resource_type == "aws_rds_instance":
        blast_radius_count = max(blast_radius_count, 100000)  # DBs have many rows
    elif resource_type == "aws_secretsmanager_secret":
        blast_radius_count = max(blast_radius_count, 1)  # 1 secret, but high value

    # 3. Business impact
    industry_loss = INDUSTRY_LOSS.get(industry, 4_000_000)
    size_mult = CUSTOMER_SIZE_MULTIPLIER.get(size, 1.0)
    reg_mult = 1.0
    for reg in regulations:
        reg_mult *= REGULATORY_MULTIPLIER.get(reg, 1.0)

    business_impact = industry_loss * size_mult * reg_mult

    # 4. Recovery cost
    forensic_cost = 50_000 + (blast_radius_count * 0.05)  # $50K + $0.05 per record
    notification_cost = blast_radius_count * 50  # $50 per record (GDPR)
    legal_cost = min(10_000_000, blast_radius_count * 20)  # $20 per record, capped
    productivity_cost = 30_000  # 2 weeks of security team time
    recovery_cost = forensic_cost + notification_cost + legal_cost + productivity_cost

    # 5. Expected loss = P × records × per_record_loss
    per_record_loss = PER_RECORD_LOSS
    expected_loss = breach_probability * blast_radius_count * per_record_loss

    # 6. Remediation cost
    rule_id = finding.get("rule_id", "")
    engineer_hours = REMEDIATION_COSTS.get(rule_id, 4)
    remediation_cost = engineer_hours * 150  # $150/hr loaded

    # 7. ROI
    if remediation_cost > 0:
        remediation_roi = (expected_loss - remediation_cost) / remediation_cost
    else:
        remediation_roi = float("inf") if expected_loss > 0 else 0

    # 8. Risk reduction
    risk_reduction = expected_loss - remediation_cost

    # 9. Priority
    if expected_loss > 500_000 or breach_probability > 0.3:
        priority = "Critical"
    elif expected_loss > 100_000 or breach_probability > 0.15:
        priority = "High"
    elif expected_loss > 10_000:
        priority = "Medium"
    else:
        priority = "Low"

    # 10. Justification
    justification = (
        f"Finding '{finding.get('title', 'Unknown')}' on {resource_type} "
        f"has {breach_probability:.1%} breach probability. "
        f"Blast radius: {blast_radius_count:,} records. "
        f"Expected loss: ${expected_loss:,.0f}. "
        f"Remediation cost: ${remediation_cost:,.0f}. "
        f"ROI: {remediation_roi:.0f}x. "
        f"Priority: {priority}."
    )

    return EconomicVerdict(
        finding_id=finding.get("id", ""),
        expected_loss=expected_loss,
        breach_probability=breach_probability,
        blast_radius_count=blast_radius_count,
        per_record_loss=per_record_loss,
        recovery_cost=recovery_cost,
        remediation_cost=remediation_cost,
        remediation_roi=remediation_roi,
        risk_reduction=risk_reduction,
        priority=priority,
        justification=justification,
    )


def compute_posture_score(severity_counts: dict) -> float:
    """Compute 0-100 posture score from severity counts.

    Formula: 100 × exp(-0.05 × (critical×4 + high×2 + medium×1 + low×0.3))
    """
    critical = severity_counts.get("critical", 0)
    high = severity_counts.get("high", 0)
    medium = severity_counts.get("medium", 0)
    low = severity_counts.get("low", 0)

    weighted = critical * 4 + high * 2 + medium * 1 + low * 0.3
    score = 100 * math.exp(-0.05 * weighted)
    return max(0, min(100, score))


def compute_total_expected_loss(verdicts: list[EconomicVerdict]) -> float:
    """Sum of expected losses across all findings (with dedup for correlated findings)."""
    # Simple sum (correlation adjustment would go here)
    return sum(v.expected_loss for v in verdicts)


def compute_remediiation_priority(verdicts: list[EconomicVerdict]) -> list[dict]:
    """Rank remediations by ROI (highest first)."""
    ranked = sorted(verdicts, key=lambda v: v.remediation_roi, reverse=True)
    return [
        {
            "finding_id": v.finding_id,
            "priority": v.priority,
            "expected_loss": v.expected_loss,
            "remediation_cost": v.remediation_cost,
            "roi": v.remediation_roi,
            "risk_reduction": v.risk_reduction,
        }
        for v in ranked
    ]
