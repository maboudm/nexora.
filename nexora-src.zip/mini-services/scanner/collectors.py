"""
AWS resource collectors.

Each function calls real boto3 APIs to fetch cloud resources from the
target AWS account. In production, the endpoint_url is None (uses real AWS).
In development, endpoint_url points at a moto server running locally.

The scanner service calls these collectors, then runs rule-based scanners
over the returned data. The same code works against real AWS - only the
endpoint differs.
"""
import json
import os
from typing import Any

import boto3


def _make_client(service: str, region: str = "us-east-1"):
    """Build a boto3 client. endpoint_url comes from AWS_ENDPOINT_URL env var
    (set by the scanner service). When unset, boto3 talks to real AWS.
    """
    endpoint = os.environ.get("AWS_ENDPOINT_URL") or None
    return boto3.client(
        service,
        region_name=region,
        endpoint_url=endpoint,
        aws_access_key_id=os.environ.get("AWS_ACCESS_KEY_ID", "test"),
        aws_secret_access_key=os.environ.get("AWS_SECRET_ACCESS_KEY", "test"),
    )


def collect_iam_roles() -> list[dict[str, Any]]:
    """Fetch all IAM roles with their trust policies, inline policies, and last-used info."""
    iam = _make_client("iam")
    roles_out = []
    paginator = iam.get_paginator("list_roles")
    for page in paginator.paginate():
        for role in page["Roles"]:
            role_name = role["RoleName"]
            arn = role["Arn"]
            # Get inline policies attached to this role
            inline_policies = []
            try:
                policy_names = iam.list_role_policies(RoleName=role_name)["PolicyNames"]
                for pname in policy_names:
                    pol = iam.get_role_policy(RoleName=role_name, PolicyName=pname)
                    inline_policies.append({
                        "PolicyName": pname,
                        "PolicyDocument": pol["PolicyDocument"],
                    })
            except Exception:
                pass
            # Get attached managed policies
            attached = []
            try:
                attached = iam.list_attached_role_policies(RoleName=role_name)["AttachedPolicies"]
            except Exception:
                pass
            # Get role last-used (for unused-role detection)
            last_used = None
            try:
                lu = iam.get_role(RoleName=role_name)["Role"].get("RoleLastUsed", {})
                if lu and lu.get("LastUsedDate"):
                    last_used = {
                        "LastUsedDate": lu["LastUsedDate"].isoformat(),
                        "Region": lu.get("Region", "us-east-1"),
                    }
            except Exception:
                pass

            roles_out.append({
                "RoleName": role_name,
                "Arn": arn,
                "Path": role.get("Path", "/"),
                "CreateDate": role["CreateDate"].isoformat() if hasattr(role.get("CreateDate"), "isoformat") else str(role.get("CreateDate", "")),
                "AssumeRolePolicyDocument": role.get("AssumeRolePolicyDocument", {}) if isinstance(role.get("AssumeRolePolicyDocument"), dict) else _parse_policy(role.get("AssumeRolePolicyDocument")),
                "InlinePolicies": inline_policies,
                "AttachedPolicies": attached,
                "LastUsed": last_used,
            })
    return roles_out


def collect_s3_buckets() -> list[dict[str, Any]]:
    """Fetch all S3 buckets with their ACL, policy, encryption, versioning, PAB, and logging config."""
    s3 = _make_client("s3")
    buckets = s3.list_buckets()["Buckets"]
    out = []
    for b in buckets:
        name = b["Name"]
        # Try to determine the bucket's region
        try:
            loc = s3.get_bucket_location(Bucket=name)
            region = loc.get("LocationConstraint") or "us-east-1"
        except Exception:
            region = "us-east-1"

        bucket = {
            "Name": name,
            "CreationDate": b["CreationDate"].isoformat() if hasattr(b.get("CreationDate"), "isoformat") else str(b.get("CreationDate", "")),
            "Region": region,
            "ACL": [],
            "Policy": None,
            "Encryption": None,
            "Versioning": "Suspended",
            "PublicAccessBlock": {
                "BlockPublicAcls": True,
                "IgnorePublicAcls": True,
                "BlockPublicPolicy": True,
                "RestrictPublicBuckets": True,
            },
            "Logging": None,
        }
        # Use a region-specific client for bucket-specific operations
        regional_client = _make_client("s3", region)
        try:
            bucket["ACL"] = regional_client.get_bucket_acl(Bucket=name).get("Grants", [])
        except Exception:
            pass
        try:
            bucket["Policy"] = regional_client.get_bucket_policy(Bucket=name).get("Policy")
            if isinstance(bucket["Policy"], str):
                bucket["Policy"] = _parse_policy(bucket["Policy"])
        except Exception:
            pass
        try:
            bucket["Encryption"] = regional_client.get_bucket_encryption(Bucket=name).get("ServerSideEncryptionConfiguration")
        except Exception:
            pass
        try:
            ver = regional_client.get_bucket_versioning(Bucket=name)
            bucket["Versioning"] = ver.get("Status", "Suspended")
        except Exception:
            pass
        try:
            bucket["PublicAccessBlock"] = regional_client.get_public_access_block(Bucket=name)["PublicAccessBlockConfiguration"]
        except Exception:
            pass  # PAB not configured - defaults to all-False which is also a finding
            bucket["PublicAccessBlock"] = {
                "BlockPublicAcls": False,
                "IgnorePublicAcls": False,
                "BlockPublicPolicy": False,
                "RestrictPublicBuckets": False,
            }
        try:
            log = regional_client.get_bucket_logging(Bucket=name)
            if "LoggingEnabled" in log:
                bucket["Logging"] = log["LoggingEnabled"]
        except Exception:
            pass
        out.append(bucket)
    return out


def collect_security_groups() -> list[dict[str, Any]]:
    """Fetch all EC2 security groups with their ingress/egress rules."""
    ec2 = _make_client("ec2")
    sgs = ec2.describe_security_groups()["SecurityGroups"]
    out = []
    for sg in sgs:
        out.append({
            "GroupId": sg["GroupId"],
            "GroupName": sg["GroupName"],
            "Description": sg.get("Description", ""),
            "VpcId": sg.get("VpcId", ""),
            "Region": "us-east-1",
            "IpPermissions": sg.get("IpPermissions", []),
            "IpPermissionsEgress": sg.get("IpPermissionsEgress", []),
        })
    return out


def collect_ec2_instances() -> list[dict[str, Any]]:
    """Fetch all EC2 instances."""
    ec2 = _make_client("ec2")
    out = []
    for res in ec2.describe_instances()["Reservations"]:
        for inst in res["Instances"]:
            # SGs may be at top level OR inside NetworkInterfaces (when launched with NI)
            sgs = list(inst.get("SecurityGroups", []))
            if not sgs:
                for ni in inst.get("NetworkInterfaces", []):
                    for sg in ni.get("Groups", []):
                        sgs.append({"GroupId": sg["GroupId"], "GroupName": sg.get("GroupName", "")})
            out.append({
                "InstanceId": inst["InstanceId"],
                "InstanceType": inst.get("InstanceType", ""),
                "State": inst.get("State", {}).get("Name", ""),
                "PublicIpAddress": inst.get("PublicIpAddress"),
                "PrivateIpAddress": inst.get("PrivateIpAddress") or (inst.get("NetworkInterfaces", [{}])[0].get("PrivateIpAddress") if inst.get("NetworkInterfaces") else None),
                "Region": "us-east-1",
                "VpcId": inst.get("VpcId", ""),
                "SubnetId": inst.get("SubnetId", ""),
                "SecurityGroups": sgs,
                "IamInstanceProfile": inst.get("IamInstanceProfile"),
                "ImageId": inst.get("ImageId", ""),
            })
    return out


def collect_eks_clusters() -> list[dict[str, Any]]:
    """Fetch all EKS clusters with their logging, encryption, and network config."""
    eks = _make_client("eks")
    cluster_names = eks.list_clusters()["clusters"]
    out = []
    for name in cluster_names:
        c = eks.describe_cluster(name=name)["cluster"]
        vpc_config = c.get("resourcesVpcConfig", {})
        out.append({
            "ClusterName": c["name"],
            "Arn": c["arn"],
            "Region": "us-east-1",
            "Status": c.get("status", ""),
            "Version": c.get("version", ""),
            "Endpoint": c.get("endpoint", ""),
            "Logging": c.get("logging", {"clusterLogging": []}),
            "EncryptionConfig": c.get("encryptionConfig", []),
            "PublicAccess": vpc_config.get("endpointPublicAccess", False),
            "PublicAccessCidrs": vpc_config.get("publicAccessCidrs", []),
        })
    return out


def collect_lambda_functions() -> list[dict[str, Any]]:
    """Fetch all Lambda functions with their role, code, and configuration."""
    lam = _make_client("lambda")
    out = []
    paginator = lam.get_paginator("list_functions")
    for page in paginator.paginate():
        for f in page.get("Functions", []):
            out.append({
                "FunctionName": f["FunctionName"],
                "FunctionArn": f["FunctionArn"],
                "Runtime": f.get("Runtime", ""),
                "Role": f.get("Role", ""),
                "Handler": f.get("Handler", ""),
                "CodeSize": f.get("CodeSize", 0),
                "Timeout": f.get("Timeout", 3),
                "MemorySize": f.get("MemorySize", 128),
                "LastModified": f.get("LastModified", ""),
                "State": f.get("State", "Active"),
                "Region": "us-east-1",
            })
    return out


def collect_secrets() -> list[dict[str, Any]]:
    """Fetch all Secrets Manager secrets."""
    sm = _make_client("secretsmanager")
    out = []
    paginator = sm.get_paginator("list_secrets")
    for page in paginator.paginate():
        for s in page.get("SecretList", []):
            out.append({
                "Name": s["Name"],
                "Arn": s["ARN"],
                "Description": s.get("Description", ""),
                "KmsKeyId": s.get("KmsKeyId"),
                "RotationEnabled": s.get("RotationEnabled", False),
                "LastChangedDate": str(s.get("LastChangedDate", "")),
                "Region": "us-east-1",
            })
    return out


def collect_kms_keys() -> list[dict[str, Any]]:
    """Fetch all KMS keys with their policies."""
    kms = _make_client("kms")
    out = []
    paginator = kms.get_paginator("list_keys")
    for page in paginator.paginate():
        for k in page.get("Keys", []):
            key_id = k["KeyId"]
            try:
                desc = kms.describe_key(KeyId=key_id)["KeyMetadata"]
                policy = None
                try:
                    policy = kms.get_key_policy(KeyId=key_id, PolicyName="default").get("Policy")
                    if isinstance(policy, str):
                        policy = json.loads(policy)
                except Exception:
                    pass
                out.append({
                    "KeyId": key_id,
                    "Arn": desc.get("Arn", ""),
                    "Description": desc.get("Description", ""),
                    "KeyState": desc.get("KeyState", "Enabled"),
                    "KeyUsage": desc.get("KeyUsage", ""),
                    "KeyPolicy": policy,
                    "Region": "us-east-1",
                })
            except Exception:
                pass
    return out


def collect_codebuild_projects() -> list[dict[str, Any]]:
    """Fetch all CodeBuild projects with their service roles."""
    cb = _make_client("codebuild")
    out = []
    for name in cb.list_projects().get("projects", []):
        try:
            proj = cb.batch_get_projects(names=[name])["projects"][0]
            out.append({
                "Name": proj["name"],
                "Arn": proj["arn"],
                "ServiceRole": proj.get("serviceRole", ""),
                "Source": proj.get("source", {}),
                "Environment": proj.get("environment", {}),
                "Region": "us-east-1",
            })
        except Exception:
            pass
    return out


def collect_all() -> dict[str, list[dict[str, Any]]]:
    """Fetch all cloud resources. Returns a dict keyed by resource type."""
    return {
        "iam_roles": collect_iam_roles(),
        "s3_buckets": collect_s3_buckets(),
        "security_groups": collect_security_groups(),
        "ec2_instances": collect_ec2_instances(),
        "eks_clusters": collect_eks_clusters(),
        "lambda_functions": collect_lambda_functions(),
        "secrets": collect_secrets(),
        "kms_keys": collect_kms_keys(),
        "codebuild_projects": collect_codebuild_projects(),
    }


def _parse_policy(raw):
    """Parse a policy document that might be a JSON string or already a dict."""
    if raw is None:
        return None
    if isinstance(raw, dict):
        return raw
    try:
        return json.loads(raw)
    except Exception:
        return None
