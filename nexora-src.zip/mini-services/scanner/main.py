"""
CNAPP Scanner Service - FastAPI mini-service
Port: 3030

This is the cloud security scanning engine. It calls real boto3 APIs to fetch
AWS resources (IAM roles, S3 buckets, Security Groups, EC2 instances, EKS clusters)
from the target AWS account, runs CIS-Benchmark-mapped rule scanners over them,
emits findings, and builds an attack-path graph from those findings using networkx.

In development, AWS_ENDPOINT_URL=http://127.0.0.1:5000 makes boto3 talk to a
local moto server (an AWS API emulator) instead of real AWS. The same scanner
code works against real AWS - only the endpoint differs.

Background task execution uses FastAPI BackgroundTasks + a SQLite-backed task
table. Status polling via GET /scan/{task_id} reads from this table.
"""
import asyncio
import json
import os
import sqlite3
import sys
import time
import uuid
from pathlib import Path
from typing import Any

from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Make local modules importable
sys.path.insert(0, str(Path(__file__).parent))

from collectors import collect_all
from rules import RULES, get_rule
from scanners import iam, s3, network, k8s
from attack_graph import build_attack_graph

app = FastAPI(
    title="CNAPP Scanner Service",
    description="Cloud-Native Application Protection Platform - real AWS scanning via boto3",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Task persistence (SQLite)
# ---------------------------------------------------------------------------
TASK_DB = Path(os.environ.get("SCANNER_DB_PATH", os.path.join(os.path.dirname(__file__), "..", "..", "db", "scanner_tasks.db")))
TASK_DB.parent.mkdir(parents=True, exist_ok=True)


def _db_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(TASK_DB))
    conn.row_factory = sqlite3.Row
    return conn


def _init_db():
    with _db_conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS scan_tasks (
                task_id TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                scan_mode TEXT,
                scanners TEXT,
                started_at REAL,
                completed_at REAL,
                duration_ms INTEGER,
                error TEXT,
                result_json TEXT
            )
        """)
        c.commit()


_init_db()


def _save_task(task_id: str, **fields):
    with _db_conn() as c:
        cols = ", ".join([f"{k} = ?" for k in fields])
        vals = list(fields.values()) + [task_id]
        c.execute(f"UPDATE scan_tasks SET {cols} WHERE task_id = ?", vals)
        c.commit()


def _create_task(task_id: str, status: str, scan_mode: str, scanners: list[str]):
    with _db_conn() as c:
        c.execute(
            "INSERT INTO scan_tasks (task_id, status, scan_mode, scanners, started_at) VALUES (?, ?, ?, ?, ?)",
            (task_id, status, scan_mode, ",".join(scanners), time.time()),
        )
        c.commit()


def _load_task(task_id: str) -> dict | None:
    with _db_conn() as c:
        row = c.execute("SELECT * FROM scan_tasks WHERE task_id = ?", (task_id,)).fetchone()
        if row is None:
            return None
        d = dict(row)
        if d.get("result_json"):
            d["result"] = json.loads(d["result_json"])
        return d


# ---------------------------------------------------------------------------
# API models
# ---------------------------------------------------------------------------

class ScanRequest(BaseModel):
    scan_mode: str = "real"  # "real" = use production scanner, "mock" = use moto
    scanners: list[str] = ["iam", "s3", "sg", "k8s"]
    account_id: str = "123456789012"
    region: str = "us-east-1"
    # Cross-account credentials (for real AWS scanning)
    role_arn: str = ""        # e.g. arn:aws:iam::123456789012:role/SentinelScanner
    external_id: str = ""     # External ID for trust policy validation
    access_key_id: str = ""   # Direct credentials (alternative to role_arn)
    secret_access_key: str = ""
    session_token: str = ""   # Optional for temporary credentials


# ---------------------------------------------------------------------------
# Scanning logic
# ---------------------------------------------------------------------------

def _normalize_resources(resources: dict[str, list]) -> list[dict]:
    """Convert raw boto3 data to a uniform shape for the graph + frontend."""
    normalized = []
    for role in resources.get("iam_roles", []):
        normalized.append({
            "type": "aws_iam_role",
            "arn": role["Arn"],
            "name": role["RoleName"],
            "region": "global",
            "metadata": role,
        })
    for bucket in resources.get("s3_buckets", []):
        normalized.append({
            "type": "aws_s3_bucket",
            "arn": f"arn:aws:s3:::{bucket['Name']}",
            "name": bucket["Name"],
            "region": bucket.get("Region", "us-east-1"),
            "metadata": bucket,
        })
    for sg in resources.get("security_groups", []):
        arn = f"arn:aws:ec2:{sg.get('Region','us-east-1')}:123456789012:security-group/{sg['GroupId']}"
        normalized.append({
            "type": "aws_security_group",
            "arn": arn,
            "name": f"{sg['GroupName']} ({sg['GroupId']})",
            "region": sg.get("Region", "us-east-1"),
            "metadata": sg,
        })
    for inst in resources.get("ec2_instances", []):
        arn = f"arn:aws:ec2:{inst.get('Region','us-east-1')}:123456789012:instance/{inst['InstanceId']}"
        normalized.append({
            "type": "aws_ec2_instance",
            "arn": arn,
            "name": inst["InstanceId"],
            "region": inst.get("Region", "us-east-1"),
            "metadata": inst,
        })
    for cluster in resources.get("eks_clusters", []):
        normalized.append({
            "type": "aws_eks_cluster",
            "arn": cluster["Arn"],
            "name": cluster["ClusterName"],
            "region": cluster.get("Region", "us-east-1"),
            "metadata": cluster,
        })
    return normalized


def _run_scanners(resources: dict[str, list], scanners: list[str]) -> list[dict]:
    """Run the requested scanners over collected AWS resources."""
    raw_findings: list[dict] = []
    if "iam" in scanners:
        raw_findings.extend(iam.scan(resources.get("iam_roles", [])))
    if "s3" in scanners:
        raw_findings.extend(s3.scan(resources.get("s3_buckets", [])))
    if "sg" in scanners or "network" in scanners:
        raw_findings.extend(network.scan(resources.get("security_groups", [])))
    if "k8s" in scanners:
        raw_findings.extend(k8s.scan(resources.get("eks_clusters", [])))

    # Enrich findings with rule metadata
    enriched: list[dict] = []
    for rf in raw_findings:
        rule = get_rule(rf["rule_id"])
        if not rule:
            continue
        enriched.append({
            "id": str(uuid.uuid4()),
            "rule_id": rule.rule_id,
            "title": rule.title,
            "description": rule.description,
            "severity": rule.severity,
            "category": rule.category,
            "compliance": rule.compliance,
            "cvss_score": rule.cvss_score,
            "remediation": rule.remediation,
            "resource_type": rf["resource_type"],
            "resource_arn": rf["resource_arn"],
            "resource_name": rf["resource_name"],
            "region": rf["region"],
            "evidence": rf["evidence"],
            "status": "open",
            "detected_at": int(time.time()),
        })
    return enriched


def _execute_scan(task_id: str, scanners: list[str], scan_config: dict = None):
    """Background task: fetch resources via boto3, run scanners, build graph, persist result.

    scan_config can contain:
      - role_arn: cross-account role to assume
      - external_id: External ID for trust policy
      - access_key_id / secret_access_key: direct credentials
      - scan_mode: "real" (production scanner) or "mock" (moto emulator)
    """
    start = time.time()
    try:
        _save_task(task_id, status="running")
        config = scan_config or {}

        # Determine scanning mode
        scan_mode = config.get("scan_mode", os.environ.get("SCAN_MODE", "mock"))
        role_arn = config.get("role_arn", "")
        external_id = config.get("external_id", "")
        access_key = config.get("access_key_id", "")
        secret_key = config.get("secret_access_key", "")

        if scan_mode == "real" and (role_arn or (access_key and secret_key)):
            # ── PRODUCTION MODE: Use production_scanner.py with real AWS ──
            from production_scanner import CrossAccountScanner, CrossAccountConfig

            if role_arn:
                # Cross-account via AssumeRole
                ca_config = CrossAccountConfig(
                    role_arn=role_arn,
                    external_id=external_id,
                    session_name="sentinel-prod-scan",
                )
            else:
                # Direct credentials (set as env vars for boto3)
                os.environ["AWS_ACCESS_KEY_ID"] = access_key
                os.environ["AWS_SECRET_ACCESS_KEY"] = secret_key
                if config.get("session_token"):
                    os.environ["AWS_SESSION_TOKEN"] = config["session_token"]
                # Use a dummy role_arn — the scanner will use env credentials
                ca_config = CrossAccountConfig(
                    role_arn=f"arn:aws:iam::{config.get('account_id','')}:role/DummyScanRole",
                    external_id="",
                )

            scanner = CrossAccountScanner(ca_config)

            # Validate trust policy (for AssumeRole mode)
            if role_arn:
                trust_check = scanner.validate_trust_policy()
                if not trust_check["valid"]:
                    raise PermissionError(f"Trust policy validation failed: {trust_check['details']}")

            # Scan all regions in parallel
            resources = scanner.scan_account(scanners=scanners)
        else:
            # ── MOCK MODE: Use moto emulator (development/testing) ──
            resources = collect_all()
        findings = _run_scanners(resources, scanners)
        normalized = _normalize_resources(resources)
        graph = build_attack_graph(findings, normalized)

        severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        category_counts: dict[str, int] = {}
        compliance_counts: dict[str, int] = {}
        for f in findings:
            severity_counts[f["severity"]] = severity_counts.get(f["severity"], 0) + 1
            category_counts[f["category"]] = category_counts.get(f["category"], 0) + 1
            compliance_counts[f["compliance"]] = compliance_counts.get(f["compliance"], 0) + 1

        result = {
            "scan_id": task_id,
            "status": "completed",
            "scan_mode": "real-aws" if (role_arn or (access_key and secret_key)) else "mock",
            "scanners_run": scanners,
            "duration_ms": int((time.time() - start) * 1000),
            "findings": findings,
            "resources": normalized,
            "graph": graph,
            "summary": {
                "total_findings": len(findings),
                "total_resources": len(normalized),
                "severity_counts": severity_counts,
                "category_counts": category_counts,
                "compliance_counts": compliance_counts,
                "critical_attack_paths": len(graph["attack_paths"]),
            },
        }
        _save_task(
            task_id,
            status="completed",
            completed_at=time.time(),
            duration_ms=result["duration_ms"],
            result_json=json.dumps(result, default=str),
        )
    except Exception as e:
        import traceback
        _save_task(
            task_id,
            status="failed",
            completed_at=time.time(),
            duration_ms=int((time.time() - start) * 1000),
            error=str(e),
            result_json=json.dumps({"traceback": traceback.format_exc()}, default=str),
        )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/")
def root():
    return {
        "service": "cnapp-scanner",
        "status": "running",
        "version": "2.0.0",
        "endpoint": os.environ.get("AWS_ENDPOINT_URL", "real-aws"),
        "endpoints": ["/scan (POST)", "/scan/{task_id} (GET)", "/rules", "/health"],
    }


@app.get("/health")
def health():
    # Health = scanner alive + can reach AWS endpoint
    aws_ok = True
    aws_error = None
    try:
        # Quick reachability check - list IAM roles (just 1 page)
        resources = collect_all()
        aws_ok = True
        return {
            "status": "healthy",
            "aws_endpoint": os.environ.get("AWS_ENDPOINT_URL", "real-aws"),
            "aws_reachable": aws_ok,
            "resources_cached": {
                "iam_roles": len(resources.get("iam_roles", [])),
                "s3_buckets": len(resources.get("s3_buckets", [])),
                "security_groups": len(resources.get("security_groups", [])),
                "ec2_instances": len(resources.get("ec2_instances", [])),
                "eks_clusters": len(resources.get("eks_clusters", [])),
            },
        }
    except Exception as e:
        return {
            "status": "degraded",
            "aws_endpoint": os.environ.get("AWS_ENDPOINT_URL", "real-aws"),
            "aws_reachable": False,
            "error": str(e),
        }


@app.get("/rules")
def list_rules():
    return [
        {
            "rule_id": r.rule_id,
            "title": r.title,
            "description": r.description,
            "severity": r.severity,
            "category": r.category,
            "compliance": r.compliance,
            "cvss_score": r.cvss_score,
            "remediation": r.remediation,
        }
        for r in RULES.values()
    ]


@app.post("/scan")
def run_scan(req: ScanRequest, background_tasks: BackgroundTasks):
    """Trigger a scan as a background task. Returns the task_id immediately.
    The frontend polls GET /scan/{task_id} for the result.
    """
    task_id = str(uuid.uuid4())
    _create_task(task_id, "queued", req.scan_mode, req.scanners)

    # Build scan config from request
    scan_config = {
        "scan_mode": req.scan_mode,
        "role_arn": req.role_arn,
        "external_id": req.external_id,
        "access_key_id": req.access_key_id,
        "secret_access_key": req.secret_access_key,
        "session_token": req.session_token,
        "account_id": req.account_id,
    }

    background_tasks.add_task(_execute_scan, task_id, req.scanners, scan_config)
    return {"task_id": task_id, "status": "queued"}


@app.get("/scan/{task_id}")
def get_scan(task_id: str):
    """Poll for scan status / result."""
    task = _load_task(task_id)
    if task is None:
        raise HTTPException(404, "Task not found")
    return task


# ---------------------------------------------------------------------------
# v2 Endpoints: Exploit Simulation, Suppression, Economic Engine, Chain Validation
# ---------------------------------------------------------------------------

from iam_solver import authorize, evaluate_trust_policy, compute_trust_closure, Verdict
from chain_validator import validate_chain
from exploit_simulator import run_all_simulations, simulate
from suppression import suppress as suppress_finding
from economic_engine import compute_economic_verdict, compute_posture_score, compute_total_expected_loss


def _build_solver_state(resources: dict[str, list]) -> dict:
    """Build the state dict needed by the IAM solver and simulation layer."""
    state = {
        "identities": [],
        "resources": [],
        "resource_by_arn": {},
        "security_groups": [],
        "scps": [],
        "sessions": [],
        "network": {"vpc_endpoints": []},
        "clock": int(time.time()),
        "source_ip": "0.0.0.0",
    }

    # Convert IAM roles to solver identities
    for role in resources.get("iam_roles", []):
        identity = {
            "arn": role["Arn"],
            "canonical_id": role["RoleName"],
            "name": role["RoleName"],
            "type": "role",
            "account_id": "123456789012",
            "identity_policy": _extract_effective_policy(role),
            "permission_boundary": None,
            "trust_policy": role.get("AssumeRolePolicyDocument", {}),
            "tags": {},
            "last_used": role.get("LastUsed", {}).get("LastUsedDate") if role.get("LastUsed") else None,
        }
        state["identities"].append(identity)

    # Convert S3 buckets to solver resources
    for bucket in resources.get("s3_buckets", []):
        arn = f"arn:aws:s3:::{bucket['Name']}"
        resource = {
            "arn": arn,
            "type": "aws_s3_bucket",
            "name": bucket["Name"],
            "account_id": "123456789012",
            "region": bucket.get("Region", "us-east-1"),
            "resource_policy": bucket.get("Policy"),
            "public_access_block": bucket.get("PublicAccessBlock", {}),
            "acl": bucket.get("ACL", []),
            "tags": {},
            "estimated_objects": 10000,
        }
        state["resources"].append(resource)
        state["resource_by_arn"][arn] = resource

    # Convert security groups
    for sg in resources.get("security_groups", []):
        sg_obj = {
            "GroupId": sg["GroupId"],
            "GroupName": sg["GroupName"],
            "ingress": [
                {
                    "cidr_blocks": [r.get("CidrIp", "") for r in perm.get("IpRanges", [])],
                    "from_port": perm.get("FromPort"),
                    "to_port": perm.get("ToPort"),
                }
                for perm in sg.get("IpPermissions", [])
            ],
        }
        state["security_groups"].append(sg_obj)

    # Convert EC2 instances
    for inst in resources.get("ec2_instances", []):
        arn = f"arn:aws:ec2:{inst.get('Region','us-east-1')}:123456789012:instance/{inst['InstanceId']}"
        resource = {
            "arn": arn,
            "type": "aws_ec2_instance",
            "name": inst["InstanceId"],
            "account_id": "123456789012",
            "public_ip": inst.get("PublicIpAddress"),
            "security_groups": inst.get("SecurityGroups", []),
            "iam_instance_profile": inst.get("IamInstanceProfile"),
            "imdsv2_required": False,  # IMDSv1 for testing (production AMIs use IMDSv2)
        }
        state["resources"].append(resource)
        state["resource_by_arn"][arn] = resource

    # Convert EKS clusters
    for cluster in resources.get("eks_clusters", []):
        resource = {
            "arn": cluster["Arn"],
            "type": "aws_eks_cluster",
            "name": cluster["ClusterName"],
            "account_id": "123456789012",
            "endpoint_public": cluster.get("PublicAccess", False),
            "public_cidrs": cluster.get("PublicAccessCidrs", []),
        }
        state["resources"].append(resource)
        state["resource_by_arn"][cluster["Arn"]] = resource

    # Convert Lambda functions
    for f in resources.get("lambda_functions", []):
        resource = {
            "arn": f["FunctionArn"],
            "type": "aws_lambda_function",
            "name": f["FunctionName"],
            "account_id": "123456789012",
            "role_arn": f.get("Role", ""),
            "state": f.get("State", "Active"),
            "runtime": f.get("Runtime", ""),
        }
        state["resources"].append(resource)
        state["resource_by_arn"][f["FunctionArn"]] = resource

    # Convert Secrets Manager secrets
    for s in resources.get("secrets", []):
        resource = {
            "arn": s["Arn"],
            "type": "aws_secretsmanager_secret",
            "name": s["Name"],
            "account_id": "123456789012",
            "kms_key_arn": s.get("KmsKeyId"),
            "description": s.get("Description", ""),
        }
        state["resources"].append(resource)
        state["resource_by_arn"][s["Arn"]] = resource

    # Convert KMS keys
    for k in resources.get("kms_keys", []):
        resource = {
            "arn": k["Arn"],
            "type": "aws_kms_key",
            "name": k.get("KeyId", ""),
            "account_id": "123456789012",
            "key_state": k.get("KeyState", "Enabled"),
            "key_policy": k.get("KeyPolicy"),
            "description": k.get("Description", ""),
        }
        state["resources"].append(resource)
        state["resource_by_arn"][k["Arn"]] = resource

    # Convert CodeBuild projects
    for p in resources.get("codebuild_projects", []):
        resource = {
            "arn": p["Arn"],
            "type": "aws_codebuild_project",
            "name": p["Name"],
            "account_id": "123456789012",
            "service_role_arn": p.get("ServiceRole", ""),
        }
        state["resources"].append(resource)
        state["resource_by_arn"][p["Arn"]] = resource

    return state


def _extract_effective_policy(role: dict) -> dict:
    """Extract the effective identity policy from a role (inline + attached)."""
    statements = []

    # Inline policies
    for policy in role.get("InlinePolicies", []):
        doc = policy.get("PolicyDocument", {})
        if isinstance(doc, dict):
            statements.extend(doc.get("Statement", []))

    # Attached policies (simplified — in production, fetch the actual policy doc)
    for policy in role.get("AttachedPolicies", []):
        # We don't have the actual policy doc for managed policies in mock mode
        # In production, this would fetch from IAM
        pass

    # Trust policy is separate
    if statements:
        return {"Version": "2012-10-17", "Statement": statements}
    return {}


@app.post("/v2/simulate")
def run_simulation(req: dict = None):
    """Run exploit simulation primitives against the current AWS state."""
    try:
        resources = collect_all()
        state = _build_solver_state(resources)

        # Default attacker: starts from internet with no credentials
        attacker = {
            "principal_arn": "arn:aws:iam::123456789012:role/AdminRole-Production",
            "credentials": [{"type": "session", "expiry": time.time() + 3600}],
            "network_position": "internet",
            "capabilities": set(),
        }

        # If specific primitive requested, run just that one
        primitive = req.get("primitive") if req else None
        if primitive:
            result = simulate(primitive, state, attacker, req.get("goal", {}))
            return result.to_dict()
        else:
            # Run all 10 primitives
            results = run_all_simulations(state, attacker)
            return {
                "simulations": [r.to_dict() for r in results],
                "summary": {
                    "total": len(results),
                    "success": sum(1 for r in results if r.verdict == "SUCCESS"),
                    "blocked": sum(1 for r in results if r.verdict == "BLOCKED"),
                    "failure": sum(1 for r in results if r.verdict == "FAILURE"),
                },
            }
    except Exception as e:
        import traceback
        raise HTTPException(500, f"Simulation failed: {e}\n{traceback.format_exc()}")


@app.post("/v2/suppress")
def run_suppression(findings: list[dict] = None):
    """Run suppression engine on a list of findings."""
    try:
        resources = collect_all()
        state = _build_solver_state(resources)

        results = []
        for finding in (findings or []):
            result = suppress_finding(finding, state)
            results.append({
                "finding_id": finding.get("id", ""),
                "rule_id": finding.get("rule_id", ""),
                **result.to_dict(),
            })

        suppressed = sum(1 for r in results if r["suppressed"])
        return {
            "results": results,
            "summary": {
                "total": len(results),
                "suppressed": suppressed,
                "kept": len(results) - suppressed,
                "suppression_rate": suppressed / len(results) if results else 0,
            },
        }
    except Exception as e:
        raise HTTPException(500, f"Suppression failed: {e}")


@app.post("/v2/economic")
def run_economic_engine(req: dict = None):
    """Compute economic verdicts for findings."""
    try:
        req = req or {}
        findings = req.get("findings", [])
        customer_profile = req.get("customer_profile", {
            "industry": "other",
            "size": "mid",
            "regulations": [],
        })

        verdicts = []
        for finding in findings:
            confidence = req.get("confidence_tier", "CONFIRMED")
            verdict = compute_economic_verdict(finding, confidence, customer_profile)
            verdicts.append(verdict.to_dict())

        total_loss = compute_total_expected_loss([compute_economic_verdict(f, req.get("confidence_tier", "CONFIRMED"), customer_profile) for f in findings])

        return {
            "verdicts": verdicts,
            "total_expected_loss": round(total_loss, 2),
            "customer_profile": customer_profile,
        }
    except Exception as e:
        raise HTTPException(500, f"Economic engine failed: {e}")


@app.post("/v2/validate")
def run_chain_validation(req: dict = None):
    """Validate an attack chain."""
    try:
        req = req or {}
        chain = req.get("chain", [])
        attacker = req.get("attacker", {
            "principal_arn": "arn:aws:iam::123456789012:role/AdminRole-Production",
            "credentials": [{"type": "session"}],
            "network_position": "internet",
            "capabilities": set(),
        })

        resources = collect_all()
        state = _build_solver_state(resources)

        result = validate_chain(chain, state, attacker)
        return result.to_dict()
    except Exception as e:
        raise HTTPException(500, f"Validation failed: {e}")


@app.get("/v2/trust-closure")
def get_trust_closure():
    """Compute and return the transitive trust closure."""
    try:
        resources = collect_all()
        roles = resources.get("iam_roles", [])
        closure = compute_trust_closure(roles)

        # Convert sets to lists for JSON
        return {
            "closure": {k: list(v) for k, v in closure.items()},
            "role_count": len(roles),
        }
    except Exception as e:
        raise HTTPException(500, f"Trust closure failed: {e}")


@app.get("/v2/capabilities")
def get_v2_capabilities():
    """List all v2 capabilities and their status."""
    return {
        "iam_solver": {
            "version": "2.0",
            "semantics_supported": 21,
            "target_fidelity": "99%",
            "features": [
                "SCP evaluation (org chain)",
                "Permission boundaries",
                "Session policies",
                "Explicit deny precedence",
                "Segment-aware wildcard resolution",
                "Policy variables",
                "NotAction / NotResource",
                "50+ condition operators",
                "AssumeRole chains (transitive closure)",
                "Federation (SAML/OIDC)",
                "Service principals",
                "Session tags (ABAC)",
                "Trust loop detection",
                "External ID",
                "MFA requirement",
                "Resource policy same/cross-account",
                "KMS grant chain",
                "VPC endpoint policy",
                "Service-linked roles",
                "Policy versioning",
                "Eventual consistency",
            ],
        },
        "chain_validator": {
            "version": "2.0",
            "predicates": ["permission", "identity", "network", "runtime", "credential"],
            "detection_classes": 6,
        },
        "exploit_simulator": {
            "version": "2.0",
            "primitives": 10,
            "primitive_names": [
                "public_bucket_exploit",
                "imds_theft",
                "ssrf_to_credentials",
                "passrole_escalation",
                "secret_exfiltration",
                "kms_decrypt_abuse",
                "lambda_privesc",
                "cicd_compromise",
                "cross_account_compromise",
                "ransomware_blast",
            ],
        },
        "suppression_engine": {
            "version": "2.0",
            "rules": 6,
            "target_fp_rate": "<3%",
            "safety_check": "simulation_override",
        },
        "economic_engine": {
            "version": "2.0",
            "formula": "ExpectedLoss = P(compromise) × BlastRadius × BusinessImpact × RecoveryCost",
            "outputs": ["expected_loss", "remediation_roi", "risk_reduction", "priority"],
        },
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=3030, log_level="info")
