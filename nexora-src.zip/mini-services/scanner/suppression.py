"""
False Positive Suppression Engine — Target: <3% FP rate.

6 suppression rules:
  1. Network isolation — target is network-unreachable
  2. Conjunction missing — PassRole without co-permission
  3. Intentional exposure — resource tagged as intentionally public
  4. Dead resource — no API activity in 90 days
  5. Dormant identity — identity unused for 90 days
  6. Impossible chain — chain validator says invalid

Safety: simulation override — if simulation says EXPLOITABLE, do NOT suppress.
"""
from typing import Optional
from dataclasses import dataclass
from exploit_simulator import simulate, SimulationResult


@dataclass
class SuppressionResult:
    suppressed: bool
    rule: str
    evidence: str
    simulation_override: bool = False

    def to_dict(self) -> dict:
        return {
            "suppressed": self.suppressed,
            "rule": self.rule,
            "evidence": self.evidence,
            "simulation_override": self.simulation_override,
        }


def suppress(finding: dict, state: dict) -> SuppressionResult:
    """Evaluate all suppression rules. Returns TRUE if finding should be suppressed.

    Conservative: when uncertain, do NOT suppress.
    Safety: simulation override prevents suppressing real exploits.
    """
    rules = [
        _rule_network_isolation,
        _rule_conjunction_missing,
        _rule_intentional_exposure,
        _rule_dead_resource,
        _rule_dormant_identity,
        _rule_impossible_chain,
    ]

    for rule in rules:
        result = rule(finding, state)
        if result.suppressed:
            # SAFETY CHECK: run simulation to confirm finding is NOT exploitable
            sim_result = _run_safety_simulation(finding, state)
            if sim_result and sim_result.verdict == "SUCCESS":
                # Suppression would be a false negative — do NOT suppress
                return SuppressionResult(
                    suppressed=False,
                    rule=result.rule,
                    evidence=f"suppression overridden by simulation: {sim_result.reason}",
                    simulation_override=True,
                )
            return result

    return SuppressionResult(False, "no_rule_matched", "no suppression rule matched")


def _rule_network_isolation(finding: dict, state: dict) -> SuppressionResult:
    """Suppress if target resource is network-unreachable from attacker."""
    resource_arn = finding.get("resource_arn", "")
    resource = state.get("resource_by_arn", {}).get(resource_arn)
    if not resource:
        return SuppressionResult(False, "network_isolation", "resource not found")

    resource_type = resource.get("type", "")

    # S3: check PAB + VPC endpoint
    if resource_type == "aws_s3_bucket":
        pab = resource.get("public_access_block", {})
        if pab.get("block_public_acls") and pab.get("restrict_public_buckets"):
            # Check if there's a VPC endpoint
            vpc_endpoints = state.get("network", {}).get("vpc_endpoints", [])
            if not vpc_endpoints:
                return SuppressionResult(True, "network_isolation",
                    "S3 bucket has PAB enabled and no VPC endpoint — not reachable from internet")

    # EC2: check public IP + SG
    if resource_type == "aws_ec2_instance":
        if not resource.get("public_ip"):
            return SuppressionResult(True, "network_isolation",
                "EC2 instance has no public IP — not reachable from internet")

    # EKS: check endpoint config
    if resource_type == "aws_eks_cluster":
        if not resource.get("endpoint_public"):
            return SuppressionResult(True, "network_isolation",
                "EKS API endpoint is private — not reachable from internet")
        cidrs = resource.get("public_cidrs", [])
        if "0.0.0.0/0" not in cidrs:
            return SuppressionResult(True, "network_isolation",
                f"EKS API public but CIDR-restricted: {cidrs}")

    return SuppressionResult(False, "network_isolation", "network reachable or N/A")


def _rule_conjunction_missing(finding: dict, state: dict) -> SuppressionResult:
    """Suppress PassRole findings without co-permission."""
    rule_id = finding.get("rule_id", "")
    if "PassRole" not in rule_id and "IAM-002" not in rule_id and "IAM-004" not in rule_id:
        return SuppressionResult(False, "conjunction_missing", "not a PassRole finding")

    from iam_solver import authorize, Verdict

    attacker_arn = finding.get("attacker_arn", "")
    identity = None
    for ident in state.get("identities", []):
        if ident.get("arn") == attacker_arn:
            identity = ident
            break

    if not identity:
        return SuppressionResult(False, "conjunction_missing", "attacker identity not found")

    co_permissions = [
        "lambda:CreateFunction",
        "ec2:RunInstances",
        "glue:CreateJob",
        "ecs:CreateTaskDefinition",
        "cloudformation:CreateStack",
        "iam:CreateServiceLinkedRole",
    ]

    has_co = any(
        authorize(identity, perm, "*", state).verdict == Verdict.ALLOW
        for perm in co_permissions
    )

    if not has_co:
        return SuppressionResult(True, "conjunction_missing",
            "PassRole without co-permission (no CreateFunction/RunInstances/etc.) — not exploitable")

    return SuppressionResult(False, "conjunction_missing", "co-permission exists — exploitable")


def _rule_intentional_exposure(finding: dict, state: dict) -> SuppressionResult:
    """Suppress findings on resources tagged as intentionally public."""
    resource_arn = finding.get("resource_arn", "")
    resource = state.get("resource_by_arn", {}).get(resource_arn)
    if not resource:
        return SuppressionResult(False, "intentional_exposure", "resource not found")

    tags = resource.get("tags", {})
    if tags.get("public-intentional") or tags.get("allow-public"):
        return SuppressionResult(True, "intentional_exposure",
            f"resource tagged as intentionally public: {tags}")

    return SuppressionResult(False, "intentional_exposure", "no intentional-exposure tag")


def _rule_dead_resource(finding: dict, state: dict) -> SuppressionResult:
    """Suppress findings on resources with no API activity in 90 days."""
    resource_arn = finding.get("resource_arn", "")
    resource = state.get("resource_by_arn", {}).get(resource_arn)
    if not resource:
        return SuppressionResult(False, "dead_resource", "resource not found")

    last_activity = resource.get("last_activity")
    if last_activity:
        from datetime import datetime, timezone, timedelta
        try:
            last = datetime.fromisoformat(str(last_activity).replace("Z", "+00:00"))
            days_inactive = (datetime.now(timezone.utc) - last).days
            if days_inactive > 90:
                return SuppressionResult(True, "dead_resource",
                    f"resource dead: last activity {days_inactive} days ago")
        except (ValueError, TypeError):
            pass

    return SuppressionResult(False, "dead_resource", "resource is active")


def _rule_dormant_identity(finding: dict, state: dict) -> SuppressionResult:
    """Suppress findings on identities unused for 90 days."""
    attacker_arn = finding.get("attacker_arn", "")
    if not attacker_arn:
        return SuppressionResult(False, "dormant_identity", "no attacker identity")

    identity = None
    for ident in state.get("identities", []):
        if ident.get("arn") == attacker_arn:
            identity = ident
            break

    if not identity:
        return SuppressionResult(False, "dormant_identity", "identity not found")

    last_used = identity.get("last_used")
    if last_used:
        from datetime import datetime, timezone
        try:
            last = datetime.fromisoformat(str(last_used).replace("Z", "+00:00"))
            days_inactive = (datetime.now(timezone.utc) - last).days
            if days_inactive > 90:
                return SuppressionResult(True, "dormant_identity",
                    f"identity dormant: last used {days_inactive} days ago")
        except (ValueError, TypeError):
            pass

    return SuppressionResult(False, "dormant_identity", "identity is active")


def _rule_impossible_chain(finding: dict, state: dict) -> SuppressionResult:
    """Suppress findings whose attack chain is invalid."""
    attack_path = finding.get("attack_path")
    if not attack_path:
        return SuppressionResult(False, "impossible_chain", "no attack path to validate")

    from chain_validator import validate_chain

    attacker = {
        "principal_arn": finding.get("attacker_arn", ""),
        "credentials": [{"type": "session"}],
        "network_position": "internet",
        "capabilities": set(),
    }

    result = validate_chain(attack_path, state, attacker)
    if not result.valid:
        return SuppressionResult(True, "impossible_chain",
            f"chain invalid: {result.reason}")

    return SuppressionResult(False, "impossible_chain", "chain is valid")


def _run_safety_simulation(finding: dict, state: dict) -> Optional[SimulationResult]:
    """Run simulation to verify finding is NOT exploitable before suppressing."""
    resource_arn = finding.get("resource_arn", "")
    resource = state.get("resource_by_arn", {}).get(resource_arn)
    if not resource:
        return None

    resource_type = resource.get("type", "")

    # Map finding to simulation primitive
    primitive_map = {
        "aws_s3_bucket": "public_bucket_exploit",
        "aws_lambda_function": "lambda_privesc",
        "aws_ec2_instance": "imds_theft",
        "aws_secretsmanager_secret": "secret_exfiltration",
        "aws_kms_key": "kms_decrypt_abuse",
    }

    primitive = primitive_map.get(resource_type)
    if not primitive:
        return None

    attacker = {
        "principal_arn": finding.get("attacker_arn", ""),
        "credentials": [{"type": "session"}],
        "network_position": "internet",
        "capabilities": set(),
    }

    try:
        return simulate(primitive, state, attacker)
    except Exception:
        return None
