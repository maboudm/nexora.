"""
Provision real AWS resources into moto (an in-process AWS API emulator
that implements the same wire protocol as AWS).

This script uses the EXACT same AWS CLI / boto3 calls a real DevOps engineer
would use to provision an AWS account. moto intercepts those calls and
returns realistic responses. The scanner then uses boto3 to read those
resources back - the same code path that would work against real AWS.

Run this once on scanner startup to populate the "AWS account" with
intentionally misconfigured resources for the scanner to find.

Resources created:
  - 4 IAM roles (one with Principal:* trust, one with AdministratorAccess,
    one with S3FullAccess on EC2, one unused for 90+ days)
  - 4 S3 buckets (2 public, 2 unencrypted, 1 without versioning, 1 without logging)
  - 4 Security Groups (SSH/RDP/DB ports open to 0.0.0.0/0, unrestricted egress)
  - 2 EKS clusters (one with public API + 0.0.0.0/0, missing logging, missing KMS)
  - 2 EC2 instances (one with public IP + IAM profile, one bastion)
"""
import os
import sys
from datetime import datetime, timedelta, timezone

# boto3 must be configured to talk to moto's server (or run in standalone mode).
# We run moto in standalone server mode and point boto3 at it via env vars.
import boto3
from botocore.exceptions import ClientError


ACCOUNT_ID = "123456789012"
REGION = "us-east-1"


def _client(service: str, region: str = REGION):
    """Build a boto3 client. endpoint_url points at the moto server."""
    endpoint = os.environ.get("AWS_ENDPOINT_URL", "http://localhost:5000")
    return boto3.client(
        service,
        region_name=region,
        endpoint_url=endpoint,
        aws_access_key_id="test",
        aws_secret_access_key="test",
    )


def _resource(service: str, region: str = REGION):
    """Build a boto3 resource (for higher-level APIs like S3)."""
    endpoint = os.environ.get("AWS_ENDPOINT_URL", "http://localhost:5000")
    return boto3.resource(
        service,
        region_name=region,
        endpoint_url=endpoint,
        aws_access_key_id="test",
        aws_secret_access_key="test",
    )


def provision_iam():
    """Create IAM roles with intentional misconfigurations.

    Uses real boto3 IAM API calls. Each role's misconfiguration is exactly
    what a real AWS account might contain - we just create them on purpose
    so the scanner has something to find.
    """
    import json
    iam = _client("iam")
    print("[IAM] Creating roles...")

    # Role 1: AdminRole-Production - Principal:* in trust policy + admin inline policy (CRITICAL x2)
    trust_policy_wildcard = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"AWS": "*"},
            "Action": "sts:AssumeRole",
        }],
    }
    iam.create_role(
        RoleName="AdminRole-Production",
        AssumeRolePolicyDocument=json.dumps(trust_policy_wildcard),
        Path="/",
        Description="Production admin role - misconfigured",
    )
    # Inline policy granting *:* (AdministratorAccess equivalent)
    iam.put_role_policy(
        RoleName="AdminRole-Production",
        PolicyName="AdministratorAccess",
        PolicyDocument=json.dumps({
            "Version": "2012-10-17",
            "Statement": [{"Effect": "Allow", "Action": "*", "Resource": "*"}],
        }),
    )

    # Role 2: EC2InstanceRole-WebApp - S3FullAccess inline policy on compute role (HIGH)
    trust_policy_ec2 = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "ec2.amazonaws.com"},
            "Action": "sts:AssumeRole",
        }],
    }
    iam.create_role(
        RoleName="EC2InstanceRole-WebApp",
        AssumeRolePolicyDocument=json.dumps(trust_policy_ec2),
        Path="/",
        Description="EC2 web app role",
    )
    # Inline policy granting S3 FullAccess (matches IAM-004 rule pattern)
    iam.put_role_policy(
        RoleName="EC2InstanceRole-WebApp",
        PolicyName="AmazonS3FullAccess",
        PolicyDocument=json.dumps({
            "Version": "2012-10-17",
            "Statement": [{"Effect": "Allow", "Action": "s3:*", "Resource": "*"}],
        }),
    )
    # Also DynamoDB FullAccess (overly permissive)
    iam.put_role_policy(
        RoleName="EC2InstanceRole-WebApp",
        PolicyName="AmazonDynamoDBFullAccess",
        PolicyDocument=json.dumps({
            "Version": "2012-10-17",
            "Statement": [{"Effect": "Allow", "Action": "dynamodb:*", "Resource": "*"}],
        }),
    )
    # Instance profile for EC2 attachment
    iam.create_instance_profile(InstanceProfileName="EC2InstanceRole-WebApp")
    iam.add_role_to_instance_profile(
        InstanceProfileName="EC2InstanceRole-WebApp",
        RoleName="EC2InstanceRole-WebApp",
    )

    # Role 3: LambdaProcessorRole - properly scoped (NO findings)
    trust_policy_lambda = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "lambda.amazonaws.com"},
            "Action": "sts:AssumeRole",
        }],
    }
    iam.create_role(
        RoleName="LambdaProcessorRole",
        AssumeRolePolicyDocument=json.dumps(trust_policy_lambda),
        Path="/",
        Description="Lambda processor role",
    )
    iam.put_role_policy(
        RoleName="LambdaProcessorRole",
        PolicyName="BasicExecution",
        PolicyDocument=json.dumps({
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Action": ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"],
                "Resource": "arn:aws:logs:*:*:*",
            }],
        }),
    )

    # Role 4: CrossAccountBackupRole - properly scoped but unused (LOW - unused)
    trust_policy_cross_account = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"AWS": f"arn:aws:iam::987654321098:root"},
            "Action": "sts:AssumeRole",
        }],
    }
    iam.create_role(
        RoleName="CrossAccountBackupRole",
        AssumeRolePolicyDocument=json.dumps(trust_policy_cross_account),
        Path="/",
        Description="Cross-account backup role - unused",
    )
    iam.put_role_policy(
        RoleName="CrossAccountBackupRole",
        PolicyName="S3ReadOnly",
        PolicyDocument=json.dumps({
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Action": ["s3:GetObject", "s3:ListBucket"],
                "Resource": ["arn:aws:s3:::company-backup-prod", "arn:aws:s3:::company-backup-prod/*"],
            }],
        }),
    )

    print(f"[IAM] Created 4 roles in account {ACCOUNT_ID}")


def provision_s3():
    """Create S3 buckets with intentional misconfigurations."""
    s3 = _client("s3")
    s3r = _resource("s3")
    print("[S3] Creating buckets...")

    # Bucket 1: company-public-assets - public via policy, no encryption, no versioning, no logging
    s3.create_bucket(Bucket="company-public-assets", CreateBucketConfiguration={"LocationConstraint": REGION} if REGION != "us-east-1" else {})
    s3.put_bucket_policy(
        Bucket="company-public-assets",
        Policy=__import__("json").dumps({
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Principal": "*",
                "Action": "s3:GetObject",
                "Resource": "arn:aws:s3:::company-public-assets/*",
            }],
        }),
    )
    # Disable public access block (allow public)
    s3.put_public_access_block(
        Bucket="company-public-assets",
        PublicAccessBlockConfiguration={
            "BlockPublicAcls": False,
            "IgnorePublicAcls": False,
            "BlockPublicPolicy": False,
            "RestrictPublicBuckets": False,
        },
    )
    # Suspend versioning
    s3.put_bucket_versioning(
        Bucket="company-public-assets",
        VersioningConfiguration={"Status": "Suspended"},
    )

    # Bucket 2: company-logs-archive - properly configured (no findings)
    s3.create_bucket(Bucket="company-logs-archive")
    s3.put_bucket_encryption(
        Bucket="company-logs-archive",
        ServerSideEncryptionConfiguration={
            "Rules": [{
                "ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"},
            }],
        },
    )
    s3.put_bucket_versioning(
        Bucket="company-logs-archive",
        VersioningConfiguration={"Status": "Enabled"},
    )
    s3.put_public_access_block(
        Bucket="company-logs-archive",
        PublicAccessBlockConfiguration={
            "BlockPublicAcls": True,
            "IgnorePublicAcls": True,
            "BlockPublicPolicy": True,
            "RestrictPublicBuckets": True,
        },
    )
    # Add log-delivery WRITE+READ_ACP permission via ACL (required for PutBucketLogging)
    s3.put_bucket_acl(
        Bucket="company-logs-archive",
        GrantWrite='uri="http://acs.amazonaws.com/groups/s3/LogDelivery"',
        GrantReadACP='uri="http://acs.amazonaws.com/groups/s3/LogDelivery"',
    )
    s3.put_bucket_logging(
        Bucket="company-logs-archive",
        BucketLoggingStatus={
            "LoggingEnabled": {
                "TargetBucket": "company-logs-archive",
                "TargetPrefix": "log/",
            },
        },
    )

    # Bucket 3: company-data-lake-staging - public, no encryption, no versioning
    s3.create_bucket(
        Bucket="company-data-lake-staging",
        CreateBucketConfiguration={"LocationConstraint": "us-west-2"},
    )
    s3.put_public_access_block(
        Bucket="company-data-lake-staging",
        PublicAccessBlockConfiguration={
            "BlockPublicAcls": False,
            "IgnorePublicAcls": False,
            "BlockPublicPolicy": False,
            "RestrictPublicBuckets": False,
        },
    )
    # Add public ACL
    s3.put_bucket_acl(
        Bucket="company-data-lake-staging",
        ACL="public-read",
    )
    s3.put_bucket_versioning(
        Bucket="company-data-lake-staging",
        VersioningConfiguration={"Status": "Suspended"},
    )

    # Bucket 4: company-backup-prod - missing encryption and logging
    s3.create_bucket(Bucket="company-backup-prod")
    s3.put_bucket_versioning(
        Bucket="company-backup-prod",
        VersioningConfiguration={"Status": "Enabled"},
    )
    s3.put_public_access_block(
        Bucket="company-backup-prod",
        PublicAccessBlockConfiguration={
            "BlockPublicAcls": True,
            "IgnorePublicAcls": True,
            "BlockPublicPolicy": True,
            "RestrictPublicBuckets": True,
        },
    )

    print("[S3] Created 4 buckets")


def provision_ec2_security_groups():
    """Create VPC, security groups, and EC2 instances."""
    ec2 = _client("ec2")
    print("[EC2] Creating VPC, security groups, instances...")

    # Create default VPC
    vpc = ec2.create_vpc(CidrBlock="10.0.0.0/16")
    vpc_id = vpc["Vpc"]["VpcId"]
    ec2.modify_vpc_attribute(VpcId=vpc_id, EnableDnsSupport={"Value": True})
    ec2.modify_vpc_attribute(VpcId=vpc_id, EnableDnsHostnames={"Value": True})

    # Create subnet
    subnet = ec2.create_subnet(VpcId=vpc_id, CidrBlock="10.0.1.0/24")
    subnet_id = subnet["Subnet"]["SubnetId"]

    # Internet gateway for public IPs
    igw = ec2.create_internet_gateway()
    igw_id = igw["InternetGateway"]["InternetGatewayId"]
    ec2.attach_internet_gateway(VpcId=vpc_id, InternetGatewayId=igw_id)

    # SG 1: web-tier-sg - SSH (22) open to 0.0.0.0/0 (CRITICAL)
    sg1 = ec2.create_security_group(
        GroupName="web-tier-sg",
        Description="Web tier security group",
        VpcId=vpc_id,
    )
    sg1_id = sg1["GroupId"]
    ec2.authorize_security_group_ingress(
        GroupId=sg1_id,
        IpPermissions=[{
            "IpProtocol": "tcp",
            "FromPort": 22,
            "ToPort": 22,
            "IpRanges": [{"CidrIp": "0.0.0.0/0", "Description": "SSH from anywhere"}],
        }],
    )
    ec2.authorize_security_group_ingress(
        GroupId=sg1_id,
        IpPermissions=[{
            "IpProtocol": "tcp",
            "FromPort": 443,
            "ToPort": 443,
            "IpRanges": [{"CidrIp": "0.0.0.0/0"}],
        }],
    )

    # SG 2: db-tier-sg - MySQL (3306) open to 0.0.0.0/0 (CRITICAL)
    sg2 = ec2.create_security_group(
        GroupName="db-tier-sg",
        Description="Database tier security group",
        VpcId=vpc_id,
    )
    sg2_id = sg2["GroupId"]
    ec2.authorize_security_group_ingress(
        GroupId=sg2_id,
        IpPermissions=[{
            "IpProtocol": "tcp",
            "FromPort": 3306,
            "ToPort": 3306,
            "IpRanges": [{"CidrIp": "0.0.0.0/0", "Description": "MySQL from anywhere - TESTING ONLY"}],
        }],
    )
    ec2.authorize_security_group_ingress(
        GroupId=sg2_id,
        IpPermissions=[{
            "IpProtocol": "tcp",
            "FromPort": 5432,
            "ToPort": 5432,
            "UserIdGroupPairs": [{"GroupId": sg1_id}],
        }],
    )

    # SG 3: bastion-sg - properly scoped SSH (no finding)
    sg3 = ec2.create_security_group(
        GroupName="bastion-sg",
        Description="Bastion host security group",
        VpcId=vpc_id,
    )
    sg3_id = sg3["GroupId"]
    ec2.authorize_security_group_ingress(
        GroupId=sg3_id,
        IpPermissions=[{
            "IpProtocol": "tcp",
            "FromPort": 22,
            "ToPort": 22,
            "IpRanges": [{"CidrIp": "10.0.0.0/8"}],
        }],
    )

    # SG 4: rds-public-sg - MSSQL (1433) open to 0.0.0.0/0 (CRITICAL)
    sg4 = ec2.create_security_group(
        GroupName="rds-public-sg",
        Description="RDS public security group",
        VpcId=vpc_id,
    )
    sg4_id = sg4["GroupId"]
    ec2.authorize_security_group_ingress(
        GroupId=sg4_id,
        IpPermissions=[{
            "IpProtocol": "tcp",
            "FromPort": 1433,
            "ToPort": 1433,
            "IpRanges": [{"CidrIp": "0.0.0.0/0"}],
        }],
    )

    print(f"[EC2] Created VPC {vpc_id} and 4 security groups")

    # EC2 instances
    # Use a dummy AMI ID - moto accepts any
    ami_id = "ami-0abc123def456789a"

    # Instance 1: web app with public IP + IAM profile (uses NetworkInterfaces for public IP)
    ec2.run_instances(
        ImageId=ami_id,
        InstanceType="t3.large",
        MinCount=1,
        MaxCount=1,
        IamInstanceProfile={"Name": "EC2InstanceRole-WebApp"},
        NetworkInterfaces=[{
            "DeviceIndex": 0,
            "AssociatePublicIpAddress": True,
            "SubnetId": subnet_id,
            "Groups": [sg1_id],
        }],
        TagSpecifications=[{
            "ResourceType": "instance",
            "Tags": [{"Key": "Name", "Value": "web-app-prod-1"}],
        }],
    )

    # Instance 2: bastion, no IAM profile, no public IP
    ec2.run_instances(
        ImageId=ami_id,
        InstanceType="m5.xlarge",
        MinCount=1,
        MaxCount=1,
        SubnetId=subnet_id,
        SecurityGroupIds=[sg3_id],
        TagSpecifications=[{
            "ResourceType": "instance",
            "Tags": [{"Key": "Name", "Value": "bastion-1"}],
        }],
    )

    print("[EC2] Created 2 EC2 instances")


def provision_eks():
    """Create EKS clusters with intentional misconfigurations."""
    eks = _client("eks")
    print("[EKS] Creating clusters...")

    # Cluster 1: prod-cluster - public API + 0.0.0.0/0, no logging, no encryption
    eks.create_cluster(
        name="prod-cluster",
        version="1.28",
        roleArn=f"arn:aws:iam::{ACCOUNT_ID}:role/EKSServiceRole",
        resourcesVpcConfig={
            "subnetIds": ["subnet-0abc123", "subnet-0def456"],
            "endpointPublicAccess": True,
            "endpointPrivateAccess": False,
            "publicAccessCidrs": ["0.0.0.0/0"],
        },
        logging={
            "clusterLogging": [
                {"types": ["api"], "enabled": False},
                {"types": ["audit"], "enabled": False},
                {"types": ["authenticator"], "enabled": False},
            ],
        },
    )

    # Cluster 2: staging-cluster - properly configured
    eks.create_cluster(
        name="staging-cluster",
        version="1.28",
        roleArn=f"arn:aws:iam::{ACCOUNT_ID}:role/EKSServiceRole",
        resourcesVpcConfig={
            "subnetIds": ["subnet-0abc123", "subnet-0def456"],
            "endpointPublicAccess": True,
            "endpointPrivateAccess": True,
            "publicAccessCidrs": ["10.0.0.0/8"],
        },
        logging={
            "clusterLogging": [
                {"types": ["api", "audit", "authenticator"], "enabled": True},
            ],
        },
        encryptionConfig=[{
            "resources": ["secrets"],
            "provider": {"keyArn": "arn:aws:kms:us-east-1:123456789012:key/abc123"},
        }],
    )

    print("[EKS] Created 2 clusters")


def verify():
    """Verify all resources are accessible via boto3 - same path the scanner uses."""
    print("\n[VERIFY] Reading back resources via boto3...")
    iam = _client("iam")
    s3 = _client("s3")
    ec2 = _client("ec2")
    eks = _client("eks")

    roles = iam.list_roles()["Roles"]
    print(f"  IAM roles: {len(roles)}")
    for r in roles:
        print(f"    - {r['RoleName']}")

    buckets = s3.list_buckets()["Buckets"]
    print(f"  S3 buckets: {len(buckets)}")
    for b in buckets:
        print(f"    - {b['Name']}")

    sgs = ec2.describe_security_groups()["SecurityGroups"]
    print(f"  Security groups: {len(sgs)}")
    for sg in sgs:
        print(f"    - {sg['GroupName']} ({sg['GroupId']})")

    instances = ec2.describe_instances()
    inst_count = sum(len(r["Instances"]) for r in instances["Reservations"])
    print(f"  EC2 instances: {inst_count}")

    clusters = eks.list_clusters()["clusters"]
    print(f"  EKS clusters: {len(clusters)}")
    for c in clusters:
        print(f"    - {c}")


if __name__ == "__main__":
    print("=" * 60)
    print("Provisioning AWS account 123456789012 (via moto emulator)")
    print("=" * 60)
    try:
        provision_iam()
        provision_s3()
        provision_ec2_security_groups()
        provision_eks()
        verify()
        print("\n✓ Provisioning complete. Scanner can now read these resources via boto3.")
    except Exception as e:
        print(f"\n✗ Provisioning failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
