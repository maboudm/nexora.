"""
CNAPP Rules Engine - CIS AWS Benchmark mappings.
Each rule defines: id, title, severity, category, compliance, remediation.
Scanners consume these and emit findings when a rule matches.
"""

from dataclasses import dataclass


@dataclass
class Rule:
    rule_id: str
    title: str
    description: str
    severity: str  # critical | high | medium | low
    category: str  # iam | s3 | network | k8s | encryption | logging
    compliance: str  # CIS-AWS | PCI-DSS | SOC2 | ISO27001
    cvss_score: float
    remediation: str


RULES: dict[str, Rule] = {
    # IAM rules
    "IAM-001": Rule(
        rule_id="IAM-001",
        title="Overly permissive assume role policy (Principal: *)",
        description="The role trust policy allows any AWS principal to assume it. "
        "Anyone in the world with valid AWS credentials can escalate to this role's permissions.",
        severity="critical",
        category="iam",
        compliance="CIS-AWS-1.3",
        cvss_score=9.8,
        remediation="Restrict the Principal to specific AWS accounts, services, or roles. "
        "Never use Principal: '*' for production roles.",
    ),
    "IAM-002": Rule(
        rule_id="IAM-002",
        title="AdministratorAccess policy attached",
        description="The role has the AWS-managed AdministratorAccess policy attached. "
        "This grants full access to all AWS services and resources.",
        severity="high",
        category="iam",
        compliance="CIS-AWS-1.4",
        cvss_score=8.5,
        remediation="Replace AdministratorAccess with a least-privilege custom policy that grants only "
        "the specific actions the workload requires.",
    ),
    "IAM-003": Rule(
        rule_id="IAM-003",
        title="Unused IAM role (no activity in 90+ days)",
        description="The role has not been used in over 90 days. Unused roles expand the attack surface "
        "and may have stale overly-permissive policies.",
        severity="low",
        category="iam",
        compliance="CIS-AWS-1.21",
        cvss_score=3.5,
        remediation="Remove the role if no longer needed. If retained, audit and tighten its policies.",
    ),
    "IAM-004": Rule(
        rule_id="IAM-004",
        title="Role grants S3 FullAccess to compute service",
        description="Compute service role (EC2/Lambda) has AmazonS3FullAccess attached. "
        "A compromised instance could read/delete/modify all S3 data in the account.",
        severity="high",
        category="iam",
        compliance="CIS-AWS-1.16",
        cvss_score=7.7,
        remediation="Scope S3 permissions to specific bucket ARNs and required actions (s3:GetObject, s3:PutObject).",
    ),

    # S3 rules
    "S3-001": Rule(
        rule_id="S3-001",
        title="S3 bucket is publicly readable",
        description="Bucket ACL or policy grants READ permission to AllUsers group. "
        "Anyone on the internet can list and download objects.",
        severity="critical",
        category="s3",
        compliance="CIS-AWS-2.1",
        cvss_score=9.1,
        remediation="Remove public ACL grants. Enable Block Public Access at the bucket and account level. "
        "Use CloudFront with signed URLs for public content delivery.",
    ),
    "S3-002": Rule(
        rule_id="S3-002",
        title="S3 bucket has no server-side encryption",
        description="Bucket does not have default server-side encryption configured. "
        "Objects are stored in plaintext.",
        severity="medium",
        category="encryption",
        compliance="CIS-AWS-2.2",
        cvss_score=5.3,
        remediation="Enable SSE-S3 (AES256) or SSE-KMS on the bucket. Existing objects can be encrypted "
        "with a batch operation.",
    ),
    "S3-003": Rule(
        rule_id="S3-003",
        title="S3 bucket versioning is not enabled",
        description="Without versioning, deleted or overwritten objects cannot be recovered. "
        "No protection against ransomware or accidental deletion.",
        severity="low",
        category="s3",
        compliance="CIS-AWS-2.3",
        cvss_score=3.7,
        remediation="Enable versioning and MFA delete on critical buckets. Combine with lifecycle rules.",
    ),
    "S3-004": Rule(
        rule_id="S3-004",
        title="S3 bucket public access block is disabled",
        description="Block Public Access is not enabled. Future ACLs or policies could accidentally "
        "expose the bucket to the internet.",
        severity="high",
        category="s3",
        compliance="CIS-AWS-2.4",
        cvss_score=7.5,
        remediation="Enable all four Block Public Access settings at both bucket and account levels.",
    ),
    "S3-005": Rule(
        rule_id="S3-005",
        title="S3 bucket access logging is not enabled",
        description="Without access logging, you cannot audit who accessed, modified, or deleted objects. "
        "Hinders incident response and compliance audits.",
        severity="medium",
        category="logging",
        compliance="CIS-AWS-2.6",
        cvss_score=4.3,
        remediation="Enable server access logging to a dedicated logging bucket in the same region.",
    ),

    # Network rules
    "NET-001": Rule(
        rule_id="NET-001",
        title="Security group allows SSH (port 22) from 0.0.0.0/0",
        description="SSH is open to the entire internet. Brute-force and credential-stuffing attacks "
        "will succeed against weak credentials or unpatched vulnerabilities.",
        severity="critical",
        category="network",
        compliance="CIS-AWS-5.2",
        cvss_score=9.0,
        remediation="Restrict SSH to known corporate CIDR ranges or use AWS Systems Manager Session Manager "
        "instead of direct SSH.",
    ),
    "NET-002": Rule(
        rule_id="NET-002",
        title="Security group allows RDP (port 3389) from 0.0.0.0/0",
        description="RDP is open to the entire internet. RDP is the #1 vector for ransomware delivery.",
        severity="critical",
        category="network",
        compliance="CIS-AWS-5.3",
        cvss_score=9.5,
        remediation="Restrict RDP to specific corporate CIDR ranges via a bastion or VPN. "
        "Better: replace RDP with SSM Session Manager.",
    ),
    "NET-003": Rule(
        rule_id="NET-003",
        title="Security group allows database port (MySQL/Postgres/MSSQL) from 0.0.0.0/0",
        description="Database ports are publicly accessible. Internet-exposed databases are routinely "
        "compromised for data exfiltration and ransomware.",
        severity="critical",
        category="network",
        compliance="CIS-AWS-5.4",
        cvss_score=9.4,
        remediation="Database security groups should only allow ingress from application tier security groups "
        "via UserIdGroupPairs, never from public CIDRs.",
    ),
    "NET-004": Rule(
        rule_id="NET-004",
        title="Security group allows all egress traffic to 0.0.0.0/0",
        description="Outbound traffic is unrestricted. A compromised instance can reach any external "
        "service for C2, data exfiltration, or cryptomining.",
        severity="medium",
        category="network",
        compliance="CIS-AWS-5.6",
        cvss_score=5.4,
        remediation="Restrict egress to required destinations only (specific CIDRs, AWS service prefixes, "
        "or VPC endpoints).",
    ),

    # K8s / EKS rules
    "K8S-001": Rule(
        rule_id="K8S-001",
        title="EKS cluster has public API server endpoint with 0.0.0.0/0 cidr",
        description="The Kubernetes API server is reachable from the internet with no IP restriction. "
        "Attackers can probe the API for unauthenticated endpoints and vulnerable admission controllers.",
        severity="critical",
        category="k8s",
        compliance="CIS-EKS-1.1",
        cvss_score=8.6,
        remediation="Either set the API endpoint to private, or restrict publicAccessCidrs to specific "
        "corporate CIDR ranges.",
    ),
    "K8S-002": Rule(
        rule_id="K8S-002",
        title="EKS cluster control plane logging is disabled",
        description="API, audit, and authenticator logs are not being shipped to CloudWatch. "
        "Without these logs, Kubernetes API attacks cannot be detected or investigated.",
        severity="high",
        category="logging",
        compliance="CIS-EKS-1.2",
        cvss_score=7.1,
        remediation="Enable all cluster control plane log types (api, audit, authenticator, controllerManager, scheduler).",
    ),
    "K8S-003": Rule(
        rule_id="K8S-003",
        title="EKS cluster secrets encryption (KMS) is not configured",
        description="Kubernetes secrets stored in etcd are not encrypted with a customer-managed KMS key. "
        "Anyone with access to etcd backups can read all secrets in plaintext.",
        severity="high",
        category="encryption",
        compliance="CIS-EKS-1.3",
        cvss_score=7.4,
        remediation="Configure EncryptionConfig with a customer-managed KMS key during cluster creation or update.",
    ),
}


def get_rule(rule_id: str) -> Rule | None:
    return RULES.get(rule_id)
