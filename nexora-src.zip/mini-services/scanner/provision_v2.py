"""
Provision additional AWS resources for exploit simulation testing.

Creates:
  - Lambda functions (with IAM roles for privesc testing)
  - Secrets Manager secrets (encrypted with KMS)
  - KMS keys (with various access patterns)
  - CodeBuild projects (with service roles)
  - Cross-account trust role (for cross-account simulation)
  - VPC endpoint (for network isolation testing)

Run after provision.py to complete the test environment.
"""
import json
import os
import sys

import boto3

ACCOUNT_ID = "123456789012"
REGION = "us-east-1"


def _client(service: str, region: str = REGION):
    endpoint = os.environ.get("AWS_ENDPOINT_URL", "http://127.0.0.1:5000")
    return boto3.client(
        service,
        region_name=region,
        endpoint_url=endpoint,
        aws_access_key_id="test",
        aws_secret_access_key="test",
    )


def provision_lambda():
    """Create Lambda functions with IAM roles for privilege escalation testing."""
    lam = _client("lambda")
    iam = _client("iam")
    print("[Lambda] Creating functions...")

    # Function 1: web-processor with EC2InstanceRole-WebApp (for lambda_privesc)
    # This function has a role that the attacker can update
    try:
        lam.create_function(
            FunctionName="web-processor",
            Runtime="python3.11",
            Role=f"arn:aws:iam::{ACCOUNT_ID}:role/EC2InstanceRole-WebApp",
            Handler="index.handler",
            Code={"ZipFile": b"def handler(event, context):\n    return {'statusCode': 200}"},
            Description="Web request processor - vulnerable to code update",
            Timeout=30,
            MemorySize=256,
        )
    except Exception as e:
        if "ResourceConflict" not in str(e):
            raise

    # Function 2: data-pipeline with AdminRole-Production (high value target)
    try:
        lam.create_function(
            FunctionName="data-pipeline",
            Runtime="python3.11",
            Role=f"arn:aws:iam::{ACCOUNT_ID}:role/AdminRole-Production",
            Handler="index.handler",
            Code={"ZipFile": b"def handler(event, context):\n    return {'statusCode': 200}"},
            Description="Data pipeline with admin role",
            Timeout=60,
            MemorySize=512,
        )
    except Exception as e:
        if "ResourceConflict" not in str(e):
            raise

    print("[Lambda] Created 2 functions")


def provision_kms():
    """Create KMS keys with various access patterns."""
    kms = _client("kms")
    print("[KMS] Creating keys...")

    # Key 1: production-data-key (decryptable by EC2InstanceRole)
    try:
        key1 = kms.create_key(
            Description="Production data encryption key",
            KeyUsage="ENCRYPT_DECRYPT",
            Origin="AWS_KMS",
            Policy=json.dumps({
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Principal": {"AWS": f"arn:aws:iam::{ACCOUNT_ID}:role/EC2InstanceRole-WebApp"},
                        "Action": ["kms:Decrypt", "kms:DescribeKey", "kms:Encrypt"],
                        "Resource": "*",
                    },
                    {
                        "Effect": "Allow",
                        "Principal": {"AWS": f"arn:aws:iam::{ACCOUNT_ID}:root"},
                        "Action": "kms:*",
                        "Resource": "*",
                    },
                ],
            }),
        )
        print(f"  Key 1: {key1['KeyMetadata']['KeyId']} (production-data-key)")
    except Exception as e:
        if "AlreadyExists" not in str(e) and "KMSKeyUnavailable" not in str(e):
            print(f"  Key 1 skipped: {e}")

    # Key 2: backup-key (with ScheduleKeyDeletion permission for ransomware test)
    try:
        key2 = kms.create_key(
            Description="Backup encryption key",
            KeyUsage="ENCRYPT_DECRYPT",
            Origin="AWS_KMS",
            Policy=json.dumps({
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Principal": {"AWS": f"arn:aws:iam::{ACCOUNT_ID}:role/AdminRole-Production"},
                        "Action": "kms:*",
                        "Resource": "*",
                    },
                ],
            }),
        )
        print(f"  Key 2: {key2['KeyMetadata']['KeyId']} (backup-key)")
    except Exception as e:
        if "AlreadyExists" not in str(e) and "KMSKeyUnavailable" not in str(e):
            print(f"  Key 2 skipped: {e}")

    print("[KMS] Created keys")


def provision_secrets():
    """Create Secrets Manager secrets for exfiltration testing."""
    sm = _client("secretsmanager")
    print("[Secrets] Creating secrets...")

    # Secret 1: database credentials (encrypted with default AWS managed key)
    try:
        sm.create_secret(
            Name="prod/database/credentials",
            Description="Production database credentials",
            SecretString=json.dumps({
                "username": "admin",
                "password": "SuperSecret123!",
                "host": "prod-db.cluster-abc123.us-east-1.rds.amazonaws.com",
                "port": 5432,
                "database": "production",
            }),
        )
    except Exception as e:
        if "ResourceExists" not in str(e):
            raise

    # Secret 2: API keys (encrypted with KMS)
    try:
        sm.create_secret(
            Name="prod/api/stripe-key",
            Description="Stripe API key",
            SecretString=json.dumps({
                "secret_key": "sk_live_1234567890abcdef",
                "publishable_key": "pk_live_1234567890abcdef",
            }),
        )
    except Exception as e:
        if "ResourceExists" not in str(e):
            raise

    print("[Secrets] Created 2 secrets")


def provision_codebuild():
    """Create CodeBuild projects for CI/CD compromise testing."""
    cb = _client("codebuild")
    iam = _client("iam")
    print("[CodeBuild] Creating projects...")

    # Project 1: deploy-pipeline (with admin role)
    try:
        cb.create_project(
            name="deploy-pipeline",
            description="Production deployment pipeline",
            source={
                "type": "GITHUB",
                "location": "https://github.com/company/app.git",
                "buildspec": "buildspec.yml",
            },
            artifacts={"type": "NO_ARTIFACTS"},
            environment={
                "type": "LINUX_CONTAINER",
                "image": "aws/codebuild/standard:6.0",
                "computeType": "BUILD_GENERAL1_SMALL",
                "privilegedMode": False,
            },
            serviceRole=f"arn:aws:iam::{ACCOUNT_ID}:role/AdminRole-Production",
            timeoutInMinutes=60,
        )
    except Exception as e:
        if "ResourceAlreadyExists" not in str(e):
            raise

    print("[CodeBuild] Created 1 project")


def provision_cross_account_role():
    """Create roles with various trust policies for cross-account simulation."""
    iam = _client("iam")
    print("[IAM] Creating trust test roles...")

    # Role 1: CrossAccountAuditRole - trusts external account 987654321098
    trust_policy_external = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"AWS": f"arn:aws:iam::987654321098:root"},
            "Action": "sts:AssumeRole",
            "Condition": {
                "StringEquals": {"sts:ExternalId": "sentinel-external-id-12345"}
            },
        }],
    }

    try:
        iam.create_role(
            RoleName="CrossAccountAuditRole",
            AssumeRolePolicyDocument=json.dumps(trust_policy_external),
            Description="Cross-account audit role - trusts account 987654321098",
        )
        iam.put_role_policy(
            RoleName="CrossAccountAuditRole",
            PolicyName="AuditAccess",
            PolicyDocument=json.dumps({
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": ["s3:GetObject", "s3:ListBucket"],
                        "Resource": ["arn:aws:s3:::company-public-assets", "arn:aws:s3:::company-public-assets/*"],
                    },
                    {
                        "Effect": "Allow",
                        "Action": ["iam:ListRoles", "iam:GetRole"],
                        "Resource": "*",
                    },
                ],
            }),
        )
    except Exception as e:
        if "EntityAlreadyExists" not in str(e):
            raise

    # Role 2: DataAnalystRole - trusts same account root (attacker can assume)
    trust_policy_same_account = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"AWS": f"arn:aws:iam::{ACCOUNT_ID}:root"},
            "Action": "sts:AssumeRole",
        }],
    }

    try:
        iam.create_role(
            RoleName="DataAnalystRole",
            AssumeRolePolicyDocument=json.dumps(trust_policy_same_account),
            Description="Data analyst role - trusts same account root",
        )
        iam.put_role_policy(
            RoleName="DataAnalystRole",
            PolicyName="DataAccess",
            PolicyDocument=json.dumps({
                "Version": "2012-10-17",
                "Statement": [{
                    "Effect": "Allow",
                    "Action": ["s3:GetObject", "s3:ListBucket", "glue:GetTable"],
                    "Resource": "*",
                }],
            }),
        )
    except Exception as e:
        if "EntityAlreadyExists" not in str(e):
            raise

    # Role 3: WildcardTrustRole - trusts everyone (Principal: *)
    trust_policy_wildcard = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"AWS": "*"},
            "Action": "sts:AssumeRole",
        }],
    }

    try:
        iam.create_role(
            RoleName="WildcardTrustRole",
            AssumeRolePolicyDocument=json.dumps(trust_policy_wildcard),
            Description="Wildcard trust role - trusts everyone (security risk)",
        )
        iam.put_role_policy(
            RoleName="WildcardTrustRole",
            PolicyName="LimitedAccess",
            PolicyDocument=json.dumps({
                "Version": "2012-10-17",
                "Statement": [{
                    "Effect": "Allow",
                    "Action": ["s3:GetObject"],
                    "Resource": "arn:aws:s3:::company-data-lake-staging/*",
                }],
            }),
        )
    except Exception as e:
        if "EntityAlreadyExists" not in str(e):
            raise

    print("[IAM] Created 3 trust test roles")


def provision_ssm():
    """Create SSM documents and ensure EC2 instances have SSM agent."""
    ssm = _client("ssm")
    print("[SSM] Setting up SSM...")

    # Register the EC2 instances as SSM managed instances
    # In moto, we create managed instance registrations
    ec2 = _client("ec2")
    instances = ec2.describe_instances()
    for res in instances.get("Reservations", []):
        for inst in res.get("Instances", []):
            instance_id = inst["InstanceId"]
            try:
                ssm.create_document(
                    Content="schemaVersion: '1.0'\ndescription: Test document\n",
                    Name=f"ssm-doc-{instance_id}",
                    DocumentType="Command",
                )
            except Exception:
                pass

    print("[SSM] Setup complete")


def verify_additional():
    """Verify all additional resources are accessible."""
    print("\n[VERIFY] Reading back additional resources...")
    lam = _client("lambda")
    sm = _client("secretsmanager")
    kms = _client("kms")
    cb = _client("codebuild")

    functions = lam.list_functions().get("Functions", [])
    print(f"  Lambda functions: {len(functions)}")
    for f in functions:
        print(f"    - {f['FunctionName']} (role: {f.get('Role', 'N/A')})")

    secrets = sm.list_secrets().get("SecretList", [])
    print(f"  Secrets: {len(secrets)}")
    for s in secrets:
        print(f"    - {s['Name']}")

    keys = kms.list_keys().get("Keys", [])
    print(f"  KMS keys: {len(keys)}")
    for k in keys:
        print(f"    - {k['KeyId']}")

    projects = cb.list_projects().get("projects", [])
    print(f"  CodeBuild projects: {len(projects)}")
    for p in projects:
        print(f"    - {p}")

    iam = _client("iam")
    roles = iam.list_roles()["Roles"]
    print(f"  IAM roles (total): {len(roles)}")
    for r in roles:
        print(f"    - {r['RoleName']}")


if __name__ == "__main__":
    print("=" * 60)
    print("Provisioning additional resources for exploit simulation")
    print("=" * 60)
    try:
        provision_lambda()
        provision_kms()
        provision_secrets()
        provision_codebuild()
        provision_cross_account_role()
        provision_ssm()
        verify_additional()
        print("\n✓ Additional provisioning complete.")
    except Exception as e:
        print(f"\n✗ Provisioning failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
