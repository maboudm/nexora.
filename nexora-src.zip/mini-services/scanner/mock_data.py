"""
Mock AWS data for development mode.
This simulates an AWS account with realistic misconfigurations that
a real CNAPP would detect. Each resource is structured to match what
boto3 returns, so the same scanner code can run against real AWS.
"""

from typing import Any

MOCK_IAM_ROLES: list[dict[str, Any]] = [
    {
        "RoleName": "AdminRole-Production",
        "Arn": "arn:aws:iam::123456789012:role/AdminRole-Production",
        "Path": "/",
        "CreateDate": "2023-01-15T00:00:00Z",
        "AssumeRolePolicyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {"AWS": "*"},
                    "Action": "sts:AssumeRole",
                }
            ],
        },
        "AttachedPolicies": [
            {"PolicyName": "AdministratorAccess", "PolicyArn": "arn:aws:iam::aws:policy/AdministratorAccess"}
        ],
        "LastUsed": {"LastUsedDate": "2024-08-01T00:00:00Z", "Region": "us-east-1"},
    },
    {
        "RoleName": "EC2InstanceRole-WebApp",
        "Arn": "arn:aws:iam::123456789012:role/EC2InstanceRole-WebApp",
        "Path": "/",
        "CreateDate": "2023-06-20T00:00:00Z",
        "AssumeRolePolicyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {"Effect": "Allow", "Principal": {"Service": "ec2.amazonaws.com"}, "Action": "sts:AssumeRole"}
            ],
        },
        "AttachedPolicies": [
            {"PolicyName": "AmazonS3FullAccess", "PolicyArn": "arn:aws:iam::aws:policy/AmazonS3FullAccess"},
            {"PolicyName": "AmazonDynamoDBFullAccess", "PolicyArn": "arn:aws:iam::aws:policy/AmazonDynamoDBFullAccess"},
        ],
        "LastUsed": {"LastUsedDate": "2025-06-15T00:00:00Z", "Region": "us-east-1"},
    },
    {
        "RoleName": "LambdaProcessorRole",
        "Arn": "arn:aws:iam::123456789012:role/LambdaProcessorRole",
        "Path": "/",
        "CreateDate": "2023-09-10T00:00:00Z",
        "AssumeRolePolicyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {"Effect": "Allow", "Principal": {"Service": "lambda.amazonaws.com"}, "Action": "sts:AssumeRole"}
            ],
        },
        "AttachedPolicies": [
            {"PolicyName": "AWSLambdaBasicExecutionRole", "PolicyArn": "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"}
        ],
        "LastUsed": None,
    },
    {
        "RoleName": "CrossAccountBackupRole",
        "Arn": "arn:aws:iam::123456789012:role/CrossAccountBackupRole",
        "Path": "/",
        "CreateDate": "2022-03-05T00:00:00Z",
        "AssumeRolePolicyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {"AWS": "arn:aws:iam::987654321098:root"},
                    "Action": "sts:AssumeRole",
                }
            ],
        },
        "AttachedPolicies": [
            {"PolicyName": "AmazonS3ReadOnlyAccess", "PolicyArn": "arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess"}
        ],
        "LastUsed": {"LastUsedDate": "2022-04-01T00:00:00Z", "Region": "us-east-1"},
    },
]

MOCK_S3_BUCKETS: list[dict[str, Any]] = [
    {
        "Name": "company-public-assets",
        "CreationDate": "2023-02-10T00:00:00Z",
        "Region": "us-east-1",
        "ACL": [{"Permission": "READ", "Grantee": {"Type": "Group", "URI": "http://acs.amazonaws.com/groups/global/AllUsers"}}],
        "Policy": {
            "Version": "2012-10-17",
            "Statement": [
                {"Effect": "Allow", "Principal": "*", "Action": "s3:GetObject", "Resource": "arn:aws:s3:::company-public-assets/*"}
            ],
        },
        "Encryption": None,
        "Versioning": "Suspended",
        "PublicAccessBlock": {
            "BlockPublicAcls": False,
            "IgnorePublicAcls": False,
            "BlockPublicPolicy": False,
            "RestrictPublicBuckets": False,
        },
        "Logging": None,
    },
    {
        "Name": "company-logs-archive",
        "CreationDate": "2022-08-15T00:00:00Z",
        "Region": "us-east-1",
        "ACL": [{"Permission": "FULL_CONTROL", "Grantee": {"Type": "CanonicalUser", "ID": "owner"}}],
        "Policy": None,
        "Encryption": {"ServerSideEncryptionConfiguration": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]},
        "Versioning": "Enabled",
        "PublicAccessBlock": {
            "BlockPublicAcls": True,
            "IgnorePublicAcls": True,
            "BlockPublicPolicy": True,
            "RestrictPublicBuckets": True,
        },
        "Logging": {"TargetBucket": "company-logs-archive", "TargetPrefix": "log/"},
    },
    {
        "Name": "company-data-lake-staging",
        "CreationDate": "2024-01-20T00:00:00Z",
        "Region": "us-west-2",
        "ACL": [{"Permission": "READ", "Grantee": {"Type": "Group", "URI": "http://acs.amazonaws.com/groups/global/AllUsers"}}],
        "Policy": None,
        "Encryption": None,
        "Versioning": "Suspended",
        "PublicAccessBlock": {
            "BlockPublicAcls": False,
            "IgnorePublicAcls": False,
            "BlockPublicPolicy": False,
            "RestrictPublicBuckets": False,
        },
        "Logging": None,
    },
    {
        "Name": "company-backup-prod",
        "CreationDate": "2023-11-30T00:00:00Z",
        "Region": "us-east-1",
        "ACL": [{"Permission": "FULL_CONTROL", "Grantee": {"Type": "CanonicalUser", "ID": "owner"}}],
        "Policy": None,
        "Encryption": None,
        "Versioning": "Enabled",
        "PublicAccessBlock": {
            "BlockPublicAcls": True,
            "IgnorePublicAcls": True,
            "BlockPublicPolicy": True,
            "RestrictPublicBuckets": True,
        },
        "Logging": None,
    },
]

MOCK_SECURITY_GROUPS: list[dict[str, Any]] = [
    {
        "GroupId": "sg-0abc123def456",
        "GroupName": "web-tier-sg",
        "Description": "Web tier security group",
        "VpcId": "vpc-0abc123",
        "Region": "us-east-1",
        "IpPermissions": [
            {
                "IpProtocol": "tcp",
                "FromPort": 22,
                "ToPort": 22,
                "IpRanges": [{"CidrIp": "0.0.0.0/0", "Description": "SSH from anywhere"}],
            },
            {
                "IpProtocol": "tcp",
                "FromPort": 443,
                "ToPort": 443,
                "IpRanges": [{"CidrIp": "0.0.0.0/0"}],
            },
        ],
        "IpPermissionsEgress": [
            {"IpProtocol": "-1", "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}
        ],
    },
    {
        "GroupId": "sg-0def789ghi012",
        "GroupName": "db-tier-sg",
        "Description": "Database tier security group",
        "VpcId": "vpc-0abc123",
        "Region": "us-east-1",
        "IpPermissions": [
            {
                "IpProtocol": "tcp",
                "FromPort": 3306,
                "ToPort": 3306,
                "IpRanges": [{"CidrIp": "0.0.0.0/0", "Description": "MySQL from anywhere - TESTING ONLY"}],
            },
            {
                "IpProtocol": "tcp",
                "FromPort": 5432,
                "ToPort": 5432,
                "UserIdGroupPairs": [{"GroupId": "sg-0abc123def456"}],
            },
        ],
        "IpPermissionsEgress": [
            {"IpProtocol": "-1", "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}
        ],
    },
    {
        "GroupId": "sg-0jkl345mno678",
        "GroupName": "bastion-sg",
        "Description": "Bastion host security group",
        "VpcId": "vpc-0abc123",
        "Region": "us-east-1",
        "IpPermissions": [
            {
                "IpProtocol": "tcp",
                "FromPort": 22,
                "ToPort": 22,
                "IpRanges": [{"CidrIp": "10.0.0.0/8"}],
            }
        ],
        "IpPermissionsEgress": [
            {"IpProtocol": "-1", "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}
        ],
    },
    {
        "GroupId": "sg-0pqr901stu234",
        "GroupName": "rds-public-sg",
        "Description": "RDS public security group",
        "VpcId": "vpc-0abc123",
        "Region": "us-east-1",
        "IpPermissions": [
            {
                "IpProtocol": "tcp",
                "FromPort": 1433,
                "ToPort": 1433,
                "IpRanges": [{"CidrIp": "0.0.0.0/0"}],
            }
        ],
        "IpPermissionsEgress": [],
    },
]

MOCK_EKS_CLUSTERS: list[dict[str, Any]] = [
    {
        "ClusterName": "prod-cluster",
        "Arn": "arn:aws:eks:us-east-1:123456789012:cluster/prod-cluster",
        "Region": "us-east-1",
        "Status": "ACTIVE",
        "Version": "1.28",
        "Endpoint": "https://123456789012.gr7.us-east-1.eks.amazonaws.com",
        "Logging": {
            "clusterLogging": [
                {"types": ["api"], "enabled": False},
                {"types": ["audit"], "enabled": False},
                {"types": ["authenticator"], "enabled": False},
            ]
        },
        "EncryptionConfig": [],
        "PublicAccess": True,
        "PublicAccessCidrs": ["0.0.0.0/0"],
    },
    {
        "ClusterName": "staging-cluster",
        "Arn": "arn:aws:eks:us-west-2:123456789012:cluster/staging-cluster",
        "Region": "us-west-2",
        "Status": "ACTIVE",
        "Version": "1.28",
        "Endpoint": "https://987654321098.gr7.us-west-2.eks.amazonaws.com",
        "Logging": {
            "clusterLogging": [
                {"types": ["api", "audit", "authenticator"], "enabled": True}
            ]
        },
        "EncryptionConfig": [{"resources": ["secrets"], "provider": {"keyArn": "arn:aws:kms:us-west-2:123456789012:key/abc123"}}],
        "PublicAccess": True,
        "PublicAccessCidrs": ["10.0.0.0/8"],
    },
]

MOCK_EC2_INSTANCES: list[dict[str, Any]] = [
    {
        "InstanceId": "i-0abc123def456789",
        "InstanceType": "t3.large",
        "State": "running",
        "PublicIpAddress": "54.210.1.20",
        "PrivateIpAddress": "10.0.1.10",
        "Region": "us-east-1",
        "VpcId": "vpc-0abc123",
        "SubnetId": "subnet-0abc123",
        "SecurityGroups": [{"GroupId": "sg-0abc123def456", "GroupName": "web-tier-sg"}],
        "IamInstanceProfile": {"Arn": "arn:aws:iam::123456789012:instance-profile/EC2InstanceRole-WebApp"},
        "ImageId": "ami-0abc123",
    },
    {
        "InstanceId": "i-0def789ghi012345",
        "InstanceType": "m5.xlarge",
        "State": "running",
        "PublicIpAddress": None,
        "PrivateIpAddress": "10.0.2.20",
        "Region": "us-east-1",
        "VpcId": "vpc-0abc123",
        "SubnetId": "subnet-0def456",
        "SecurityGroups": [{"GroupId": "sg-0jkl345mno678", "GroupName": "bastion-sg"}],
        "IamInstanceProfile": None,
        "ImageId": "ami-0def456",
    },
]


def get_all_mock_resources() -> dict[str, list[dict[str, Any]]]:
    return {
        "iam_roles": MOCK_IAM_ROLES,
        "s3_buckets": MOCK_S3_BUCKETS,
        "security_groups": MOCK_SECURITY_GROUPS,
        "eks_clusters": MOCK_EKS_CLUSTERS,
        "ec2_instances": MOCK_EC2_INSTANCES,
    }
