# Nexora — Cloud-Native Application Protection Platform

**Created by Maboud Bakhshi Nezhad**

An enterprise-grade CNAPP that competes with Wiz, Prisma Cloud, Orca Security, and Lacework — built with zero budget using open-source foundations.

## What Sentinel Does

Sentinel scans your cloud accounts (AWS, Azure, GCP) for security misconfigurations, vulnerabilities, and compliance violations — then tells you **which finding to fix first** based on economics, attack paths, and threat intelligence.

### Key Differentiators (vs Prowler, Wiz, etc.)

| Feature | Prowler | Wiz | Sentinel |
|---------|---------|-----|----------|
| Cloud security rules | 915 | 300+ | **2,064** (Prowler + Checkov) |
| IaC scanning | ❌ | ✅ ($30K/yr) | ✅ **Free** (1,149 Checkov policies) |
| Continuous drift detection | ❌ | ✅ | ✅ |
| Risk-based prioritization | ❌ | ✅ (Wiz Risk Score) | ✅ (Bayesian + EPSS) |
| Attack path visualization | ❌ | ✅ (their $32B differentiator) | ✅ (MITRE ATT&CK mapped) |
| Compliance evidence vault | ❌ | ✅ | ✅ (hash-chained, tamper-evident) |
| Workflow integration (Jira/Slack) | ❌ | ✅ | ✅ (8 providers, bidirectional) |
| Multi-account auto-discovery | ❌ | ✅ | ✅ (AWS Organizations API) |
| Scheduled scans + email alerts | ❌ | ✅ | ✅ (Gmail SMTP, free) |
| Multi-tenant SaaS | ❌ | ✅ | ✅ |
| Price | Free | $30K-100K/yr | **Free (open-source)** |

## Quick Start (5 minutes)

### Option 1: Docker (recommended for production)

```bash
# Clone
git clone https://github.com/yourname/nexora.git
cd nexora

# Build + run
docker-compose up -d

# Open browser
open http://localhost:3000
# Login: admin@nexora.io / admin123
```

### Option 2: Local development

```bash
# Backend (Python)
cd backend
pip install -r requirements.txt
python -m gateway.app
# Runs on http://localhost:8000

# Frontend (Next.js) — in another terminal
npm install
npm run dev
# Runs on http://localhost:3000
```

### Connect your AWS account

1. Login at http://localhost:3000
2. Go to **Settings → Cloud Accounts → Add**
3. Enter your AWS account ID + IAM role ARN
4. Click **Scan Now**

Or use the API:
```bash
curl -X POST http://localhost:8000/v1/cloud-accounts \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "provider": "aws",
    "name": "Production AWS",
    "external_id": "123456789012",
    "credential_type": "assume_role",
    "role_arn": "arn:aws:iam::123456789012:role/SentinelScanner",
    "regions": ["us-east-1", "us-west-2"]
  }'
```

### Set up scheduled scans + email alerts

1. Get a Gmail App Password: https://myaccount.google.com/apppasswords
2. Set environment variables:
```bash
export SMTP_USER=your.email@gmail.com
export SMTP_PASSWORD=your-16-char-app-password
```
3. Create a schedule:
```bash
curl -X POST http://localhost:8000/v1/schedules \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "cloud_account_id": "...",
    "name": "Daily Scan",
    "frequency": "daily",
    "hour": 2,
    "alert_email": "you@company.com"
  }'
```

You'll now get an email every day at 2am if critical findings are detected.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Next.js Frontend                         │
│  Dashboard, Findings, Attack Graph, Premium Features, etc.  │
└────────────────────────┬────────────────────────────────────┘
                         │ HTTP (JWT auth)
┌────────────────────────▼────────────────────────────────────┐
│              FastAPI Gateway (163 routes)                     │
│  Auth (JWT), RBAC, Rate Limiting, Audit, WebSocket           │
└────────────────────────┬────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────────────────────┐
        │                │                                 │
┌───────▼──────┐  ┌──────▼──────┐  ┌──────────────────────▼──┐
│  Scanners    │  │   Rules     │  │   Premium Engines       │
│              │  │             │  │                          │
│ • Prowler    │  │ • 58 native │  │ • Drift Detection       │
│   (915)      │  │   CIS+ext   │  │ • Finding Prioritization│
│ • Checkov    │  │             │  │ • Kill Chain (ATT&CK)   │
│   (1,149)    │  │             │  │ • Evidence Vault        │
│ • boto3 AWS  │  │             │  │ • Workflow Integration  │
│ • Azure SDK  │  │             │  │ • Multi-Account         │
│ • GCP SDK    │  │             │  │ • Scheduler + Email     │
└──────────────┘  └─────────────┘  └──────────────────────────┘
        │                │                                 │
        └────────────────┼─────────────────────────────────┘
                         │
              ┌──────────▼──────────┐
              │  SQLite (WAL mode)  │
              │  17 tables + 8 premium│
              └─────────────────────┘
```

## Engines (28 backend modules)

| Engine | Purpose | Lines |
|--------|---------|-------|
| `scanner_engine` | Real AWS/Azure/GCP boto3 scanning | 1,103 |
| `rule_engine` | CIS AWS Benchmark v3.0 + extended rules | 800+ |
| `prowler_integration` | 915 cloud security checks (absorbed) | 340 |
| `checkov_integration` | 1,149 IaC policies (absorbed) | 310 |
| `drift_detection` | Continuous posture monitoring | 516 |
| `finding_prioritization` | Risk-based ranking + knapsack optimizer | 487 |
| `kill_chain` | Attack path + MITRE ATT&CK mapping | 535 |
| `evidence_vault` | Hash-chained compliance evidence | 490 |
| `workflow_integration` | Jira/Slack/ServiceNow bidirectional sync | 741 |
| `multi_account` | AWS Organizations auto-discovery + rollup | 666 |
| `scheduler` | Scheduled scans + Gmail SMTP alerts | 470 |
| `bayesian_engine` | P(compromise) via Bayesian Belief Networks | — |
| `economics_engine` | ROI of remediation vs exploitation | — |
| `ciem` | Cloud Infrastructure Entitlement Management | 800 |
| `vulnerability` | CVSS v3.1 + EPSS + NVD CVE database | 902 |
| `threat_intel` | IOC matching + 7 APT profiles | 749 |
| `asset_inventory` | Universal Asset Model + drift | 688 |
| `realtime_detection` | Sigma-compatible detection rules | 982 |
| `policy_engine` | Rego-like DSL policy-as-code | 787 |
| `blast_radius` | NetworkX graph + Bayesian P(compromise) | 592 |
| `posture_score` | Multi-factor KPI scoring | 591 |
| `reporting` | PDF (ReportLab) + Excel (openpyxl) | 865 |
| `dspm` | Data Security Posture Management (PII/PHI/secrets) | 914 |
| `container_security` | Dockerfile AST scanner + CIS Docker | 879 |
| `kspm` | Kubernetes CIS Benchmark + RBAC graph | 1,062 |
| `iac_security` | Terraform HCL + CloudFormation scanner | 1,098 |
| `cwpp_agent` | Runtime threat detection (MITRE ATT&CK) | 872 |
| `remediator` | Auto-remediation with 3-tier safety | 1,073 |
| `audit` | Immutable hash-chained audit log | — |
| `compliance_engine` | 7 frameworks (CIS/PCI/ISO/SOC2/HIPAA/NIST/GDPR) | — |
| `ai_engine` | RAG-based AI copilot | — |
| `notification_engine` | 8-channel alerting (Email/Slack/Jira/PagerDuty/...) | — |

## API Documentation

When the gateway is running, visit:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### Key endpoints

```
# Auth
POST   /v1/auth/login                    # Get JWT token

# Scans
POST   /v1/scans                         # Trigger scan
GET    /v1/scans                         # List scans
GET    /v1/scans/{id}                    # Get scan detail

# Premium Features
POST   /v1/drift/detect                  # Detect config drift
POST   /v1/prioritization/prioritize     # Rank findings by risk
POST   /v1/kill-chain/find-paths         # Find attack paths
POST   /v1/evidence/ingest               # Add to hash-chained vault
GET    /v1/evidence/verify               # Verify chain integrity
POST   /v1/workflow/tickets              # Auto-create Jira/Slack tickets
POST   /v1/multi-account/discover        # Auto-discover AWS accounts

# Prowler (915 checks)
GET    /v1/prowler/stats                 # Catalog statistics
GET    /v1/prowler/checks                # Browse with filters
POST   /v1/prowler/scan                  # Real Prowler scan

# Checkov (1,149 policies)
GET    /v1/checkov/stats                 # Policy catalog
POST   /v1/checkov/scan-code             # Live IaC scanner

# Schedules + Alerts
POST   /v1/schedules                     # Create scheduled scan
GET    /v1/schedules                     # List schedules
POST   /v1/schedules/{id}/run-now        # Trigger immediately
GET    /v1/schedules/smtp/status         # Check SMTP config
POST   /v1/schedules/test-email          # Send test email
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `GATEWAY_PORT` | `8000` | Backend port |
| `SENTINEL_DB_PATH` | `/app/db/sentinel.db` | SQLite database path |
| `JWT_SECRET` | (random) | JWT signing secret |
| `AUDIT_MASTER_KEY` | (random) | Audit log signing key |
| `PASSWORD_SALT` | `sentinel-salt` | Password hashing salt |
| `SMTP_HOST` | `smtp.gmail.com` | SMTP server |
| `SMTP_PORT` | `587` | SMTP port |
| `SMTP_USER` | (none) | Your Gmail address |
| `SMTP_PASSWORD` | (none) | Gmail App Password (16 chars) |
| `AWS_ACCESS_KEY_ID` | (none) | For real AWS scanning |
| `AWS_SECRET_ACCESS_KEY` | (none) | For real AWS scanning |
| `SENTINEL_DASHBOARD_URL` | (none) | Public URL for email links |

## Deployment

### Docker Compose (recommended)

```bash
docker-compose up -d
```

See `docker-compose.yml` for configuration.

### Manual VPS deployment

```bash
# 1. Install dependencies
apt update && apt install -y python3.11 python3-pip nodejs npm

# 2. Clone
git clone https://github.com/yourname/nexora.git
cd nexora

# 3. Backend
pip install -r backend/requirements.txt
pip install prowler checkov  # premium integrations

# 4. Frontend
npm install && npm run build

# 5. Run with systemd (see deploy/sentinel.service)
cp deploy/sentinel.service /etc/systemd/system/
systemctl enable --now sentinel
```

### Environment setup for production

```bash
# Generate strong secrets
export JWT_SECRET=$(openssl rand -hex 32)
export AUDIT_MASTER_KEY=$(openssl rand -hex 32)
export PASSWORD_SALT=$(openssl rand -hex 16)

# Set SMTP for email alerts
export SMTP_USER=you@gmail.com
export SMTP_PASSWORD=your-app-password

# Optional: real AWS scanning
export AWS_ACCESS_KEY_ID=...
export AWS_SECRET_ACCESS_KEY=...
```

## Security

- **JWT authentication** (HS256, 24h expiry)
- **Multi-tenant isolation** (tenant_id always from JWT, never from client)
- **RBAC** (4 roles: owner, admin, analyst, viewer)
- **Rate limiting** (300 req/min per tenant)
- **Audit logging** on every mutation (hash-chained, tamper-evident)
- **SQLite WAL mode** for concurrent reads
- **HMAC-SHA256 webhook signatures** for workflow integrations

## Limitations (honest)

- **Not SOC2/ISO certified** — if you need enterprise compliance, use Wiz
- **No SSO/SAML** — only email+password auth
- **No real-time CloudTrail EventsBridge** — drift detected on scan, not in real-time
- **No agentless snapshot scanning** — Wiz's differentiator (we use API scanning instead)
- **No CWPP agent deployment** — engine exists but no runtime agent for production
- **No 24/7 support** — community only
- **Azure/GCP scanners** — code exists but less battle-tested than AWS

## License

Apache License 2.0 — same as Prowler and Checkov.

## Credits

Built on top of these excellent open-source projects:
- [Prowler](https://github.com/prowler-cloud/prowler) — 915 cloud security checks
- [Checkov](https://github.com/bridgecrewio/checkov) — 1,149 IaC policies
- [FastAPI](https://fastapi.tiangolo.com/) — Python web framework
- [Next.js](https://nextjs.org/) — React framework
- [NetworkX](https://networkx.org/) — Graph algorithms for attack paths
- [ReportLab](https://www.reportlab.com/) — PDF generation

## Contributing

PRs welcome. Please run `python scripts/validate_all.sh` before submitting.
