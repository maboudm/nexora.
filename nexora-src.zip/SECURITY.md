# Security Policy

## 🔒 Supported Versions

| Version | Supported          |
|---------|--------------------|
| 1.0.x   | ✅ Active support  |
| < 1.0   | ❌ No support      |

## 🐛 Reporting a Vulnerability

**DO NOT open a public GitHub issue for security vulnerabilities.**

Instead, please report vulnerabilities responsibly:

### How to Report

1. **Email**: `security@yourdomain.com`
2. **Subject**: `[SECURITY] Brief description`
3. **Include**:
   - Description of the vulnerability
   - Affected components (file paths, endpoints)
   - Steps to reproduce
   - Proof of concept (if available)
   - Potential impact
   - Suggested fix (optional)

### Response Timeline

| Action | Time |
|--------|------|
| Acknowledgment of report | 24 hours |
| Initial assessment | 72 hours |
| Fix or mitigation | 7 days (critical) / 30 days (high) |
| Public disclosure | After fix is released |

### What to Expect

- We will acknowledge your report within 24 hours
- We will investigate and validate the vulnerability
- We will work on a fix and coordinate disclosure with you
- We will credit you in the security advisory (unless you prefer to remain anonymous)

## 🛡️ Security Measures

This project implements the following security measures:

### Authentication & Authorization
- **JWT authentication** (HS256, 24h expiry)
- **Multi-tenant isolation** (tenant_id always from JWT, never from client)
- **RBAC** (4 roles: owner, admin, analyst, viewer)
- **Rate limiting** (300 req/min per tenant)
- **bcrypt password hashing** (with salt)

### Data Protection
- **SQLite WAL mode** (concurrent reads, atomic writes)
- **Hash-chained audit log** (tamper-evident, SHA256 + HMAC-SHA256)
- **Evidence vault** (cryptographic chain, per-tenant signing keys)
- **Credential encryption** at rest (MASTER_ENCRYPTION_KEY)

### Webhook Security
- **Stripe webhook signature verification** (HMAC-SHA256)
- **Replay attack prevention** (5-minute timestamp tolerance)
- **Constant-time comparison** (hmac.compare_digest)

### Network Security
- **HTTPS enforced** (via Caddy + Let's Encrypt)
- **CORS configured** (configurable origins)
- **No sensitive data in URLs** (POST body for all mutations)

### Dependencies
- **Pinned versions** in requirements.txt
- **Regular updates** (monthly dependency audit)
- **CVE monitoring** via GitHub Dependabot

## 🔍 Security Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    User Browser                          │
│  JWT token stored in localStorage (24h expiry)          │
└──────────────────────────┬──────────────────────────────┘
                           │ HTTPS (TLS 1.3)
┌──────────────────────────▼──────────────────────────────┐
│                   Caddy Reverse Proxy                    │
│  • Auto-HTTPS (Let's Encrypt)                           │
│  • Rate limiting                                        │
│  • Request size limits                                  │
└──────────────────────────┬──────────────────────────────┘
                           │
       ┌───────────────────┼───────────────────┐
       │                   │                   │
┌──────▼──────┐   ┌────────▼────────┐   ┌──────▼──────┐
│  Next.js    │   │  FastAPI Gateway │   │  SQLite     │
│  (port 3000)│   │  (port 8000)     │   │  (WAL mode) │
│             │   │                  │   │             │
│ • CSRF token│   │ • JWT verify     │   │ • Per-tenant│
│ • XSS proof │   │ • RBAC check     │   │   isolation │
│ • No secrets│   │ • Rate limit     │   │ • Hash chain│
└─────────────┘   │ • Audit log      │   └─────────────┘
                  └──────────────────┘
```

## 🚨 Incident Response

In case of a security incident:

1. **Immediate**: Disable affected endpoints
2. **24h**: Notify affected users via email
3. **72h**: Public disclosure with CVE
4. **7 days**: Fix released
5. **30 days**: Post-mortem published

## 📧 Contact

- **Security issues**: security@yourdomain.com
- **General questions**: GitHub Issues
- **Bug reports**: GitHub Issues

## 🏆 Hall of Fame

We gratefully acknowledge security researchers who help keep Nexora safe:

<!-- Add contributors here as vulnerabilities are reported and fixed -->

Thank you for helping protect our users! 🛡️
